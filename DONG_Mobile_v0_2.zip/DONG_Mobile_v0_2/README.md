# DONG Mobile v0.2

This is a separate native Android/Kivy branch made from **DONG desktop v0.45**. The desktop project is untouched.

## What v0.2 is

DONG Mobile v0.2 is the first major desktop-parity pass after the v0.1 Android proof of concept. It keeps the same game/data modules as desktop v0.45 and expands the touch UI so the systems that already existed under the hood are actually playable on a phone.

It is **not** a browser game and does not use a web wrapper. Saves use SQLite inside Android's private app storage (`user_data_dir/game.db`).

## Major v0.2 parity additions

### Property and home

- Six customizable property structure slots
- Build/replace structures using Cash, Wood and Ore
- Enter individual structures
- Home interior storage
- Home room slots and room construction
- Kitchen cooking and homebrew
- Living Room recovery
- Bedroom sleep bonus
- Bathroom shower recovery
- Household-capacity checks when changing homes

### Farming and animals

- Garden Bed planting, watering and harvesting
- Vegetable and abstract contraband crops
- Chicken Coop production
- Barn milk production
- Stable horse management
- Buy and name Chickens, Cows and Horses
- Pet and feed animals
- Saddles and horse travel
- Well daily draw and random finds

### Vehicles

- Carl's Cars dealership
- Garage capacity
- Buy and store vehicles
- Vehicle condition/speed display
- Owned cars automatically become Map travel methods

### Combat

- Full Fighting Pits loop
- Random opponents
- Punch / Heavy Hit / Run
- Weapon and armor bonuses shared with desktop combat logic
- Wins, losses and cash rewards

### Crime and jail

- Pickpocket, Theft and Murder actions from NPC interactions
- Witness checks and fines/sentences
- Persistent criminal record
- Body-evidence system
- Carry / vehicle trunk / Hidden Cache / Riverside Park evidence handling
- Timed police discovery while carrying unresolved evidence
- Police Station record view
- Jail sentence screen
- Jail reading, showering, exercise and prison work
- Good-behavior sentence reduction

### Relationships and family

- Talk and daily relationship actions
- Contacts
- Flirting
- Dating
- Adult non-explicit intimacy progression
- Marriage
- Children and household capacity
- Arguments and negative relationship score
- Phone contact/family summary

### Other parity improvements

- Adjustable Bank deposit/withdraw amounts
- Education cash vs student-loan enrollment
- Desktop-matching 12 Energy / 2-hour classes
- Adjustable Casino wagers
- Drug-dealing criminal record and abstract police-risk consequence
- Drunken Donkey meal purchase
- Riverside Park walking and evidence interaction
- Farm, garage, market, casino and education clothing racks
- Existing Dungeon, jobs, Forge, inventory, equipment, shops, travel and background timers retained

## Known differences from desktop v0.45

The underlying game rules are shared, but the UI is intentionally mobile-native rather than a pixel-for-pixel copy of PySide. Desktop modal dialogs are represented as Kivy popups/cards, and the Workshop remains a future crafting location just as its desktop gameplay is still minimal.

This source was syntax-checked and its save/game logic was exercised in a non-Kivy test environment. The current build environment used to prepare the source does not have Kivy installed, so graphical click-through testing must happen in the Android APK build/device test.

## Build an Android APK

The repository workflow can build the APK on GitHub Actions. For a local Linux/WSL build:

```bash
python3 -m pip install --user buildozer cython
buildozer android debug
```

The resulting APK will be under `bin/`.

## Save compatibility

v0.2 keeps the same package name (`com.donggame.dongmobile`) and GameState/database model as v0.1, so an existing v0.1 save is intended to load in v0.2. Android may require uninstalling the old debug APK if separate CI builds are signed with different debug keys. Uninstalling can remove private app save data, so v0.1 should still be treated as a test build.

## Source layout

```text
DONG_Mobile_v0_2/
  main.py
  buildozer.spec
  database/
  game/
  .github/workflows/
```
