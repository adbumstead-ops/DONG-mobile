# DONG Mobile v0.1

This is a separate Android/mobile branch made from **DONG desktop v0.45**. The desktop project is untouched.

## What this is

- Native Python/Kivy mobile UI. It is **not** a web app and does not use a browser wrapper.
- Portrait-first touch layout with large controls and scrollable cards.
- Uses the same `game/` rules/data modules as desktop wherever practical.
- Uses SQLite in Android's private app storage (`user_data_dir/game.db`).
- Includes a `buildozer.spec` for generating a debug APK.

## Mobile v0.1 gameplay coverage

Already mobile-enabled:

- New Game / Continue
- `Test` profile shortcut from desktop ($100,000,000 / 1,000 Wood / 1,000 Ore)
- Character/status sheet
- Inventory and equipment, including Vest and Weapon slots
- Consumables
- Home overview, sleep, and home upgrades
- Casual jobs and education-gated careers
- Persistent job timers
- Forge gathering and persistent Forge timers
- Map travel with real-time countdowns
- Grocery Store
- Main Street Threads
- Gus' Gunporium
- Outdoors Specials
- themed clothing racks
- Bank basics
- Gym training
- Education Center / qualifications / student loans
- The Drunken Donkey basic shop/dealing actions
- Farmers Market homebrew sales
- Riverside Park basic actions
- Lucky Horseshoe Casino
- 100-floor Dungeon, checkpoints, fights, traps, puzzles, loot and Gift Shop
- NPC presence/talking and relationship scores
- Phone contacts/calling
- SQLite autosave on pause/exit

Still using simplified mobile interactions in v0.1:

- Farm animal management
- Carl's full vehicle dealership/garage management
- Fighting Pits combat
- full Crime/Jail interaction screens
- full relationship romance/marriage interaction dialog
- detailed Home room/structure management

Those systems remain in the copied `game/` modules and are the next UI-port targets. This is intentionally a testable mobile branch rather than a rewrite of the desktop project.

## Test on a computer first

### Windows

Double-click:

`run_desktop_preview.bat`

### Linux

Run:

```bash
./run_desktop_preview.sh
```

## Build an Android APK

Buildozer builds Android packages on Linux. On Ubuntu/WSL/Linux, install the normal Android build prerequisites, then from this folder run:

```bash
./build_android.sh
```

or manually:

```bash
python3 -m pip install --user buildozer cython
buildozer android debug
```

The first Android build downloads the Android SDK/NDK and takes considerably longer than later builds. The generated debug APK will be placed in `bin/`.

Copy that APK to the Android phone and install it. Android may ask you to allow installation from the app you used to open the APK.

## Save location on Android

The mobile build does **not** write into its installed package. It stores the SQLite save in the app's private writable data directory as:

`game.db`

Uninstalling the app may remove this private app data, so treat mobile v0.1 saves as test saves unless you have backed them up.

## Project structure

```text
DONG_Mobile_v0_1/
├── main.py                 # Kivy Android/mobile UI
├── buildozer.spec          # Android packaging configuration
├── build_android.sh
├── requirements.txt
├── README.md
├── database/
│   ├── db.py               # mobile-safe writable SQLite path
│   └── migrations.py
└── game/                   # copied v0.45 game logic/data
```
