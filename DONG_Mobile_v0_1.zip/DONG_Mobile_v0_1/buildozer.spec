[app]
title = DONG Mobile
package.name = dongmobile
package.domain = com.donggame
source.dir = .
source.include_exts = py,txt,md,png,jpg,jpeg,kv,atlas
source.exclude_dirs = .git,.buildozer,bin,__pycache__
version = 0.1
requirements = python3,kivy==2.3.1
orientation = portrait
fullscreen = 0

# Android package settings
android.api = 35
android.minapi = 26
android.archs = arm64-v8a
android.accept_sdk_license = True
android.logcat_filters = *:S python:D
android.allow_backup = True

[buildozer]
log_level = 2
warn_on_root = 1
