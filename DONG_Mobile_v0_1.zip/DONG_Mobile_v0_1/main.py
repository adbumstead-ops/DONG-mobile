from __future__ import annotations

import random
import time
from pathlib import Path

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.graphics import Color, RoundedRectangle
from kivy.metrics import dp, sp
from kivy.properties import ListProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.progressbar import ProgressBar
from kivy.uix.screenmanager import Screen, ScreenManager
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget

from database.db import Database
from game.dungeon import (
    DUNGEON_ARMOR,
    DUNGEON_WEAPONS,
    GIFT_SHOP_ITEMS,
    clear_floor as dungeon_clear_floor,
    dungeon_defense,
    end_run as end_dungeon_run,
    enemy_damage as dungeon_enemy_damage,
    ensure_dungeon_state,
    make_encounter as make_dungeon_encounter,
    player_damage as dungeon_player_damage,
    start_run as start_dungeon_run,
    weapon_bonus as dungeon_weapon_bonus,
)
from game.education import COURSES, course_by_name, has_qualification
from game.gunporium import GUN_ARMOR, GUN_WEAPONS, GUNPORIUM_ITEMS
from game.home import allows_live_in_partner, child_capacity, home_storage_capacity
from game.items import (
    CLOTHING_SLOT_NAMES,
    FASHION_STORE_SECTIONS,
    LOCATION_CLOTHING_SHOPS,
    OUTDOORS_SPECIALS_ITEMS,
    clothing_slot,
)
from game.models import GameState
from game.npcs import npc_by_name, npcs_for_location
from game.property import HOME_UPGRADES, can_afford_build
from game.relationships import CONTACT_SCORE, add_contact, apply_score_action
from game.relationships import score as relationship_score, status as relationship_status
from game.services import (
    LOCATION_DISTANCE_KM,
    advance_minutes,
    available_travel_methods,
    create_new_state,
    equip_clothing,
    gain_skill,
    sleep_until_morning,
    travel_game_minutes,
    travel_seconds,
    unequip_clothing,
)
from game.vice import (
    BEER_KIT_ITEM,
    BEER_KIT_PRICE,
    DRUG_ITEM,
    DRUG_SALE_PRICE,
    DRUG_SEED_ITEM,
    DRUG_SEED_PRICE,
    FARMERS_MARKET_BEER_PRICE,
    blackjack as casino_blackjack,
    drink_beer,
    roulette as casino_roulette,
    sell_drug,
    slots as casino_slots,
    use_drugs,
)

# Some imports above intentionally share the exact game modules used by desktop.
# The mobile branch replaces only the PySide UI and desktop save-path assumptions.

Window.clearcolor = (0.025, 0.028, 0.033, 1)

BG = (0.025, 0.028, 0.033, 1)
PANEL = (0.055, 0.06, 0.07, 1)
CARD = (0.075, 0.08, 0.09, 1)
CARD_ALT = (0.095, 0.10, 0.11, 1)
ACCENT = (0.22, 0.23, 0.25, 1)
ACCENT_HOVER = (0.30, 0.31, 0.33, 1)
TEXT = (0.92, 0.93, 0.95, 1)
MUTED = (0.62, 0.64, 0.68, 1)
DANGER = (0.44, 0.16, 0.16, 1)
SUCCESS = (0.18, 0.34, 0.22, 1)


class Surface(BoxLayout):
    bg_color = ListProperty(CARD)

    def __init__(self, **kwargs):
        radius = kwargs.pop("radius", dp(12))
        super().__init__(**kwargs)
        with self.canvas.before:
            self._color = Color(*self.bg_color)
            self._rect = RoundedRectangle(pos=self.pos, size=self.size, radius=[radius])
        self.bind(pos=self._sync_canvas, size=self._sync_canvas, bg_color=self._sync_color)

    def _sync_canvas(self, *_):
        self._rect.pos = self.pos
        self._rect.size = self.size

    def _sync_color(self, *_):
        self._color.rgba = self.bg_color


class DLabel(Label):
    def __init__(self, text="", muted=False, title=False, small=False, **kwargs):
        kwargs.setdefault("color", MUTED if muted else TEXT)
        kwargs.setdefault("font_size", sp(12 if small else 18 if title else 14))
        kwargs.setdefault("halign", "left")
        kwargs.setdefault("valign", "middle")
        kwargs.setdefault("size_hint_y", None)
        super().__init__(text=text, **kwargs)
        self.bind(width=self._set_text_width, texture_size=self._fit_height)

    def _set_text_width(self, *_):
        self.text_size = (max(0, self.width), None)

    def _fit_height(self, *_):
        self.height = max(dp(24), self.texture_size[1] + dp(8))


class DButton(Button):
    def __init__(self, text="", danger=False, secondary=False, **kwargs):
        kwargs.setdefault("size_hint_y", None)
        kwargs.setdefault("height", dp(48))
        kwargs.setdefault("font_size", sp(13))
        kwargs.setdefault("color", TEXT)
        kwargs.setdefault("background_normal", "")
        kwargs.setdefault("background_down", "")
        kwargs.setdefault("background_color", DANGER if danger else CARD_ALT if secondary else ACCENT)
        super().__init__(text=text, **kwargs)


class StartScreen(Screen):
    def __init__(self, app_ref, **kwargs):
        super().__init__(**kwargs)
        self.app_ref = app_ref
        root = BoxLayout(orientation="vertical", padding=dp(24), spacing=dp(16))
        root.add_widget(Widget())
        title = Label(text="DONG", color=TEXT, font_size=sp(50), bold=True, size_hint_y=None, height=dp(84))
        root.add_widget(title)
        subtitle = DLabel("MOBILE TEST BUILD", muted=True, small=True, halign="center")
        root.add_widget(subtitle)
        root.add_widget(Widget(size_hint_y=None, height=dp(20)))
        new_btn = DButton("NEW GAME")
        new_btn.bind(on_release=lambda *_: self.app_ref.show_create())
        root.add_widget(new_btn)
        self.continue_btn = DButton("CONTINUE", secondary=True)
        self.continue_btn.bind(on_release=lambda *_: self.app_ref.continue_game())
        root.add_widget(self.continue_btn)
        root.add_widget(Widget())
        self.add_widget(root)

    def refresh(self):
        self.continue_btn.disabled = not self.app_ref.db.has_save()


class CreateScreen(Screen):
    def __init__(self, app_ref, **kwargs):
        super().__init__(**kwargs)
        self.app_ref = app_ref
        outer = BoxLayout(orientation="vertical", padding=dp(20), spacing=dp(12))
        outer.add_widget(DLabel("NEW GAME", title=True))
        outer.add_widget(DLabel("Name", muted=True, small=True))
        self.name_input = TextInput(multiline=False, size_hint_y=None, height=dp(48), font_size=sp(16))
        outer.add_widget(self.name_input)
        outer.add_widget(DLabel("Age", muted=True, small=True))
        self.age_input = TextInput(text="22", input_filter="int", multiline=False, size_hint_y=None, height=dp(48), font_size=sp(16))
        outer.add_widget(self.age_input)
        outer.add_widget(DLabel("Race", muted=True, small=True))
        self.race = Spinner(text="Human", values=("Human", "Elf", "Dwarf", "Orc", "Goblin", "Halfling"), size_hint_y=None, height=dp(48))
        outer.add_widget(self.race)
        outer.add_widget(Widget())
        start = DButton("START GAME")
        start.bind(on_release=lambda *_: self._create())
        outer.add_widget(start)
        back = DButton("BACK", secondary=True)
        back.bind(on_release=lambda *_: self.app_ref.show_start())
        outer.add_widget(back)
        self.add_widget(outer)

    def _create(self):
        name = self.name_input.text.strip()
        if not name:
            self.app_ref.notice("Enter a character name.")
            return
        try:
            age = max(1, min(120, int(self.age_input.text or "22")))
        except ValueError:
            age = 22
        self.app_ref.new_game(name, age, self.race.text)


class GameScreen(Screen):
    NAV = (("HOME", "Home"), ("CHAR", "Character"), ("BAG", "Inventory"), ("JOBS", "Jobs"), ("MAP", "Map"), ("MORE", "More"))

    def __init__(self, app_ref, **kwargs):
        super().__init__(**kwargs)
        self.app_ref = app_ref
        self.page = "Home"
        self.location_view = False
        root = BoxLayout(orientation="vertical", spacing=dp(6), padding=(dp(6), dp(6), dp(6), dp(4)))
        self.header = Surface(orientation="vertical", padding=(dp(12), dp(6)), spacing=0, size_hint_y=None, height=dp(66), bg_color=PANEL)
        self.header_name = DLabel(title=True)
        self.header_status = DLabel(muted=True, small=True)
        self.header.add_widget(self.header_name)
        self.header.add_widget(self.header_status)
        root.add_widget(self.header)

        self.scroll = ScrollView(do_scroll_x=False, bar_width=dp(4))
        self.content = GridLayout(cols=1, spacing=dp(8), padding=(dp(4), dp(8)), size_hint_y=None)
        self.content.bind(minimum_height=self.content.setter("height"))
        self.scroll.add_widget(self.content)
        root.add_widget(self.scroll)

        nav = GridLayout(cols=6, spacing=dp(4), size_hint_y=None, height=dp(56))
        for label, page in self.NAV:
            b = DButton(label, secondary=True, font_size=sp(11), height=dp(54))
            b.bind(on_release=lambda _b, p=page: self.navigate(p))
            nav.add_widget(b)
        root.add_widget(nav)
        self.add_widget(root)

    def refresh_header(self):
        s = self.app_ref.state
        if not s:
            return
        self.header_name.text = s.character_name
        self.header_status.text = (
            f"Day {s.day}  {s.clock_text}  ·  HP {s.health}/{s.max_health}  ·  EN {s.energy}/{s.max_energy}\n"
            f"${s.cash:,.0f}  ·  Wood {s.wood}  ·  Ore {s.ore}"
        )

    def navigate(self, page):
        if page == "More":
            self.show_more()
            return
        self.page = page
        self.location_view = False
        self.render()

    def clear(self):
        self.content.clear_widgets()

    def add_title(self, text):
        self.content.add_widget(DLabel(text, title=True))

    def add_section(self, text):
        lbl = DLabel(text.upper(), small=True)
        lbl.color = (0.78, 0.79, 0.81, 1)
        lbl.height = dp(30)
        self.content.add_widget(lbl)

    def add_text(self, text, muted=False):
        self.content.add_widget(DLabel(text, muted=muted))

    def add_button(self, text, callback, disabled=False, danger=False, secondary=False):
        b = DButton(text, danger=danger, secondary=secondary)
        b.disabled = disabled
        b.bind(on_release=lambda *_: callback())
        self.content.add_widget(b)
        return b

    def add_card(self, title, detail="", action_text=None, action=None, disabled=False):
        card = Surface(orientation="vertical", padding=dp(12), spacing=dp(4), size_hint_y=None, bg_color=CARD)
        card.bind(minimum_height=card.setter("height"))
        card.add_widget(DLabel(title))
        if detail:
            card.add_widget(DLabel(detail, muted=True, small=True))
        if action_text and action:
            b = DButton(action_text, height=dp(44), secondary=True)
            b.disabled = disabled
            b.bind(on_release=lambda *_: action())
            card.add_widget(b)
        self.content.add_widget(card)
        return card

    def render(self):
        self.refresh_header()
        self.clear()
        if self.location_view:
            self.render_location()
        elif self.page == "Home":
            self.render_home()
        elif self.page == "Character":
            self.render_character()
        elif self.page == "Inventory":
            self.render_inventory()
        elif self.page == "Jobs":
            self.render_jobs()
        elif self.page == "Map":
            self.render_map()
        elif self.page == "Forge":
            self.render_forge()
        elif self.page == "Phone":
            self.render_phone()
        self.scroll.scroll_y = 1

    def show_more(self):
        box = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(8))
        pop = Popup(title="More", content=box, size_hint=(0.88, 0.70), auto_dismiss=True)
        for title, page in (("FORGE", "Forge"), ("PHONE", "Phone")):
            b = DButton(title)
            b.bind(on_release=lambda _b, p=page: (pop.dismiss(), self.navigate(p)))
            box.add_widget(b)
        save = DButton("SAVE", secondary=True)
        save.bind(on_release=lambda *_: (self.app_ref.save(), self.app_ref.notice("Game saved.")))
        box.add_widget(save)
        menu = DButton("MAIN MENU", secondary=True)
        menu.bind(on_release=lambda *_: (self.app_ref.save(), pop.dismiss(), self.app_ref.show_start()))
        box.add_widget(menu)
        pop.open()

    def render_home(self):
        s = self.app_ref.state
        self.add_title("HOME")
        self.add_text(f"Lot {s.lot_number}  ·  {s.home_type}", muted=True)
        self.add_card(
            "PROPERTY",
            f"Home storage: {sum(s.home_storage.values())}/{home_storage_capacity(s.home_type)} items\n"
            f"Partner allowed: {'Yes' if allows_live_in_partner(s.home_type) else 'No'} · Child capacity: {child_capacity(s.home_type)}",
        )
        self.add_button("SLEEP UNTIL MORNING", self._sleep)
        self.add_section("Home upgrades")
        for option in HOME_UPGRADES:
            if option.name == s.home_type:
                self.add_card(option.name, "Current home")
                continue
            affordable = can_afford_build(s.cash, s.wood, s.ore, option)
            detail = f"${option.cash:,} · Wood {option.wood} · Ore {option.ore}\n{option.description}"
            self.add_card(option.name, detail, "BUILD", lambda o=option: self._build_home(o), not affordable)

    def _sleep(self):
        s = self.app_ref.state
        sleep_until_morning(s, health_recovery=20)
        self.app_ref.save()
        self.render()
        self.app_ref.notice("You wake at 8:00 AM with restored Energy.")

    def _build_home(self, option):
        s = self.app_ref.state
        if not can_afford_build(s.cash, s.wood, s.ore, option):
            return
        s.cash -= option.cash
        s.wood -= option.wood
        s.ore -= option.ore
        s.home_type = option.name
        s.add_activity(f"You built a {option.name} on your property.")
        self.app_ref.save()
        self.render()

    def render_character(self):
        s = self.app_ref.state
        self.add_title("CHARACTER")
        self.add_card("IDENTITY", f"{s.character_name} · Age {s.age} · {s.race}\nHome: {s.home_type} · Location: {s.current_location}")
        self.add_section("Stats")
        self.add_card("PHYSICAL", f"Strength {s.strength} · Endurance {s.endurance} · Agility {s.agility}\nIntelligence {s.intelligence} · Perception {s.perception}")
        self.add_card("SKILLS", f"Woodcutting {s.woodcutting_level} · Mining {s.mining_level} · Hunting {s.hunting_level}")
        self.add_section("Vice")
        self.add_card("STATUS", f"Drunkenness {s.drunk_level}/5 · Addiction {s.addiction}/100 · Drug uses {s.drugs_used_total}")
        self.add_section("Education")
        quals = ", ".join(s.qualifications) if s.qualifications else "None"
        self.add_card("QUALIFICATIONS", quals + f"\nStudent loan: ${s.student_loan_balance:,.2f}")
        self.add_section("Criminal record")
        crimes = [f"{k}: {v}" for k, v in s.crime_record.items() if int(v or 0) > 0 and not k.endswith("Day")]
        self.add_card("RECORD", "\n".join(crimes) if crimes else "No recorded offenses.")
        self.add_section("Recent activity")
        for item in s.activity_log[:8]:
            self.add_text(item, muted=True)

    def render_inventory(self):
        s = self.app_ref.state
        self.add_title("INVENTORY")
        self.add_section("Equipped")
        for slot, item in s.equipment.items():
            display = item if item not in ("Nothing", "None", "") else "Empty"
            action = None
            if display != "Empty":
                action = lambda sl=slot: self._unequip(sl)
            self.add_card(slot, display, "UNEQUIP" if action else None, action)
        self.add_section("Backpack")
        items = [(name, qty) for name, qty in sorted(s.inventory.items(), key=lambda p: p[0].lower()) if qty > 0]
        if not items:
            self.add_text("Your backpack is empty.", muted=True)
            return
        for item, qty in items:
            action_text, action = self._inventory_action(item)
            self.add_card(item, f"Quantity: {qty} · {self._item_detail(item)}", action_text, action)

    def _item_detail(self, item):
        slot = clothing_slot(item)
        if item in DUNGEON_ARMOR:
            return f"{slot} · Dungeon Defense +{DUNGEON_ARMOR[item][1]}"
        if item in GUN_ARMOR:
            return f"{slot} · Combat Defense +{GUN_ARMOR[item][1]}"
        if item in DUNGEON_WEAPONS:
            return f"Weapon · Attack +{DUNGEON_WEAPONS[item]}"
        if item in GUN_WEAPONS:
            return f"Weapon · Attack +{GUN_WEAPONS[item]}"
        if slot:
            return f"Clothing · {slot}"
        details = {
            "Food": "Restores 10 Energy",
            "Water": "Restores 5 Energy",
            "Milk": "Restores 8 Energy",
            "Cooked Meal": "Restores 25 Energy",
            "Beer": "Raises drunkenness",
            "Homebrew Beer": "Drink or sell at Farmers Market",
            DRUG_ITEM: "Vice item · raises addiction pressure",
            DRUG_SEED_ITEM: "Plantable contraband crop",
            BEER_KIT_ITEM: "Kitchen brewing supply",
        }
        return details.get(item, "General item")

    def _inventory_action(self, item):
        if clothing_slot(item):
            return "EQUIP", lambda i=item: self._equip(i)
        if item in DUNGEON_WEAPONS or item in GUN_WEAPONS:
            return "EQUIP", lambda i=item: self._equip_weapon(i)
        if item in ("Food", "Water", "Milk", "Cooked Meal", "Beer", "Homebrew Beer", DRUG_ITEM):
            return "USE", lambda i=item: self._use_item(i)
        return None, None

    def _equip(self, item):
        ok, msg = equip_clothing(self.app_ref.state, item)
        if ok:
            self.app_ref.save()
            self.render()
        else:
            self.app_ref.notice(msg)

    def _unequip(self, slot):
        s = self.app_ref.state
        if slot == "Weapon":
            item = s.equipment.get("Weapon", "None")
            if item not in ("None", "Nothing", ""):
                s.inventory[item] = s.inventory.get(item, 0) + 1
                s.equipment["Weapon"] = "None"
                s.add_activity(f"You unequipped {item}.")
                self.app_ref.save(); self.render()
            return
        ok, msg = unequip_clothing(s, slot)
        if ok:
            self.app_ref.save(); self.render()
        else:
            self.app_ref.notice(msg)

    def _equip_weapon(self, item):
        s = self.app_ref.state
        if s.inventory.get(item, 0) <= 0:
            return
        old = s.equipment.get("Weapon", "None")
        s.inventory[item] -= 1
        if old not in ("None", "Nothing", ""):
            s.inventory[old] = s.inventory.get(old, 0) + 1
        s.equipment["Weapon"] = item
        s.add_activity(f"You equipped {item}.")
        self.app_ref.save(); self.render()

    def _use_item(self, item):
        s = self.app_ref.state
        if s.inventory.get(item, 0) <= 0:
            return
        if item == "Food":
            s.energy = min(s.max_energy, s.energy + 10); msg = "You ate Food. Energy +10."
        elif item == "Water":
            s.energy = min(s.max_energy, s.energy + 5); msg = "You drank Water. Energy +5."
        elif item == "Milk":
            s.energy = min(s.max_energy, s.energy + 8); msg = "You drank Milk. Energy +8."
        elif item == "Cooked Meal":
            s.energy = min(s.max_energy, s.energy + 25); msg = "You ate a Cooked Meal. Energy +25."
        elif item in ("Beer", "Homebrew Beer"):
            msg = drink_beer(s)
        else:
            msg = use_drugs(s)
        s.inventory[item] -= 1
        s.add_activity(msg)
        self.app_ref.save(); self.render()
        self.app_ref.notice(msg)

    def render_jobs(self):
        s = self.app_ref.state
        self.add_title("JOBS")
        if s.active_job_name:
            remain = max(0, int(s.active_job_end_ts - time.time() + .999))
            self.add_card("CURRENT SHIFT", f"{s.active_job_name} · {remain}s remaining")
        casual = [
            ("Dishwasher", 14, 8, True, "None"),
            ("Janitor", 15, 7, True, "None"),
            ("Cashier", 16, 6, True, "None"),
            ("Delivery Helper", 17, 8, True, "None"),
            ("Barback", 17, 8, s.endurance >= 6, "Endurance 6"),
            ("Warehouse Worker", 18, 10, s.strength >= 7, "Strength 7"),
            ("Landscaping Crew", 19, 11, s.strength >= 6, "Strength 6"),
            ("Security Guard", 20, 6, s.perception >= 8, "Perception 8"),
        ]
        careers = [
            ("Office Administrator", 220, 25, "Office Administration Certificate"),
            ("IT Support Technician", 300, 30, "IT Support Certificate"),
            ("Bookkeeper", 340, 28, "Bookkeeping Diploma"),
            ("Medical Receptionist", 290, 26, "Medical Office Certificate"),
        ]
        self.add_section("Casual jobs")
        for name, pay, energy, unlocked, req in casual:
            disabled = (not unlocked) or s.energy < energy or bool(s.active_job_name or s.active_forge_name)
            self.add_card(name, f"${pay}/hour · Energy {energy} · Requirement: {req}", "WORK 1 HOUR", lambda n=name,p=pay,e=energy:self._start_job(n,p,e,1,60), disabled)
        self.add_section("Full-time careers")
        for name, pay, energy, qual in careers:
            unlocked = has_qualification(s, qual)
            disabled = (not unlocked) or s.energy < energy or bool(s.active_job_name or s.active_forge_name)
            self.add_card(name, f"${pay}/shift · 8 hours · Energy {energy} · {qual}", "WORK FULL SHIFT", lambda n=name,p=pay,e=energy:self._start_job(n,p,e,8,120), disabled)

    def _start_job(self, name, pay, energy, hours, seconds):
        s = self.app_ref.state
        if s.active_job_name or s.active_forge_name or s.energy < energy:
            return
        s.active_job_name = name; s.active_job_pay = pay; s.active_job_energy = energy
        s.active_job_hours = hours; s.active_job_end_ts = time.time() + seconds
        s.add_activity(f"You started a {hours}-hour shift as a {name}.")
        self.app_ref.save(); self.render()

    def render_forge(self):
        s = self.app_ref.state
        self.add_title("FORGE")
        if s.active_forge_name:
            remain = max(0, int(s.active_forge_end_ts - time.time() + .999))
            self.add_card("CURRENT ACTIVITY", f"{s.active_forge_name} · {remain}s remaining")
        data = [
            ("Cut Trees", "Wood Axe", 5),
            ("Mine Ore", "Pickaxe", 6),
            ("Hunt Animals", "Hunting Bow or Hunting Rifle", 8),
        ]
        for name, requirement, energy in data:
            tool_ok = self._forge_tool_ok(name)
            disabled = not tool_ok or s.energy < energy or bool(s.active_job_name or s.active_forge_name)
            self.add_card(name, f"Energy {energy} · Requires {requirement}", "START", lambda n=name,e=energy:self._start_forge(n,e), disabled)

    def _forge_tool_ok(self, name):
        s = self.app_ref.state
        if name == "Cut Trees": return s.inventory.get("Wood Axe",0)>0
        if name == "Mine Ore": return s.inventory.get("Pickaxe",0)>0
        return s.inventory.get("Hunting Bow",0)>0 or s.inventory.get("Hunting Rifle",0)>0

    def _start_forge(self, name, energy):
        s = self.app_ref.state
        if s.active_job_name or s.active_forge_name or s.energy < energy or not self._forge_tool_ok(name): return
        s.active_forge_name=name; s.active_forge_energy=energy; s.active_forge_end_ts=time.time()+60
        s.add_activity(f"You started {name.lower()} for 1 hour.")
        self.app_ref.save(); self.render()

    def render_map(self):
        s = self.app_ref.state
        self.add_title("MAP")
        self.add_text(f"Current location: {s.current_location}", muted=True)
        if s.current_location != "Home":
            self.add_button(f"OPEN {s.current_location.upper()}", self._open_current_location)
        self.add_section("Destinations")
        for location in LOCATION_DISTANCE_KM:
            if location == s.current_location:
                continue
            distance = LOCATION_DISTANCE_KM[location]
            self.add_card(location, f"{distance:.1f} km", "TRAVEL", lambda loc=location:self._choose_travel(loc))

    def _open_current_location(self):
        self.location_view = True; self.render()

    def _choose_travel(self, destination):
        s = self.app_ref.state
        box = BoxLayout(orientation="vertical", spacing=dp(8), padding=dp(12))
        pop = Popup(title=f"Travel to {destination}", content=box, size_hint=(.92,.72))
        for method in available_travel_methods(s):
            sec = travel_seconds(destination, method); mins = travel_game_minutes(destination, method)
            b = DButton(f"{method.name} · {sec}s · {mins} game min")
            b.bind(on_release=lambda _b,m=method: (pop.dismiss(), self.app_ref.start_travel(destination,m)))
            box.add_widget(b)
        cancel = DButton("CANCEL", secondary=True); cancel.bind(on_release=lambda *_:pop.dismiss()); box.add_widget(cancel)
        pop.open()

    def render_location(self):
        s = self.app_ref.state
        loc = s.current_location
        self.add_title(loc.upper())
        self.add_button("BACK TO MAP", lambda:self.navigate("Map"), secondary=True)
        self._location_actions(loc)
        self.add_section("People here")
        people = [npc for npc in npcs_for_location(loc, s.day, s.hour) if npc.name not in s.dead_npcs]
        if not people:
            self.add_text("No one is around right now.", muted=True)
        for npc in people:
            self.add_card(npc.name, npc.description, "TALK", lambda n=npc:self._talk(n))

    def _talk(self, npc):
        s=self.app_ref.state
        ok, result=apply_score_action(s,npc.name,"Talk",5)
        line=random.choice(npc.dialogue) if npc.dialogue else "You have a short conversation."
        if ok:
            s.add_activity(f"You talked with {npc.name}. Relationship: {relationship_status(s,npc.name)}.")
        self.app_ref.save()
        extra=f"\n\nRelationship: {relationship_status(s,npc.name)} ({relationship_score(s,npc.name)})"
        if relationship_score(s,npc.name)>=CONTACT_SCORE and npc.name not in s.contacts:
            extra += "\nYou can add this person to Contacts from Phone."
        self.app_ref.notice(line+extra)

    def _location_actions(self, loc):
        s = self.app_ref.state
        if loc == "Grocery Store":
            self.add_section("Shop")
            for item, price, desc in (
                ("Food", 5, "Restores 10 Energy"),
                ("Water", 2, "Restores 5 Energy"),
                ("Vegetable Seeds", 4, "Garden Bed seeds"),
                (BEER_KIT_ITEM, BEER_KIT_PRICE, "Kitchen brewing supply"),
            ):
                self._shop_item(item, price, desc)
        elif loc == "Main Street Threads":
            for section, items in FASHION_STORE_SECTIONS.items():
                self.add_section(section)
                for item, price, desc in items:
                    self._shop_item(item, price, desc)
        elif loc == "Gus' Gunporium":
            self.add_text("Fictional RPG weapons and combat gear.", muted=True)
            for item in GUNPORIUM_ITEMS:
                self._shop_item(item.name, item.price, item.description)
        elif loc == "Outdoors Specials":
            for item, price in OUTDOORS_SPECIALS_ITEMS:
                self._shop_item(item, price, "Outdoor equipment")
            self._themed_clothes(loc)
        elif loc == "The Drunken Donkey":
            self.add_text("Beer, fried food, pub merch, and one extremely questionable corner.", muted=True)
            self._shop_item("Beer", 4, "Raises drunkenness")
            self._shop_item(DRUG_SEED_ITEM, DRUG_SEED_PRICE, "Suspicious abstract seeds")
            self.add_button(
                f"SELL 1 DRUG · ${DRUG_SALE_PRICE}",
                self._sell_drug,
                disabled=s.inventory.get(DRUG_ITEM, 0) <= 0,
            )
            self._themed_clothes(loc)
        elif loc == "Farmers Market":
            self.add_button(
                f"SELL HOMEBREW · ${FARMERS_MARKET_BEER_PRICE}",
                self._sell_homebrew,
                disabled=s.inventory.get("Homebrew Beer", 0) <= 0,
            )
            self._themed_clothes(loc)
        elif loc == "Bank":
            self.add_card("BANKING", f"Cash ${s.cash:,.2f}\nBank ${s.bank_balance:,.2f}")
            self.add_button("DEPOSIT $100", lambda: self._bank(100, True), disabled=s.cash < 100)
            self.add_button("WITHDRAW $100", lambda: self._bank(100, False), disabled=s.bank_balance < 100, secondary=True)
        elif loc == "Gym":
            for stat in ("strength", "endurance", "agility"):
                self.add_button(
                    f"TRAIN {stat.upper()} · 10 ENERGY",
                    lambda st=stat: self._train(st),
                    disabled=s.energy < 10 or bool(s.active_job_name or s.active_forge_name),
                )
        elif loc == "Education Center":
            self._education()
            self._themed_clothes(loc)
        elif loc == "Lucky Horseshoe Casino":
            self._casino()
            self._themed_clothes(loc)
        elif loc == "Riverside Park":
            self.add_text("Walk the paths and meet whoever happens to be around.", muted=True)
            self.add_button(
                f"SELL 1 DRUG · ${DRUG_SALE_PRICE}",
                self._sell_drug,
                disabled=s.inventory.get(DRUG_ITEM, 0) <= 0,
            )
        elif loc == "The Dungeon":
            self._dungeon()
        elif loc == "Home":
            self.navigate("Home")
        elif loc in LOCATION_CLOTHING_SHOPS:
            self._themed_clothes(loc)
            self.add_text(
                "The mobile test build currently exposes this location's clothing rack and NPCs; "
                "its deeper desktop interactions will move over in a later mobile pass.",
                muted=True,
            )
        else:
            self.add_text(
                "This location is available in the mobile map. Its deeper desktop interactions are being moved over in later mobile passes.",
                muted=True,
            )

    def _themed_clothes(self, loc):
        items=LOCATION_CLOTHING_SHOPS.get(loc,())
        if items:
            self.add_section("Clothing")
            for item,price,desc in items:self._shop_item(item,price,desc)

    def _shop_item(self,item,price,desc):
        s=self.app_ref.state
        self.add_card(item,f"${price:,} · {desc}\nOwned: {s.inventory.get(item,0)}","BUY",lambda i=item,p=price:self._buy(i,p),s.cash<price)

    def _buy(self,item,price):
        s=self.app_ref.state
        if s.cash<price:return
        s.cash-=price;s.inventory[item]=s.inventory.get(item,0)+1
        s.add_activity(f"You bought {item} for ${price:,}.")
        self.app_ref.save();self.render()

    def _bank(self,amount,deposit):
        s=self.app_ref.state
        if deposit and s.cash>=amount:s.cash-=amount;s.bank_balance+=amount
        elif not deposit and s.bank_balance>=amount:s.bank_balance-=amount;s.cash+=amount
        self.app_ref.save();self.render()

    def _train(self,stat):
        s=self.app_ref.state
        if s.energy<10:return
        s.energy-=10;setattr(s,stat,getattr(s,stat)+1);advance_minutes(s,60)
        s.add_activity(f"You trained {stat.title()} at the Gym.")
        self.app_ref.save();self.render()

    def _education(self):
        s=self.app_ref.state
        self.add_section("Courses")
        for course in COURSES:
            if course.qualification in s.qualifications:
                self.add_card(course.name,"COMPLETED · "+course.qualification)
                continue
            progress=int(s.course_progress.get(course.name,0) or 0)
            if s.current_course==course.name:
                self.add_card(course.name,f"Session {progress}/{course.sessions} · 10 Energy per class","ATTEND CLASS",lambda c=course:self._attend_course(c),s.energy<10)
            elif not s.current_course:
                self.add_card(course.name,f"Tuition ${course.tuition:,} · {course.sessions} sessions\n{course.description}","ENROLL",lambda c=course:self._enroll(c),False)
            else:
                self.add_card(course.name,"Finish your current course first.")
        if s.student_loan_balance>0:
            self.add_section("Student loan")
            self.add_card("BALANCE",f"${s.student_loan_balance:,.2f}")
            self.add_button("PAY $100",lambda:self._loan_pay(100),disabled=s.cash<100)

    def _enroll(self,course):
        s=self.app_ref.state
        if s.cash>=course.tuition:
            s.cash-=course.tuition
        else:
            borrowed=float(course.tuition)
            s.student_loan_balance+=borrowed;s.student_loan_borrowed_total+=borrowed
        s.current_course=course.name;s.course_progress.setdefault(course.name,0)
        s.add_activity(f"You enrolled in {course.name}.")
        self.app_ref.save();self.render()

    def _attend_course(self,course):
        s=self.app_ref.state
        if s.energy<10:return
        s.energy-=10;advance_minutes(s,120)
        s.course_progress[course.name]=int(s.course_progress.get(course.name,0))+1
        if s.course_progress[course.name]>=course.sessions:
            s.qualifications.append(course.qualification);s.current_course=""
            s.add_activity(f"You completed {course.name} and earned {course.qualification}.")
        else:s.add_activity(f"You attended a {course.name} class session.")
        self.app_ref.save();self.render()

    def _loan_pay(self,amount):
        s=self.app_ref.state
        pay=min(float(amount),s.cash,s.student_loan_balance)
        s.cash-=pay;s.student_loan_balance-=pay
        self.app_ref.save();self.render()

    def _sell_drug(self):
        s=self.app_ref.state
        ok,msg=sell_drug(s)
        if ok:s.add_activity(msg)
        self.app_ref.save();self.render();self.app_ref.notice(msg)

    def _sell_homebrew(self):
        s=self.app_ref.state
        if s.inventory.get("Homebrew Beer",0)<=0:return
        s.inventory["Homebrew Beer"]-=1;s.cash+=FARMERS_MARKET_BEER_PRICE
        s.add_activity(f"You sold Homebrew Beer for ${FARMERS_MARKET_BEER_PRICE}.")
        self.app_ref.save();self.render()

    def _casino(self):
        s=self.app_ref.state
        self.add_text("Mobile test wager: $25 per play.",muted=True)
        for name,fn in (("ROULETTE",casino_roulette),("SLOTS",casino_slots),("BLACKJACK",casino_blackjack)):
            self.add_button(name,lambda f=fn:self._casino_play(f),disabled=s.cash<25)

    def _casino_play(self,fn):
        s=self.app_ref.state;wager=25
        if s.cash<wager:return
        result=fn(wager,random.Random())
        s.cash+=result.delta
        s.add_activity(result.text)
        self.app_ref.save();self.render();self.app_ref.notice(result.text+f"\nCash change: ${result.delta:+d}")

    def _dungeon(self):
        s=self.app_ref.state;ensure_dungeon_state(s)
        self.add_text(f"Checkpoint: Floor {s.dungeon_checkpoint} · Floors cleared: {s.dungeon_clears}",muted=True)
        if not s.dungeon_active:
            self.add_button("START FROM FLOOR 1",lambda:self._start_dungeon(1))
            for floor in range(10,s.dungeon_checkpoint+1,10):self.add_button(f"START FROM FLOOR {floor}",lambda f=floor:self._start_dungeon(f),secondary=True)
            self.add_section("Gift shop")
            for item in GIFT_SHOP_ITEMS:self._shop_item(item.name,item.price,item.description)
            return
        floor=s.dungeon_floor
        self.add_section(f"Floor {floor}/100")
        enc=s.dungeon_encounter or make_dungeon_encounter(s);self.app_ref.save()
        kind=enc.get("kind")
        if kind=="fight":
            self.add_card(enc.get("name","Enemy"),f"Enemy HP {enc.get('health')}/{enc.get('max_health')} · Your HP {s.health}/{s.max_health}\nDefense {dungeon_defense(s)} · Weapon +{dungeon_weapon_bonus(s)}")
            self.add_button("ATTACK",lambda:self._dungeon_attack(False))
            self.add_button("HEAVY ATTACK",lambda:self._dungeon_attack(True),secondary=True)
            self.add_button("RETREAT",self._dungeon_retreat,danger=True)
        elif kind=="trap":
            self.add_card("TRAP",enc.get("name","Unknown trap"))
            self.add_button("MOVE CAREFULLY",lambda:self._trap("careful"))
            self.add_button("DASH THROUGH",lambda:self._trap("dash"),secondary=True)
        elif kind=="puzzle":
            self.add_card("PUZZLE",enc.get("question",""))
            for idx,opt in enumerate(enc.get("options",[])):self.add_button(str(opt),lambda i=idx:self._puzzle(i),secondary=True)
        else:
            self.add_card("TREASURE",enc.get("name","Chest"))
            self.add_button("OPEN CHEST",self._treasure)

    def _start_dungeon(self,floor):
        s=self.app_ref.state
        if floor!=1 and floor>s.dungeon_checkpoint:return
        start_dungeon_run(s,floor);s.add_activity(f"You entered The Dungeon at Floor {floor}.")
        self.app_ref.save();self.render()

    def _dungeon_attack(self,heavy):
        s=self.app_ref.state;enc=s.dungeon_encounter
        hit,damage=dungeon_player_damage(s,heavy)
        if hit:enc["health"]=max(0,int(enc.get("health",0))-damage)
        if int(enc.get("health",0))<=0:
            loot,done=dungeon_clear_floor(s);s.add_activity(f"Dungeon floor cleared. Loot: {', '.join(loot)}")
            if not done: s.dungeon_floor+=1;s.dungeon_encounter={}
            self.app_ref.save();self.render();return
        s.health=max(0,s.health-dungeon_enemy_damage(s,enc))
        if s.health<=0:
            s.health=10;end_dungeon_run(s);s.current_location="The Dungeon";s.add_activity("You were defeated in The Dungeon and dragged back to the entrance.")
        self.app_ref.save();self.render()

    def _trap(self,mode):
        s=self.app_ref.state
        chance=(0.55+s.perception*0.03) if mode=="careful" else (0.45+s.agility*0.035)
        if random.random()>min(.9,chance):s.health=max(1,s.health-random.randint(5,15))
        self._clear_nonfight_floor()

    def _puzzle(self,answer):
        s=self.app_ref.state;enc=s.dungeon_encounter
        if int(answer)!=int(enc.get("answer",-1)):s.health=max(1,s.health-random.randint(3,10))
        self._clear_nonfight_floor()

    def _treasure(self):self._clear_nonfight_floor()

    def _clear_nonfight_floor(self):
        s=self.app_ref.state
        loot,done=dungeon_clear_floor(s)
        if not done:s.dungeon_floor+=1;s.dungeon_encounter={}
        s.add_activity(f"Dungeon floor cleared. Loot: {', '.join(loot)}")
        self.app_ref.save();self.render()

    def _dungeon_retreat(self):
        s=self.app_ref.state;floor=s.dungeon_floor;end_dungeon_run(s);s.add_activity(f"You retreated from Floor {floor}.")
        self.app_ref.save();self.render()

    def render_phone(self):
        s=self.app_ref.state
        self.add_title("PHONE")
        self.add_section("Contacts")
        if not s.contacts:self.add_text("No contacts yet. Talk to people in town first.",muted=True)
        for name in s.contacts:
            self.add_card(name,f"{relationship_status(s,name)} · Relationship {relationship_score(s,name)}","CALL",lambda n=name:self._call(n))
        self.add_section("People you can add")
        for name in sorted(s.relationships):
            if name not in s.contacts and relationship_score(s,name)>=CONTACT_SCORE:
                self.add_card(name,f"Relationship {relationship_score(s,name)}","ADD CONTACT",lambda n=name:self._add_contact(n))
        self.add_section("Family")
        spouses=[n for n in s.relationships if s.relationships[n].get("romance")=="Married"]
        self.add_text("Spouse: "+(", ".join(spouses) if spouses else "None"),muted=True)
        self.add_text(f"Children: {len(s.children)} / {child_capacity(s.home_type)}",muted=True)

    def _call(self,name):
        s=self.app_ref.state;npc=npc_by_name(name)
        ok,msg=apply_score_action(s,name,"Call",2)
        line=random.choice(npc.dialogue) if npc and npc.dialogue else "You have a short conversation."
        self.app_ref.save();self.render();self.app_ref.notice(line if ok else msg)

    def _add_contact(self,name):
        s=self.app_ref.state;ok,msg=add_contact(s,name)
        self.app_ref.save();self.render();self.app_ref.notice(msg)


class DongMobileApp(App):
    title = "DONG Mobile"

    def build(self):
        self.state: GameState | None = None
        self.db = Database(Path(self.user_data_dir) / "game.db")
        self.travel_popup = None
        self.travel_event = None
        self.travel_end = 0.0
        self.travel_destination = ""
        self.travel_method = None
        sm = ScreenManager()
        self.start_screen = StartScreen(self, name="start")
        self.create_screen = CreateScreen(self, name="create")
        self.game_screen = GameScreen(self, name="game")
        sm.add_widget(self.start_screen); sm.add_widget(self.create_screen); sm.add_widget(self.game_screen)
        self.sm = sm
        Clock.schedule_interval(self._tick, 1.0)
        return sm

    def on_start(self):
        self.show_start()

    def on_pause(self):
        self.save(); return True

    def on_stop(self):
        self.save()

    def show_start(self):
        self.start_screen.refresh(); self.sm.current="start"

    def show_create(self):
        self.sm.current="create"

    def new_game(self,name,age,race):
        self.state=create_new_state(name,age,race);self.save();self.game_screen.page="Home";self.game_screen.location_view=False;self.sm.current="game";self.game_screen.render()

    def continue_game(self):
        self.state=self.db.load()
        if not self.state:self.show_start();return
        self._complete_expired_background()
        self.game_screen.page="Home" if self.state.current_location=="Home" else "Map"
        self.game_screen.location_view=self.state.current_location!="Home"
        self.sm.current="game";self.game_screen.render()

    def save(self):
        if self.state:self.db.save(self.state)

    def notice(self,text,title="DONG"):
        box=BoxLayout(orientation="vertical",padding=dp(14),spacing=dp(10))
        box.add_widget(DLabel(str(text)))
        close=DButton("OK");box.add_widget(close)
        pop=Popup(title=title,content=box,size_hint=(.9,.55))
        close.bind(on_release=lambda *_:pop.dismiss());pop.open()

    def _complete_expired_background(self):
        if not self.state:return
        now=time.time();changed=False
        s=self.state
        if s.active_job_name and s.active_job_end_ts<=now:
            name=s.active_job_name;pay=s.active_job_pay;energy=s.active_job_energy;hours=max(1,int(s.active_job_hours or 1))
            s.energy=max(0,s.energy-energy)
            loan=min(s.student_loan_balance,round(pay*.10,2)) if s.student_loan_balance>0 else 0.0
            s.student_loan_balance=max(0.0,s.student_loan_balance-loan);s.cash+=pay-loan;advance_minutes(s,60*hours)
            s.add_activity(f"You finished a {hours}-hour shift as a {name}. Gross pay ${pay}.")
            s.active_job_name="";s.active_job_pay=0;s.active_job_energy=0;s.active_job_end_ts=0.0;s.active_job_hours=1;changed=True
        if s.active_forge_name and s.active_forge_end_ts<=now:
            name=s.active_forge_name;s.energy=max(0,s.energy-s.active_forge_energy)
            if name=="Cut Trees":s.wood+=3;gain_skill(s,"woodcutting",10);result="Wood x3"
            elif name=="Mine Ore":s.ore+=2;gain_skill(s,"mining",10);result="Ore x2"
            else:s.inventory["Food"]=s.inventory.get("Food",0)+2;gain_skill(s,"hunting",10);result="Food x2"
            advance_minutes(s,60);s.add_activity(f"You finished {name.lower()} and gathered {result}.")
            s.active_forge_name="";s.active_forge_energy=0;s.active_forge_end_ts=0.0;changed=True
        if changed:self.save()

    def _tick(self,_dt):
        if not self.state:return
        was_job=bool(self.state.active_job_name);was_forge=bool(self.state.active_forge_name)
        self._complete_expired_background()
        if self.sm.current=="game":
            self.game_screen.refresh_header()
            if (was_job and not self.state.active_job_name) or (was_forge and not self.state.active_forge_name):self.game_screen.render()
        if self.travel_popup and time.time()>=self.travel_end:self._finish_travel()

    def start_travel(self,destination,method):
        seconds=travel_seconds(destination,method)
        self.travel_end=time.time()+seconds;self.travel_destination=destination;self.travel_method=method
        box=BoxLayout(orientation="vertical",padding=dp(14),spacing=dp(10))
        label=DLabel(f"{method.verb.title()}ing to {destination}...",title=True);box.add_widget(label)
        countdown=DLabel("",muted=True);box.add_widget(countdown)
        bar=ProgressBar(max=seconds,value=0,size_hint_y=None,height=dp(24));box.add_widget(bar)
        cancel=DButton("CANCEL TRAVEL",secondary=True);box.add_widget(cancel)
        pop=Popup(title="Travel",content=box,size_hint=(.9,.55),auto_dismiss=False)
        self.travel_popup=pop
        def update(_dt):
            remaining=max(0,self.travel_end-time.time());elapsed=max(0,seconds-remaining);bar.value=elapsed;countdown.text=f"{int(remaining+0.999)} seconds remaining"
            return self.travel_popup is pop
        event=Clock.schedule_interval(update,.25);self.travel_event=event
        def do_cancel(*_):
            event.cancel();pop.dismiss();self.travel_popup=None
        cancel.bind(on_release=do_cancel);pop.open();update(0)

    def _finish_travel(self):
        if not self.travel_popup or not self.state:return
        pop=self.travel_popup;self.travel_popup=None
        if self.travel_event:self.travel_event.cancel();self.travel_event=None
        dest=self.travel_destination;method=self.travel_method
        advance_minutes(self.state,travel_game_minutes(dest,method));self.state.current_location=dest
        self.state.add_activity(f"You arrived at {dest} by {method.name}.")
        self.save();pop.dismiss();self.game_screen.page="Map";self.game_screen.location_view=(dest!="Home")
        if dest=="Home":self.game_screen.page="Home";self.game_screen.location_view=False
        self.game_screen.render()


if __name__ == "__main__":
    DongMobileApp().run()
