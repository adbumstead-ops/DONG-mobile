#!/usr/bin/env bash
set -e
python3 -m pip install --user buildozer cython
buildozer android debug
printf '\nAPK output is in the bin/ folder.\n'
