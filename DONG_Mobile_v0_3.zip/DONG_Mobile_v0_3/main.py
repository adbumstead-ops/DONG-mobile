from __future__ import annotations

import random
import time
from pathlib import Path

from kivy.animation import Animation
from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.graphics import Color, RoundedRectangle
from kivy.metrics import dp, sp
from kivy.properties import ListProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.progressbar import ProgressBar
from kivy.uix.screenmanager import Screen, ScreenManager
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget

from database.db import Database
from game.dungeon import (
    DUNGEON_ARMOR,
    DUNGEON_WEAPONS,
    GIFT_SHOP_ITEMS,
    clear_floor as dungeon_clear_floor,
    dungeon_defense,
    end_run as end_dungeon_run,
    enemy_damage as dungeon_enemy_damage,
    ensure_dungeon_state,
    make_encounter as make_dungeon_encounter,
    player_damage as dungeon_player_damage,
    start_run as start_dungeon_run,
    weapon_bonus as dungeon_weapon_bonus,
)
from game.animals import (
    ANIMAL_TYPES, SADDLE_PRICE, SEED_ITEM, animal_type, animals_in_slot, make_animal,
)
from game.combat import Enemy, enemy_attack_damage, make_random_enemy, player_attack_damage
from game.crime import (
    PICKPOCKET_FINE, THEFT_JAIL_DAYS, MURDER_JAIL_DAYS, HIDDEN_CACHE_CAPACITY,
    add_body_evidence, arrest, arm_body_carry_timer, carried_bodies, carried_body_due,
    ensure_crime_state, jail_day, witness_roll,
)
from game.education import COURSES, course_by_name, has_qualification
from game.gunporium import GUN_ARMOR, GUN_WEAPONS, GUNPORIUM_ITEMS
from game.home import (
    ROOM_OPTIONS, allows_live_in_partner, child_capacity, home_storage_capacity, room_capacity, room_option,
)
from game.items import (
    CLOTHING_SLOT_NAMES,
    FASHION_STORE_SECTIONS,
    LOCATION_CLOTHING_SHOPS,
    OUTDOORS_SPECIALS_ITEMS,
    clothing_slot,
)
from game.models import GameState
from game.npcs import npc_by_name, npcs_for_location
from game.property import HOME_UPGRADES, PROPERTY_BUILDS, can_afford_build, property_option
from game.relationships import (
    CONTACT_SCORE, DATE_SCORE, FLIRT_SCORE, INTIMATE_SCORE, MARRY_SCORE,
    add_contact, apply_score_action, ensure_relationship, make_child, set_romance,
)
from game.relationships import score as relationship_score, status as relationship_status
from game.vehicles import GARAGE_CAPACITY, VEHICLE_TYPES, make_vehicle, vehicle_type, vehicles_in_slot
from game.services import (
    LOCATION_DISTANCE_KM,
    advance_minutes,
    available_travel_methods,
    create_new_state,
    equip_clothing,
    gain_skill,
    sleep_until_morning,
    travel_game_minutes,
    travel_seconds,
    unequip_clothing,
)
from game.vice import (
    BEER_KIT_ITEM,
    BEER_KIT_PRICE,
    DRUG_ITEM,
    DRUG_SALE_PRICE,
    DRUG_SEED_ITEM,
    DRUG_SEED_PRICE,
    FARMERS_MARKET_BEER_PRICE,
    blackjack as casino_blackjack,
    drink_beer,
    roulette as casino_roulette,
    sell_drug,
    slots as casino_slots,
    use_drugs,
)

# Some imports above intentionally share the exact game modules used by desktop.
# The mobile branch replaces only the PySide UI and desktop save-path assumptions.

Window.clearcolor = (0.025, 0.028, 0.033, 1)

BG = (0.025, 0.028, 0.033, 1)
PANEL = (0.055, 0.06, 0.07, 1)
CARD = (0.075, 0.08, 0.09, 1)
CARD_ALT = (0.095, 0.10, 0.11, 1)
ACCENT = (0.22, 0.23, 0.25, 1)
ACCENT_HOVER = (0.30, 0.31, 0.33, 1)
TEXT = (0.92, 0.93, 0.95, 1)
MUTED = (0.62, 0.64, 0.68, 1)
DANGER = (0.44, 0.16, 0.16, 1)
SUCCESS = (0.18, 0.34, 0.22, 1)


class Surface(BoxLayout):
    bg_color = ListProperty(CARD)

    def __init__(self, **kwargs):
        radius = kwargs.pop("radius", dp(12))
        super().__init__(**kwargs)
        with self.canvas.before:
            self._color = Color(*self.bg_color)
            self._rect = RoundedRectangle(pos=self.pos, size=self.size, radius=[radius])
        self.bind(pos=self._sync_canvas, size=self._sync_canvas, bg_color=self._sync_color)

    def _sync_canvas(self, *_):
        self._rect.pos = self.pos
        self._rect.size = self.size

    def _sync_color(self, *_):
        self._color.rgba = self.bg_color


class DLabel(Label):
    def __init__(self, text="", muted=False, title=False, small=False, **kwargs):
        kwargs.setdefault("color", MUTED if muted else TEXT)
        kwargs.setdefault("font_size", sp(12 if small else 18 if title else 14))
        kwargs.setdefault("halign", "left")
        kwargs.setdefault("valign", "middle")
        kwargs.setdefault("size_hint_y", None)
        super().__init__(text=text, **kwargs)
        self.bind(width=self._set_text_width, texture_size=self._fit_height)

    def _set_text_width(self, *_):
        self.text_size = (max(0, self.width), None)

    def _fit_height(self, *_):
        self.height = max(dp(24), self.texture_size[1] + dp(8))


class DButton(Button):
    def __init__(self, text="", danger=False, secondary=False, **kwargs):
        kwargs.setdefault("size_hint_y", None)
        kwargs.setdefault("height", dp(48))
        kwargs.setdefault("font_size", sp(13))
        kwargs.setdefault("color", TEXT)
        kwargs.setdefault("background_normal", "")
        kwargs.setdefault("background_down", "")
        kwargs.setdefault("background_color", DANGER if danger else CARD_ALT if secondary else ACCENT)
        super().__init__(text=text, **kwargs)


class StartScreen(Screen):
    def __init__(self, app_ref, **kwargs):
        super().__init__(**kwargs)
        self.app_ref = app_ref
        root = BoxLayout(orientation="vertical", padding=dp(24), spacing=dp(16))
        root.add_widget(Widget())
        title = Label(text="DONG", color=TEXT, font_size=sp(50), bold=True, size_hint_y=None, height=dp(84))
        root.add_widget(title)
        subtitle = DLabel("MOBILE TEST BUILD", muted=True, small=True, halign="center")
        root.add_widget(subtitle)
        root.add_widget(Widget(size_hint_y=None, height=dp(20)))
        new_btn = DButton("NEW GAME")
        new_btn.bind(on_release=lambda *_: self.app_ref.show_create())
        root.add_widget(new_btn)
        self.continue_btn = DButton("CONTINUE", secondary=True)
        self.continue_btn.bind(on_release=lambda *_: self.app_ref.continue_game())
        root.add_widget(self.continue_btn)
        root.add_widget(Widget())
        self.add_widget(root)

    def refresh(self):
        self.continue_btn.disabled = not self.app_ref.db.has_save()


class CreateScreen(Screen):
    def __init__(self, app_ref, **kwargs):
        super().__init__(**kwargs)
        self.app_ref = app_ref
        outer = BoxLayout(orientation="vertical", padding=dp(20), spacing=dp(12))
        outer.add_widget(DLabel("NEW GAME", title=True))
        outer.add_widget(DLabel("Name", muted=True, small=True))
        self.name_input = TextInput(multiline=False, size_hint_y=None, height=dp(48), font_size=sp(16))
        outer.add_widget(self.name_input)
        outer.add_widget(DLabel("Age", muted=True, small=True))
        self.age_input = TextInput(text="22", input_filter="int", multiline=False, size_hint_y=None, height=dp(48), font_size=sp(16))
        outer.add_widget(self.age_input)
        outer.add_widget(DLabel("Race", muted=True, small=True))
        self.race = Spinner(text="Human", values=("Human", "Elf", "Dwarf", "Orc", "Goblin", "Halfling"), size_hint_y=None, height=dp(48))
        outer.add_widget(self.race)
        outer.add_widget(Widget())
        start = DButton("START GAME")
        start.bind(on_release=lambda *_: self._create())
        outer.add_widget(start)
        back = DButton("BACK", secondary=True)
        back.bind(on_release=lambda *_: self.app_ref.show_start())
        outer.add_widget(back)
        self.add_widget(outer)

    def _create(self):
        name = self.name_input.text.strip()
        if not name:
            self.app_ref.notice("Enter a character name.")
            return
        try:
            age = max(1, min(120, int(self.age_input.text or "22")))
        except ValueError:
            age = 22
        self.app_ref.new_game(name, age, self.race.text)


class GameScreen(Screen):
    NAV = (("HOME", "Home"), ("CHARACTER", "Character"), ("INVENTORY", "Inventory"), ("JOBS", "Jobs"), ("MAP", "Map"))
    EXTRA_NAV = (("FORGE", "Forge"), ("PHONE", "Phone"), ("CRIME", "Crime"), ("JAIL", "Jail"))

    def __init__(self, app_ref, **kwargs):
        super().__init__(**kwargs)
        self.app_ref = app_ref
        self.page = "Home"
        self.location_view = False
        self.home_inside = False
        self.home_room_slot = None
        self.structure_slot = None
        self.combat_enemy: Enemy | None = None
        self.combat_message = ""
        self.drawer_open = False

        root = FloatLayout()
        main = BoxLayout(orientation="vertical", spacing=dp(6), padding=(dp(6), dp(6), dp(6), dp(6)))
        self.header = Surface(orientation="vertical", padding=(dp(12), dp(6)), spacing=0, size_hint_y=None, height=dp(66), bg_color=PANEL)
        self.header_name = DLabel(title=True)
        self.header_status = DLabel(muted=True, small=True)
        self.header.add_widget(self.header_name)
        self.header.add_widget(self.header_status)
        main.add_widget(self.header)

        self.scroll = ScrollView(do_scroll_x=False, bar_width=dp(4))
        self.content = GridLayout(cols=1, spacing=dp(8), padding=(dp(4), dp(8)), size_hint_y=None)
        self.content.bind(minimum_height=self.content.setter("height"))
        self.scroll.add_widget(self.content)
        main.add_widget(self.scroll)
        root.add_widget(main)

        self.drawer_scrim = Button(
            text="", size_hint=(1, 1), background_normal="", background_down="",
            background_color=(0, 0, 0, 0.72), opacity=0, disabled=True,
        )
        self.drawer_scrim.bind(on_release=lambda *_: self.close_drawer())
        root.add_widget(self.drawer_scrim)

        self.drawer = Surface(
            orientation="vertical", padding=(dp(12), dp(14)), spacing=dp(8),
            size_hint=(None, 1), width=min(Window.width * 0.82, dp(320)), bg_color=PANEL, radius=0,
        )
        self.drawer.x = -self.drawer.width
        self.drawer.add_widget(DLabel("DONG", title=True, size_hint_y=None, height=dp(42)))
        self.drawer.add_widget(DLabel("NAVIGATION", muted=True, small=True, size_hint_y=None, height=dp(28)))

        drawer_scroll = ScrollView(do_scroll_x=False, bar_width=dp(3))
        self.drawer_items = GridLayout(cols=1, spacing=dp(6), size_hint_y=None)
        self.drawer_items.bind(minimum_height=self.drawer_items.setter("height"))
        drawer_scroll.add_widget(self.drawer_items)
        self.drawer.add_widget(drawer_scroll)

        self.drawer_nav_buttons = {}
        for label, page in self.NAV + self.EXTRA_NAV:
            b = DButton(label, secondary=True, height=dp(46))
            b.bind(on_release=lambda _b, p=page: self._drawer_navigate(p))
            self.drawer_items.add_widget(b)
            self.drawer_nav_buttons[page] = b

        self.drawer_items.add_widget(Widget(size_hint_y=None, height=dp(8)))
        save = DButton("SAVE GAME", secondary=True, height=dp(46))
        save.bind(on_release=lambda *_: self._drawer_save())
        self.drawer_items.add_widget(save)
        menu = DButton("MAIN MENU", secondary=True, height=dp(46))
        menu.bind(on_release=lambda *_: self._drawer_main_menu())
        self.drawer_items.add_widget(menu)
        root.add_widget(self.drawer)

        self.menu_tab = DButton(">", secondary=False, size_hint=(None, None), width=dp(34), height=dp(68), font_size=sp(20))
        self.menu_tab.bind(on_release=lambda *_: self.toggle_drawer())
        root.add_widget(self.menu_tab)

        root.bind(size=self._sync_drawer_geometry)
        Window.bind(size=lambda *_: self._sync_drawer_geometry(root))
        Clock.schedule_once(lambda *_: self._sync_drawer_geometry(root), 0)
        self.add_widget(root)

    def _sync_drawer_geometry(self, *_):
        width = min(Window.width * 0.82, dp(320))
        self.drawer.width = width
        if not self.drawer_open:
            self.drawer.x = -width
            self.menu_tab.x = 0
        else:
            self.drawer.x = 0
            self.menu_tab.x = width
        self.menu_tab.y = max(dp(18), (self.height - self.menu_tab.height) / 2)

    def toggle_drawer(self):
        if self.drawer_open:
            self.close_drawer()
        else:
            self.open_drawer()

    def open_drawer(self):
        if self.drawer_open:
            return
        self.drawer_open = True
        self.menu_tab.text = "<"
        self.drawer_scrim.disabled = False
        Animation.cancel_all(self.drawer, "x")
        Animation.cancel_all(self.menu_tab, "x")
        Animation.cancel_all(self.drawer_scrim, "opacity")
        Animation(x=0, duration=0.18, t="out_quad").start(self.drawer)
        Animation(x=self.drawer.width, duration=0.18, t="out_quad").start(self.menu_tab)
        Animation(opacity=0.45, duration=0.14).start(self.drawer_scrim)

    def close_drawer(self):
        if not self.drawer_open:
            return
        self.drawer_open = False
        self.menu_tab.text = ">"
        Animation.cancel_all(self.drawer, "x")
        Animation.cancel_all(self.menu_tab, "x")
        Animation.cancel_all(self.drawer_scrim, "opacity")
        Animation(x=-self.drawer.width, duration=0.18, t="out_quad").start(self.drawer)
        Animation(x=0, duration=0.18, t="out_quad").start(self.menu_tab)
        fade = Animation(opacity=0, duration=0.12)
        fade.bind(on_complete=lambda *_: setattr(self.drawer_scrim, "disabled", True))
        fade.start(self.drawer_scrim)

    def _drawer_navigate(self, page):
        self.close_drawer()
        self.navigate(page)

    def _drawer_save(self):
        self.close_drawer()
        self.app_ref.save()
        self.app_ref.notice("Game saved.")

    def _drawer_main_menu(self):
        self.close_drawer()
        self.app_ref.save()
        self.app_ref.show_start()

    def refresh_header(self):
        s = self.app_ref.state
        if not s:
            return
        self.header_name.text = s.character_name
        self.header_status.text = (
            f"Day {s.day}  {s.clock_text}  ·  HP {s.health}/{s.max_health}  ·  EN {s.energy}/{s.max_energy}\n"
            f"${s.cash:,.0f}  ·  Wood {s.wood}  ·  Ore {s.ore}"
        )

    def navigate(self, page):
        s = self.app_ref.state
        if s and s.jail_days_remaining > 0 and page not in ("Jail",):
            self.page = "Jail"
            self.location_view = False
            self.home_inside = False
            self.home_room_slot = None
            self.structure_slot = None
            self.render()
            self.app_ref.notice("You are incarcerated. Serve the remaining sentence before leaving Jail.")
            return
        self.page = page
        self.location_view = False
        if page != "Home":
            self.home_inside = False
            self.home_room_slot = None
            self.structure_slot = None
        self.render()

    def _refresh_drawer_selection(self):
        current = "Map" if self.location_view else self.page
        for page, button in self.drawer_nav_buttons.items():
            button.background_color = ACCENT if page == current else CARD_ALT

    def clear(self):
        self.content.clear_widgets()

    def add_title(self, text):
        self.content.add_widget(DLabel(text, title=True))

    def add_section(self, text):
        lbl = DLabel(text.upper(), small=True)
        lbl.color = (0.78, 0.79, 0.81, 1)
        lbl.height = dp(30)
        self.content.add_widget(lbl)

    def add_text(self, text, muted=False):
        self.content.add_widget(DLabel(text, muted=muted))

    def add_button(self, text, callback, disabled=False, danger=False, secondary=False):
        b = DButton(text, danger=danger, secondary=secondary)
        b.disabled = disabled
        b.bind(on_release=lambda *_: callback())
        self.content.add_widget(b)
        return b

    def add_card(self, title, detail="", action_text=None, action=None, disabled=False):
        card = Surface(orientation="vertical", padding=dp(12), spacing=dp(4), size_hint_y=None, bg_color=CARD)
        card.bind(minimum_height=card.setter("height"))
        card.add_widget(DLabel(title))
        if detail:
            card.add_widget(DLabel(detail, muted=True, small=True))
        if action_text and action:
            b = DButton(action_text, height=dp(44), secondary=True)
            b.disabled = disabled
            b.bind(on_release=lambda *_: action())
            card.add_widget(b)
        self.content.add_widget(card)
        return card

    def render(self):
        self.refresh_header()
        self.clear()
        s = self.app_ref.state
        if s and s.jail_days_remaining > 0 and self.page != "Jail":
            self.page = "Jail"
            self.location_view = False
        self._refresh_drawer_selection()
        if self.location_view:
            self.render_location()
        elif self.page == "Home":
            self.render_home()
        elif self.page == "Character":
            self.render_character()
        elif self.page == "Inventory":
            self.render_inventory()
        elif self.page == "Jobs":
            self.render_jobs()
        elif self.page == "Map":
            self.render_map()
        elif self.page == "Forge":
            self.render_forge()
        elif self.page == "Phone":
            self.render_phone()
        elif self.page == "Crime":
            self.render_crime()
        elif self.page == "Jail":
            self.render_jail()
        self.scroll.scroll_y = 1

    def render_home(self):
        s = self.app_ref.state
        self.add_title("HOME")
        if s.current_location != "Home":
            self.add_text(f"You are currently at {s.current_location}. Travel Home to use your property.", muted=True)
            self.add_button("OPEN MAP", lambda: self.navigate("Map"))
            return
        if self.home_room_slot is not None:
            self._render_home_room(self.home_room_slot)
            return
        if self.structure_slot is not None:
            self._render_structure(self.structure_slot)
            return
        if self.home_inside:
            self._render_home_interior()
            return

        occupied = [name for name in s.property_slots if name]
        self.add_card("PROPERTY", f"Lot {s.lot_number} · {s.home_type}\nStructures: {', '.join(occupied) if occupied else 'None'}")
        self.add_button(f"ENTER {s.home_type.upper()}", self._enter_home)
        self.add_section("Home upgrades")
        for option in HOME_UPGRADES:
            if option.name == s.home_type:
                continue
            detail = f"${option.cash:,} · Wood {option.wood} · Ore {option.ore}\n{option.description}"
            partners = [name for name in s.relationships if str(ensure_relationship(s,name).get("romance","None")) in ("Intimate","Married")]
            household_ok = (not partners or allows_live_in_partner(option.name)) and len(s.children) <= child_capacity(option.name)
            self.add_card(option.name, detail, "BUILD", lambda o=option: self._build_home(o), (not can_afford_build(s.cash,s.wood,s.ore,option)) or not household_ok)

        self.add_section("Property structure slots")
        self.add_text("Six customizable slots. Duplicate structures are allowed.", muted=True)
        for idx in range(6):
            existing = s.property_slots[idx] if idx < len(s.property_slots) else ""
            if existing:
                opt = property_option(existing)
                self.add_card(f"SLOT {idx+1} · {existing}", opt.description if opt else "", "ENTER", lambda i=idx:self._enter_structure(i))
                self.add_button(f"CHANGE SLOT {idx+1}", lambda i=idx:self._choose_structure(i), secondary=True)
            else:
                self.add_card(f"SLOT {idx+1} · EMPTY", "Build a property structure here.", "BUILD", lambda i=idx:self._choose_structure(i))

    def _enter_home(self):
        self.home_inside = True
        self.home_room_slot = None
        self.structure_slot = None
        self.render()

    def _leave_home(self):
        self.home_inside = False
        self.home_room_slot = None
        self.render()

    def _enter_structure(self, slot_index):
        self.structure_slot = slot_index
        self.home_inside = False
        self.home_room_slot = None
        self.render()

    def _leave_structure(self):
        self.structure_slot = None
        self.render()

    def _home_storage_used(self):
        return sum(max(0, int(qty or 0)) for qty in self.app_ref.state.home_storage.values())

    def _render_home_interior(self):
        s = self.app_ref.state
        self.add_button("BACK TO PROPERTY", self._leave_home, secondary=True)
        capacity = home_storage_capacity(s.home_type)
        slots = room_capacity(s.home_type)
        self.add_card(s.home_type.upper(), f"Storage {self._home_storage_used()}/{capacity} · Room slots {slots}")
        has_bedroom = any(name == "Bedroom" for name in s.home_room_slots[:slots])
        self.add_button("SLEEP UNTIL MORNING" + (" · BEDROOM BONUS" if has_bedroom else ""), lambda: self._sleep(has_bedroom))
        self.add_section("Home storage")
        stored = [(i,q) for i,q in sorted(s.home_storage.items()) if q>0]
        if not stored:
            self.add_text("Nothing is stored inside your home.", muted=True)
        for item, qty in stored:
            self.add_card(item, f"Stored: {qty}", "TAKE ONE", lambda i=item:self._home_storage_take_one(i))
        if self._home_storage_used() < capacity:
            self.add_section("Store from backpack")
            for item, qty in sorted(s.inventory.items()):
                if qty > 0:
                    self.add_card(item, f"Backpack: {qty}", "STORE ONE", lambda i=item:self._home_storage_put_one(i), self._home_storage_used() >= capacity)
        if slots <= 0:
            self.add_section("Rooms")
            self.add_text("A Tent has no interior room slots. Build a larger home first.", muted=True)
            return
        self.add_section("Rooms")
        for idx in range(slots):
            name = s.home_room_slots[idx]
            if name:
                opt=room_option(name)
                self.add_card(f"ROOM {idx+1} · {name}", opt.description if opt else "", "ENTER", lambda i=idx:self._enter_room(i))
            else:
                self.add_card(f"ROOM {idx+1} · EMPTY", "Build an interior room.", "BUILD ROOM", lambda i=idx:self._choose_room(i))

    def _enter_room(self, slot_index):
        self.home_room_slot = slot_index
        self.render()

    def _leave_room(self):
        self.home_room_slot = None
        self.render()

    def _render_home_room(self, slot_index):
        s=self.app_ref.state
        cap=room_capacity(s.home_type)
        if slot_index < 0 or slot_index >= cap or not s.home_room_slots[slot_index]:
            self.home_room_slot=None; self.render(); return
        name=s.home_room_slots[slot_index]
        self.add_button("BACK TO HOME INTERIOR", self._leave_room, secondary=True)
        opt=room_option(name)
        if opt:self.add_text(opt.description, muted=True)
        data=s.home_room_data[slot_index]
        if name=="Kitchen":
            self.add_card("KITCHEN", f"Food: {s.inventory.get('Food',0)} · Beer Kits: {s.inventory.get(BEER_KIT_ITEM,0)}")
            self.add_button("COOK MEAL · 2 FOOD", self._cook_meal, disabled=s.inventory.get("Food",0)<2)
            self.add_button("BREW 4 HOMEBREW BEER · 1 KIT", self._brew_beer, disabled=s.inventory.get(BEER_KIT_ITEM,0)<1)
        elif name=="Living Room":
            used=int(data.get("relaxed_day",0) or 0)==s.day
            self.add_button("RELAX · +10 ENERGY / +5 HP", lambda:self._relax_living_room(slot_index), disabled=used)
            if used:self.add_text("You already relaxed here today.", muted=True)
        elif name=="Bedroom":
            self.add_button("SLEEP UNTIL MORNING · +30 HP", lambda:self._sleep(True))
        elif name=="Bathroom":
            used=int(data.get("showered_day",0) or 0)==s.day
            self.add_button("TAKE SHOWER · +10 HP", lambda:self._shower(slot_index), disabled=used)
            if used:self.add_text("You already showered today.", muted=True)

    def _choose_room(self, slot_index):
        s=self.app_ref.state
        box=BoxLayout(orientation="vertical",padding=dp(10),spacing=dp(6))
        pop=Popup(title=f"Build Room {slot_index+1}",content=box,size_hint=(.94,.82))
        built={x for x in s.home_room_slots if x}
        for opt in ROOM_OPTIONS:
            b=DButton(f"{opt.name} · ${opt.cash:,} · W{opt.wood} · O{opt.ore}")
            b.disabled=opt.name in built or not can_afford_build(s.cash,s.wood,s.ore,opt)
            b.bind(on_release=lambda _b,o=opt:(pop.dismiss(),self._build_home_room(slot_index,o)))
            box.add_widget(b)
        close=DButton("CANCEL",secondary=True);close.bind(on_release=lambda *_:pop.dismiss());box.add_widget(close);pop.open()

    def _build_home_room(self, slot_index, option):
        s=self.app_ref.state
        if slot_index<0 or slot_index>=room_capacity(s.home_type) or s.home_room_slots[slot_index] or option.name in s.home_room_slots:return
        if not self._spend_build_cost(option.cash,option.wood,option.ore):return
        s.home_room_slots[slot_index]=option.name;s.home_room_data[slot_index]={}
        s.add_activity(f"You built a {option.name} inside your {s.home_type}.")
        self.app_ref.save();self.render()

    def _home_storage_put_one(self,item):
        s=self.app_ref.state
        if s.inventory.get(item,0)<=0 or self._home_storage_used()>=home_storage_capacity(s.home_type):return
        s.inventory[item]-=1;s.home_storage[item]=s.home_storage.get(item,0)+1
        s.add_activity(f"You stored 1 {item} inside your {s.home_type}.");self.app_ref.save();self.render()

    def _home_storage_take_one(self,item):
        s=self.app_ref.state
        if s.home_storage.get(item,0)<=0:return
        s.home_storage[item]-=1;s.inventory[item]=s.inventory.get(item,0)+1
        s.add_activity(f"You took 1 {item} from home storage.");self.app_ref.save();self.render()

    def _cook_meal(self):
        s=self.app_ref.state
        if s.inventory.get("Food",0)<2:return
        s.inventory["Food"]-=2;s.inventory["Cooked Meal"]=s.inventory.get("Cooked Meal",0)+1
        s.add_activity("You cooked 2 Food into 1 Cooked Meal.");self.app_ref.save();self.render()

    def _brew_beer(self):
        s=self.app_ref.state
        if s.inventory.get(BEER_KIT_ITEM,0)<=0:return
        s.inventory[BEER_KIT_ITEM]-=1;s.inventory["Homebrew Beer"]=s.inventory.get("Homebrew Beer",0)+4
        s.add_activity("You used a Beer Kit in the Kitchen and made 4 Homebrew Beer.");self.app_ref.save();self.render()

    def _relax_living_room(self,slot_index):
        s=self.app_ref.state;data=s.home_room_data[slot_index]
        if int(data.get("relaxed_day",0) or 0)==s.day:return
        data["relaxed_day"]=s.day;s.energy=min(s.max_energy,s.energy+10);s.health=min(s.max_health,s.health+5)
        s.add_activity("You relaxed in the Living Room and recovered 10 Energy and 5 Health.");self.app_ref.save();self.render()

    def _shower(self,slot_index):
        s=self.app_ref.state;data=s.home_room_data[slot_index]
        if int(data.get("showered_day",0) or 0)==s.day:return
        data["showered_day"]=s.day;s.health=min(s.max_health,s.health+10)
        s.add_activity("You took a shower and recovered 10 Health.");self.app_ref.save();self.render()

    def _spend_build_cost(self,cash,wood,ore):
        s=self.app_ref.state
        if s.cash<cash or s.wood<wood or s.ore<ore:return False
        s.cash-=cash;s.wood-=wood;s.ore-=ore;return True

    def _structure_data(self,slot_index):
        s=self.app_ref.state
        while len(s.property_slot_data)<6:s.property_slot_data.append({})
        s.property_slot_data[slot_index]=dict(s.property_slot_data[slot_index] or {})
        return s.property_slot_data[slot_index]

    def _structure_slot_has_contents(self,slot_index):
        s=self.app_ref.state
        if any(b.get("storage")=="cache" and int(b.get("structure_slot",-1))==slot_index and not b.get("linked") for b in s.crime_bodies):return True
        data=self._structure_data(slot_index)
        if any(int(q or 0)>0 for q in dict(data.get("storage",{}) or {}).values()):return True
        if list(data.get("animals",[]) or []) or list(data.get("vehicles",[]) or []):return True
        return any(v not in (None,"",0,False,[],{}) for k,v in data.items() if k not in {"storage","animals","vehicles"})

    def _choose_structure(self,slot_index):
        s=self.app_ref.state;current=s.property_slots[slot_index];blocked=bool(current) and self._structure_slot_has_contents(slot_index)
        box=BoxLayout(orientation="vertical",padding=dp(8),spacing=dp(5))
        scroll=ScrollView(do_scroll_x=False);inner=GridLayout(cols=1,spacing=dp(5),size_hint_y=None);inner.bind(minimum_height=inner.setter("height"));scroll.add_widget(inner);box.add_widget(scroll)
        pop=Popup(title=f"Property Slot {slot_index+1}",content=box,size_hint=(.96,.90))
        if blocked:inner.add_widget(DLabel(f"{current} contains saved contents. Empty it before replacing.",muted=True))
        for opt in PROPERTY_BUILDS:
            b=DButton(f"{opt.name} · ${opt.cash:,} · W{opt.wood} · O{opt.ore}")
            b.disabled=opt.name==current or blocked or not can_afford_build(s.cash,s.wood,s.ore,opt)
            b.bind(on_release=lambda _b,o=opt:(pop.dismiss(),self._build_property_slot(slot_index,o)))
            inner.add_widget(b)
        close=DButton("CANCEL",secondary=True);close.bind(on_release=lambda *_:pop.dismiss());box.add_widget(close);pop.open()

    def _build_property_slot(self,slot_index,option):
        s=self.app_ref.state;current=s.property_slots[slot_index]
        if current and self._structure_slot_has_contents(slot_index):return
        if not self._spend_build_cost(option.cash,option.wood,option.ore):return
        if current:
            try:s.property_buildings.remove(current)
            except ValueError:pass
        s.property_slots[slot_index]=option.name;self._structure_data(slot_index).clear();s.property_buildings.append(option.name)
        s.add_activity(f"You {'replaced '+current+' with' if current else 'built'} a {option.name} in property slot {slot_index+1}.")
        self.app_ref.save();self.render()

    def _render_structure(self,slot_index):
        s=self.app_ref.state
        if slot_index<0 or slot_index>=6 or not s.property_slots[slot_index]:self.structure_slot=None;self.render();return
        name=s.property_slots[slot_index];data=self._structure_data(slot_index)
        self.add_button("BACK TO PROPERTY",self._leave_structure,secondary=True)
        opt=property_option(name)
        if opt:self.add_text(opt.description,muted=True)
        if name=="Storage Shed":
            self.add_section("Storage")
            storage=dict(data.get("storage",{}) or {})
            for item,qty in sorted(storage.items()):
                if qty>0:self.add_card(item,f"Stored: {qty}","TAKE ONE",lambda i=item:self._storage_take_one(slot_index,i))
            self.add_section("Backpack")
            for item,qty in sorted(s.inventory.items()):
                if qty>0:self.add_card(item,f"Backpack: {qty}","STORE ONE",lambda i=item:self._storage_put_one(slot_index,i))
        elif name=="Garden Bed":
            planted=bool(data.get("planted")) or bool(data.get("ready_day"));ready=int(data.get("ready_day",0) or 0);crop=str(data.get("crop","Vegetables") or "Vegetables")
            if ready and s.day>=ready:self.add_button(f"HARVEST {crop.upper()}",lambda:self._harvest_garden(slot_index))
            elif not planted:
                self.add_card("EMPTY GARDEN",f"Vegetable Seeds {s.inventory.get(SEED_ITEM,0)} · Drug Seeds {s.inventory.get(DRUG_SEED_ITEM,0)}")
                self.add_button("PLANT VEGETABLE SEEDS",lambda:self._plant_garden(slot_index,SEED_ITEM),disabled=s.inventory.get(SEED_ITEM,0)<=0)
                self.add_button("PLANT DRUG SEEDS",lambda:self._plant_garden(slot_index,DRUG_SEED_ITEM),disabled=s.inventory.get(DRUG_SEED_ITEM,0)<=0,secondary=True)
            elif int(data.get("watered_day",0) or 0)==s.day:self.add_text(f"The {crop.lower()} crop is watered and will be ready tomorrow.",muted=True)
            else:self.add_button(f"WATER {crop.upper()}",lambda:self._water_garden(slot_index))
        elif name in ("Chicken Coop","Barn","Stable"):
            kind={"Chicken Coop":"Chicken","Barn":"Cow","Stable":"Horse"}[name];cap=animal_type(kind).capacity
            animals=animals_in_slot(data);typed=[(i,a) for i,a in enumerate(animals) if a.get("type")==kind]
            self.add_card(kind.upper()+"S",f"{len(typed)} / {cap}")
            for ai,a in typed:self._add_animal_card(slot_index,ai,a,show_saddle=(kind=="Horse"))
            if name=="Chicken Coop":self.add_button("COLLECT EGGS",lambda:self._collect_coop(slot_index),disabled=not typed)
            elif name=="Barn":self.add_button("MILK COWS",lambda:self._milk_barn(slot_index),disabled=not typed)
        elif name=="Well":
            used=int(data.get("drawn_day",0) or 0)==s.day;self.add_button("DRAW FROM WELL",lambda:self._draw_well(slot_index),disabled=used)
        elif name=="Garage":
            vehicles=vehicles_in_slot(data);self.add_card("GARAGE",f"Vehicles {len(vehicles)} / {GARAGE_CAPACITY}")
            for v in vehicles:
                mult=max(.01,float(v.get("travel_multiplier",.3) or .3));self.add_card(str(v.get("model","Car")),f"Condition {int(v.get('condition',100))}/100 · {1.0/mult:.1f}x walking speed")
            bodies=[b for b in s.crime_bodies if b.get("storage")=="trunk" and not b.get("linked")]
            for b in bodies:self.add_text(f"Trunk evidence: {b.get('victim','Unknown')}",muted=True)
        elif name=="Hidden Cache":
            bodies=[b for b in s.crime_bodies if b.get("storage")=="cache" and int(b.get("structure_slot",-1))==slot_index and not b.get("linked")]
            self.add_card("HIDDEN EVIDENCE",f"{len(bodies)} / {HIDDEN_CACHE_CAPACITY}")
            for b in bodies:self.add_card(str(b.get("victim","Unknown")),"Stored evidence","MOVE TO CARRY",lambda body=b:self._move_body_to_carry(body))
        else:self.add_text("Workshop crafting is not active yet.",muted=True)

    def _add_animal_card(self,slot_index,animal_index,animal,show_saddle=False):
        s=self.app_ref.state
        stats=f"Health {int(animal.get('health',100))}/100 · Happiness {int(animal.get('happiness',50))}/100 · Hunger {int(animal.get('hunger',0))}/100 · Age {int(animal.get('age',1))}"
        if animal.get("type")=="Horse":stats+=f" · Speed {float(animal.get('speed',1.2)):.2f}x · Saddle {'Yes' if animal.get('saddled') else 'No'}"
        self.add_card(str(animal.get("name",animal.get("type","Animal"))),stats)
        self.add_button("PET",lambda:self._pet_animal(slot_index,animal_index),disabled=int(animal.get("last_petted_day",0) or 0)==s.day,secondary=True)
        self.add_button("FEED",lambda:self._feed_animal(slot_index,animal_index),disabled=s.inventory.get("Food",0)<=0 or int(animal.get("last_fed_day",0) or 0)==s.day,secondary=True)
        if show_saddle:
            self.add_button("REMOVE SADDLE" if animal.get("saddled") else "EQUIP SADDLE",lambda:self._toggle_horse_saddle(slot_index,animal_index),disabled=not animal.get("saddled") and s.inventory.get("Saddle",0)<=0,secondary=True)

    def _pet_animal(self,slot_index,animal_index):
        s=self.app_ref.state;data=self._structure_data(slot_index);animals=animals_in_slot(data)
        if animal_index>=len(animals):return
        a=animals[animal_index]
        if int(a.get("last_petted_day",0) or 0)==s.day:return
        a["last_petted_day"]=s.day;a["happiness"]=min(100,int(a.get("happiness",50) or 0)+12);data["animals"]=animals
        s.add_activity(f"You spent some time with {a.get('name','your animal')}.");self.app_ref.save();self.render()

    def _feed_animal(self,slot_index,animal_index):
        s=self.app_ref.state
        if s.inventory.get("Food",0)<=0:return
        data=self._structure_data(slot_index);animals=animals_in_slot(data)
        if animal_index>=len(animals):return
        a=animals[animal_index]
        if int(a.get("last_fed_day",0) or 0)==s.day:return
        s.inventory["Food"]-=1;a["last_fed_day"]=s.day;a["hunger"]=max(0,int(a.get("hunger",0) or 0)-45);a["happiness"]=min(100,int(a.get("happiness",50) or 0)+5);data["animals"]=animals
        s.add_activity(f"You fed {a.get('name','your animal')}.");self.app_ref.save();self.render()

    def _toggle_horse_saddle(self,slot_index,animal_index):
        s=self.app_ref.state;data=self._structure_data(slot_index);animals=animals_in_slot(data)
        if animal_index>=len(animals):return
        a=animals[animal_index]
        if a.get("type")!="Horse":return
        if a.get("saddled"):a["saddled"]=False;s.inventory["Saddle"]=s.inventory.get("Saddle",0)+1;msg=f"You removed the saddle from {a.get('name','your horse')}."
        else:
            if s.inventory.get("Saddle",0)<=0:return
            s.inventory["Saddle"]-=1;a["saddled"]=True;msg=f"You saddled {a.get('name','your horse')}. Horse travel is now available."
        data["animals"]=animals;s.add_activity(msg);self.app_ref.save();self.render()

    def _storage_put_one(self,slot_index,item):
        s=self.app_ref.state
        if s.inventory.get(item,0)<=0:return
        data=self._structure_data(slot_index);storage=dict(data.get("storage",{}) or {});s.inventory[item]-=1;storage[item]=storage.get(item,0)+1;data["storage"]=storage
        s.add_activity(f"You stored 1 {item} in your Storage Shed.");self.app_ref.save();self.render()

    def _storage_take_one(self,slot_index,item):
        s=self.app_ref.state;data=self._structure_data(slot_index);storage=dict(data.get("storage",{}) or {})
        if storage.get(item,0)<=0:return
        storage[item]-=1;s.inventory[item]=s.inventory.get(item,0)+1;data["storage"]=storage;s.add_activity(f"You took 1 {item} from your Storage Shed.");self.app_ref.save();self.render()

    def _plant_garden(self,slot_index,seed_item=SEED_ITEM):
        s=self.app_ref.state
        if s.inventory.get(seed_item,0)<=0:return
        data=self._structure_data(slot_index)
        if data.get("planted") or data.get("ready_day"):return
        s.inventory[seed_item]-=1;data["planted"]=True;data["crop"]="Drugs" if seed_item==DRUG_SEED_ITEM else "Vegetables";s.add_activity(f"You planted {seed_item} in a Garden Bed.");self.app_ref.save();self.render()

    def _water_garden(self,slot_index):
        s=self.app_ref.state;data=self._structure_data(slot_index)
        if not data.get("planted") and not data.get("ready_day"):return
        data["watered_day"]=s.day;data["ready_day"]=s.day+1;s.add_activity("You watered a Garden Bed.");self.app_ref.save();self.render()

    def _harvest_garden(self,slot_index):
        s=self.app_ref.state;data=self._structure_data(slot_index)
        if not data.get("ready_day") or s.day<int(data["ready_day"]):return
        if str(data.get("crop","Vegetables"))=="Drugs":s.inventory[DRUG_ITEM]=s.inventory.get(DRUG_ITEM,0)+3;msg="You harvested 3 Drugs from a Garden Bed."
        else:s.inventory["Food"]=s.inventory.get("Food",0)+4;msg="You harvested 4 Food from a Garden Bed."
        data.clear();s.add_activity(msg);self.app_ref.save();self.render()

    def _collect_coop(self,slot_index):
        s=self.app_ref.state;data=self._structure_data(slot_index);animals=animals_in_slot(data);produced=0
        for a in animals:
            if a.get("type")!="Chicken" or int(a.get("last_product_day",0) or 0)==s.day or int(a.get("hunger",0) or 0)>=90:continue
            a["last_product_day"]=s.day;produced+=1
        data["animals"]=animals
        if produced:s.inventory["Food"]=s.inventory.get("Food",0)+produced;s.add_activity(f"You collected eggs and gained {produced} Food.")
        self.app_ref.save();self.render()

    def _milk_barn(self,slot_index):
        s=self.app_ref.state;data=self._structure_data(slot_index);animals=animals_in_slot(data);produced=0
        for a in animals:
            if a.get("type")!="Cow" or int(a.get("last_product_day",0) or 0)==s.day or int(a.get("hunger",0) or 0)>=90:continue
            a["last_product_day"]=s.day;produced+=2
        data["animals"]=animals
        if produced:s.inventory["Milk"]=s.inventory.get("Milk",0)+produced;s.add_activity(f"You milked your cows and gained {produced} Milk.")
        self.app_ref.save();self.render()

    def _draw_well(self,slot_index):
        s=self.app_ref.state;data=self._structure_data(slot_index)
        if int(data.get("drawn_day",0) or 0)==s.day:return
        data["drawn_day"]=s.day;s.inventory["Water"]=s.inventory.get("Water",0)+2;msg="You drew 2 Water from the Well."
        rng=random.Random(s.day*1009+slot_index*97+s.lot_number);roll=rng.random()
        if roll<.12:bonus=rng.randint(5,20);s.cash+=bonus;msg+=f" You also found ${bonus} in old coins."
        elif roll<.22:s.inventory["Food"]=s.inventory.get("Food",0)+1;msg+=" You also found 1 sealed Food item."
        s.add_activity(msg);self.app_ref.save();self.render()

    def _sleep(self, bedroom=False):
        s = self.app_ref.state
        sleep_until_morning(s, health_recovery=30 if bedroom else 20)
        self.app_ref.save()
        self.home_inside = False
        self.home_room_slot = None
        self.structure_slot = None
        self.render()
        self.app_ref.notice("You wake at 8:00 AM with restored Energy." + (" The Bedroom improved Health recovery." if bedroom else ""))

    def _build_home(self, option):
        s = self.app_ref.state
        if not can_afford_build(s.cash, s.wood, s.ore, option):
            return
        live_in = any(str(ensure_relationship(s,name).get("romance","None")) in ("Intimate","Married") for name in s.relationships)
        if live_in and not allows_live_in_partner(option.name):
            self.app_ref.notice("A live-in partner or spouse requires at least a Shack.")
            return
        if len(s.children) > child_capacity(option.name):
            self.app_ref.notice(f"Your household has {len(s.children)} child(ren), but a {option.name} only supports {child_capacity(option.name)}.")
            return
        s.cash -= option.cash
        s.wood -= option.wood
        s.ore -= option.ore
        old=s.home_type
        s.home_type = option.name
        s.add_activity(f"You replaced your {old} with a {option.name}.")
        self.app_ref.save()
        self.render()

    def render_character(self):
        s = self.app_ref.state
        self.add_title("CHARACTER")
        self.add_card("IDENTITY", f"{s.character_name} · Age {s.age} · {s.race}\nHome: {s.home_type} · Location: {s.current_location}")
        self.add_section("Stats")
        self.add_card("PHYSICAL", f"Strength {s.strength} · Endurance {s.endurance} · Agility {s.agility}\nIntelligence {s.intelligence} · Perception {s.perception}")
        self.add_card("SKILLS", f"Woodcutting {s.woodcutting_level} · Mining {s.mining_level} · Hunting {s.hunting_level}")
        self.add_section("Vice")
        self.add_card("STATUS", f"Drunkenness {s.drunk_level}/5 · Addiction {s.addiction}/100 · Drug uses {s.drugs_used_total}")
        self.add_section("Education")
        quals = ", ".join(s.qualifications) if s.qualifications else "None"
        self.add_card("QUALIFICATIONS", quals + f"\nStudent loan: ${s.student_loan_balance:,.2f}")
        self.add_section("Criminal record")
        crimes = [f"{k}: {v}" for k, v in s.crime_record.items() if int(v or 0) > 0 and not k.endswith("Day")]
        self.add_card("RECORD", "\n".join(crimes) if crimes else "No recorded offenses.")
        self.add_section("Recent activity")
        for item in s.activity_log[:8]:
            self.add_text(item, muted=True)

    def render_inventory(self):
        s = self.app_ref.state
        self.add_title("INVENTORY")
        self.add_section("Equipped")
        for slot, item in s.equipment.items():
            display = item if item not in ("Nothing", "None", "") else "Empty"
            action = None
            if display != "Empty":
                action = lambda sl=slot: self._unequip(sl)
            self.add_card(slot, display, "UNEQUIP" if action else None, action)
        self.add_section("Backpack")
        items = [(name, qty) for name, qty in sorted(s.inventory.items(), key=lambda p: p[0].lower()) if qty > 0]
        if not items:
            self.add_text("Your backpack is empty.", muted=True)
            return
        for item, qty in items:
            action_text, action = self._inventory_action(item)
            self.add_card(item, f"Quantity: {qty} · {self._item_detail(item)}", action_text, action)

    def _item_detail(self, item):
        slot = clothing_slot(item)
        if item in DUNGEON_ARMOR:
            return f"{slot} · Dungeon Defense +{DUNGEON_ARMOR[item][1]}"
        if item in GUN_ARMOR:
            return f"{slot} · Combat Defense +{GUN_ARMOR[item][1]}"
        if item in DUNGEON_WEAPONS:
            return f"Weapon · Attack +{DUNGEON_WEAPONS[item]}"
        if item in GUN_WEAPONS:
            return f"Weapon · Attack +{GUN_WEAPONS[item]}"
        if slot:
            return f"Clothing · {slot}"
        details = {
            "Food": "Restores 10 Energy",
            "Water": "Restores 5 Energy",
            "Milk": "Restores 8 Energy",
            "Cooked Meal": "Restores 25 Energy",
            "Beer": "Raises drunkenness",
            "Homebrew Beer": "Drink or sell at Farmers Market",
            DRUG_ITEM: "Vice item · raises addiction pressure",
            DRUG_SEED_ITEM: "Plantable contraband crop",
            BEER_KIT_ITEM: "Kitchen brewing supply",
        }
        return details.get(item, "General item")

    def _inventory_action(self, item):
        if clothing_slot(item):
            return "EQUIP", lambda i=item: self._equip(i)
        if item in DUNGEON_WEAPONS or item in GUN_WEAPONS:
            return "EQUIP", lambda i=item: self._equip_weapon(i)
        if item in ("Food", "Water", "Milk", "Cooked Meal", "Beer", "Homebrew Beer", DRUG_ITEM):
            return "USE", lambda i=item: self._use_item(i)
        return None, None

    def _equip(self, item):
        ok, msg = equip_clothing(self.app_ref.state, item)
        if ok:
            self.app_ref.save()
            self.render()
        else:
            self.app_ref.notice(msg)

    def _unequip(self, slot):
        s = self.app_ref.state
        if slot == "Weapon":
            item = s.equipment.get("Weapon", "None")
            if item not in ("None", "Nothing", ""):
                s.inventory[item] = s.inventory.get(item, 0) + 1
                s.equipment["Weapon"] = "None"
                s.add_activity(f"You unequipped {item}.")
                self.app_ref.save(); self.render()
            return
        ok, msg = unequip_clothing(s, slot)
        if ok:
            self.app_ref.save(); self.render()
        else:
            self.app_ref.notice(msg)

    def _equip_weapon(self, item):
        s = self.app_ref.state
        if s.inventory.get(item, 0) <= 0:
            return
        old = s.equipment.get("Weapon", "None")
        s.inventory[item] -= 1
        if old not in ("None", "Nothing", ""):
            s.inventory[old] = s.inventory.get(old, 0) + 1
        s.equipment["Weapon"] = item
        s.add_activity(f"You equipped {item}.")
        self.app_ref.save(); self.render()

    def _use_item(self, item):
        s = self.app_ref.state
        if s.inventory.get(item, 0) <= 0:
            return
        if item == "Food":
            s.energy = min(s.max_energy, s.energy + 10); msg = "You ate Food. Energy +10."
        elif item == "Water":
            s.energy = min(s.max_energy, s.energy + 5); msg = "You drank Water. Energy +5."
        elif item == "Milk":
            s.energy = min(s.max_energy, s.energy + 8); msg = "You drank Milk. Energy +8."
        elif item == "Cooked Meal":
            s.energy = min(s.max_energy, s.energy + 25); msg = "You ate a Cooked Meal. Energy +25."
        elif item in ("Beer", "Homebrew Beer"):
            msg = drink_beer(s)
        else:
            msg = use_drugs(s)
        s.inventory[item] -= 1
        s.add_activity(msg)
        self.app_ref.save(); self.render()
        self.app_ref.notice(msg)

    def render_jobs(self):
        s = self.app_ref.state
        self.add_title("JOBS")
        if s.active_job_name:
            remain = max(0, int(s.active_job_end_ts - time.time() + .999))
            self.add_card("CURRENT SHIFT", f"{s.active_job_name} · {remain}s remaining")
        casual = [
            ("Dishwasher", 14, 8, True, "None"),
            ("Janitor", 15, 7, True, "None"),
            ("Cashier", 16, 6, True, "None"),
            ("Delivery Helper", 17, 8, True, "None"),
            ("Barback", 17, 8, s.endurance >= 6, "Endurance 6"),
            ("Warehouse Worker", 18, 10, s.strength >= 7, "Strength 7"),
            ("Landscaping Crew", 19, 11, s.strength >= 6, "Strength 6"),
            ("Security Guard", 20, 6, s.perception >= 8, "Perception 8"),
        ]
        careers = [
            ("Office Administrator", 220, 25, "Office Administration Certificate"),
            ("IT Support Technician", 300, 30, "IT Support Certificate"),
            ("Bookkeeper", 340, 28, "Bookkeeping Diploma"),
            ("Medical Receptionist", 290, 26, "Medical Office Certificate"),
        ]
        self.add_section("Casual jobs")
        for name, pay, energy, unlocked, req in casual:
            disabled = (not unlocked) or s.energy < energy or bool(s.active_job_name or s.active_forge_name)
            self.add_card(name, f"${pay}/hour · Energy {energy} · Requirement: {req}", "WORK 1 HOUR", lambda n=name,p=pay,e=energy:self._start_job(n,p,e,1,60), disabled)
        self.add_section("Full-time careers")
        for name, pay, energy, qual in careers:
            unlocked = has_qualification(s, qual)
            disabled = (not unlocked) or s.energy < energy or bool(s.active_job_name or s.active_forge_name)
            self.add_card(name, f"${pay}/shift · 8 hours · Energy {energy} · {qual}", "WORK FULL SHIFT", lambda n=name,p=pay,e=energy:self._start_job(n,p,e,8,120), disabled)

    def _start_job(self, name, pay, energy, hours, seconds):
        s = self.app_ref.state
        if s.active_job_name or s.active_forge_name or s.energy < energy:
            return
        s.active_job_name = name; s.active_job_pay = pay; s.active_job_energy = energy
        s.active_job_hours = hours; s.active_job_end_ts = time.time() + seconds
        s.add_activity(f"You started a {hours}-hour shift as a {name}.")
        self.app_ref.save(); self.render()

    def render_forge(self):
        s = self.app_ref.state
        self.add_title("FORGE")
        if s.active_forge_name:
            remain = max(0, int(s.active_forge_end_ts - time.time() + .999))
            self.add_card("CURRENT ACTIVITY", f"{s.active_forge_name} · {remain}s remaining")
        data = [
            ("Cut Trees", "Wood Axe", 5),
            ("Mine Ore", "Pickaxe", 6),
            ("Hunt Animals", "Hunting Bow or Hunting Rifle", 8),
        ]
        for name, requirement, energy in data:
            tool_ok = self._forge_tool_ok(name)
            disabled = not tool_ok or s.energy < energy or bool(s.active_job_name or s.active_forge_name)
            self.add_card(name, f"Energy {energy} · Requires {requirement}", "START", lambda n=name,e=energy:self._start_forge(n,e), disabled)

    def _forge_tool_ok(self, name):
        s = self.app_ref.state
        if name == "Cut Trees": return s.inventory.get("Wood Axe",0)>0
        if name == "Mine Ore": return s.inventory.get("Pickaxe",0)>0
        return s.inventory.get("Hunting Bow",0)>0 or s.inventory.get("Hunting Rifle",0)>0

    def _start_forge(self, name, energy):
        s = self.app_ref.state
        if s.active_job_name or s.active_forge_name or s.energy < energy or not self._forge_tool_ok(name): return
        s.active_forge_name=name; s.active_forge_energy=energy; s.active_forge_end_ts=time.time()+60
        s.add_activity(f"You started {name.lower()} for 1 hour.")
        self.app_ref.save(); self.render()

    def render_map(self):
        s = self.app_ref.state
        self.add_title("MAP")
        self.add_text(f"Current location: {s.current_location}", muted=True)
        if s.current_location != "Home":
            self.add_button(f"OPEN {s.current_location.upper()}", self._open_current_location)
        self.add_section("Destinations")
        for location in LOCATION_DISTANCE_KM:
            if location == s.current_location:
                continue
            distance = LOCATION_DISTANCE_KM[location]
            self.add_card(location, f"{distance:.1f} km", "TRAVEL", lambda loc=location:self._choose_travel(loc))

    def _open_current_location(self):
        self.location_view = True; self.render()

    def _choose_travel(self, destination):
        s = self.app_ref.state
        box = BoxLayout(orientation="vertical", spacing=dp(8), padding=dp(12))
        pop = Popup(title=f"Travel to {destination}", content=box, size_hint=(.92,.72))
        for method in available_travel_methods(s):
            sec = travel_seconds(destination, method); mins = travel_game_minutes(destination, method)
            b = DButton(f"{method.name} · {sec}s · {mins} game min")
            b.bind(on_release=lambda _b,m=method: (pop.dismiss(), self.app_ref.start_travel(destination,m)))
            box.add_widget(b)
        cancel = DButton("CANCEL", secondary=True); cancel.bind(on_release=lambda *_:pop.dismiss()); box.add_widget(cancel)
        pop.open()

    def render_location(self):
        s = self.app_ref.state
        loc = s.current_location
        self.add_title(loc.upper())
        self.add_button("BACK TO MAP", lambda:self.navigate("Map"), secondary=True)
        self._location_actions(loc)
        self.add_section("People here")
        people = [npc for npc in npcs_for_location(loc, s.day, s.hour) if npc.name not in s.dead_npcs]
        if not people:
            self.add_text("No one is around right now.", muted=True)
        for npc in people:
            self.add_card(npc.name, npc.description, "TALK", lambda n=npc:self._talk(n))

    def _talk(self, npc):
        s=self.app_ref.state
        ensure_relationship(s,npc.name)
        outer=BoxLayout(orientation="vertical",padding=dp(10),spacing=dp(7))
        scroll=ScrollView(do_scroll_x=False)
        inner=GridLayout(cols=1,spacing=dp(6),size_hint_y=None);inner.bind(minimum_height=inner.setter("height"));scroll.add_widget(inner);outer.add_widget(scroll)
        pop=Popup(title=npc.name,content=outer,size_hint=(.96,.92))
        inner.add_widget(DLabel(f"Age {npc.age} · {relationship_status(s,npc.name)} · Score {relationship_score(s,npc.name)}",muted=True))
        inner.add_widget(DLabel(npc.description,muted=True))
        message=DLabel(random.choice(npc.dialogue) if npc.dialogue else "...");inner.add_widget(message)
        def finish(text):
            self.app_ref.save();pop.dismiss();self.render();self.app_ref.notice(text,npc.name)
        def score_action(action,delta,text,romance=None):
            ok,result=apply_score_action(s,npc.name,action,delta)
            if ok and romance:set_romance(s,npc.name,romance)
            if ok:s.add_activity(text)
            finish(text if ok else result)
        b=DButton("TALK")
        def do_talk(*_):
            if carried_bodies(s) and witness_roll(s,npc.name,"CarriedBodyDiscovery"):
                body=carried_bodies(s)[0];body["linked"]=True;victim=str(body.get("victim","Unknown"));arrest(s,MURDER_JAIL_DAYS,f"carrying evidence linked to {victim}'s murder")
                msg=f"{npc.name} notices the body evidence you are carrying and reports you. You are arrested for murder.";s.add_activity(msg);self.app_ref.save();pop.dismiss();self.page="Jail";self.location_view=False;self.render();self.app_ref.notice(msg,"Crime");return
            score_action("Talk",5,f"You talked with {npc.name}.")
        b.bind(on_release=do_talk);inner.add_widget(b)
        b=DButton("ADD TO CONTACTS",secondary=True);b.disabled=relationship_score(s,npc.name)<CONTACT_SCORE or npc.name in s.contacts
        def contact(*_):
            ok,msg=add_contact(s,npc.name)
            if ok:s.add_activity(f"You added {npc.name} to your Phone contacts.")
            finish(msg)
        b.bind(on_release=contact);inner.add_widget(b)
        adults=s.age>=18 and npc.age>=18
        if npc.romanceable:
            romance=str(ensure_relationship(s,npc.name).get("romance","None"))
            b=DButton("FLIRT",secondary=True);b.disabled=not adults or relationship_score(s,npc.name)<FLIRT_SCORE;b.bind(on_release=lambda *_:score_action("Flirt",7,f"You flirted with {npc.name}.","Flirting"));inner.add_widget(b)
            b=DButton("GO ON A DATE",secondary=True);b.disabled=not adults or relationship_score(s,npc.name)<DATE_SCORE or romance not in ("Flirting","Dating","Intimate","Married");b.bind(on_release=lambda *_:score_action("Date",10,f"You went on a date with {npc.name}.","Dating"));inner.add_widget(b)
            b=DButton("GET INTIMATE",secondary=True);b.disabled=not adults or relationship_score(s,npc.name)<INTIMATE_SCORE or romance not in ("Dating","Intimate","Married") or (not allows_live_in_partner(s.home_type) and romance not in ("Intimate","Married"));b.bind(on_release=lambda *_:score_action("Intimate",8,f"You and {npc.name} shared a private moment together.",None if romance=="Married" else "Intimate"));inner.add_widget(b)
            b=DButton("PROPOSE MARRIAGE",secondary=True);b.disabled=not adults or relationship_score(s,npc.name)<MARRY_SCORE or romance not in ("Dating","Intimate") or not allows_live_in_partner(s.home_type)
            def marry(*_):
                set_romance(s,npc.name,"Married");ensure_relationship(s,npc.name)["score"]=max(MARRY_SCORE,relationship_score(s,npc.name))
                if npc.name not in s.contacts:s.contacts.append(npc.name)
                s.add_activity(f"You married {npc.name}.");finish(f"{npc.name} said yes. You are now married.")
            b.bind(on_release=marry);inner.add_widget(b)
            if romance=="Married":
                b=DButton("START / GROW FAMILY",secondary=True);b.disabled=len(s.children)>=child_capacity(s.home_type)
                def family(*_):
                    if len(s.children)>=child_capacity(s.home_type):finish("Upgrade your home before growing the family further.");return
                    ok,result=apply_score_action(s,npc.name,"Family",3)
                    if not ok:finish(result);return
                    child=make_child(s,npc.name);s.add_activity(f"You and {npc.name} welcomed {child['name']} into the family.");finish(f"Welcome, {child['name']}.")
                b.bind(on_release=family);inner.add_widget(b)
        b=DButton("ARGUE",secondary=True);b.bind(on_release=lambda *_:score_action("Argue",-15,f"You argued with {npc.name}."));inner.add_widget(b)
        inner.add_widget(DLabel("CRIME",small=True))
        for crime in ("Pickpocket","Theft","Murder"):
            b=DButton(crime.upper(),danger=(crime=="Murder"),secondary=(crime!="Murder"));b.bind(on_release=lambda _b,c=crime:self._commit_npc_crime(pop,npc,c));inner.add_widget(b)
        close=DButton("LEAVE",secondary=True);close.bind(on_release=lambda *_:pop.dismiss());outer.add_widget(close);pop.open()

    def _location_actions(self, loc):
        s = self.app_ref.state
        if loc == "Grocery Store":
            self.add_section("Shop")
            for item, price, desc in (("Food",5,"Restores 10 Energy"),("Water",2,"Restores 5 Energy"),(SEED_ITEM,4,"Garden Bed seeds"),(BEER_KIT_ITEM,BEER_KIT_PRICE,"Kitchen brewing supply")):self._shop_item(item,price,desc)
        elif loc == "Main Street Threads":
            for section, items in FASHION_STORE_SECTIONS.items():
                self.add_section(section)
                for item, price, desc in items:self._shop_item(item,price,desc)
        elif loc == "Gus' Gunporium":
            self.add_text("Fictional RPG weapons and protective gear.", muted=True)
            for item in GUNPORIUM_ITEMS:self._shop_item(item.name,item.price,item.description)
        elif loc == "Outdoors Specials":
            for item, price in OUTDOORS_SPECIALS_ITEMS:self._shop_item(item,price,"Outdoor equipment")
            self._themed_clothes(loc)
        elif loc == "Old McDonald's Farm Supplies":
            self.add_section("Animals")
            for animal in ANIMAL_TYPES:
                self.add_card(animal.name,f"${animal.price:,} · Requires {animal.structure} · Capacity {animal.capacity}\n{animal.description}","BUY",lambda a=animal:self._buy_animal_prompt(a),s.cash<animal.price or self._find_structure_for_animal(animal.structure,animal.capacity) is None)
            self.add_section("Tack");self._shop_item("Saddle",SADDLE_PRICE,"Equip to a Horse to unlock horse travel");self._themed_clothes(loc)
        elif loc == "Carl's Cars":
            self.add_section("Vehicles")
            for v in VEHICLE_TYPES:
                garage=self._find_garage_for_vehicle();self.add_card(v.name,f"${v.price:,} · {v.speed_text} · Seats {v.seats}\n{v.description}","BUY",lambda model=v.name:self._buy_vehicle(model),s.cash<v.price or garage is None)
            self._themed_clothes(loc)
        elif loc == "The Drunken Donkey":
            self.add_text("Beer, fried food, pub merch, and one extremely questionable corner.", muted=True)
            self._shop_item("Beer",4,"Raises drunkenness");self._shop_item(DRUG_SEED_ITEM,DRUG_SEED_PRICE,"Suspicious abstract seeds")
            self.add_button("BUY MEAL · $10 · +20 ENERGY",self._buy_meal,disabled=s.cash<10)
            self.add_button(f"SELL 1 DRUG · ${DRUG_SALE_PRICE}",self._sell_drug,disabled=s.inventory.get(DRUG_ITEM,0)<=0);self._themed_clothes(loc)
        elif loc == "Farmers Market":
            self.add_button(f"SELL HOMEBREW · ${FARMERS_MARKET_BEER_PRICE}",self._sell_homebrew,disabled=s.inventory.get("Homebrew Beer",0)<=0);self._themed_clothes(loc)
        elif loc == "Bank":
            self.add_card("BANKING",f"Cash ${s.cash:,.2f}\nBank ${s.bank_balance:,.2f}")
            self.add_button("DEPOSIT",lambda:self._amount_popup("Deposit",int(s.cash),lambda amount:self._bank(amount,True)),disabled=s.cash<1);self.add_button("WITHDRAW",lambda:self._amount_popup("Withdraw",int(s.bank_balance),lambda amount:self._bank(amount,False)),disabled=s.bank_balance<1,secondary=True)
        elif loc == "Gym":
            for stat in ("strength","endurance","agility"):self.add_button(f"TRAIN {stat.upper()} · 10 ENERGY",lambda st=stat:self._train(st),disabled=s.energy<10 or bool(s.active_job_name or s.active_forge_name))
        elif loc == "Education Center":self._education();self._themed_clothes(loc)
        elif loc == "Lucky Horseshoe Casino":self._casino();self._themed_clothes(loc)
        elif loc == "Riverside Park":
            self.add_button("WALK AROUND · 30 MIN",self._walk_park)
            self.add_button("BURY CARRIED BODY EVIDENCE",self._bury_body_at_park,disabled=not bool(carried_bodies(s)),danger=True)
            self.add_button(f"SELL 1 DRUG · ${DRUG_SALE_PRICE}",self._sell_drug,disabled=s.inventory.get(DRUG_ITEM,0)<=0)
        elif loc == "Police Station":
            ensure_crime_state(s);self.add_card("RECEPTION DESK","Records, fines, and the long administrative shadow of bad decisions.","VIEW MY RECORD",self._show_crime_record)
        elif loc == "Jail":self.render_jail()
        elif loc == "The Fighting Pits":self._fighting_pits()
        elif loc == "The Dungeon":self._dungeon()
        elif loc == "Home":self.navigate("Home")
        elif loc in LOCATION_CLOTHING_SHOPS:self._themed_clothes(loc)
        else:self.add_text("No special interactions here yet.",muted=True)

    def _find_structure_for_animal(self,structure_name,capacity):
        s=self.app_ref.state
        for idx,name in enumerate(s.property_slots):
            if name==structure_name and len([a for a in animals_in_slot(self._structure_data(idx)) if a.get("type")])<capacity:return idx
        return None

    def _buy_animal_prompt(self,animal_def):
        s=self.app_ref.state;slot=self._find_structure_for_animal(animal_def.structure,animal_def.capacity)
        if slot is None or s.cash<animal_def.price:return
        box=BoxLayout(orientation="vertical",padding=dp(12),spacing=dp(8));box.add_widget(DLabel(f"{animal_def.name} · ${animal_def.price:,}\n{animal_def.description}",muted=True));name=TextInput(multiline=False,hint_text=f"Name your {animal_def.name.lower()}",size_hint_y=None,height=dp(48));box.add_widget(name)
        pop=Popup(title=f"Buy {animal_def.name}",content=box,size_hint=(.92,.55));buy=DButton("BUY");cancel=DButton("CANCEL",secondary=True);box.add_widget(buy);box.add_widget(cancel)
        def confirm(*_):
            chosen=name.text.strip()
            if not chosen:self.app_ref.notice("Give the animal a name first.");return
            slot2=self._find_structure_for_animal(animal_def.structure,animal_def.capacity)
            if slot2 is None or s.cash<animal_def.price:pop.dismiss();return
            draft=make_animal(animal_def.name,chosen[:32],int(time.time()*1000)^(s.day*10007)^(s.lot_number*101));data=self._structure_data(slot2);animals=animals_in_slot(data);animals.append(draft);data["animals"]=animals;s.cash-=animal_def.price;s.add_activity(f"You bought a {animal_def.name} named {draft['name']} for ${animal_def.price}.");self.app_ref.save();pop.dismiss();self.render()
        buy.bind(on_release=confirm);cancel.bind(on_release=lambda *_:pop.dismiss());pop.open()

    def _find_garage_for_vehicle(self):
        s=self.app_ref.state
        for idx,name in enumerate(s.property_slots):
            if name=="Garage" and len(vehicles_in_slot(self._structure_data(idx)))<GARAGE_CAPACITY:return idx
        return None

    def _buy_vehicle(self,model):
        s=self.app_ref.state;definition=vehicle_type(model);slot=self._find_garage_for_vehicle()
        if not definition or slot is None or s.cash<definition.price:return
        vehicle=make_vehicle(model,int(time.time()*1000)^(s.day*65537)^(s.lot_number*313));data=self._structure_data(slot);owned=vehicles_in_slot(data);owned.append(vehicle);data["vehicles"]=owned;s.cash-=definition.price;s.add_activity(f"You bought a {definition.name} from Carl's Cars for ${definition.price:,}.");self.app_ref.save();self.render()

    def _buy_meal(self):
        s=self.app_ref.state
        if s.cash<10:return
        s.cash-=10;s.energy=min(s.max_energy,s.energy+20);s.add_activity("You bought a meal at The Drunken Donkey for $10 and restored 20 Energy.");self.app_ref.save();self.render()

    def _fighting_pits(self):
        s=self.app_ref.state
        self.add_card("COMBAT RECORD",f"{s.combat_wins} wins / {s.combat_losses} losses")
        if self.combat_enemy is None:
            self.add_button("FIND A FIGHT",self._start_combat,disabled=s.health<=10)
            if s.health<=10:self.add_text("Recover above 10 Health before fighting.",muted=True)
            return
        e=self.combat_enemy;self.add_card("CURRENT FIGHT",f"You {s.health}/{s.max_health} HP\n{e.name} {e.health}/{e.max_health} HP\n{self.combat_message}")
        self.add_button("PUNCH",lambda:self._combat_move("Punch"));self.add_button("HEAVY HIT",lambda:self._combat_move("Heavy Hit"));self.add_button("RUN",self._run_from_combat,secondary=True)

    def _start_combat(self):
        s=self.app_ref.state
        if s.health<=10:return
        self.combat_enemy=make_random_enemy();self.combat_message=f"A {self.combat_enemy.name} wants to fight.";s.add_activity(f"You got into a fight with a {self.combat_enemy.name}.");self.app_ref.save();self.render()

    def _combat_move(self,move):
        s=self.app_ref.state;e=self.combat_enemy
        if not e:return
        _hit,damage,text=player_attack_damage(s,move);e.health=max(0,e.health-damage);lines=[text]
        if e.health<=0:
            s.cash+=e.cash_reward;s.combat_wins+=1;advance_minutes(s,10);lines.append(f"You won and found ${e.cash_reward}.");s.add_activity(f"You defeated {e.name} and earned ${e.cash_reward}.");self.combat_enemy=None;self.combat_message="";self.app_ref.save();self.render();self.app_ref.notice("\n".join(lines),"Fighting Pits");return
        dmg=enemy_attack_damage(e,s);s.health=max(0,s.health-dmg);lines.append(f"{e.name} hit you for {dmg} damage.")
        if s.health<=0:
            s.combat_losses+=1;s.health=10;advance_minutes(s,60);lines.append("You lost. You come to later with 10 Health.");s.add_activity(f"You lost a fight against {e.name}.");self.combat_enemy=None
        self.combat_message="\n".join(lines);self.app_ref.save();self.render()

    def _run_from_combat(self):
        s=self.app_ref.state;e=self.combat_enemy
        if not e:return
        s.add_activity(f"You ran away from {e.name}.");self.combat_enemy=None;self.combat_message="";advance_minutes(s,5);self.app_ref.save();self.render()

    def _commit_npc_crime(self,pop,npc,crime_name):
        s=self.app_ref.state;ensure_crime_state(s)
        if npc.name in s.dead_npcs:return
        witnessed=witness_roll(s,npc.name,crime_name)
        if crime_name=="Murder":
            people=[p for p in npcs_for_location(s.current_location,s.day,s.hour) if p.name not in s.dead_npcs];witnessed=len(people)>1
        if crime_name=="Pickpocket":
            s.crime_record["Pickpocket"]+=1
            if witnessed:s.cash=max(0,s.cash-PICKPOCKET_FINE);msg=f"You were caught pickpocketing {npc.name}. Fine: ${PICKPOCKET_FINE:,}."
            else:rng=random.Random(f"pick-{s.day}-{npc.name}-{len(s.activity_log)}");amount=rng.randint(20,140);s.cash+=amount;msg=f"You picked {npc.name}'s pocket and got ${amount}."
        elif crime_name=="Theft":
            s.crime_record["Theft"]+=1
            if witnessed:arrest(s,THEFT_JAIL_DAYS,"theft");msg="You were caught stealing and sentenced to 1 day in jail."
            else:rng=random.Random(f"steal-{s.day}-{npc.name}-{len(s.activity_log)}");item=rng.choice(["Food","Water","Beer"]);s.inventory[item]=s.inventory.get(item,0)+1;msg=f"You stole 1 {item} without being identified."
        else:
            s.crime_record["Murder"]+=1;s.dead_npcs.append(npc.name);s.contacts=[n for n in s.contacts if n!=npc.name];body=add_body_evidence(s,npc.name)
            if witnessed:body.update({"linked":True,"storage":"police","vehicle":"","structure_slot":-1,"carry_discovery_ts":0.0});arrest(s,MURDER_JAIL_DAYS,"murder");msg=f"A witness identified you after {npc.name}'s death. Police seized the evidence and you received 7 days in jail."
            else:msg=f"{npc.name} is dead. The body is being carried as unresolved evidence."
        s.add_activity(msg);self.app_ref.save();pop.dismiss()
        if s.jail_days_remaining>0:self.page="Jail";self.location_view=False
        self.render();self.app_ref.notice(msg,"Crime")

    def render_crime(self):
        s=self.app_ref.state;ensure_crime_state(s);self.add_title("CRIME")
        self.add_card("CRIMINAL RECORD",f"Pickpocket {s.crime_record.get('Pickpocket',0)} · Theft {s.crime_record.get('Theft',0)} · Murder {s.crime_record.get('Murder',0)} · Arrests {s.crime_record.get('Arrests',0)}\nSentence: {s.jail_days_remaining} day(s)")
        self.add_section("Unresolved body evidence")
        unresolved=[b for b in s.crime_bodies if not b.get("linked")]
        if not unresolved:self.add_text("No unresolved body evidence.",muted=True)
        for body in unresolved:
            storage=str(body.get("storage","carried"));label={"carried":"Carried","trunk":"Vehicle trunk","park":"Buried at Riverside Park","cache":"Hidden Cache"}.get(storage,storage);self.add_card(str(body.get("victim","Unknown")),f"Location: {label}")
            if storage=="carried":
                self.add_button("MOVE TO VEHICLE TRUNK",lambda b=body:self._move_body_to_trunk(b),disabled=self._first_owned_vehicle_name() is None,secondary=True)
                self.add_button("MOVE TO HIDDEN CACHE",lambda b=body:self._move_body_to_cache(b),disabled=self._find_hidden_cache_space() is None,secondary=True)
            elif storage in ("trunk","cache"):self.add_button("MOVE TO CARRY",lambda b=body:self._move_body_to_carry(b),secondary=True)

    def _first_owned_vehicle_name(self):
        s=self.app_ref.state
        for idx,name in enumerate(s.property_slots):
            if name=="Garage":
                vs=vehicles_in_slot(self._structure_data(idx))
                if vs:return str(vs[0].get("model","Car"))
        return None

    def _find_hidden_cache_space(self):
        s=self.app_ref.state
        for idx,name in enumerate(s.property_slots):
            if name=="Hidden Cache":
                count=sum(1 for b in s.crime_bodies if b.get("storage")=="cache" and int(b.get("structure_slot",-1))==idx and not b.get("linked"))
                if count<HIDDEN_CACHE_CAPACITY:return idx
        return None

    def _move_body_to_trunk(self,body):
        v=self._first_owned_vehicle_name()
        if not v:return
        body.update({"storage":"trunk","vehicle":v,"structure_slot":-1});self.app_ref.state.add_activity(f"You moved evidence linked to {body.get('victim','Unknown')} into a vehicle trunk.");self.app_ref.save();self.render()

    def _move_body_to_cache(self,body):
        slot=self._find_hidden_cache_space()
        if slot is None:return
        body.update({"storage":"cache","structure_slot":slot,"vehicle":""});self.app_ref.state.add_activity(f"You moved evidence linked to {body.get('victim','Unknown')} into Hidden Cache slot {slot+1}.");self.app_ref.save();self.render()

    def _move_body_to_carry(self,body):
        body.update({"storage":"carried","vehicle":"","structure_slot":-1});body.pop("carry_discovery_ts",None);arm_body_carry_timer(self.app_ref.state,body);self.app_ref.save();self.render()

    def _bury_body_at_park(self):
        s=self.app_ref.state;bodies=carried_bodies(s)
        if not bodies:return
        b=bodies[0];b.update({"storage":"park","buried_day":s.day,"vehicle":"","structure_slot":-1});s.add_activity(f"You concealed evidence linked to {b.get('victim','Unknown')} at Riverside Park.");self.app_ref.save();self.render()

    def _walk_park(self):
        s=self.app_ref.state;advance_minutes(s,30);s.energy=max(0,s.energy-2);s.add_activity("You walked around Riverside Park for a while.");self.app_ref.save();self.render()

    def _show_crime_record(self):
        s=self.app_ref.state;ensure_crime_state(s);self.app_ref.notice(f"Pickpocket attempts: {s.crime_record.get('Pickpocket',0)}\nThefts: {s.crime_record.get('Theft',0)}\nMurders: {s.crime_record.get('Murder',0)}\nArrests: {s.crime_record.get('Arrests',0)}\nSentence remaining: {s.jail_days_remaining} day(s)","Criminal Record")

    def render_jail(self):
        s=self.app_ref.state;ensure_crime_state(s);self.add_title("JAIL")
        if s.jail_days_remaining<=0:
            self.add_card("RECEPTION DESK","You are not incarcerated. Visitors can check in here.");self.add_text("The secured cell blocks are off limits.",muted=True);return
        s.current_location="Jail";self.add_card("SENTENCE",f"{s.jail_days_remaining} day(s) remaining · Good behavior {s.jail_behavior}/3 · Prison earnings ${s.jail_cash:,.2f}")
        self.add_card("JAIL INVENTORY",", ".join(f"{k} x{v}" for k,v in s.jail_inventory.items()) or "Empty")
        self.add_button("SLEEP / SERVE ONE JAIL DAY",self._serve_jail_day)
        self.add_button("READ",self._jail_read,disabled=int(s.crime_record.get("JailReadDay",0) or 0)==s.day,secondary=True)
        self.add_button("SHOWER",self._jail_shower,disabled=int(s.crime_record.get("JailShowerDay",0) or 0)==s.day,secondary=True)
        self.add_button("EXERCISE",self._jail_exercise,disabled=s.energy<10 or int(s.crime_record.get("JailExerciseDay",0) or 0)==s.day,secondary=True)
        self.add_button("PRISON WORK",self._jail_work,disabled=int(s.crime_record.get("JailWorkDay",0) or 0)==s.day,secondary=True)
        self.add_text("Reading, exercise and prison work earn good-behavior credit. Every 3 points can reduce a jail day.",muted=True)

    def _serve_jail_day(self):
        s=self.app_ref.state;released,msg=jail_day(s);s.add_activity(msg);self.app_ref.save()
        if released:self.page="Map";self.location_view=True
        self.render();self.app_ref.notice(msg,"Jail")

    def _jail_read(self):
        s=self.app_ref.state
        if int(s.crime_record.get("JailReadDay",0) or 0)==s.day:return
        s.crime_record["JailReadDay"]=s.day;s.jail_behavior+=1;s.add_activity("You read in the jail library and earned good-behavior credit.");self.app_ref.save();self.render()

    def _jail_shower(self):
        s=self.app_ref.state
        if int(s.crime_record.get("JailShowerDay",0) or 0)==s.day:return
        s.crime_record["JailShowerDay"]=s.day;s.health=min(s.max_health,s.health+5);self.app_ref.save();self.render()

    def _jail_exercise(self):
        s=self.app_ref.state
        if s.energy<10 or int(s.crime_record.get("JailExerciseDay",0) or 0)==s.day:return
        s.crime_record["JailExerciseDay"]=s.day;s.energy-=10;s.jail_behavior+=1;s.add_activity("You exercised in the jail courtyard and earned good-behavior credit.");self.app_ref.save();self.render()

    def _jail_work(self):
        s=self.app_ref.state
        if int(s.crime_record.get("JailWorkDay",0) or 0)==s.day:return
        s.crime_record["JailWorkDay"]=s.day;s.jail_cash+=25;s.jail_behavior+=1;s.add_activity("You completed prison work, earning $25 and good-behavior credit.");self.app_ref.save();self.render()

    def _body_evidence_tick(self):
        s=self.app_ref.state
        if not s or s.jail_days_remaining>0:return
        armed=False
        for b in carried_bodies(s):
            if not float(b.get("carry_discovery_ts",0.0) or 0.0):arm_body_carry_timer(s,b);armed=True
        if armed:self.app_ref.save()
        body=carried_body_due(s)
        if body is None:return
        body["linked"]=True;victim=str(body.get("victim","Unknown"));arrest(s,MURDER_JAIL_DAYS,f"evidence connected to {victim}'s murder");msg=f"Police tracked you down while you were carrying evidence linked to {victim}. You were sentenced to 7 days in jail.";s.add_activity(msg);self.app_ref.save();self.page="Jail";self.location_view=False;self.render();self.app_ref.notice(msg,"Crime")

    def _themed_clothes(self, loc):
        items=LOCATION_CLOTHING_SHOPS.get(loc,())
        if items:
            self.add_section("Clothing")
            for item,price,desc in items:self._shop_item(item,price,desc)

    def _shop_item(self,item,price,desc):
        s=self.app_ref.state
        self.add_card(item,f"${price:,} · {desc}\nOwned: {s.inventory.get(item,0)}","BUY",lambda i=item,p=price:self._buy(i,p),s.cash<price)

    def _buy(self,item,price):
        s=self.app_ref.state
        if s.cash<price:return
        s.cash-=price;s.inventory[item]=s.inventory.get(item,0)+1
        s.add_activity(f"You bought {item} for ${price:,}.")
        self.app_ref.save();self.render()

    def _amount_popup(self,title,maximum,callback,default=None):
        maximum=max(0,int(maximum))
        if maximum<=0:return
        box=BoxLayout(orientation="vertical",padding=dp(12),spacing=dp(8));box.add_widget(DLabel(f"Maximum: ${maximum:,}",muted=True));entry=TextInput(text=str(default if default is not None else min(100,maximum)),input_filter="int",multiline=False,size_hint_y=None,height=dp(48),font_size=sp(16));box.add_widget(entry)
        pop=Popup(title=title,content=box,size_hint=(.9,.48));confirm=DButton("CONFIRM");cancel=DButton("CANCEL",secondary=True);box.add_widget(confirm);box.add_widget(cancel)
        def go(*_):
            try:amount=max(1,min(maximum,int(entry.text or "0")))
            except ValueError:return
            pop.dismiss();callback(amount)
        confirm.bind(on_release=go);cancel.bind(on_release=lambda *_:pop.dismiss());pop.open()

    def _bank(self,amount,deposit):
        s=self.app_ref.state
        if deposit and s.cash>=amount:s.cash-=amount;s.bank_balance+=amount
        elif not deposit and s.bank_balance>=amount:s.bank_balance-=amount;s.cash+=amount
        self.app_ref.save();self.render()

    def _train(self,stat):
        s=self.app_ref.state
        if s.energy<10:return
        s.energy-=10;setattr(s,stat,getattr(s,stat)+1);advance_minutes(s,60)
        s.add_activity(f"You trained {stat.title()} at the Gym.")
        self.app_ref.save();self.render()

    def _education(self):
        s=self.app_ref.state
        quals=", ".join(s.qualifications) if s.qualifications else "None yet"
        self.add_card("EDUCATION",f"Qualifications: {quals}\nStudent loan: ${s.student_loan_balance:,.2f}")
        if s.current_course:
            course=course_by_name(s.current_course)
            if course:
                progress=int(s.course_progress.get(course.name,0) or 0);self.add_section("Current course");self.add_card(course.name,f"{progress}/{course.sessions} classes · 12 Energy · 2 hours","ATTEND CLASS",lambda c=course:self._attend_course(c),s.energy<12 or bool(s.active_job_name or s.active_forge_name))
        else:
            self.add_section("Courses")
            for course in COURSES:
                if course.qualification in s.qualifications:self.add_card(course.name,"COMPLETED · "+course.qualification);continue
                self.add_card(course.name,f"Tuition ${course.tuition:,} · {course.sessions} classes\n{course.description}")
                self.add_button(f"ENROLL WITH CASH · ${course.tuition:,}",lambda c=course:self._enroll(c,False),disabled=s.cash<course.tuition,secondary=True)
                self.add_button("USE STUDENT LOAN",lambda c=course:self._enroll(c,True),secondary=True)
        if s.student_loan_balance>0:
            self.add_section("Student loan");self.add_text("10% of job earnings automatically goes toward the loan.",muted=True);self.add_button("MAKE EXTRA PAYMENT",lambda:self._amount_popup("Student Loan Payment",int(min(s.cash,s.student_loan_balance)),self._loan_pay),disabled=s.cash<1)

    def _enroll(self,course,use_loan=False):
        s=self.app_ref.state
        if s.current_course or course.qualification in s.qualifications:return
        if use_loan:s.student_loan_balance+=course.tuition;s.student_loan_borrowed_total+=course.tuition;how="a student loan"
        else:
            if s.cash<course.tuition:return
            s.cash-=course.tuition;how="cash"
        s.current_course=course.name;s.course_progress[course.name]=0;s.add_activity(f"You enrolled in {course.name} using {how} for ${course.tuition:,}.");self.app_ref.save();self.render()

    def _attend_course(self,course):
        s=self.app_ref.state
        if s.energy<12 or s.active_job_name or s.active_forge_name:return
        s.energy-=12;advance_minutes(s,120);s.course_progress[course.name]=int(s.course_progress.get(course.name,0))+1
        if s.course_progress[course.name]>=course.sessions:
            if course.qualification not in s.qualifications:s.qualifications.append(course.qualification)
            s.current_course="";msg=f"You completed {course.name} and earned {course.qualification}."
        else:msg=f"You attended {course.name} class {s.course_progress[course.name]}/{course.sessions}."
        s.add_activity(msg);self.app_ref.save();self.render();self.app_ref.notice(msg,"Education")

    def _loan_pay(self,amount):
        s=self.app_ref.state;pay=min(float(amount),s.cash,s.student_loan_balance)
        if pay<=0:return
        s.cash-=pay;s.student_loan_balance=max(0.0,s.student_loan_balance-pay);s.add_activity(f"You paid ${pay:,.2f} toward your student loan.");self.app_ref.save();self.render()

    def _sell_drug(self):
        s=self.app_ref.state;ensure_crime_state(s);ok,msg=sell_drug(s)
        if not ok:self.app_ref.notice(msg);return
        s.crime_record["Drug Dealing"]=int(s.crime_record.get("Drug Dealing",0) or 0)+1
        if random.random()<.12:
            arrest(s,1,"drug dealing");msg += " Police moved in during the deal. You received 1 day in jail."
        s.add_activity(msg);self.app_ref.save()
        if s.jail_days_remaining>0:self.page="Jail";self.location_view=False
        self.render();self.app_ref.notice(msg,"Crime")

    def _sell_homebrew(self):
        s=self.app_ref.state
        if s.inventory.get("Homebrew Beer",0)<=0:return
        s.inventory["Homebrew Beer"]-=1;s.cash+=FARMERS_MARKET_BEER_PRICE
        s.add_activity(f"You sold Homebrew Beer for ${FARMERS_MARKET_BEER_PRICE}.")
        self.app_ref.save();self.render()

    def _casino(self):
        s=self.app_ref.state
        self.add_text("Choose a game, then set a wager up to $10,000 or your available cash.",muted=True)
        maximum=max(0,min(10000,int(s.cash)))
        for name,fn in (("ROULETTE",casino_roulette),("SLOTS",casino_slots),("BLACKJACK",casino_blackjack)):
            self.add_button(name,lambda f=fn:self._amount_popup("Casino Wager",maximum,lambda wager:self._casino_play(f,wager),default=min(100,maximum)),disabled=maximum<1)

    def _casino_play(self,fn,wager):
        s=self.app_ref.state;wager=max(1,min(int(wager),int(s.cash)))
        if s.cash<wager:return
        result=fn(wager,random.Random(time.time_ns()^(s.day*7919)^int(s.cash)));s.cash+=result.delta
        verb=f"won ${result.delta:,}" if result.delta>0 else (f"lost ${-result.delta:,}" if result.delta<0 else "broke even");msg=f"{result.text} You {verb}.";s.add_activity(f"Casino: {msg}");self.app_ref.save();self.render();self.app_ref.notice(msg,"Lucky Horseshoe Casino")

    def _dungeon(self):
        s=self.app_ref.state;ensure_dungeon_state(s)
        self.add_text(f"Checkpoint: Floor {s.dungeon_checkpoint} · Floors cleared: {s.dungeon_clears}",muted=True)
        if not s.dungeon_active:
            self.add_button("START FROM FLOOR 1",lambda:self._start_dungeon(1))
            for floor in range(10,s.dungeon_checkpoint+1,10):self.add_button(f"START FROM FLOOR {floor}",lambda f=floor:self._start_dungeon(f),secondary=True)
            self.add_section("Gift shop")
            for item in GIFT_SHOP_ITEMS:self._shop_item(item.name,item.price,item.description)
            return
        floor=s.dungeon_floor
        self.add_section(f"Floor {floor}/100")
        enc=s.dungeon_encounter or make_dungeon_encounter(s);self.app_ref.save()
        kind=enc.get("kind")
        if kind=="fight":
            self.add_card(enc.get("name","Enemy"),f"Enemy HP {enc.get('health')}/{enc.get('max_health')} · Your HP {s.health}/{s.max_health}\nDefense {dungeon_defense(s)} · Weapon +{dungeon_weapon_bonus(s)}")
            self.add_button("ATTACK",lambda:self._dungeon_attack(False))
            self.add_button("HEAVY ATTACK",lambda:self._dungeon_attack(True),secondary=True)
            self.add_button("RETREAT",self._dungeon_retreat,danger=True)
        elif kind=="trap":
            self.add_card("TRAP",enc.get("name","Unknown trap"))
            self.add_button("MOVE CAREFULLY",lambda:self._trap("careful"))
            self.add_button("DASH THROUGH",lambda:self._trap("dash"),secondary=True)
        elif kind=="puzzle":
            self.add_card("PUZZLE",enc.get("question",""))
            for idx,opt in enumerate(enc.get("options",[])):self.add_button(str(opt),lambda i=idx:self._puzzle(i),secondary=True)
        else:
            self.add_card("TREASURE",enc.get("name","Chest"))
            self.add_button("OPEN CHEST",self._treasure)

    def _start_dungeon(self,floor):
        s=self.app_ref.state
        if floor!=1 and floor>s.dungeon_checkpoint:return
        start_dungeon_run(s,floor);s.add_activity(f"You entered The Dungeon at Floor {floor}.")
        self.app_ref.save();self.render()

    def _dungeon_attack(self,heavy):
        s=self.app_ref.state;enc=s.dungeon_encounter
        hit,damage=dungeon_player_damage(s,heavy)
        if hit:enc["health"]=max(0,int(enc.get("health",0))-damage)
        if int(enc.get("health",0))<=0:
            loot,done=dungeon_clear_floor(s);s.add_activity(f"Dungeon floor cleared. Loot: {', '.join(loot)}")
            if not done: s.dungeon_floor+=1;s.dungeon_encounter={}
            self.app_ref.save();self.render();return
        s.health=max(0,s.health-dungeon_enemy_damage(s,enc))
        if s.health<=0:
            s.health=10;end_dungeon_run(s);s.current_location="The Dungeon";s.add_activity("You were defeated in The Dungeon and dragged back to the entrance.")
        self.app_ref.save();self.render()

    def _trap(self,mode):
        s=self.app_ref.state
        chance=(0.55+s.perception*0.03) if mode=="careful" else (0.45+s.agility*0.035)
        if random.random()>min(.9,chance):s.health=max(1,s.health-random.randint(5,15))
        self._clear_nonfight_floor()

    def _puzzle(self,answer):
        s=self.app_ref.state;enc=s.dungeon_encounter
        if int(answer)!=int(enc.get("answer",-1)):s.health=max(1,s.health-random.randint(3,10))
        self._clear_nonfight_floor()

    def _treasure(self):self._clear_nonfight_floor()

    def _clear_nonfight_floor(self):
        s=self.app_ref.state
        loot,done=dungeon_clear_floor(s)
        if not done:s.dungeon_floor+=1;s.dungeon_encounter={}
        s.add_activity(f"Dungeon floor cleared. Loot: {', '.join(loot)}")
        self.app_ref.save();self.render()

    def _dungeon_retreat(self):
        s=self.app_ref.state;floor=s.dungeon_floor;end_dungeon_run(s);s.add_activity(f"You retreated from Floor {floor}.")
        self.app_ref.save();self.render()

    def render_phone(self):
        s=self.app_ref.state
        self.add_title("PHONE")
        self.add_section("Contacts")
        if not s.contacts:self.add_text("No contacts yet. Talk to people in town first.",muted=True)
        for name in s.contacts:
            if name in s.dead_npcs:continue
            self.add_card(name,f"{relationship_status(s,name)} · Relationship {relationship_score(s,name)}","CALL",lambda n=name:self._call(n))
        self.add_section("People you can add")
        for name in sorted(s.relationships):
            if name not in s.contacts and name not in s.dead_npcs and relationship_score(s,name)>=CONTACT_SCORE:self.add_card(name,f"Relationship {relationship_score(s,name)}","ADD CONTACT",lambda n=name:self._add_contact(n))
        self.add_section("Family")
        spouses=[n for n in s.relationships if n not in s.dead_npcs and str(ensure_relationship(s,n).get("romance","None"))=="Married"]
        self.add_text("Spouse: "+(", ".join(spouses) if spouses else "None"),muted=True)
        self.add_text(f"Children: {len(s.children)} / {child_capacity(s.home_type)}",muted=True)
        for child in s.children:self.add_card(str(child.get("name","Child")),f"Age {child.get('age',0)} · Born Day {child.get('born_day','?')}")

    def _call(self,name):
        s=self.app_ref.state;npc=npc_by_name(name)
        ok,msg=apply_score_action(s,name,"Call",2)
        line=random.choice(npc.dialogue) if npc and npc.dialogue else "You have a short conversation."
        if ok:s.add_activity(f"You called {name}.")
        self.app_ref.save();self.render();self.app_ref.notice(line if ok else msg)

    def _add_contact(self,name):
        s=self.app_ref.state;ok,msg=add_contact(s,name)
        self.app_ref.save();self.render();self.app_ref.notice(msg)


class DongMobileApp(App):
    title = "DONG Mobile"

    def build(self):
        self.state: GameState | None = None
        self.db = Database(Path(self.user_data_dir) / "game.db")
        self.travel_popup = None
        self.travel_event = None
        self.travel_end = 0.0
        self.travel_destination = ""
        self.travel_method = None
        sm = ScreenManager()
        self.start_screen = StartScreen(self, name="start")
        self.create_screen = CreateScreen(self, name="create")
        self.game_screen = GameScreen(self, name="game")
        sm.add_widget(self.start_screen); sm.add_widget(self.create_screen); sm.add_widget(self.game_screen)
        self.sm = sm
        Window.bind(on_keyboard=self._on_keyboard)
        Clock.schedule_interval(self._tick, 1.0)
        return sm

    def _on_keyboard(self, _window, key, *_args):
        if key == 27 and getattr(self, "sm", None) and self.sm.current == "game" and self.game_screen.drawer_open:
            self.game_screen.close_drawer()
            return True
        return False

    def on_start(self):
        self.show_start()

    def on_pause(self):
        self.save(); return True

    def on_stop(self):
        self.save()

    def show_start(self):
        self.start_screen.refresh(); self.sm.current="start"

    def show_create(self):
        self.sm.current="create"

    def new_game(self,name,age,race):
        self.state=create_new_state(name,age,race);self.save();self.game_screen.page="Home";self.game_screen.location_view=False;self.game_screen.home_inside=False;self.game_screen.home_room_slot=None;self.game_screen.structure_slot=None;self.sm.current="game";self.game_screen.render()

    def continue_game(self):
        self.state=self.db.load()
        if not self.state:self.show_start();return
        self._complete_expired_background()
        self.game_screen.page="Jail" if self.state.jail_days_remaining>0 else ("Home" if self.state.current_location=="Home" else "Map")
        self.game_screen.location_view=self.state.current_location!="Home" and self.state.jail_days_remaining<=0
        self.game_screen.home_inside=False;self.game_screen.home_room_slot=None;self.game_screen.structure_slot=None
        self.sm.current="game";self.game_screen.render()

    def save(self):
        if self.state:self.db.save(self.state)

    def notice(self,text,title="DONG"):
        box=BoxLayout(orientation="vertical",padding=dp(14),spacing=dp(10))
        box.add_widget(DLabel(str(text)))
        close=DButton("OK");box.add_widget(close)
        pop=Popup(title=title,content=box,size_hint=(.9,.55))
        close.bind(on_release=lambda *_:pop.dismiss());pop.open()

    def _complete_expired_background(self):
        if not self.state:return
        now=time.time();changed=False
        s=self.state
        if s.active_job_name and s.active_job_end_ts<=now:
            name=s.active_job_name;pay=s.active_job_pay;energy=s.active_job_energy;hours=max(1,int(s.active_job_hours or 1))
            s.energy=max(0,s.energy-energy)
            loan=min(s.student_loan_balance,round(pay*.10,2)) if s.student_loan_balance>0 else 0.0
            s.student_loan_balance=max(0.0,s.student_loan_balance-loan);s.cash+=pay-loan;advance_minutes(s,60*hours)
            s.add_activity(f"You finished a {hours}-hour shift as a {name}. Gross pay ${pay}.")
            s.active_job_name="";s.active_job_pay=0;s.active_job_energy=0;s.active_job_end_ts=0.0;s.active_job_hours=1;changed=True
        if s.active_forge_name and s.active_forge_end_ts<=now:
            name=s.active_forge_name;s.energy=max(0,s.energy-s.active_forge_energy)
            if name=="Cut Trees":s.wood+=3;gain_skill(s,"woodcutting",10);result="Wood x3"
            elif name=="Mine Ore":s.ore+=2;gain_skill(s,"mining",10);result="Ore x2"
            else:s.inventory["Food"]=s.inventory.get("Food",0)+2;gain_skill(s,"hunting",10);result="Food x2"
            advance_minutes(s,60);s.add_activity(f"You finished {name.lower()} and gathered {result}.")
            s.active_forge_name="";s.active_forge_energy=0;s.active_forge_end_ts=0.0;changed=True
        if changed:self.save()

    def _tick(self,_dt):
        if not self.state:return
        was_job=bool(self.state.active_job_name);was_forge=bool(self.state.active_forge_name)
        self._complete_expired_background()
        if self.sm.current=="game":
            self.game_screen.refresh_header()
            self.game_screen._body_evidence_tick()
            if (was_job and not self.state.active_job_name) or (was_forge and not self.state.active_forge_name):self.game_screen.render()
        if self.travel_popup and time.time()>=self.travel_end:self._finish_travel()

    def start_travel(self,destination,method):
        seconds=travel_seconds(destination,method)
        self.travel_end=time.time()+seconds;self.travel_destination=destination;self.travel_method=method
        box=BoxLayout(orientation="vertical",padding=dp(14),spacing=dp(10))
        label=DLabel(f"{method.verb.title()}ing to {destination}...",title=True);box.add_widget(label)
        countdown=DLabel("",muted=True);box.add_widget(countdown)
        bar=ProgressBar(max=seconds,value=0,size_hint_y=None,height=dp(24));box.add_widget(bar)
        cancel=DButton("CANCEL TRAVEL",secondary=True);box.add_widget(cancel)
        pop=Popup(title="Travel",content=box,size_hint=(.9,.55),auto_dismiss=False)
        self.travel_popup=pop
        def update(_dt):
            remaining=max(0,self.travel_end-time.time());elapsed=max(0,seconds-remaining);bar.value=elapsed;countdown.text=f"{int(remaining+0.999)} seconds remaining"
            return self.travel_popup is pop
        event=Clock.schedule_interval(update,.25);self.travel_event=event
        def do_cancel(*_):
            event.cancel();pop.dismiss();self.travel_popup=None
        cancel.bind(on_release=do_cancel);pop.open();update(0)

    def _finish_travel(self):
        if not self.travel_popup or not self.state:return
        pop=self.travel_popup;self.travel_popup=None
        if self.travel_event:self.travel_event.cancel();self.travel_event=None
        dest=self.travel_destination;method=self.travel_method
        advance_minutes(self.state,travel_game_minutes(dest,method));self.state.current_location=dest
        self.state.add_activity(f"You arrived at {dest} by {method.name}.")
        self.save();pop.dismiss();self.game_screen.page="Map";self.game_screen.location_view=(dest!="Home")
        if dest=="Home":self.game_screen.page="Home";self.game_screen.location_view=False
        self.game_screen.render()


if __name__ == "__main__":
    DongMobileApp().run()
