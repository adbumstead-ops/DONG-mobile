from __future__ import annotations

import json
import sqlite3
from dataclasses import asdict
from pathlib import Path

from database.migrations import apply_migrations
from game.models import GameState


class Database:
    """SQLite save wrapper with a caller-provided writable path.

    On Android the app passes App.user_data_dir/game.db, which lives in the
    application's private storage and survives normal app restarts/updates.
    """

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        return conn

    def _initialize(self) -> None:
        with self.connect() as conn:
            apply_migrations(conn)

    def has_save(self) -> bool:
        with self.connect() as conn:
            return conn.execute("SELECT 1 FROM save_state WHERE id = 1").fetchone() is not None

    def save(self, state: GameState) -> None:
        payload = json.dumps(asdict(state), ensure_ascii=False, separators=(",", ":"))
        with self.connect() as conn:
            conn.execute(
                """
                INSERT INTO save_state(id, payload_json, updated_at)
                VALUES (1, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(id) DO UPDATE SET
                    payload_json = excluded.payload_json,
                    updated_at = CURRENT_TIMESTAMP
                """,
                (payload,),
            )

    def load(self) -> GameState | None:
        with self.connect() as conn:
            row = conn.execute("SELECT payload_json FROM save_state WHERE id = 1").fetchone()
        if row is None:
            return None
        raw = json.loads(row["payload_json"])
        defaults = asdict(GameState())
        defaults.update(raw)
        return GameState(**defaults)
