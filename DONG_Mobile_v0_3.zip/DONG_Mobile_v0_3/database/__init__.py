"""SQLite persistence package for DONG."""
