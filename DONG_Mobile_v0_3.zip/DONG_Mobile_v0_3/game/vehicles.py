from __future__ import annotations

from dataclasses import dataclass
import random


@dataclass(frozen=True)
class VehicleType:
    name: str
    price: int
    travel_multiplier: float
    description: str
    seats: int

    @property
    def speed_text(self) -> str:
        return f"{1.0 / self.travel_multiplier:.1f}x walking speed"


VEHICLE_TYPES: tuple[VehicleType, ...] = (
    VehicleType(
        "Rustbucket Compact", 1_500, 0.42,
        "Cheap, dented, and still considerably faster than walking.", 4,
    ),
    VehicleType(
        "Carl's Family Sedan", 3_500, 0.32,
        "A sensible four-door car with respectable road speed.", 5,
    ),
    VehicleType(
        "Workhorse Pickup", 6_500, 0.27,
        "A sturdy pickup built for rough roads and property owners with too many projects.", 3,
    ),
    VehicleType(
        "Roadrunner Sport Coupe", 12_000, 0.20,
        "Fast, impractical, and priced accordingly. Humanity remains consistent.", 2,
    ),
)

GARAGE_CAPACITY = 2


def vehicle_type(name: str) -> VehicleType | None:
    return next((vehicle for vehicle in VEHICLE_TYPES if vehicle.name == name), None)


def make_vehicle(model: str, seed: int | None = None) -> dict:
    definition = vehicle_type(model)
    if definition is None:
        raise ValueError(f"Unknown vehicle model: {model}")
    rng = random.Random(seed)
    condition = rng.randint(78, 100)
    # Condition has a small real effect instead of existing only to decorate a tooltip.
    condition_penalty = 1.0 + ((100 - condition) / 100.0) * 0.12
    return {
        "model": definition.name,
        "condition": condition,
        "travel_multiplier": round(definition.travel_multiplier * condition_penalty, 3),
        "purchased_price": definition.price,
    }


def vehicles_in_slot(slot_data: dict) -> list[dict]:
    vehicles = list(slot_data.get("vehicles", []) or [])
    return [dict(vehicle or {}) for vehicle in vehicles]


def owned_garage_vehicles(state) -> list[dict]:
    vehicles: list[dict] = []
    for index, structure in enumerate(list(state.property_slots or [])):
        if structure != "Garage" or index >= len(state.property_slot_data):
            continue
        vehicles.extend(vehicles_in_slot(state.property_slot_data[index]))
    return vehicles
