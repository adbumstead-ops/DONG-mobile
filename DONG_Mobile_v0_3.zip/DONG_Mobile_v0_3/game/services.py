from __future__ import annotations

import random
from dataclasses import dataclass

from game.models import GameState
from game.items import CLOTHING_SLOT_NAMES, clothing_slot
from game.animals import care_for_new_day, saddled_horses
from game.vehicles import owned_garage_vehicles
from game.crime import process_evidence_checks
from game.vice import vice_new_day


WEATHERS = ("Clear", "Cloudy", "Rainy", "Windy", "Foggy")


def weather_for_day(day: int) -> str:
    return random.Random(day * 7919 + 17).choice(WEATHERS)


def create_new_state(name: str, age: int, race: str) -> GameState:
    character_name = name.strip()
    is_test_profile = character_name == "Test"
    state = GameState(
        character_name=character_name,
        age=age,
        race=race,
        lot_number=random.randint(100, 999),
        weather=weather_for_day(1),
        cash=100_000_000.0 if is_test_profile else 100.0,
        wood=1_000 if is_test_profile else 0,
        ore=1_000 if is_test_profile else 0,
    )
    if is_test_profile:
        state.add_activity(
            "Test profile created with $100,000,000, 1,000 Wood, and 1,000 Ore."
        )
    else:
        state.add_activity("You arrived at your empty plot of land with a tent and $100.")
    return state


def advance_minutes(state: GameState, minutes: int) -> None:
    total = state.hour * 60 + state.minute + minutes
    while total >= 24 * 60:
        total -= 24 * 60
        state.day += 1
        state.weather = weather_for_day(state.day)
        care_for_new_day(state)
        for message in vice_new_day(state):
            state.add_activity(message)
        for message in process_evidence_checks(state):
            state.add_activity(message)
    state.hour, state.minute = divmod(total, 60)


def sleep_until_morning(state: GameState, health_recovery: int = 20) -> None:
    state.day += 1
    care_for_new_day(state)
    for message in vice_new_day(state):
        state.add_activity(message)
    for message in process_evidence_checks(state):
        state.add_activity(message)
    state.hour = 8
    state.minute = 0
    state.weather = weather_for_day(state.day)
    state.energy = state.max_energy
    state.health = min(state.max_health, state.health + health_recovery)
    if state.jail_days_remaining <= 0:
        state.current_location = "Home"
        state.add_activity(f"You slept in your {state.home_type.lower()} and woke up at 8:00 AM.")


def gain_skill(state: GameState, skill: str, amount: int) -> None:
    xp_attr = f"{skill}_xp"
    level_attr = f"{skill}_level"
    setattr(state, xp_attr, getattr(state, xp_attr) + amount)
    while getattr(state, xp_attr) >= getattr(state, level_attr) * 100:
        setattr(state, xp_attr, getattr(state, xp_attr) - getattr(state, level_attr) * 100)
        setattr(state, level_attr, getattr(state, level_attr) + 1)


@dataclass(frozen=True)
class TravelMethod:
    name: str
    speed_multiplier: float
    verb: str


TRAVEL_METHODS = {
    "Walk": TravelMethod("Walk", 1.0, "WALK"),
    "Bicycle": TravelMethod("Bicycle", 0.50, "RIDE"),
    "Horse": TravelMethod("Horse", 0.70, "RIDE"),
    "Car": TravelMethod("Car", 0.20, "DRIVE"),
    "Motorcycle": TravelMethod("Motorcycle", 0.17, "RIDE"),
    "Plane": TravelMethod("Plane", 0.04, "FLY"),
}

# Deliberately small starter map. Distances are fictional game-world values.
LOCATION_DISTANCE_KM = {
    "Home": 0.0,
    "Grocery Store": 2.4,
    "Main Street Threads": 2.1,
    "Gus' Gunporium": 3.4,
    "Bank": 3.2,
    "Gym": 2.8,
    "The Drunken Donkey": 1.8,
    "The Fighting Pits": 4.0,
    "Outdoors Specials": 3.6,
    "Old McDonald\'s Farm Supplies": 3.1,
    "Carl\'s Cars": 4.4,
    "Police Station": 2.6,
    "Jail": 3.8,
    "Riverside Park": 2.2,
    "Farmers Market": 2.7,
    "Lucky Horseshoe Casino": 4.1,
    "Education Center": 3.0,
    "The Dungeon": 5.2,
}


def available_travel_methods(state: GameState) -> list[TravelMethod]:
    methods = [TRAVEL_METHODS["Walk"]]
    for horse in saddled_horses(state):
        speed = max(1.0, float(horse.get("speed", 1.2) or 1.2))
        multiplier = max(0.55, min(0.72, 0.82 / speed))
        methods.append(TravelMethod(f"Horse - {horse.get('name', 'Unnamed')}", multiplier, "RIDE"))
    for vehicle in owned_garage_vehicles(state):
        model = str(vehicle.get("model", "Car") or "Car")
        multiplier = max(0.12, min(0.50, float(vehicle.get("travel_multiplier", 0.30) or 0.30)))
        methods.append(TravelMethod(f"Car - {model}", multiplier, "DRIVE"))
    # Preserve compatibility with any very old/future saves that used the legacy
    # generic vehicle list before Garage-based ownership was introduced.
    for vehicle in state.vehicles:
        if isinstance(vehicle, str):
            method = TRAVEL_METHODS.get(vehicle)
            if method and method not in methods:
                methods.append(method)
    return methods


def travel_seconds(destination: str, method: TravelMethod) -> int:
    distance = LOCATION_DISTANCE_KM[destination]
    base = max(5, round(distance * 30))
    return max(3, round(base * method.speed_multiplier))


def travel_game_minutes(destination: str, method: TravelMethod) -> int:
    distance = LOCATION_DISTANCE_KM[destination]
    base_minutes = max(5, round(distance * 10))
    return max(2, round(base_minutes * method.speed_multiplier))


def equip_clothing(state: GameState, item: str) -> tuple[bool, str]:
    """Equip a clothing item from inventory, returning any replaced item to inventory."""
    slot = clothing_slot(item)
    if slot is None:
        return False, f"{item} cannot be equipped as clothing."
    if state.inventory.get(item, 0) <= 0:
        return False, f"You do not have {item} in your backpack."

    previous = state.equipment.get(slot, "Nothing")
    state.inventory[item] -= 1
    if previous not in ("Nothing", "None", ""):
        state.inventory[previous] = state.inventory.get(previous, 0) + 1
    state.equipment[slot] = item

    if previous not in ("Nothing", "None", ""):
        message = f"You equipped {item} and put {previous} in your backpack."
    else:
        message = f"You equipped {item}."
    state.add_activity(message)
    return True, message


def unequip_clothing(state: GameState, slot: str) -> tuple[bool, str]:
    """Unequip clothing from a slot and return it to inventory."""
    if slot not in CLOTHING_SLOT_NAMES:
        return False, f"{slot} is not a clothing slot."
    item = state.equipment.get(slot, "Nothing")
    if item in ("Nothing", "None", ""):
        return False, f"There is nothing equipped in {slot}."

    state.inventory[item] = state.inventory.get(item, 0) + 1
    state.equipment[slot] = "Nothing"
    message = f"You unequipped {item} and put it in your backpack."
    state.add_activity(message)
    return True, message
