from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class BuildOption:
    name: str
    cash: int
    wood: int
    ore: int
    description: str


HOME_UPGRADES: tuple[BuildOption, ...] = (
    BuildOption("Shack", 200, 25, 5, "A rough little shack with four walls, a roof, and very modest ambitions."),
    BuildOption("Trailer", 750, 35, 20, "A compact trailer home with more comfort and security than the starter tent."),
    BuildOption("Cabin", 1_500, 80, 30, "A sturdy wooden cabin with enough room to feel properly settled."),
    BuildOption("2 Story Home", 5_000, 180, 80, "A proper two-story home with plenty of living space."),
    BuildOption("Farm House", 10_000, 300, 140, "A large country home suited to a busy, developed property."),
    BuildOption("A Castle", 50_000, 800, 500, "Stone walls, towers, and the sort of property statement that alarms the neighbors."),
    BuildOption("Mega Mansion", 150_000, 1_500, 1_000, "An enormous luxury home for players who have clearly defeated the concept of moderation."),
)

PROPERTY_BUILDS: tuple[BuildOption, ...] = (
    BuildOption("Storage Shed", 250, 30, 10, "Store spare items and supplies off your character."),
    BuildOption("Garage", 1_000, 60, 40, "Store and manage road vehicles on your property."),
    BuildOption("Garden Bed", 180, 20, 5, "Water crops and harvest Food after they grow."),
    BuildOption("Barn", 2_500, 120, 60, "Keep larger farm animals and collect fresh Milk."),
    BuildOption("Chicken Coop", 600, 45, 15, "Keep chickens and collect Food from their eggs."),
    BuildOption("Workshop", 1_500, 80, 50, "A future work area for crafting and repairs."),
    BuildOption("Well", 900, 35, 45, "Draw fresh Water and occasionally pull up something unexpected."),
    BuildOption("Stable", 1_800, 100, 45, "Keep horses here and care for them between trips."),
    BuildOption("Hidden Cache", 2_000, 90, 70, "A concealed property space that can hold up to 3 pieces of criminal evidence."),
)


def home_option(name: str) -> BuildOption | None:
    return next((option for option in HOME_UPGRADES if option.name == name), None)


def property_option(name: str) -> BuildOption | None:
    return next((option for option in PROPERTY_BUILDS if option.name == name), None)


def can_afford_build(cash: float, wood: int, ore: int, option: BuildOption) -> bool:
    return cash >= option.cash and wood >= option.wood and ore >= option.ore
