from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class GunporiumItem:
    name: str
    price: int
    kind: str
    description: str


# Fictional/generic game weapons. Values are RPG combat bonuses, not real-world specs.
GUN_WEAPONS: dict[str, int] = {
    "Gus' Pocket Sidearm": 3,
    "Service Sidearm": 5,
    "Trail Revolver": 6,
    "Pump Shotgun": 8,
    "Ranch Rifle": 9,
    "Compact Carbine": 11,
}

GUN_ARMOR: dict[str, tuple[str, int]] = {
    "Padded Field Jacket": ("Outer Wear", 1),
    "Reinforced Combat Vest": ("Outer Wear", 3),
    "Combat Helmet": ("Head", 2),
}

GUNPORIUM_ITEMS = (
    GunporiumItem("Gus' Pocket Sidearm", 450, "weapon", "A small fictional sidearm. Combat attack +3."),
    GunporiumItem("Service Sidearm", 750, "weapon", "A sturdy fictional duty sidearm. Combat attack +5."),
    GunporiumItem("Trail Revolver", 900, "weapon", "A heavy fictional trail handgun. Combat attack +6."),
    GunporiumItem("Pump Shotgun", 1200, "weapon", "A fictional close-range long gun. Combat attack +8."),
    GunporiumItem("Ranch Rifle", 1500, "weapon", "A fictional sporting rifle. Combat attack +9."),
    GunporiumItem("Compact Carbine", 2200, "weapon", "A fictional compact long gun. Combat attack +11."),
    GunporiumItem("Field Cap", 32, "clothing", "Head · Plain field cap for range days and bad hair days."),
    GunporiumItem("Tactical Face Wrap", 28, "clothing", "Face · Dark fabric face covering with no magical stealth powers."),
    GunporiumItem("Combat Utility Shirt", 65, "clothing", "Inner Wear · Durable utility shirt with reinforced elbows."),
    GunporiumItem("Ranger Cargo Pants", 78, "clothing", "Pants · Hard-wearing cargo trousers with many pockets."),
    GunporiumItem("Patrol Boots", 92, "clothing", "Feet · Heavy-duty lace-up boots."),
    GunporiumItem("Padded Field Jacket", 180, "armor", "Outer Wear · Light protective jacket. Combat defense +1."),
    GunporiumItem("Reinforced Combat Vest", 650, "armor", "Outer Wear · Reinforced fictional body armor. Combat defense +3."),
    GunporiumItem("Combat Helmet", 420, "armor", "Head · Reinforced helmet. Combat defense +2."),
)


def weapon_bonus(item_name: str) -> int:
    return GUN_WEAPONS.get(item_name, 0)


def armor_defense(item_name: str) -> int:
    armor = GUN_ARMOR.get(item_name)
    return armor[1] if armor else 0
