"""Core game package for DONG."""
