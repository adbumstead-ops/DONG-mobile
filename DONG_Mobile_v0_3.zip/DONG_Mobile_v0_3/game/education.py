from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Course:
    name: str
    tuition: int
    sessions: int
    qualification: str
    description: str


COURSES = (
    Course(
        "Office Administration",
        2500,
        3,
        "Office Administration Certificate",
        "Basic office systems, scheduling, records, and professional administration.",
    ),
    Course(
        "IT Support",
        4500,
        4,
        "IT Support Certificate",
        "General computer support, troubleshooting, and workplace technology skills.",
    ),
    Course(
        "Bookkeeping",
        6000,
        5,
        "Bookkeeping Diploma",
        "Practical bookkeeping, payroll, invoicing, and basic business accounting.",
    ),
    Course(
        "Medical Office Administration",
        7000,
        5,
        "Medical Office Certificate",
        "Front-desk administration, scheduling, records, and clinic office procedures.",
    ),
)

COURSE_BY_NAME = {course.name: course for course in COURSES}


def course_by_name(name: str) -> Course | None:
    return COURSE_BY_NAME.get(name)


def has_qualification(state, qualification: str) -> bool:
    return qualification in list(getattr(state, "qualifications", []) or [])
