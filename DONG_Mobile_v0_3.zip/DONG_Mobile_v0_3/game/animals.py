from __future__ import annotations

from dataclasses import dataclass
import random


@dataclass(frozen=True)
class AnimalType:
    name: str
    price: int
    structure: str
    description: str
    product: str
    capacity: int


ANIMAL_TYPES: tuple[AnimalType, ...] = (
    AnimalType("Chicken", 35, "Chicken Coop", "A laying hen that can produce food from eggs each day.", "Food", 6),
    AnimalType("Cow", 220, "Barn", "A dairy cow that can be milked each day for fresh Milk.", "Milk", 4),
    AnimalType("Horse", 650, "Stable", "A riding horse. Equip a Saddle to use it as a faster travel method.", "Travel", 3),
)

SADDLE_PRICE = 120
SEED_ITEM = "Vegetable Seeds"
SEED_PRICE = 4


def animal_type(name: str) -> AnimalType | None:
    return next((animal for animal in ANIMAL_TYPES if animal.name == name), None)


def make_animal(kind: str, name: str, seed: int | None = None) -> dict:
    rng = random.Random(seed)
    animal = {
        "type": kind,
        "name": name.strip() or kind,
        "health": 100,
        "happiness": rng.randint(55, 75),
        "hunger": rng.randint(0, 20),
        "age": 1,
        "last_product_day": 0,
        "last_petted_day": 0,
        "last_fed_day": 0,
    }
    if kind == "Horse":
        animal["saddled"] = False
        animal["speed"] = round(rng.uniform(1.15, 1.35), 2)
    return animal


def animals_in_slot(slot_data: dict) -> list[dict]:
    animals = list(slot_data.get("animals", []) or [])
    return [dict(animal or {}) for animal in animals]


def saddled_horses(state) -> list[dict]:
    horses: list[dict] = []
    for index, structure in enumerate(list(state.property_slots or [])):
        if structure != "Stable" or index >= len(state.property_slot_data):
            continue
        for animal in animals_in_slot(state.property_slot_data[index]):
            if animal.get("type") == "Horse" and animal.get("saddled"):
                horses.append(animal)
    return horses


def has_saddled_horse(state) -> bool:
    return bool(saddled_horses(state))


def care_for_new_day(state) -> None:
    for index, structure in enumerate(list(state.property_slots or [])):
        if structure not in {"Chicken Coop", "Barn", "Stable"} or index >= len(state.property_slot_data):
            continue
        data = state.property_slot_data[index]
        animals = animals_in_slot(data)
        for animal in animals:
            animal["hunger"] = min(100, int(animal.get("hunger", 0) or 0) + 18)
            if animal["hunger"] >= 75:
                animal["happiness"] = max(0, int(animal.get("happiness", 50) or 0) - 8)
            elif animal["hunger"] >= 50:
                animal["happiness"] = max(0, int(animal.get("happiness", 50) or 0) - 3)
        data["animals"] = animals
