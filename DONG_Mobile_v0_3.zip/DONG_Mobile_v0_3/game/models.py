from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class GameState:
    character_name: str = "Ricky"
    age: int = 22
    race: str = "Human"
    day: int = 1
    hour: int = 8
    minute: int = 0
    weather: str = "Clear"
    health: int = 100
    max_health: int = 100
    energy: int = 100
    max_energy: int = 100
    cash: float = 100.0
    bank_balance: float = 0.0
    wood: int = 0
    ore: int = 0
    strength: int = 5
    endurance: int = 5
    agility: int = 5
    intelligence: int = 5
    perception: int = 5
    woodcutting_level: int = 1
    woodcutting_xp: int = 0
    mining_level: int = 1
    mining_xp: int = 0
    hunting_level: int = 1
    hunting_xp: int = 0
    lot_number: int = 100
    home_type: str = "Tent"
    current_location: str = "Home"
    inventory: dict[str, int] = field(default_factory=lambda: {
        "Food": 2,
        "Water": 2,
        "Beer": 0,
    })
    equipment: dict[str, str] = field(default_factory=lambda: {
        "Head": "Nothing",
        "Face": "Nothing",
        "Outer Wear": "Nothing",
        "Vest": "Nothing",
        "Inner Wear": "T-Shirt",
        "Pants": "Jeans",
        "Feet": "Shoes",
        "Weapon": "None",
    })
    vehicles: list[str] = field(default_factory=list)
    property_buildings: list[str] = field(default_factory=list)
    property_slots: list[str] = field(default_factory=lambda: ["", "", "", "", "", ""])
    property_slot_data: list[dict] = field(default_factory=lambda: [{}, {}, {}, {}, {}, {}])
    home_storage: dict[str, int] = field(default_factory=dict)
    home_room_slots: list[str] = field(default_factory=lambda: ["", "", "", ""])
    home_room_data: list[dict] = field(default_factory=lambda: [{}, {}, {}, {}])
    activity_log: list[str] = field(default_factory=list)
    combat_wins: int = 0
    combat_losses: int = 0
    active_job_name: str = ""
    active_job_pay: int = 0
    active_job_energy: int = 0
    active_job_end_ts: float = 0.0
    active_job_hours: int = 1
    active_forge_name: str = ""
    active_forge_energy: int = 0
    active_forge_end_ts: float = 0.0
    relationships: dict[str, dict] = field(default_factory=dict)
    contacts: list[str] = field(default_factory=list)
    children: list[dict] = field(default_factory=list)
    crime_record: dict[str, int] = field(default_factory=dict)
    crime_bodies: list[dict] = field(default_factory=list)
    dead_npcs: list[str] = field(default_factory=list)
    jail_days_remaining: int = 0
    jail_behavior: int = 0
    jail_cash: float = 0.0
    jail_inventory: dict[str, int] = field(default_factory=dict)
    drunk_level: int = 0
    addiction: int = 0
    last_drug_day: int = 0
    drugs_used_total: int = 0
    qualifications: list[str] = field(default_factory=list)
    current_course: str = ""
    course_progress: dict[str, int] = field(default_factory=dict)
    student_loan_balance: float = 0.0
    student_loan_borrowed_total: float = 0.0
    dungeon_checkpoint: int = 1
    dungeon_floor: int = 0
    dungeon_active: bool = False
    dungeon_encounter: dict = field(default_factory=dict)
    dungeon_clears: int = 0

    def __post_init__(self) -> None:
        # v0.9 and older saves used Body/Legs. Normalize those slots while
        # retaining the equipped items. This keeps old save files compatible.
        equipment = dict(self.equipment or {})
        if "Inner Wear" not in equipment and "Body" in equipment:
            equipment["Inner Wear"] = equipment.get("Body", "Nothing")
        if "Pants" not in equipment and "Legs" in equipment:
            equipment["Pants"] = equipment.get("Legs", "Nothing")
        equipment.pop("Body", None)
        equipment.pop("Legs", None)
        defaults = {
            "Head": "Nothing",
            "Face": "Nothing",
            "Outer Wear": "Nothing",
            "Vest": "Nothing",
            "Inner Wear": "Nothing",
            "Pants": "Nothing",
            "Feet": "Nothing",
            "Weapon": "None",
        }
        defaults.update(equipment)
        self.equipment = defaults

        # v0.17 and older stored gathered resources inside the backpack.
        # Move them into dedicated property-resource counters once, then remove
        # the legacy inventory entries so old saves remain compatible.
        inventory = dict(self.inventory or {})

        # v0.41 dungeon gear used deliberately plain placeholder names. v0.42
        # gives the same items proper fantasy names while preserving quantities
        # and anything currently equipped in older saves.
        dungeon_item_renames = {
            "Dungeon T-Shirt": "Mossgreen Tunic",
            "Dungeon Hood": "Gravekeeper Hood",
            "Iron Helm": "Ironbound Helm",
            "Dungeon Jacket": "Mosscloak Jerkin",
            "Crypt Plate": "Graveforged Cuirass",
            "Dungeon Trousers": "Worn Leather Trousers",
            "Knight Greaves": "Blacksteel Greaves",
            "Dungeon Boots": "Ranger Boots",
            "Iron Sabatons": "Ironbound Sabatons",
        }
        for old_name, new_name in dungeon_item_renames.items():
            qty = int(inventory.pop(old_name, 0) or 0)
            if qty:
                inventory[new_name] = int(inventory.get(new_name, 0) or 0) + qty
        for slot, equipped_item in list(self.equipment.items()):
            if equipped_item in dungeon_item_renames:
                self.equipment[slot] = dungeon_item_renames[equipped_item]

        # v0.45 splits formal suits into real layers and adds a dedicated Vest slot.
        # Existing one-piece suit items are expanded into their component garments.
        suit_sets = {
            "Midnight Two-Piece Suit": ("Midnight Suit Jacket", "Midnight Dress Shirt", "Midnight Suit Trousers"),
            "Midnight Three-Piece Suit": ("Midnight Suit Jacket", "Midnight Dress Shirt", "Midnight Suit Trousers", "Midnight Waistcoat"),
        }
        for old_name, components in suit_sets.items():
            qty = int(inventory.pop(old_name, 0) or 0)
            if qty:
                for component in components:
                    inventory[component] = int(inventory.get(component, 0) or 0) + qty
            for slot, equipped_item in list(self.equipment.items()):
                if equipped_item == old_name:
                    self.equipment[slot] = "Midnight Suit Jacket"
                    for component in components:
                        if component != "Midnight Suit Jacket":
                            inventory[component] = int(inventory.get(component, 0) or 0) + 1

        vest_items = {"Patchwork Market Vest", "Bartender's Waistcoat", "Lucky Horseshoe Dealer Vest", "Second-Breakfast Waistcoat", "Midnight Waistcoat"}
        outer_item = self.equipment.get("Outer Wear", "Nothing")
        if outer_item in vest_items and self.equipment.get("Vest", "Nothing") in ("Nothing", "None", ""):
            self.equipment["Vest"] = outer_item
            self.equipment["Outer Wear"] = "Nothing"

        legacy_wood = int(inventory.pop("Wood", 0) or 0)
        legacy_stone = int(inventory.pop("Stone", 0) or 0)
        legacy_ore = int(inventory.pop("Ore", 0) or 0)
        self.wood = int(self.wood or 0) + legacy_wood
        self.ore = int(self.ore or 0) + legacy_stone + legacy_ore
        self.inventory = inventory
        self.property_buildings = list(self.property_buildings or [])

        # Education/career fields are deliberately forgiving so older saves load cleanly.
        self.qualifications = list(self.qualifications or [])
        self.course_progress = dict(self.course_progress or {})
        self.current_course = str(self.current_course or "")
        self.student_loan_balance = max(0.0, float(self.student_loan_balance or 0.0))
        self.student_loan_borrowed_total = max(0.0, float(self.student_loan_borrowed_total or 0.0))
        self.active_job_hours = max(1, int(self.active_job_hours or 1))
        self.dungeon_checkpoint = max(1, min(100, int(self.dungeon_checkpoint or 1)))
        self.dungeon_floor = max(0, min(100, int(self.dungeon_floor or 0)))
        self.dungeon_active = bool(self.dungeon_active)
        self.dungeon_encounter = dict(self.dungeon_encounter or {})
        self.dungeon_clears = max(0, int(self.dungeon_clears or 0))

        # v0.18 used a fixed list of one-off buildings. v0.19 introduces six
        # customizable property slots. Preserve older structures by assigning
        # as many as possible to the new slots on first load.
        slots = list(self.property_slots or [])[:6]
        slots.extend([""] * (6 - len(slots)))
        if not any(slots) and self.property_buildings:
            for index, name in enumerate(self.property_buildings[:6]):
                slots[index] = name
        # Normalize structure names from earlier builds.
        structure_names = {"Storage Shack": "Storage Shed", "Coop": "Chicken Coop"}
        self.property_slots = [structure_names.get(name, name) for name in slots]

        slot_data = list(self.property_slot_data or [])[:6]
        slot_data.extend({} for _ in range(6 - len(slot_data)))
        self.property_slot_data = [dict(data or {}) for data in slot_data]

        self.home_storage = dict(self.home_storage or {})
        room_slots = list(self.home_room_slots or [])[:4]
        room_slots.extend([""] * (4 - len(room_slots)))
        self.home_room_slots = room_slots
        room_data = list(self.home_room_data or [])[:4]
        room_data.extend({} for _ in range(4 - len(room_data)))
        self.home_room_data = [dict(data or {}) for data in room_data]

        # Normalize any older location wording if stores are renamed later.
        self.relationships = {str(name): dict(data or {}) for name, data in dict(self.relationships or {}).items()}
        self.contacts = list(dict.fromkeys(str(name) for name in (self.contacts or [])))
        self.children = [dict(child or {}) for child in (self.children or [])]
        self.crime_record = {str(k): int(v or 0) for k, v in dict(self.crime_record or {}).items()}
        self.crime_bodies = [dict(body or {}) for body in (self.crime_bodies or [])]
        self.dead_npcs = list(dict.fromkeys(str(name) for name in (self.dead_npcs or [])))
        self.jail_days_remaining = int(self.jail_days_remaining or 0)
        self.jail_behavior = int(self.jail_behavior or 0)
        self.jail_cash = float(self.jail_cash or 0.0)
        self.jail_inventory = dict(self.jail_inventory or {})
        self.drunk_level = max(0, int(self.drunk_level or 0))
        self.addiction = max(0, min(100, int(self.addiction or 0)))
        self.last_drug_day = int(self.last_drug_day or 0)
        self.drugs_used_total = max(0, int(self.drugs_used_total or 0))

        if not self.current_location:
            self.current_location = "Home"

    @property
    def clock_text(self) -> str:
        hour = self.hour % 12 or 12
        suffix = "AM" if self.hour < 12 else "PM"
        return f"{hour}:{self.minute:02d} {suffix}"

    def add_activity(self, text: str) -> None:
        self.activity_log.insert(0, f"Day {self.day}, {self.clock_text}  {text}")
