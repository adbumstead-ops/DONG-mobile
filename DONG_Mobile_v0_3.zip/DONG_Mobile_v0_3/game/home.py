from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RoomOption:
    name: str
    cash: int
    wood: int
    ore: int
    description: str


ROOM_OPTIONS: tuple[RoomOption, ...] = (
    RoomOption("Kitchen", 700, 35, 20, "Cook simple meals from food you have gathered or bought."),
    RoomOption("Living Room", 500, 25, 10, "A comfortable place to relax and recover a little each day."),
    RoomOption("Bedroom", 800, 40, 15, "A proper sleeping room that improves overnight Health recovery."),
    RoomOption("Bathroom", 650, 25, 20, "A private washroom where a daily shower restores some Health."),
)

# Larger homes provide more interior room slots and more built-in storage.
HOME_INTERIORS: dict[str, tuple[int, int]] = {
    "Tent": (0, 1),
    "Shack": (1, 5),
    "Trailer": (2, 8),
    "Cabin": (2, 10),
    "2 Story Home": (3, 16),
    "Farm House": (4, 24),
    "A Castle": (4, 36),
    "Mega Mansion": (4, 50),
}


# Housing also limits live-in relationships and family size.
HOME_FAMILY_CAPACITY: dict[str, tuple[bool, int]] = {
    "Tent": (False, 0),
    "Shack": (True, 0),
    "Trailer": (True, 1),
    "Cabin": (True, 2),
    "2 Story Home": (True, 3),
    "Farm House": (True, 4),
    "A Castle": (True, 6),
    "Mega Mansion": (True, 8),
}


def allows_live_in_partner(home_type: str) -> bool:
    return HOME_FAMILY_CAPACITY.get(home_type, (False, 0))[0]


def child_capacity(home_type: str) -> int:
    return HOME_FAMILY_CAPACITY.get(home_type, (False, 0))[1]

def room_option(name: str) -> RoomOption | None:
    return next((option for option in ROOM_OPTIONS if option.name == name), None)


def room_capacity(home_type: str) -> int:
    return HOME_INTERIORS.get(home_type, (0, 1))[0]


def home_storage_capacity(home_type: str) -> int:
    return HOME_INTERIORS.get(home_type, (0, 1))[1]
