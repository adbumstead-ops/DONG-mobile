from __future__ import annotations

import random
from dataclasses import dataclass

from game.models import GameState

DRUG_SEED_ITEM = "Drug Seeds"
DRUG_ITEM = "Drugs"
BEER_KIT_ITEM = "Beer Kit"
DRUG_SEED_PRICE = 120
BEER_KIT_PRICE = 75
FARMERS_MARKET_BEER_PRICE = 8
DRUG_SALE_PRICE = 90


def ensure_vice_state(state: GameState) -> None:
    state.drunk_level = max(0, int(getattr(state, "drunk_level", 0) or 0))
    state.addiction = max(0, min(100, int(getattr(state, "addiction", 0) or 0)))
    state.last_drug_day = int(getattr(state, "last_drug_day", 0) or 0)
    state.drugs_used_total = max(0, int(getattr(state, "drugs_used_total", 0) or 0))
    state.inventory.setdefault("Beer", 0)
    state.inventory.setdefault(DRUG_ITEM, 0)
    state.inventory.setdefault(DRUG_SEED_ITEM, 0)
    state.inventory.setdefault(BEER_KIT_ITEM, 0)


def drink_beer(state: GameState) -> str:
    ensure_vice_state(state)
    state.drunk_level = min(5, state.drunk_level + 1)
    rng = random.Random((state.day * 10007) + state.hour * 131 + state.minute * 17 + state.drunk_level)
    events = (
        "You became convinced the bar stool understood you better than most people.",
        "You told a stranger a story twice. They were too polite to mention it.",
        "You attempted a heroic toast and spilled some of it on yourself.",
        "You briefly became extremely confident about your dancing ability.",
        "You laughed much harder than the situation deserved.",
    )
    text = rng.choice(events)
    if state.drunk_level >= 4:
        state.energy = max(0, state.energy - 5)
        text += " You are very drunk and lost 5 Energy."
    return text


def use_drugs(state: GameState) -> str:
    ensure_vice_state(state)
    consecutive = state.last_drug_day in (state.day, state.day - 1)
    gain = 18 + (10 if consecutive else 0)
    state.addiction = min(100, state.addiction + gain)
    state.last_drug_day = state.day
    state.drugs_used_total += 1
    state.energy = min(state.max_energy, state.energy + 20)
    state.health = max(1, state.health - 5)
    if state.addiction >= 60:
        return f"You used Drugs. Energy +20, Health -5. Dependence is now high ({state.addiction}/100)."
    return f"You used Drugs. Energy +20, Health -5. Addiction pressure: {state.addiction}/100."


def vice_new_day(state: GameState) -> list[str]:
    ensure_vice_state(state)
    messages: list[str] = []
    if state.drunk_level:
        state.drunk_level = max(0, state.drunk_level - 2)
    if state.addiction >= 60 and state.last_drug_day < state.day - 1:
        state.energy = max(0, state.energy - 15)
        messages.append("Drug withdrawal left you restless and drained. You lost 15 Energy.")
        state.addiction = max(0, state.addiction - 3)
    elif state.last_drug_day < state.day - 2:
        state.addiction = max(0, state.addiction - 5)
    return messages


def sell_drug(state: GameState, rng: random.Random | None = None) -> tuple[bool, str]:
    ensure_vice_state(state)
    if state.inventory.get(DRUG_ITEM, 0) <= 0:
        return False, "You do not have any Drugs to sell."
    state.inventory[DRUG_ITEM] -= 1
    state.cash += DRUG_SALE_PRICE
    roll = (rng or random.Random()).random()
    if roll < 0.15:
        return True, f"You sold Drugs for ${DRUG_SALE_PRICE}, but the buyer looked nervous enough to attract attention."
    return True, f"You sold Drugs for ${DRUG_SALE_PRICE}."


@dataclass(frozen=True)
class CasinoResult:
    delta: int
    text: str


def slots(wager: int, rng: random.Random) -> CasinoResult:
    roll = rng.random()
    if roll < 0.03:
        return CasinoResult(wager * 9, "JACKPOT! The machine erupts into obnoxious celebration.")
    if roll < 0.18:
        return CasinoResult(wager * 2, "Three cheerful symbols line up. You win.")
    if roll < 0.38:
        return CasinoResult(0, "You win your wager back. The machine calls this excitement.")
    return CasinoResult(-wager, "The reels stop on absolutely nothing useful.")


def roulette(wager: int, rng: random.Random) -> CasinoResult:
    # Simple red/black abstraction with the house edge represented by green zero.
    roll = rng.randrange(37)
    if roll == 0:
        return CasinoResult(-wager, "Green zero. The house smiles quietly.")
    if roll % 2 == 0:
        return CasinoResult(wager, "Red wins. Your wager doubles.")
    return CasinoResult(-wager, "Black wins. Your wager is gone.")


def blackjack(wager: int, rng: random.Random) -> CasinoResult:
    player = rng.randint(16, 21)
    dealer = rng.randint(16, 22)
    if player == 21 and dealer != 21:
        return CasinoResult(int(wager * 1.5), f"Blackjack. You have 21 against the dealer's {dealer}.")
    if dealer > 21 or player > dealer:
        return CasinoResult(wager, f"You win {player} to {dealer}.")
    if player == dealer:
        return CasinoResult(0, f"Push at {player}. Your wager is returned.")
    return CasinoResult(-wager, f"Dealer wins {dealer} to {player}.")
