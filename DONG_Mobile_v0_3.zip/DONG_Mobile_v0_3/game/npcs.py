from __future__ import annotations

from dataclasses import dataclass
import hashlib
import random


@dataclass(frozen=True)
class NPC:
    name: str
    description: str
    dialogue: tuple[str, ...]
    age: int = 30
    romanceable: bool = False
    routine: tuple[tuple[int, int, str], ...] = ()


# NPCs are intentionally flavor-only in v0.12. Keeping them as data makes it
# easy to add quests, reputation, trading, or combat hooks later without
# hard-coding conversations into the UI.
NPC_POOLS: dict[str, tuple[NPC, ...]] = {
    "Grocery Store": (
        NPC("Mabel Price", "An older woman comparing two suspiciously similar cans of soup.", (
            "Prices keep creeping up. Soup shouldn't require financial planning.",
            "I come here every few days. Fresh food disappears fast around here.",
        )),
        NPC("Derek Mills", "A tired-looking man carrying a basket with bread, water, and far too much coffee.", (
            "Night shift. Again.",
            "If you're buying food, get it before the evening rush.",
        )),
        NPC("Nina Park", "A young woman reading every label before putting anything in her cart.", (
            "I'm trying to figure out which one of these is actually food.",
            "The cheap stuff works. Usually.",
        )),
        NPC("Walter Briggs", "A broad man standing beside a cart containing almost nothing but canned food.", (
            "Stock up when you've got the cash. Going hungry makes every other problem worse.",
            "Water's cheap here. No excuse to wander around thirsty.",
        )),
    ),
    "Bank": (
        NPC("Clara Finch", "A neatly dressed woman clutching a deposit slip like it personally offended her.", (
            "I swear this line moves slower every time I come in.",
            "Keeping cash in your pocket is convenient right up until it isn't.",
        )),
        NPC("Eddie Vale", "A nervous man repeatedly checking his wallet.", (
            "I don't trust banks. I also don't trust myself with cash. It's complicated.",
            "You ever feel poorer after checking your balance? Funny how numbers do that.",
        )),
        NPC("Marvin Cho", "A courier waiting near the counter with a thick envelope tucked under one arm.", (
            "Been running deposits all morning.",
            "Town gets busier every week. More money moving around means more people watching it.",
        )),
    ),
    "Gym": (
        NPC("Tasha Reed", "A focused athlete stretching between sets.", (
            "Consistency beats one heroic workout followed by three days of regret.",
            "Train smart. Being exhausted isn't the same thing as getting stronger.",
        )),
        NPC("Big Ron", "A huge man who appears to consider dumbbells a light snack.", (
            "Everybody starts somewhere.",
            "Strength's useful. So is knowing when not to use it.",
        )),
        NPC("Luis Grant", "A wiry runner pacing beside the treadmills.", (
            "Endurance is just stubbornness with better lungs.",
            "I run so I can eat badly without feeling quite as guilty about it.",
        )),
        NPC("Kim Doyle", "A woman resting on a bench and glaring at the last repetition of her set.", (
            "That last rep is always the one that starts negotiations.",
            "Don't burn all your Energy here if you've still got work to do today.",
        )),
    ),
    "The Drunken Donkey": (
        NPC("Old Pete", "A weathered regular occupying the same stool as if it came with his name on it.", (
            "The Donkey used to be respectable. Then I started coming here.",
            "People talk when they drink. Listening is cheaper than asking questions.",
        )),
        NPC("Jules Mercer", "A cheerful stranger nursing a beer and watching the room.", (
            "First rule of this place: don't challenge the bouncer.",
            "Second rule: if you ignored the first rule, ice helps.",
        )),
        NPC("Frankie Knuckles", "A stocky patron with scarred hands and a grin that suggests several bad decisions.", (
            "You fight over at the Pits yet? Good way to make cash if your face can afford it.",
            "Winning feels better than losing. Deep philosophy, I know.",
        )),
        NPC("Sally Two-Shoes", "A sharply dressed woman with two very different shoes and no apparent concern about it.", (
            "Don't ask about the shoes.",
            "The meal here is better than it looks. That isn't a high bar, but still.",
        )),
    ),
    "The Fighting Pits": (
        NPC("Crusher Cole", "A bruised fighter wrapping his hands before another match.", (
            "Keep your guard up and your expectations low.",
            "Everybody thinks the heavy hit is clever until it misses.",
        )),
        NPC("Mina Sparks", "A compact fighter watching the arena with unsettling concentration.", (
            "Watch your opponent before you swing.",
            "Most fights are decided by whoever stays calm longer.",
        )),
        NPC("Doc Rattle", "A questionable ringside medic carrying a dented metal first-aid box.", (
            "If you're still standing, you're probably fine.",
            "If you're not standing, I'll eventually notice.",
        )),
        NPC("Gus Bell", "An enthusiastic spectator who seems personally invested in every punch.", (
            "Nothing like the Pits! Mostly because civilized places have rules.",
            "I've lost money on three fights today. I call that commitment.",
        )),
    ),
    "Old McDonald's Farm Supplies": (
        NPC("Old McDonald", "A sun-baked farmer who knows every animal on the property by name and most customers by their mistakes.", (
            "If you're buying livestock, make sure you've built somewhere for it to live first.",
            "A fed animal is a productive animal. Seems obvious. Apparently it needed saying.",
            "Horses are quicker than walking, but you'll need a saddle before you ride one anywhere.",
        )),
        NPC("Elsie Hart", "A farmhand carrying a feed bucket and wearing boots that have lost an argument with the mud.", (
            "Chickens are easy until they decide they aren't.",
            "Cows like routine. Feed them, keep them happy, and the milk follows.",
        )),
        NPC("Tom Bell", "A ranch hand checking the stitching on a leather saddle.", (
            "A good horse cuts travel time without needing fuel.",
            "Don't just saddle a horse and forget the feeding part. They tend to object eventually.",
        )),
    ),
    "Carl's Cars": (
        NPC("Carl Wheeler", "A smiling salesman in a cheap tie who somehow knows exactly how much cash you have.", (
            "Every car on this lot has at least four wheels. I checked most of them personally.",
            "Build a Garage before you buy. I sell cars, not municipal parking permits.",
            "The sport coupe is faster. Whether that makes it wiser is between you and your bank account.",
        )),
        NPC("Maya Grease", "A mechanic with oil-stained gloves leaning against the service counter.", (
            "Condition matters. A tired car still moves, just with less enthusiasm.",
            "Keep a Garage free if you're planning to bring another vehicle home.",
        )),
        NPC("Dean Lotman", "A customer circling the cheapest compact with the suspicion it richly deserves.", (
            "Carl says 'character' when the engine makes that noise.",
            "Still beats walking across town in the rain.",
        )),
    ),
    "Outdoors Specials": (
        NPC("Hank Alder", "A hunter inspecting a bowstring with the seriousness of a surgeon.", (
            "A decent tool pays for itself if you actually use it.",
            "Bow's quiet. Rifle's simpler. Both beat chasing dinner with your bare hands.",
        )),
        NPC("June Wilder", "A hiker wearing enough orange to be visible from orbit.", (
            "Bright orange isn't fashionable. It's useful. Fashion can complain from a safe distance.",
            "Good boots matter more than people think.",
        )),
        NPC("Cal Mercer", "A dusty man comparing pickaxes by weight.", (
            "Cheap tools cost twice when you have to replace them.",
            "Stone doesn't care how motivated you are. Bring the right tool.",
        )),
        NPC("Rita Moss", "A quiet outdoorswoman checking the edge on a wood axe.", (
            "A sharp axe saves Energy.",
            "Take care of your gear and it'll usually return the favor.",
        )),
    ),
}


# Vice-era location characters. Kept fictional and intentionally abstract.
NPC_POOLS["The Drunken Donkey"] = NPC_POOLS.get("The Drunken Donkey", ()) + (
    NPC("Shady Man", "A deliberately forgettable man sitting in the darkest corner of the bar.", (
        "I sell seeds. What grows from them is between you and your gardening choices.",
        "Cash only. Questions cost extra, so don't ask any.",
    )),
)
NPC_POOLS["Gus' Gunporium"] = (
    NPC("Gus Mallory", "The cheerful proprietor behind the counter, wearing an apron with far too many pockets.", (
        "Everything here is fictional, expensive, and somehow still needs dusting.",
        "Armor is cheaper than learning to stop getting hit. Usually.",
    )),
    NPC("Tessa Ward", "A range clerk organizing boxes and combat clothing with military neatness.", (
        "The utility shirts are on the left. Protective gear is behind the counter.",
        "People always spend all their money on the weapon and then remember they also wanted boots.",
    )),
    NPC("Mick Harrow", "A customer comparing two field jackets as if civilization depends on the choice.", (
        "I came in for a cap. This is how it starts.",
        "Gus has a frightening talent for turning browsing into ownership.",
    )),
)

NPC_POOLS["Main Street Threads"] = (
    NPC("Vivian Cross", "The store owner, immaculate from collar to shoes and quietly judging every bad color combination.", (
        "Cheap clothes can look good. Expensive clothes can look terrible. Fit and confidence do most of the work.",
        "The back wall is formalwear. Try not to check the price tags while holding your breath.",
    )),
    NPC("Jace Moreno", "A sales associate folding shirts with geometric precision.", (
        "Budget rack is up front. Streetwear is in the middle. Formal is where wallets go to reflect on their choices.",
        "Canvas sneakers never really disappear. Fashion just periodically remembers them.",
    )),
    NPC("Priya Bell", "A shopper comparing two jackets in the mirror with the seriousness of a legal proceeding.", (
        "I came in for jeans. That was forty minutes ago.",
        "The dangerous thing about this place is that everything is only one fitting-room decision away.",
    )),
)
NPC_POOLS["Farmers Market"] = (
    NPC("Mabel Green", "A cheerful market organizer who buys local goods and judges crooked price signs.", (
        "If you made it yourself, somebody here will probably buy it.",
        "Homebrew sells better when the label isn't written in pencil. Usually.",
    )),
    NPC("Eddie Crate", "A produce seller stacking boxes with unnecessary precision.", (
        "Fresh goods move fast around here.",
        "The market opens, the market closes, and somehow I still own too many crates.",
    )),
)
NPC_POOLS["Lucky Horseshoe Casino"] = (
    NPC("Lucky Lou", "A casino regular wearing a suit that has survived several losing streaks.", (
        "The house always looks happier than the customers. Probably coincidence.",
        "I have a system. The system is currently taking a break.",
    )),
    NPC("Nina Vale", "A calm blackjack dealer with the expression of someone who has seen every bad bet before.", (
        "Place the wager, accept the result, resist inventing destiny afterward.",
        "Everybody remembers the jackpot. Nobody writes songs about the hundred quiet losses.",
    )),
)

# Persistent social NPCs follow simple daily routines. Their schedules are intentionally
# readable and deterministic so players can learn where people tend to be.
ROUTINE_NPCS: tuple[NPC, ...] = (
    NPC("Ava Mercer", "A quick-witted barista with a habit of turning errands into conversations.",
        ("I keep seeing the same faces around town. Yours is becoming one of them.", "I like people who actually show up when they say they will."),
        27, True, ((6, 11, "Grocery Store"), (11, 16, "Bank"), (16, 22, "The Drunken Donkey"))),
    NPC("Rowan Hayes", "A quiet carpenter who notices more than he says.",
        ("Wood tells you when you're forcing it. People do too, usually louder.", "I spend most afternoons looking at tools I absolutely do not need."),
        32, True, ((6, 12, "Outdoors Specials"), (12, 18, "Old McDonald's Farm Supplies"), (18, 23, "The Drunken Donkey"))),
    NPC("Chloe Bennett", "An energetic runner who treats every sidewalk like a training route.",
        ("I was going to take a rest day. Then I remembered I hate rest days.", "If you see me at the Donkey later, no you didn't."),
        24, True, ((6, 12, "Gym"), (12, 17, "Grocery Store"), (17, 22, "The Drunken Donkey"))),
    NPC("Marcus Reed", "A patient mechanic who can diagnose an engine by sound and a bad decision by posture.",
        ("Carl sells them. I keep them alive.", "A machine usually tells you what's wrong. People make you guess."),
        35, True, ((7, 17, "Carl's Cars"), (17, 20, "Gym"), (20, 23, "The Drunken Donkey"))),
    NPC("Lena Ortiz", "A sharp-eyed bank clerk who is much less formal once she's off the clock.",
        ("I spend all day watching people move numbers around and call it security.", "Outside work I try very hard not to discuss interest rates."),
        29, True, ((8, 17, "Bank"), (17, 20, "Grocery Store"), (20, 23, "The Drunken Donkey"))),
    NPC("Noah Quinn", "A farmhand with an easy smile and permanently muddy boots.",
        ("Animals make sense. Feed them, care for them, don't stand behind the horse.", "Town is nice, but I sleep better after a day outside."),
        26, True, ((6, 17, "Old McDonald's Farm Supplies"), (17, 20, "Outdoors Specials"), (20, 23, "The Drunken Donkey"))),
    NPC("Ivy Foster", "A competitive fighter who is friendlier outside the ring than anyone expects.",
        ("I don't dislike people. I just enjoy hitting willing volunteers.", "The trick is knowing when a fight is worth having."),
        31, True, ((7, 12, "Gym"), (12, 19, "The Fighting Pits"), (19, 23, "The Drunken Donkey"))),
    NPC("Theo Grant", "A cheerful outdoorsman who can turn a five-minute story into an expedition.",
        ("I've got a shortcut. It only takes twice as long and crosses a creek.", "Good gear and bad ideas make excellent stories."),
        38, True, ((6, 14, "Outdoors Specials"), (14, 18, "Old McDonald's Farm Supplies"), (18, 22, "The Drunken Donkey"))),
    NPC("Mira Chen", "A practical shopper with a dry sense of humor and an alarming memory for details.",
        ("I remember what people say. It's useful and occasionally inconvenient.", "You can tell a lot about someone by how they treat service workers."),
        28, True, ((7, 12, "Grocery Store"), (12, 18, "Bank"), (18, 21, "Gym"))),
    NPC("Dante Brooks", "A confident amateur fighter who is charming right up until competition starts.",
        ("I like winning. I tolerate the parts where someone else gets a turn.", "Respect is easier to keep than to win back."),
        33, True, ((8, 13, "Gym"), (13, 21, "The Fighting Pits"), (21, 23, "The Drunken Donkey"))),
)


def routine_location(npc: NPC, hour: int) -> str | None:
    for start, end, location in npc.routine:
        if start <= hour < end:
            return location
    return None


def npc_by_name(name: str) -> NPC | None:
    for npc in ROUTINE_NPCS:
        if npc.name == name:
            return npc
    for pool in NPC_POOLS.values():
        for npc in pool:
            if npc.name == name:
                return npc
    return None


def npcs_for_location(location: str, day: int, hour: int = 12, minimum: int = 1, maximum: int = 3) -> list[NPC]:
    """Return routine NPCs present now plus a small stable daily background crowd."""
    routine_people = [npc for npc in ROUTINE_NPCS if routine_location(npc, hour) == location]
    pool = list(NPC_POOLS.get(location, ()))
    background: list[NPC] = []
    if pool:
        seed_text = f"DONG|{location}|{day}".encode("utf-8")
        seed = int.from_bytes(hashlib.sha256(seed_text).digest()[:8], "big")
        rng = random.Random(seed)
        count = min(len(pool), rng.randint(minimum, maximum))
        background = rng.sample(pool, count)
    names = {npc.name for npc in routine_people}
    return routine_people + [npc for npc in background if npc.name not in names]
