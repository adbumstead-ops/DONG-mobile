from __future__ import annotations

import random
import time
from game.models import GameState

PICKPOCKET_FINE = 1000
THEFT_JAIL_DAYS = 1
MURDER_JAIL_DAYS = 7
WITNESS_CHANCE = 0.50
HIDDEN_CACHE_CAPACITY = 3
BODY_CARRY_MIN_SECONDS = 45
BODY_CARRY_MAX_SECONDS = 90


def ensure_crime_state(state: GameState) -> None:
    state.crime_record = dict(state.crime_record or {})
    for key in ("Pickpocket", "Theft", "Murder", "Arrests"):
        state.crime_record[key] = int(state.crime_record.get(key, 0) or 0)
    state.crime_bodies = [dict(body or {}) for body in (state.crime_bodies or [])]
    state.jail_inventory = dict(state.jail_inventory or {})
    state.jail_days_remaining = int(state.jail_days_remaining or 0)
    state.jail_behavior = int(state.jail_behavior or 0)
    state.jail_cash = float(state.jail_cash or 0.0)


def witness_roll(state: GameState, victim_name: str, crime_name: str) -> bool:
    seed = f"DONG-crime-{state.character_name}-{state.day}-{state.hour}-{state.minute}-{victim_name}-{crime_name}-{len(state.activity_log)}"
    return random.Random(seed).random() < WITNESS_CHANCE


def add_body_evidence(state: GameState, victim_name: str) -> dict:
    ensure_crime_state(state)
    seed = f"DONG-carry-{state.character_name}-{state.day}-{state.hour}-{state.minute}-{victim_name}-{len(state.crime_bodies)}"
    delay = random.Random(seed).randint(BODY_CARRY_MIN_SECONDS, BODY_CARRY_MAX_SECONDS)
    body = {
        "victim": victim_name,
        "storage": "carried",
        "vehicle": "",
        "structure_slot": -1,
        "buried_day": 0,
        "linked": False,
        "carry_discovery_ts": time.time() + delay,
    }
    state.crime_bodies.append(body)
    return body


def carried_bodies(state: GameState) -> list[dict]:
    ensure_crime_state(state)
    return [body for body in state.crime_bodies if body.get("storage") == "carried"]



def arm_body_carry_timer(state: GameState, body: dict) -> None:
    """Start a fresh hidden discovery timer for body evidence being carried."""
    ensure_crime_state(state)
    victim = str(body.get("victim", "Unknown"))
    seed = f"DONG-recarry-{state.character_name}-{state.day}-{state.hour}-{state.minute}-{victim}-{len(state.activity_log)}"
    delay = random.Random(seed).randint(BODY_CARRY_MIN_SECONDS, BODY_CARRY_MAX_SECONDS)
    body["carry_discovery_ts"] = time.time() + delay


def carried_body_due(state: GameState, now: float | None = None) -> dict | None:
    """Return the first carried body whose hidden police-discovery timer has expired."""
    ensure_crime_state(state)
    current = time.time() if now is None else float(now)
    for body in carried_bodies(state):
        if body.get("linked"):
            continue
        deadline = float(body.get("carry_discovery_ts", 0.0) or 0.0)
        if deadline <= 0:
            arm_body_carry_timer(state, body)
            deadline = float(body.get("carry_discovery_ts", 0.0) or 0.0)
        if current >= deadline:
            return body
    return None

def unresolved_bodies(state: GameState) -> list[dict]:
    ensure_crime_state(state)
    return [body for body in state.crime_bodies if not body.get("linked")]


def arrest(state: GameState, days: int, reason: str) -> None:
    ensure_crime_state(state)
    state.crime_record["Arrests"] += 1
    state.jail_days_remaining += max(0, int(days))
    state.jail_behavior = 0
    state.jail_inventory = {"Soap": 1, "Library Card": 1}
    state.current_location = "Jail"
    state.add_activity(f"You were arrested for {reason}. Sentence: {days} day(s).")


def process_evidence_checks(state: GameState) -> list[str]:
    """Abstract overnight discovery checks. Returns messages for newly linked evidence."""
    ensure_crime_state(state)
    messages: list[str] = []
    for index, body in enumerate(state.crime_bodies):
        if body.get("linked"):
            continue
        storage = str(body.get("storage", "carried"))
        chance = {"carried": 0.40, "trunk": 0.20, "park": 0.15, "cache": 0.08}.get(storage, 0.10)
        rng = random.Random(f"DONG-evidence-{state.character_name}-{state.day}-{index}-{storage}")
        if rng.random() < chance:
            body["linked"] = True
            victim = str(body.get("victim", "Unknown"))
            messages.append(f"Police connected evidence from {victim}'s death to you. Another 7-day sentence was added.")
            state.jail_days_remaining += MURDER_JAIL_DAYS
    if messages and state.jail_days_remaining > 0:
        state.current_location = "Jail"
        state.jail_inventory = {"Soap": 1, "Library Card": 1}
        state.crime_record["Arrests"] = int(state.crime_record.get("Arrests", 0) or 0) + 1
    return messages


def jail_day(state: GameState) -> tuple[bool, str]:
    ensure_crime_state(state)
    if state.jail_days_remaining <= 0:
        return False, "You are not serving a sentence."
    state.day += 1
    state.hour = 8
    state.minute = 0
    state.energy = state.max_energy
    state.health = min(state.max_health, state.health + 10)
    state.jail_days_remaining = max(0, state.jail_days_remaining - 1)
    message = "A day of your sentence passes."
    if state.jail_behavior >= 3 and state.jail_days_remaining > 0:
        state.jail_days_remaining -= 1
        state.jail_behavior -= 3
        message += " Good behavior reduced your sentence by an extra day."
    if state.jail_days_remaining <= 0:
        state.cash += state.jail_cash
        earned = state.jail_cash
        state.jail_cash = 0.0
        state.jail_inventory = {}
        state.current_location = "Jail"
        message += f" Your sentence is complete. Prison earnings paid out: ${earned:,.2f}."
        return True, message
    return False, message
