from __future__ import annotations

import random
from game.models import GameState

CONTACT_SCORE = 10
FLIRT_SCORE = 15
DATE_SCORE = 30
INTIMATE_SCORE = 55
MARRY_SCORE = 80
MORTAL_ENEMY_SCORE = -70


def ensure_relationship(state: GameState, npc_name: str) -> dict:
    record = state.relationships.setdefault(npc_name, {})
    record.setdefault("score", 0)
    record.setdefault("romance", "None")
    record.setdefault("last_actions", {})
    record.setdefault("met", True)
    return record


def score(state: GameState, npc_name: str) -> int:
    return int(ensure_relationship(state, npc_name).get("score", 0) or 0)


def status(state: GameState, npc_name: str) -> str:
    r = ensure_relationship(state, npc_name)
    value = int(r.get("score", 0) or 0)
    romance = str(r.get("romance", "None") or "None")
    if value <= MORTAL_ENEMY_SCORE:
        return "Mortal Enemy"
    if value <= -35:
        return "Enemy"
    if value <= -10:
        return "Rival"
    if romance == "Married":
        return "Spouse"
    if romance == "Intimate":
        return "Partner"
    if romance == "Dating":
        return "Dating"
    if romance == "Flirting":
        return "Flirting"
    if value >= 60:
        return "Close Friend"
    if value >= 25:
        return "Friend"
    if value >= CONTACT_SCORE:
        return "Acquaintance"
    return "Stranger"


def action_available_today(state: GameState, npc_name: str, action: str) -> bool:
    r = ensure_relationship(state, npc_name)
    return int(r.get("last_actions", {}).get(action, 0) or 0) != state.day


def apply_score_action(state: GameState, npc_name: str, action: str, delta: int) -> tuple[bool, str]:
    r = ensure_relationship(state, npc_name)
    if not action_available_today(state, npc_name, action):
        return False, f"You already used {action.lower()} with {npc_name} today."
    r["last_actions"][action] = state.day
    r["score"] = max(-100, min(100, int(r.get("score", 0) or 0) + delta))
    return True, status(state, npc_name)


def add_contact(state: GameState, npc_name: str) -> tuple[bool, str]:
    if score(state, npc_name) < CONTACT_SCORE:
        return False, "Build the relationship a little more before asking for their number."
    if npc_name in state.contacts:
        return False, f"{npc_name} is already in your contacts."
    state.contacts.append(npc_name)
    return True, f"{npc_name} was added to your Phone contacts."


def set_romance(state: GameState, npc_name: str, stage: str) -> None:
    ensure_relationship(state, npc_name)["romance"] = stage


def make_child(state: GameState, spouse_name: str) -> dict:
    first_names = ("Jamie", "Riley", "Morgan", "Casey", "Avery", "Jordan", "Quinn", "Taylor", "Parker", "Sam")
    existing = {str(c.get("name", "")) for c in state.children}
    rng = random.Random(f"DONG-child-{state.character_name}-{spouse_name}-{state.day}-{len(state.children)}")
    choices = [n for n in first_names if n not in existing] or list(first_names)
    name = rng.choice(choices)
    child = {"name": name, "age": 0, "born_day": state.day, "parents": [state.character_name, spouse_name]}
    state.children.append(child)
    return child
