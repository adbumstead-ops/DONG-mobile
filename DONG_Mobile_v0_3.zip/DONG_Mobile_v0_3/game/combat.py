from __future__ import annotations

import random
from dataclasses import dataclass

from game.models import GameState
from game.gunporium import GUN_ARMOR, GUN_WEAPONS


@dataclass
class Enemy:
    name: str
    max_health: int
    health: int
    min_damage: int
    max_damage: int
    cash_reward: int


ENEMY_TEMPLATES = (
    ("Drunk Troublemaker", 32, 3, 7, 18),
    ("Back Alley Punk", 38, 4, 8, 24),
    ("Angry Bouncer", 46, 5, 10, 32),
)


def make_random_enemy() -> Enemy:
    name, hp, min_damage, max_damage, reward = random.choice(ENEMY_TEMPLATES)
    return Enemy(name, hp, hp, min_damage, max_damage, reward)


def player_attack_damage(state: GameState, move: str) -> tuple[bool, int, str]:
    """Return hit, damage, combat text for one very simple player move."""
    weapon = state.equipment.get("Weapon", "None")
    weapon_bonus = GUN_WEAPONS.get(weapon, 0)
    if move == "Punch":
        damage = random.randint(4, 7) + max(0, state.strength // 3) + weapon_bonus
        if weapon_bonus:
            return True, damage, f"You attacked with {weapon} for {damage} damage."
        return True, damage, f"You punched for {damage} damage."

    if move == "Heavy Hit":
        if random.random() < 0.75:
            damage = random.randint(7, 12) + max(0, state.strength // 2) + weapon_bonus
            if weapon_bonus:
                return True, damage, f"Your heavy attack with {weapon} landed for {damage} damage."
            return True, damage, f"Your heavy hit landed for {damage} damage."
        return False, 0, "Your heavy hit missed."

    raise ValueError(f"Unknown move: {move}")


def enemy_attack_damage(enemy: Enemy, state: GameState | None = None) -> int:
    raw = random.randint(enemy.min_damage, enemy.max_damage)
    if state is None:
        return raw
    defense = 0
    for item in state.equipment.values():
        armor = GUN_ARMOR.get(item)
        if armor:
            defense += armor[1]
    return max(1, raw - defense)
