from __future__ import annotations

import random
from dataclasses import dataclass

from game.models import GameState
from game.gunporium import GUN_ARMOR, GUN_WEAPONS


@dataclass(frozen=True)
class DungeonShopItem:
    name: str
    price: int
    kind: str
    description: str


DUNGEON_WEAPONS = {
    "Rusty Dungeon Sword": 3,
    "Crypt Blade": 6,
    "Knight's Longsword": 9,
    "Voidfang": 13,
}

DUNGEON_ARMOR = {
    "Gravekeeper Hood": ("Head", 1),
    "Ironbound Helm": ("Head", 3),
    "Mosscloak Jerkin": ("Outer Wear", 1),
    "Graveforged Cuirass": ("Outer Wear", 4),
    "Worn Leather Trousers": ("Pants", 1),
    "Blacksteel Greaves": ("Pants", 3),
    "Ranger Boots": ("Feet", 1),
    "Ironbound Sabatons": ("Feet", 3),
    # Easter-egg armor pieces. Their names are playful allusions rather than branded items.
    "Knee-Arrow Guard": ("Pants", 2),
    "Sun-Praiser's Surcoat": ("Outer Wear", 2),
    "Leather Padding": ("Outer Wear", 1),
    "Chainmail Hauberk": ("Outer Wear", 2),
    "Iron Chest Plate": ("Outer Wear", 4),
    "Blacksteel Chest Plate": ("Outer Wear", 5),
}

GIFT_SHOP_ITEMS = (
    DungeonShopItem("Mossgreen Tunic", 55, "clothing", "Soft green adventuring clothes. No defense, but considerably more heroic than a T-shirt."),
    DungeonShopItem("Worn Leather Trousers", 110, "armor", "Scuffed leather pants with too many pockets. Dungeon defense +1."),
    DungeonShopItem("Gravekeeper Hood", 90, "armor", "A charcoal hood smelling faintly of dust and bad decisions. Dungeon defense +1."),
    DungeonShopItem("Mosscloak Jerkin", 140, "armor", "A weathered green leather jerkin. Dungeon defense +1."),
    DungeonShopItem("Ranger Boots", 100, "armor", "Soft-soled boots made for suspicious corridors. Dungeon defense +1."),
    DungeonShopItem("Ironbound Helm", 350, "armor", "A battered iron helm with a heroic dent. Dungeon defense +3."),
    DungeonShopItem("Graveforged Cuirass", 700, "armor", "Blackened plate hammered into shape somewhere unpleasant. Dungeon defense +4."),
    DungeonShopItem("Blacksteel Greaves", 450, "armor", "Heavy greaves polished just enough to look expensive. Dungeon defense +3."),
    DungeonShopItem("Ironbound Sabatons", 400, "armor", "Armored boots that announce every stealth attempt. Dungeon defense +3."),
    DungeonShopItem("Leather Padding", 125, "armor", "Layered leather protection for beginning adventurers. Dungeon defense +1."),
    DungeonShopItem("Chainmail Hauberk", 360, "armor", "Linked metal armor with excellent jingle-per-step value. Dungeon defense +2."),
    DungeonShopItem("Iron Chest Plate", 680, "armor", "Heavy iron torso armor. Dungeon defense +4."),
    DungeonShopItem("Blacksteel Chest Plate", 1350, "armor", "Dark forged plate for serious dungeon work. Dungeon defense +5."),
    DungeonShopItem("Rusty Dungeon Sword", 125, "weapon", "A sword with more tetanus than prestige. Dungeon attack +3."),
    DungeonShopItem("Crypt Blade", 550, "weapon", "A cold, narrow blade recovered from somewhere best left unnamed. Dungeon attack +6."),
    DungeonShopItem("Knight's Longsword", 1200, "weapon", "A proper adventurer's sword with inconveniently good balance. Dungeon attack +9."),
    DungeonShopItem("Voidfang", 3000, "weapon", "An ominous black blade. The shopkeeper refuses to explain the humming. Dungeon attack +13."),
    DungeonShopItem("Green Wanderer's Cap", 225, "clothing", "A long green cap for heroes who feel compelled to inspect every clay pot."),
    DungeonShopItem("Chicken Chaser's Tunic", 275, "clothing", "A rustic tunic for adventurers with complicated relationships with poultry."),
    DungeonShopItem("Knee-Arrow Guard", 325, "armor", "A reinforced knee guard for retired adventurers reconsidering their career choices. Dungeon defense +2."),
    DungeonShopItem("Sun-Praiser's Surcoat", 475, "armor", "A bright ceremonial surcoat for people with suspicious enthusiasm about sunlight. Dungeon defense +2."),
    DungeonShopItem("Second-Breakfast Waistcoat", 180, "clothing", "Comfortable travel wear with enough pockets for snacks before lunch."),
)

PUZZLES = (
    ("I have keys but no locks, space but no rooms. What am I?", ["A keyboard", "A map", "A clock"], 0),
    ("What gets wetter the more it dries?", ["A sponge", "A towel", "Rain"], 1),
    ("What has hands but cannot clap?", ["A clock", "A statue", "A chair"], 0),
    ("What has one eye but cannot see?", ["A needle", "A storm", "A potato"], 0),
    ("What can travel around the world while staying in one corner?", ["A shadow", "A stamp", "A compass"], 1),
    ("The more you take, the more you leave behind. What are they?", ["Coins", "Footsteps", "Memories"], 1),
)

ENEMY_NAMES = (
    "Cellar Rat Swarm", "Cave Goblin", "Bone Walker", "Dungeon Bandit", "Tunnel Slime",
    "Crypt Hound", "Armored Skeleton", "Cultist", "Stone Brute", "Shadow Stalker",
)

BOSS_NAMES = {
    10: "The Gatekeeper",
    20: "The Rat King",
    30: "The Iron Warden",
    40: "The Bone Collector",
    50: "The Hollow Knight",
    60: "The Deepfang",
    70: "The Ashen Giant",
    80: "The Black Chancellor",
    90: "The Last Warden",
    100: "The Thing Beneath DONG",
}


def ensure_dungeon_state(state: GameState) -> None:
    state.dungeon_checkpoint = max(1, min(100, int(getattr(state, "dungeon_checkpoint", 1) or 1)))
    state.dungeon_floor = max(0, min(100, int(getattr(state, "dungeon_floor", 0) or 0)))
    state.dungeon_active = bool(getattr(state, "dungeon_active", False))
    state.dungeon_encounter = dict(getattr(state, "dungeon_encounter", {}) or {})
    state.dungeon_clears = max(0, int(getattr(state, "dungeon_clears", 0) or 0))


def start_run(state: GameState, floor: int) -> None:
    ensure_dungeon_state(state)
    floor = max(1, min(100, int(floor)))
    state.dungeon_floor = floor
    state.dungeon_active = True
    state.dungeon_encounter = {}


def end_run(state: GameState) -> None:
    ensure_dungeon_state(state)
    state.dungeon_active = False
    state.dungeon_floor = 0
    state.dungeon_encounter = {}


def make_encounter(state: GameState) -> dict:
    ensure_dungeon_state(state)
    floor = state.dungeon_floor
    if floor % 10 == 0:
        kind = "fight"
        boss = True
    else:
        roll = random.random()
        kind = "fight" if roll < 0.50 else "trap" if roll < 0.70 else "puzzle" if roll < 0.90 else "treasure"
        boss = False

    if kind == "fight":
        base_hp = 20 + floor * 2
        if boss:
            base_hp = 60 + floor * 3
        name = BOSS_NAMES.get(floor, random.choice(ENEMY_NAMES)) if boss else random.choice(ENEMY_NAMES)
        encounter = {
            "kind": "fight", "name": name, "boss": boss,
            "max_health": base_hp, "health": base_hp,
            "min_damage": max(2, 2 + floor // 10),
            "max_damage": max(5, 5 + floor // 6 + (4 if boss else 0)),
        }
    elif kind == "trap":
        encounter = {"kind": "trap", "name": random.choice(("Pressure Plates", "Swinging Blades", "Falling Stones", "Hidden Pit", "Dart Hallway"))}
    elif kind == "puzzle":
        q, options, answer = random.choice(PUZZLES)
        encounter = {"kind": "puzzle", "question": q, "options": options, "answer": answer}
    else:
        encounter = {"kind": "treasure", "name": random.choice(("Dusty Chest", "Forgotten Strongbox", "Glittering Cache", "Suspiciously Convenient Chest"))}
    state.dungeon_encounter = encounter
    return encounter


def dungeon_defense(state: GameState) -> int:
    total = 0
    for item in state.equipment.values():
        armor = DUNGEON_ARMOR.get(item)
        if armor:
            total += armor[1]
        elif item in GUN_ARMOR:
            total += GUN_ARMOR[item][1]
    return total


def weapon_bonus(state: GameState) -> int:
    return DUNGEON_WEAPONS.get(state.equipment.get("Weapon", "None"), 0) + GUN_WEAPONS.get(state.equipment.get("Weapon", "None"), 0)


def player_damage(state: GameState, heavy: bool = False) -> tuple[bool, int]:
    if heavy and random.random() > 0.72:
        return False, 0
    low, high = (7, 13) if heavy else (4, 8)
    damage = random.randint(low, high) + max(0, state.strength // 3) + weapon_bonus(state)
    return True, damage


def enemy_damage(state: GameState, encounter: dict) -> int:
    raw = random.randint(int(encounter.get("min_damage", 2)), int(encounter.get("max_damage", 6)))
    return max(1, raw - dungeon_defense(state))


def roll_loot(state: GameState, floor: int, boss: bool = False) -> list[str]:
    messages: list[str] = []
    cash = random.randint(8 + floor * 2, 18 + floor * 5) * (3 if boss else 1)
    state.cash += cash
    messages.append(f"${cash:,}")

    if random.random() < 0.35:
        item = random.choice(("Food", "Water"))
        qty = 2 if boss else 1
        state.inventory[item] = state.inventory.get(item, 0) + qty
        messages.append(f"{item} x{qty}")

    rare_chance = min(0.08 + floor / 500.0 + (0.22 if boss else 0), 0.48)
    if random.random() < rare_chance:
        pools = []
        if floor >= 10:
            pools += ["Gravekeeper Hood", "Mosscloak Jerkin", "Worn Leather Trousers", "Ranger Boots", "Leather Padding", "Rusty Dungeon Sword"]
        if floor >= 35:
            pools += ["Ironbound Helm", "Blacksteel Greaves", "Ironbound Sabatons", "Chainmail Hauberk", "Crypt Blade"]
        if floor >= 60:
            pools += ["Graveforged Cuirass", "Iron Chest Plate", "Knight's Longsword", "Knee-Arrow Guard", "Sun-Praiser's Surcoat"]
        if floor >= 90:
            pools += ["Blacksteel Chest Plate", "Voidfang"]
        if pools:
            item = random.choice(pools)
            state.inventory[item] = state.inventory.get(item, 0) + 1
            messages.append(item)
    return messages


def clear_floor(state: GameState) -> tuple[list[str], bool]:
    ensure_dungeon_state(state)
    floor = state.dungeon_floor
    boss = bool(state.dungeon_encounter.get("boss", False))
    loot = roll_loot(state, floor, boss=boss)
    state.dungeon_clears += 1
    completed = floor >= 100
    if floor % 10 == 0:
        state.dungeon_checkpoint = max(state.dungeon_checkpoint, floor)
    if completed:
        end_run(state)
    else:
        state.dungeon_floor += 1
        state.dungeon_encounter = {}
    return loot, completed
