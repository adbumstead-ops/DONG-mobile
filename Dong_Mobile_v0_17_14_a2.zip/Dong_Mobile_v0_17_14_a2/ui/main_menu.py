from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from game.game_state import GameState
from ui.new_game_dialog import NewGameDialog
from ui.main_window import GameWindow
from platform_support import IS_ANDROID, show_app_window


STYLE = """
QWidget {
    background: #0b0f11;
    color: #ece7dc;
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 13px;
}
QPushButton {
    background: transparent;
    color: #e9e2d5;
    border: none;
    border-bottom: 1px solid #334047;
    border-radius: 0px;
    padding: 10px 8px;
    min-width: 180px;
    font-weight: 750;
}
QPushButton:hover { color: #e1b469; border-bottom: 1px solid #c89b52; }
QPushButton:pressed { color: #a98248; }
QPushButton:disabled { color: #505a5f; border-bottom-color: #202a2f; }
QLineEdit {
    background: transparent;
    color: #eee8dc;
    border: none;
    border-bottom: 1px solid #4a5960;
    border-radius: 0px;
    padding: 9px 4px;
    selection-background-color: #765b31;
}
QLineEdit:focus { border-bottom: 1px solid #c89b52; }
#Title { font-size: 58px; font-weight: 900; color: #f2d5a1; letter-spacing: 7px; }
#Tagline { color: #aaa397; font-size: 15px; }
#Accent { color: #8c7046; font-size: 9px; font-weight: 800; letter-spacing: 4px; }
#Subtle { color: #596369; }
"""

MOBILE_STYLE = """
QWidget { font-size: 16px; }
QPushButton { min-width: 0px; min-height: 48px; padding: 11px 8px; font-size: 16px; }
#Title { font-size: 44px; letter-spacing: 5px; }
#Tagline { font-size: 16px; }
#Accent { font-size: 10px; letter-spacing: 2px; }
"""


class MainMenu(QMainWindow):
    def __init__(self, game_state: GameState) -> None:
        super().__init__()
        self.game_state = game_state
        self.game_window: GameWindow | None = None

        self.setWindowTitle("Dong")
        if IS_ANDROID:
            self.setMinimumSize(0, 0)
        else:
            self.resize(900, 600)
        self.setStyleSheet(STYLE + (MOBILE_STYLE if IS_ANDROID else ""))

        root = QWidget()
        layout = QVBoxLayout(root)
        if IS_ANDROID:
            layout.setContentsMargins(24, 28, 24, 20)
            layout.setSpacing(10)
        else:
            layout.setContentsMargins(80, 68, 80, 42)
            layout.setSpacing(12)
        layout.addStretch()

        accent = QLabel("A PERSISTENT LIFE RPG")
        accent.setObjectName("Accent")
        accent.setAlignment(Qt.AlignCenter)
        layout.addWidget(accent)

        title = QLabel("DONG")
        title.setObjectName("Title")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        subtitle = QLabel("Build a life in Dong.")
        subtitle.setObjectName("Tagline")
        subtitle.setAlignment(Qt.AlignCenter)
        layout.addWidget(subtitle)

        buttons = QVBoxLayout()
        buttons.setSpacing(2)

        new_game = QPushButton("NEW GAME")
        new_game.clicked.connect(self.start_new_game)
        buttons.addWidget(new_game)

        self.continue_button = QPushButton("CONTINUE")
        self.continue_button.setEnabled(self.game_state.has_save())
        self.continue_button.clicked.connect(self.continue_game)
        buttons.addWidget(self.continue_button)

        layout.addLayout(buttons)
        layout.addStretch()

        build = QLabel("Prototype v0.17.14 — Character Life Sheet")
        build.setObjectName("Subtle")
        build.setAlignment(Qt.AlignCenter)
        layout.addWidget(build)

        self.setCentralWidget(root)

    def start_new_game(self) -> None:
        dialog = NewGameDialog(self)
        if dialog.exec():
            character = self.game_state.create_new_game(dialog.character_name())
            self.open_game(character.name)

    def continue_game(self) -> None:
        character = self.game_state.load_character()
        self.open_game(character.name)

    def open_game(self, _name: str) -> None:
        self.game_window = GameWindow(self.game_state, on_return_to_menu=self.return_to_menu)
        show_app_window(self.game_window)
        self.hide()

    def return_to_menu(self) -> None:
        if self.game_window is not None:
            self.game_window.close()
            self.game_window = None
        self.continue_button.setEnabled(self.game_state.has_save())
        show_app_window(self)
