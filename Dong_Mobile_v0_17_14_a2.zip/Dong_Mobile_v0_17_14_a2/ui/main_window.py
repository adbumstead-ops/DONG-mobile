from __future__ import annotations

import math

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QFrame,
    QDialog,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QInputDialog,
    QProgressBar,
    QPushButton,
    QGridLayout,
    QScrollArea,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from game.combat import WEAPONS, weapon_moves
from game.crime import CRIMES, CRIME_JOBS, MASK_DESCRIPTION, MASK_NAME, MASK_PRICE
from game.business import BUSINESSES, PRICE_TIERS
from game.economy import JOBS, STORE_ITEMS
from game.careers import CAREERS
from game.daily_life import (
    DINER_MEALS, PREPARED_FOODS, RECIPES, clinic_price, daily_event, diner_discount,
    produce_sale_multiplier,
)
from game.farming import CROPS, PRODUCE_ITEMS, SEED_ITEMS
from game.gathering import CRAFT_RECIPES
from game.livestock import (
    ANIMALS, ANIMAL_PRODUCTS, FEED_SACK_DESCRIPTION, FEED_SACK_NAME, FEED_SACK_PORTIONS,
    FEED_SACK_PRICE, MAX_STORED_OUTPUT,
)
from game.game_state import GameState
from game.property import FURNITURE, FURNITURE_STORE, STRUCTURES
from game.world import (LOCATIONS, REGIONS, location_name, method_allowed_on_route, normalize_location_key, plot_summary, public_transport_options, region_key_for_location, route_fuel_units, travel_seconds)
from game.vehicles import FUEL_PRICE_PER_UNIT, REPAIR_PRICE_PER_CONDITION, VEHICLES
from game.life_expansion import EDUCATION_PROGRAMS, PETS, SCHOOL_NAME
from game.vice import ALCOHOL_ITEMS, DRUG_ITEMS
from platform_support import IS_ANDROID


STYLE = """
QWidget {
    background: #0b0f12;
    color: #eee9df;
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 13px;
}
QFrame#TopBar {
    background: transparent;
    border: none;
    border-bottom: 1px solid #202c33;
    border-radius: 0px;
}
QFrame#Sidebar {
    background: transparent;
    border: none;
    border-right: 1px solid #1d282e;
    border-radius: 0px;
}
QFrame#ContentPanel {
    background: transparent;
    border: none;
    border-radius: 0px;
}
QFrame#Card {
    background: transparent;
    border: none;
    border-radius: 0px;
}
QFrame#HubRow {
    border: none;
    border-bottom: 1px solid #202a30;
    background: transparent;
}
QFrame#Divider {
    background: #263239;
    border: none;
    min-height: 1px;
    max-height: 1px;
}
QPushButton {
    background: #172126;
    color: #eee9df;
    border: 1px solid #3b4b53;
    border-radius: 6px;
    padding: 7px 11px;
    text-align: left;
    font-weight: 650;
}
QPushButton:hover {
    background: #202d33;
    border-color: #d2a65d;
    color: #fff8e9;
}
QPushButton:pressed { background: #131b20; border-color: #ad8547; }
QPushButton:disabled { color: #626b70; border-color: #253137; background: #11171b; }
QPushButton#NavLink {
    background: transparent;
    border: none;
    border-left: 3px solid transparent;
    border-radius: 4px;
    padding: 8px 7px 8px 11px;
    color: #929da3;
    font-weight: 600;
    text-align: left;
}
QPushButton#NavLink:hover {
    background: #151d22;
    color: #efe9dc;
}
QPushButton#NavLink:checked {
    background: #1a2225;
    border-left: 3px solid #d2a65d;
    color: #fff4dd;
}
QPushButton#NavUtility {
    background: transparent;
    border: none;
    border-radius: 4px;
    padding: 7px 7px 7px 11px;
    color: #6e7b81;
    font-weight: 500;
    text-align: left;
}
QPushButton#NavUtility:hover { color: #e7dfd1; background: #151d22; }
QPushButton#HubLink, QPushButton#HubTile {
    background: transparent;
    border: none;
    border-radius: 0px;
    padding: 5px 8px 5px 0px;
    color: #eee9df;
    font-size: 15px;
    font-weight: 700;
    text-align: left;
}
QPushButton#HubLink:hover, QPushButton#HubTile:hover {
    color: #e1b66e;
    text-decoration: underline;
}
QPushButton#HubTile:pressed { color: #bd9250; }
QLabel#LocationCaption {
    color: #738087;
    font-size: 9px;
    font-weight: 700;
    letter-spacing: 1px;
}
QLabel#LocationTitle {
    color: #fff5e3;
    font-size: 18px;
    font-weight: 750;
}
QLabel#StatusMetric,
QLabel#StatusClock,
QLabel#StatusWorld,
QLabel#StatusHealth,
QLabel#StatusStamina,
QLabel#StatusCash {
    background: transparent;
    border: none;
    border-radius: 0px;
    padding: 4px 9px;
    color: #d6dcdf;
    font-family: Consolas, 'Courier New', monospace;
    font-size: 11px;
    font-weight: 700;
}
QLabel#StatusClock { color: #a9c9df; }
QLabel#StatusWorld { color: #c9b0d5; }
QLabel#StatusHealth { color: #e4a0a0; }
QLabel#StatusStamina { color: #e2be79; }
QLabel#StatusCash { color: #9ed0aa; }
QProgressBar {
    border: 1px solid #334149;
    border-radius: 4px;
    background: #101519;
    text-align: center;
    min-height: 18px;
    color: #e8e3d9;
    font-size: 11px;
}
QProgressBar::chunk {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #9a7843, stop:1 #d2a65d);
    border-radius: 3px;
}
QScrollArea { border: none; background: transparent; }
QScrollBar:vertical {
    background: transparent;
    width: 9px;
    margin: 2px;
}
QScrollBar::handle:vertical {
    background: #344149;
    min-height: 30px;
    border-radius: 4px;
}
QScrollBar::handle:vertical:hover { background: #56666e; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
#Heading {
    color: #e1b66e;
    font-size: 14px;
    font-weight: 750;
    letter-spacing: 1px;
    padding: 5px 0px 3px 0px;
}
#BigHeading {
    color: #fff5e3;
    background: transparent;
    border: none;
    border-left: 4px solid #d2a65d;
    border-radius: 0px;
    font-size: 22px;
    font-weight: 800;
    padding: 4px 0px 4px 13px;
}
#SidebarTitle {
    color: #fff1d5;
    font-size: 21px;
    font-weight: 850;
    letter-spacing: 2px;
    padding: 3px 0px 0px 11px;
}
#SidebarCaption {
    color: #8b7148;
    font-size: 9px;
    font-weight: 750;
    padding-left: 11px;
    letter-spacing: 2px;
}
#Muted { color: #8c989e; }
#Notice {
    color: #f0d29b;
    background: transparent;
    border: none;
    border-left: 3px solid #8b7148;
    padding: 5px 0px 5px 10px;
}
"""


MOBILE_STYLE = """
QWidget { font-size: 15px; }
QPushButton { min-height: 46px; padding: 10px 11px; font-size: 15px; }
QPushButton#MobileMenuButton {
    min-width: 74px;
    max-width: 84px;
    min-height: 40px;
    padding: 6px 9px;
    background: #172126;
    border: 1px solid #3b4b53;
    color: #f2d8a8;
    text-align: center;
    font-size: 12px;
    font-weight: 800;
}
QPushButton#MobileMenuButton:pressed { background: #10171b; border-color: #d2a65d; }
QFrame#MobileDrawer {
    background: #0f161a;
    border: 1px solid #26343b;
    border-radius: 6px;
}
QPushButton#NavLink, QPushButton#NavUtility {
    min-height: 46px;
    padding: 9px 12px;
    text-align: left;
    font-size: 15px;
}
QPushButton#HubLink, QPushButton#HubTile { min-height: 44px; font-size: 15px; padding: 8px 4px; }
QLabel#LocationTitle { font-size: 17px; }
QLabel#StatusMetric, QLabel#StatusClock, QLabel#StatusWorld, QLabel#StatusHealth, QLabel#StatusStamina, QLabel#StatusCash {
    font-size: 11px; padding: 4px 5px; min-height: 26px;
}
#BigHeading { font-size: 20px; padding-left: 9px; }
#Heading { font-size: 13px; }
"""

class HoverRevealButton(QPushButton):
    def __init__(self, title: str, description: str, description_label: QLabel, on_click) -> None:
        super().__init__(title)
        self.description = description
        self.description_label = description_label
        self.default_description = description_label.text()
        self.setObjectName("HubTile")
        self.setFlat(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip(description)
        self.pressed.connect(self.reveal_description)
        self.clicked.connect(on_click)

    def reveal_description(self) -> None:
        if self.description_label is not None:
            self.description_label.setText(self.description)

    def enterEvent(self, event) -> None:  # type: ignore[override]
        if self.description_label is not None:
            self.description_label.setText(self.description)
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:  # type: ignore[override]
        if self.description_label is not None:
            self.description_label.setText(self.default_description)
        super().leaveEvent(event)


class GameWindow(QMainWindow):
    def __init__(self, game_state: GameState, on_return_to_menu) -> None:
        super().__init__()
        self.game_state = game_state
        self.on_return_to_menu = on_return_to_menu
        self.nav_buttons: dict[str, QPushButton] = {}
        self.notice_text = ""
        self.travel_remaining_label: QLabel | None = None
        self.travel_progress: QProgressBar | None = None
        self.job_remaining_label: QLabel | None = None
        self.job_progress: QProgressBar | None = None
        self.career_remaining_label: QLabel | None = None
        self.career_progress_bar: QProgressBar | None = None
        self.construction_remaining_label: QLabel | None = None
        self.construction_progress: QProgressBar | None = None
        self.jail_remaining_label: QLabel | None = None
        self.combat_menu = "root"
        self.selected_business_id: int | None = None
        self.selected_npc_key: str | None = None
        self.selected_vehicle_id: int | None = None
        self.selected_map_destination: str | None = None
        self.character_section_widgets: dict[str, QWidget] = {}
        self.selected_directory_entry: str | None = None
        self._directory_targets: dict[str, tuple[str | None, str]] = {}
        self._business_tick_counter = 0
        self.casino_wager = 10
        self._last_travel_active = bool(self.game_state.get_travel_state())
        self._last_job_active = bool(self.game_state.get_job_state())
        self._last_career_active = bool(self.game_state.get_career_shift_state())
        self._last_construction_active = bool(self.game_state.get_construction_state())
        self._last_jail_active = bool(self.game_state.get_jail_state())
        self._farm_ready_ids = {crop["id"] for crop in self.game_state.load_farm_crops() if crop["ready"]}
        self._animal_ready_ids = {
            animal["id"] for animal in self.game_state.load_livestock() if animal["stored_output"] > 0
        }

        self.setWindowTitle("Dong")
        if IS_ANDROID:
            self.setMinimumSize(0, 0)
        else:
            self.resize(1120, 720)
            self.setMinimumSize(880, 580)
        self.setStyleSheet(STYLE + (MOBILE_STYLE if IS_ANDROID else ""))

        outer = QWidget()
        outer_layout = QVBoxLayout(outer)
        outer_layout.setContentsMargins(5 if IS_ANDROID else 10, 5 if IS_ANDROID else 10, 5 if IS_ANDROID else 10, 5 if IS_ANDROID else 10)
        outer_layout.setSpacing(5 if IS_ANDROID else 9)

        self.top_bar = QFrame()
        self.top_bar.setObjectName("TopBar")
        top_layout = QVBoxLayout(self.top_bar) if IS_ANDROID else QHBoxLayout(self.top_bar)
        top_layout.setContentsMargins(9 if IS_ANDROID else 15, 7 if IS_ANDROID else 9, 9 if IS_ANDROID else 12, 7 if IS_ANDROID else 9)
        top_layout.setSpacing(5 if IS_ANDROID else 8)

        location_block = QVBoxLayout()
        location_block.setContentsMargins(0, 0, 0 if IS_ANDROID else 10, 0)
        location_block.setSpacing(0)
        location_caption = QLabel("CURRENT LOCATION")
        location_caption.setObjectName("LocationCaption")
        location_block.addWidget(location_caption)
        self.location_label = QLabel()
        self.location_label.setObjectName("LocationTitle")
        self.location_label.setWordWrap(True)
        if not IS_ANDROID:
            self.location_label.setMinimumWidth(190)
        location_block.addWidget(self.location_label)
        if IS_ANDROID:
            location_row = QHBoxLayout()
            location_row.setContentsMargins(0, 0, 0, 0)
            location_row.setSpacing(8)
            self.mobile_menu_button = QPushButton("MENU")
            self.mobile_menu_button.setObjectName("MobileMenuButton")
            self.mobile_menu_button.setCursor(Qt.CursorShape.PointingHandCursor)
            self.mobile_menu_button.clicked.connect(self.toggle_mobile_menu)
            location_row.addWidget(self.mobile_menu_button, 0, Qt.AlignTop)
            location_row.addLayout(location_block, 1)
            top_layout.addLayout(location_row)
        else:
            self.mobile_menu_button = None
            top_layout.addLayout(location_block, 1)

        metric_names = {
            "clock": "StatusClock",
            "world": "StatusWorld",
            "hp": "StatusHealth",
            "stamina": "StatusStamina",
            "cash": "StatusCash",
        }
        self.status_metrics: dict[str, QLabel] = {}
        if IS_ANDROID:
            metric_layout = QGridLayout()
            metric_layout.setContentsMargins(0, 0, 0, 0)
            metric_layout.setHorizontalSpacing(3)
            metric_layout.setVerticalSpacing(2)
        for index, key in enumerate(("clock", "world", "hp", "stamina", "cash")):
            metric = QLabel()
            metric.setObjectName(metric_names[key])
            metric.setAlignment(Qt.AlignCenter)
            metric.setMinimumHeight(29)
            metric.setWordWrap(True)
            self.status_metrics[key] = metric
            if IS_ANDROID:
                metric_layout.addWidget(metric, index // 3, index % 3)
            else:
                top_layout.addWidget(metric, 0)
        if IS_ANDROID:
            top_layout.addLayout(metric_layout)
        outer_layout.addWidget(self.top_bar)

        self.notice_label = QLabel()
        self.notice_label.setObjectName("Notice")
        self.notice_label.setWordWrap(True)
        self.notice_label.hide()
        outer_layout.addWidget(self.notice_label)

        body = QHBoxLayout()
        body.setSpacing(5 if IS_ANDROID else 9)

        sidebar = QFrame()
        sidebar.setObjectName("MobileDrawer" if IS_ANDROID else "Sidebar")
        sidebar.setFixedWidth(196 if IS_ANDROID else 158)
        self.mobile_sidebar = sidebar if IS_ANDROID else None
        side_layout = QVBoxLayout(sidebar)
        side_layout.setContentsMargins(8 if IS_ANDROID else 9, 9 if IS_ANDROID else 12, 8 if IS_ANDROID else 9, 9 if IS_ANDROID else 10)
        side_layout.setSpacing(3 if IS_ANDROID else 2)

        if not IS_ANDROID:
            sidebar_title = QLabel("DONG")
            sidebar_title.setObjectName("SidebarTitle")
            side_layout.addWidget(sidebar_title)
            sidebar_caption = QLabel("NAVIGATION")
            sidebar_caption.setObjectName("SidebarCaption")
            side_layout.addWidget(sidebar_caption)
            side_layout.addSpacing(8)

        nav_items = [
            ("location", "Location", "location"),
            ("character", "Character", "character"),
            ("life_hub", "Life", "life_hub"),
            ("property_hub", "Home", "property_hub"),
            ("crime", "Crime", "crime"),
            ("map", "Map", "map"),
        ]
        for index, (key, label, page_key) in enumerate(nav_items):
            button = QPushButton(label)
            button.setObjectName("NavLink")
            button.setFlat(True)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setCheckable(True)
            button.clicked.connect(lambda checked=False, p=page_key: self.show_page(p))
            side_layout.addWidget(button)
            self.nav_buttons[key] = button

        side_layout.addStretch()
        separator = QFrame()
        separator.setFrameShape(QFrame.HLine)
        separator.setObjectName("Divider")
        side_layout.addWidget(separator)
        side_layout.addSpacing(3)

        save_button = QPushButton("Save")
        save_button.setObjectName("NavUtility")
        save_button.setFlat(True)
        save_button.setCursor(Qt.CursorShape.PointingHandCursor)
        save_button.clicked.connect(self.save_game)
        menu_button = QPushButton("Menu")
        menu_button.setObjectName("NavUtility")
        menu_button.setFlat(True)
        menu_button.setCursor(Qt.CursorShape.PointingHandCursor)
        menu_button.clicked.connect(self.return_to_menu)
        side_layout.addWidget(save_button)
        menu_button.setText("Main Menu")
        side_layout.addWidget(menu_button)

        panel = QFrame()
        panel.setObjectName("ContentPanel")
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(8 if IS_ANDROID else 22, 8 if IS_ANDROID else 18, 8 if IS_ANDROID else 22, 8 if IS_ANDROID else 18)
        self.pages = QStackedWidget()
        panel_layout.addWidget(self.pages)
        body.addWidget(sidebar, 0)
        body.addWidget(panel, 1)
        if IS_ANDROID:
            sidebar.hide()
        outer_layout.addLayout(body, 1)
        self.setCentralWidget(outer)

        self.page_order = {
            "location": self.pages.addWidget(self.make_scroll_page("location")),
            "life_hub": self.pages.addWidget(self.make_scroll_page("life_hub")),
            "property_hub": self.pages.addWidget(self.make_scroll_page("property_hub")),
            "world_hub": self.pages.addWidget(self.make_scroll_page("world_hub")),
            "crime_hub": self.pages.addWidget(self.make_scroll_page("crime_hub")),
            "character": self.pages.addWidget(self.make_scroll_page("character")),
            "career": self.pages.addWidget(self.make_scroll_page("career")),
            "education": self.pages.addWidget(self.make_scroll_page("education")),
            "outdoors": self.pages.addWidget(self.make_scroll_page("outdoors")),
            "properties": self.pages.addWidget(self.make_scroll_page("properties")),
            "crafting": self.pages.addWidget(self.make_scroll_page("crafting")),
            "people": self.pages.addWidget(self.make_scroll_page("people")),
            "family": self.pages.addWidget(self.make_scroll_page("family")),
            "crime": self.pages.addWidget(self.make_scroll_page("crime")),
            "vice": self.pages.addWidget(self.make_scroll_page("vice")),
            "vehicles": self.pages.addWidget(self.make_scroll_page("vehicles")),
            "property": self.pages.addWidget(self.make_scroll_page("property")),
            "world": self.pages.addWidget(self.make_scroll_page("world")),
            "map": self.pages.addWidget(self.make_scroll_page("map")),
            "employment": self.pages.addWidget(self.make_scroll_page("employment")),
            "store": self.pages.addWidget(self.make_scroll_page("store")),
            "furniture_store": self.pages.addWidget(self.make_scroll_page("furniture_store")),
            "farm_store": self.pages.addWidget(self.make_scroll_page("farm_store")),
            "business": self.pages.addWidget(self.make_scroll_page("business")),
            "npc": self.pages.addWidget(self.make_scroll_page("npc")),
            "diner": self.pages.addWidget(self.make_scroll_page("diner")),
            "clinic": self.pages.addWidget(self.make_scroll_page("clinic")),
            "park": self.pages.addWidget(self.make_scroll_page("park")),
            "community": self.pages.addWidget(self.make_scroll_page("community")),
            "mail": self.pages.addWidget(self.make_scroll_page("mail")),
            "cooking": self.pages.addWidget(self.make_scroll_page("cooking")),
            "shady_bar": self.pages.addWidget(self.make_scroll_page("shady_bar")),
            "casino": self.pages.addWidget(self.make_scroll_page("casino")),
            "motors": self.pages.addWidget(self.make_scroll_page("motors")),
        }

        self.refresh_all()
        self.show_page("location")

        self.activity_timer = QTimer(self)
        self.activity_timer.setInterval(500)
        self.activity_timer.timeout.connect(self.tick_activities)
        self.activity_timer.start()

    def make_scroll_page(self, name: str) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(0, 0, 6, 0)
        layout.setSpacing(12)
        scroll.setWidget(content)
        setattr(self, f"{name}_layout", layout)
        setattr(self, f"{name}_scroll", scroll)
        return scroll

    def clear_layout(self, layout: QVBoxLayout) -> None:
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            child_layout = item.layout()
            if widget is not None:
                widget.deleteLater()
            elif child_layout is not None:
                self.clear_layout(child_layout)

    def add_heading(self, layout: QVBoxLayout, text: str) -> None:
        label = QLabel(text)
        label.setObjectName("BigHeading")
        layout.addWidget(label)

    def add_body(self, layout: QVBoxLayout, text: str, muted: bool = False) -> QLabel:
        label = QLabel(text)
        label.setWordWrap(True)
        if muted:
            label.setObjectName("Muted")
        layout.addWidget(label)
        return label

    def add_card(self, layout: QVBoxLayout, title: str, body: str, button_text: str | None = None, callback=None, enabled: bool = True) -> None:
        section = QWidget()
        section_layout = QVBoxLayout(section)
        section_layout.setContentsMargins(1, 5, 1, 7)
        section_layout.setSpacing(4)

        title_label = QLabel(title)
        title_label.setStyleSheet("font-weight: 750; font-size: 15px; color: #f5ecdc; background: transparent; border: none;")
        section_layout.addWidget(title_label)

        body_label = QLabel(body)
        body_label.setWordWrap(True)
        body_label.setObjectName("Muted")
        section_layout.addWidget(body_label)

        if button_text is not None:
            button = QPushButton(button_text)
            button.setEnabled(enabled)
            if IS_ANDROID:
                button.setMinimumWidth(0)
            else:
                button.setMaximumWidth(180)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            if callback is not None:
                button.clicked.connect(callback)
            section_layout.addWidget(button, 0, Qt.AlignLeft)

        layout.addWidget(section)
        divider = QFrame()
        divider.setObjectName("Divider")
        layout.addWidget(divider)

    def set_notice(self, text: str, duration_ms: int = 4500) -> None:
        self.notice_text = text
        self.notice_label.setText(text)
        self.notice_label.setVisible(bool(text))
        if text:
            QTimer.singleShot(duration_ms, self.clear_notice)

    def clear_notice(self) -> None:
        self.notice_text = ""
        self.notice_label.hide()

    def refresh_all(self) -> None:
        self.travel_remaining_label = None
        self.travel_progress = None
        self.job_remaining_label = None
        self.job_progress = None
        self.career_remaining_label = None
        self.career_progress_bar = None
        self.construction_remaining_label = None
        self.construction_progress = None
        self.jail_remaining_label = None

        character = self.game_state.load_character()
        plot = self.game_state.load_home_plot()
        structures = self.game_state.load_structures()
        inventory = self.game_state.load_inventory()
        skills = self.game_state.load_skills()
        travel = self.game_state.get_travel_state()
        job = self.game_state.get_job_state()
        combat = self.game_state.get_combat_state()
        construction = self.game_state.get_construction_state()
        jail = self.game_state.get_jail_state()

        if jail:
            self.location_label.setText("DONG CITY JAIL")
        elif combat:
            self.location_label.setText(f"COMBAT — {combat['enemy_name'].upper()}")
        elif travel:
            destination = "Home" if travel["destination_key"] == "home" else LOCATIONS[travel["destination_key"]].name
            self.location_label.setText(f"TRAVELLING → {destination.upper()}")
        else:
            self.location_label.setText(location_name(character.current_location, plot).upper())

        season_profile = self.game_state.season_weather_profile()
        self.status_metrics["clock"].setText(
            f"DAY {character.day}  {self.game_state.format_time(character.time_minutes)}"
        )
        self.status_metrics["world"].setText(
            f"{season_profile['season'].upper()}  {season_profile['weather'].upper()}"
        )
        self.status_metrics["hp"].setText(f"HP  {character.hp}/{character.max_hp}")
        self.status_metrics["stamina"].setText(f"STA  {character.stamina}/{character.max_stamina}")
        self.status_metrics["cash"].setText(f"${character.cash:,}")

        self.render_location(character, plot, structures, travel, job, combat, jail)
        self.render_life_hub()
        self.render_property_hub()
        self.render_world_hub()
        self.render_crime_hub()
        self.render_character(character, plot, inventory, skills, combat, job, travel)
        self.render_outdoors(character, job, travel, combat)
        self.render_properties(character, job, travel, combat)
        self.render_crafting(character, job, travel, combat)
        self.render_people(character)
        self.render_crime(character, job, travel, combat, jail)
        self.render_vice(character, job, travel, combat, jail)
        self.render_vehicles(character, job, travel, combat)
        self.render_property(character, plot, structures, construction, travel, job, combat)
        self.render_world(character)
        self.render_map(character, plot, travel, job, combat)
        self.render_employment(character, job, travel, combat)
        self.render_store(character, job, travel, combat)
        self.render_furniture_store(character, job, travel, combat)
        self.render_farm_store(character, job, travel, combat)
        self.render_business(character, job, travel, combat)
        self.render_npc(character, job, travel, combat)
        self.render_diner(character, job, travel, combat)
        self.render_clinic(character, job, travel, combat)
        self.render_park(character, job, travel, combat)
        self.render_community(character, job, travel, combat)
        self.render_mail(character, job, travel, combat)
        self.render_cooking(character, job, travel, combat)
        self.render_shady_bar(character, job, travel, combat, jail)
        self.render_casino(character, job, travel, combat, jail)
        self.render_motors(character, job, travel, combat)

    def add_hub_grid(self, layout: QVBoxLayout, items: list[tuple[str, str, str]]) -> None:
        grid_frame = QFrame()
        grid_layout = QGridLayout(grid_frame)
        grid_layout.setContentsMargins(0, 2, 0, 2)
        grid_layout.setHorizontalSpacing(26)
        grid_layout.setVerticalSpacing(10)

        description_label = QLabel("Tap a title to view its description." if IS_ANDROID else "Hover a title to view its description.")
        description_label.setObjectName("Muted")
        description_label.setWordWrap(True)
        description_label.setMinimumHeight(36)

        for index, (title, description, target) in enumerate(items):
            button = HoverRevealButton(
                title,
                description,
                description_label,
                lambda checked=False, key=target: self.show_page(key),
            )
            if not IS_ANDROID:
                button.setMaximumWidth(220)
            columns = 1 if IS_ANDROID else 2
            grid_layout.addWidget(button, index // columns, index % columns, Qt.AlignLeft)

        grid_layout.setColumnStretch(0, 1)
        if not IS_ANDROID:
            grid_layout.setColumnStretch(1, 1)
        layout.addWidget(grid_frame)
        layout.addWidget(description_label)

    def render_life_hub(self) -> None:
        layout = self.life_hub_layout
        self.clear_layout(layout)
        self.add_heading(layout, "LIFE")
        self.add_body(layout, "People, relationships, and correspondence across Dong.", muted=True)
        self.add_hub_grid(layout, [
            ("People", "Review residents, friendships, romance, and relationships.", "people"),
            ("Mail", "Read letters and official correspondence delivered to your home.", "mail"),
        ])
        layout.addStretch()

    def render_property_hub(self) -> None:
        layout = self.property_hub_layout
        self.clear_layout(layout)
        self.add_heading(layout, "HOME")
        self.add_body(layout, "Your home, property portfolio, vehicles, pets, construction, storage, and crafting.", muted=True)
        self.add_hub_grid(layout, [
            ("Home", "Manage your primary residence, structures, storage, pets, and businesses.", "property"),
            ("All Properties", "Review owned plots, buy land, move residence, and manage rentals.", "properties"),
            ("Vehicles", "Review owned bicycles, motor vehicles, boats, cargo, fuel, and condition.", "vehicles"),
            ("Crafting", "Process gathered resources, forge materials, and make tools.", "crafting"),
            ("Cooking", "Prepare food using ingredients from your farm and inventory.", "cooking"),
            ("Pets", "View and care for your household pets and adopt new ones when available.", "property"),
        ])
        layout.addStretch()

    def render_world_hub(self) -> None:
        layout = self.world_hub_layout
        self.clear_layout(layout)
        self.add_heading(layout, "WORLD")
        self.add_body(layout, "Travel, transportation, outdoor activities, and city standing.", muted=True)
        self.add_hub_grid(layout, [
            ("World", "Review regions and your reputation across the wider world.", "world"),
            ("Outdoors", "Manage hunting, survival, pets, boats, and related outdoor systems.", "outdoors"),
            ("Vehicles", "Review owned bicycles, motor vehicles, boats, cargo, fuel, and condition.", "vehicles"),
            ("Map", "Choose destinations, travel methods, and city standing.", "map"),
        ])
        layout.addStretch()

    def render_crime_hub(self) -> None:
        layout = self.crime_hub_layout
        self.clear_layout(layout)
        self.add_heading(layout, "CRIME & VICE")
        self.add_body(layout, "Criminal activity, Heat, records, addiction, dealing, and gambling.", muted=True)
        self.add_hub_grid(layout, [
            ("Crime", "Review Crime skill, Heat, criminal history, masks, arrests, and court activity.", "crime"),
            ("Vice", "Manage alcohol, Drugs, addiction, dealing progression, and gambling history.", "vice"),
        ])
        layout.addStretch()

    def render_location(self, character, plot: dict, structures: list[dict], travel: dict | None, job: dict | None, combat: dict | None, jail: dict | None) -> None:
        layout = self.location_layout
        self.clear_layout(layout)

        if jail:
            self.add_heading(layout, "DONG CITY JAIL")
            self.add_body(layout, f"Reason for arrest: {jail['reason']}\nFine paid at arrest: ${jail['fine']}")
            self.add_body(layout, "You remain in city custody until the sentence is complete. Travel, work, shopping, property management, and criminal activity are unavailable while jailed.", muted=True)
            self.jail_remaining_label = QLabel()
            self.jail_remaining_label.setStyleSheet("font-size: 18px; font-weight: 700;")
            layout.addWidget(self.jail_remaining_label)
            self.jail_remaining_label.setText(f"Release in {jail['remaining_seconds']} seconds")
            layout.addStretch()
            return

        if combat:
            self.render_combat(layout, character, combat)
            layout.addStretch()
            return

        if travel:
            destination = "Home" if travel["destination_key"] == "home" else LOCATIONS[travel["destination_key"]].name
            self.add_heading(layout, f"TRAVELLING TO {destination.upper()}")
            self.add_body(layout, f"Method: {travel['method']}\nYou continue toward your destination.")
            self.travel_progress = QProgressBar()
            self.travel_progress.setRange(0, travel["duration_seconds"])
            self.travel_remaining_label = QLabel()
            layout.addWidget(self.travel_progress)
            layout.addWidget(self.travel_remaining_label)
            cancel = QPushButton("CANCEL TRIP")
            cancel.clicked.connect(self.cancel_travel)
            layout.addWidget(cancel)
            self.update_activity_widgets()
            if travel["method"] in {"Bus", "Train", "Plane", "Taxi"}:
                self.add_body(layout, "The fare was paid when the journey began. Cancelling public transport does not refund the fare.", muted=True)
            else:
                self.add_body(layout, "You can still browse Character, Inventory, Skills, Property, and other menus while travelling.", muted=True)
            layout.addStretch()
            return

        current = normalize_location_key(character.current_location)
        if current == "home":
            self.add_heading(layout, "HOME")
            self.add_body(
                layout,
                f"{plot['code']}\n\n"
                f"{character.weather} settles over the {plot['terrain'].lower()}. "
                "The property remains quiet beyond the road and tree line.",
            )
            self.add_body(layout, f"Natural features: {plot_summary(plot)}", muted=True)
            profile = self.game_state.home_rest_profile()
            self.add_body(layout, f"Primary shelter: {profile['name']}\nCash: ${character.cash}")
            rest = QPushButton(f"REST IN {profile['name'].upper()}  •  RECOVER HP / STAMINA  •  2 HOURS")
            rest.setEnabled((character.stamina < character.max_stamina or character.hp < character.max_hp) and not job)
            rest.clicked.connect(self.rest_in_tent)
            layout.addWidget(rest)
            property_button = QPushButton("MANAGE HOME")
            property_button.clicked.connect(lambda: self.show_page("property"))
            layout.addWidget(property_button)
            cooking_button = QPushButton("COOK")
            cooking_button.clicked.connect(lambda: self.show_page("cooking"))
            layout.addWidget(cooking_button)
            unread = self.game_state.unread_mail_count()
            mail_label = "CHECK MAILBOX" + (f"  •  {unread} UNREAD" if unread else "")
            mailbox_button = QPushButton(mail_label)
            mailbox_button.clicked.connect(lambda: self.show_page("mail"))
            layout.addWidget(mailbox_button)
            vehicles_here = [v for v in self.game_state.load_vehicles() if v["current_location"] == "home"]
            if vehicles_here:
                self.add_body(layout, "VEHICLES HERE\n" + "\n".join(v["name"] for v in vehicles_here), muted=True)
                vehicle_button = QPushButton("MANAGE VEHICLES")
                vehicle_button.clicked.connect(lambda: self.show_page("vehicles"))
                layout.addWidget(vehicle_button)
            map_button = QPushButton("OPEN MAP")
            map_button.clicked.connect(lambda: self.show_page("map"))
            layout.addWidget(map_button)
            self.render_residents_here(layout)
            layout.addStretch()
            return

        location = LOCATIONS.get(current)
        if not location:
            self.add_heading(layout, "UNKNOWN LOCATION")
            self.add_body(layout, character.current_location)
            layout.addStretch()
            return

        region = REGIONS[location.region_key]
        self.add_heading(layout, location.name.upper())
        self.add_body(layout, location.description)
        self.add_body(layout, region.name, muted=True)

        if current == "blackwood_trail":
            self.add_body(layout, "Exploring costs 2 stamina and advances the clock by 20 minutes.", muted=True)
            explore = QPushButton("EXPLORE BLACKWOOD TRAIL  •  2 STAMINA")
            explore.setEnabled(character.stamina >= self.game_state.EXPLORE_STAMINA_COST and not job)
            explore.clicked.connect(self.explore_blackwood)
            layout.addWidget(explore)
            self.add_body(layout, "TIMBER")
            chop = QPushButton("CUT TIMBER")
            chop.setEnabled(not job and character.stamina >= 2)
            chop.clicked.connect(self.gather_wood)
            layout.addWidget(chop)
        elif current == "millhaven_quarry":
            self.add_body(layout, "MINING")
            mine = QPushButton("MINE STONE AND ORE")
            mine.setEnabled(not job and character.stamina >= 3)
            mine.clicked.connect(self.mine_quarry)
            layout.addWidget(mine)
        elif current in {"lake_mercy", "lake_mercy_north_shore"}:
            self.add_body(layout, "FISHING")
            self.add_body(layout, "Freshwater fishing is available from public shoreline access. A Fishing Rod is required.", muted=True)
            fish = QPushButton("FISH LAKE MERCY  •  2 STAMINA")
            fish.setEnabled(not job and character.stamina >= 2)
            fish.clicked.connect(self.fish_lake_mercy)
            layout.addWidget(fish)
        elif current == "redwater_industrial":
            self.add_body(layout, "SALVAGE")
            self.add_body(layout, "Discarded industrial material can be searched for reusable scrap and mechanical parts.", muted=True)
            salvage = QPushButton("SEARCH SALVAGE YARD  •  3 STAMINA")
            salvage.setEnabled(not job and character.stamina >= 3)
            salvage.clicked.connect(self.salvage_redwater)
            layout.addWidget(salvage)
        elif current == "hollow_creek_sawmill":
            self.add_body(layout, "TIMBER")
            chop = QPushButton("CUT MARKED TIMBER")
            chop.setEnabled(not job and character.stamina >= 2)
            chop.clicked.connect(self.gather_wood)
            layout.addWidget(chop)
        elif current == "pine_ridge_mine":
            self.add_body(layout, "MINING")
            mine = QPushButton("MINE HIGHLAND ORE")
            mine.setEnabled(not job and character.stamina >= 3)
            mine.clicked.connect(self.mine_quarry)
            layout.addWidget(mine)
        elif current == "redwater_fight_club":
            self.add_body(layout, "FIGHT CLUB")
            self.add_body(layout, "Enter a supervised one-on-one bout. Opponents vary in experience and each victory awards Combat XP and a fight purse.", muted=True)
            bout = QPushButton("ENTER NEXT BOUT")
            bout.setEnabled(not job and not combat)
            bout.clicked.connect(self.start_fight_club_bout)
            layout.addWidget(bout)
        elif current == "blackstone_dungeon":
            self.add_body(layout, "DUNGEON")
            self.add_body(layout, "Enter the lower chambers and search for hostile creatures. Each entry can begin a new combat encounter.", muted=True)
            delve = QPushButton("ENTER LOWER CHAMBERS")
            delve.setEnabled(not job and not combat)
            delve.clicked.connect(self.start_dungeon_encounter)
            layout.addWidget(delve)

        if current in {"blackwood_trail", "lake_mercy_north_shore", "pine_ridge"}:
            hunt = QPushButton("HUNT")
            hunt.setEnabled(not job and not combat and character.stamina >= 3)
            hunt.clicked.connect(self.hunt_game)
            layout.addWidget(hunt)
        if current in {"blackwood_trail", "lake_mercy_north_shore", "pine_ridge", "hollow_creek_sawmill"}:
            camp = QPushButton("MAKE CAMP")
            camp.setEnabled(not job and not combat)
            camp.clicked.connect(self.camp_wilderness)
            layout.addWidget(camp)
        if current == "greybridge_city":
            edu = QPushButton("GREYBRIDGE COMMUNITY COLLEGE")
            edu.clicked.connect(lambda: self.show_page("education"))
            layout.addWidget(edu)
        if current == "millhaven":
            pets = QPushButton("MILLHAVEN ANIMAL SHELTER")
            pets.clicked.connect(lambda: self.show_page("property"))
            layout.addWidget(pets)

        jobs_here = [j for j in JOBS.values() if j.location_key == current]
        if jobs_here:
            employment = QPushButton("EMPLOYMENT OFFICE / JOB BOARD")
            employment.clicked.connect(lambda: self.show_page("employment"))
            layout.addWidget(employment)
        careers_here = [c for c in CAREERS.values() if c.location_key == current]
        if careers_here:
            careers_button = QPushButton("FULL-TIME CAREERS")
            careers_button.clicked.connect(lambda: self.show_page("career"))
            layout.addWidget(careers_button)

        retail_hubs = {"millhaven", "redwater", "lake_mercy", "greybridge_city", "hollow_creek", "pine_ridge", "westhaven"}
        if current in retail_hubs:
            store = QPushButton("GENERAL MARKET")
            store.clicked.connect(lambda: self.show_page("store"))
            layout.addWidget(store)
            diner = QPushButton("DINER / CAFE")
            diner.clicked.connect(lambda: self.show_page("diner"))
            layout.addWidget(diner)
            clinic = QPushButton("MEDICAL SERVICES")
            clinic.clicked.connect(lambda: self.show_page("clinic"))
            layout.addWidget(clinic)

        if current in {"millhaven", "lake_mercy", "hollow_creek"}:
            farm_store = QPushButton("FARM SUPPLY MARKET")
            farm_store.clicked.connect(lambda: self.show_page("farm_store"))
            layout.addWidget(farm_store)

        if current in {"millhaven", "redwater", "greybridge_city", "westhaven", "lake_mercy"}:
            motors = QPushButton("MOTORS / MARINA SERVICE")
            motors.clicked.connect(lambda: self.show_page("motors"))
            layout.addWidget(motors)

        if current in {"millhaven", "greybridge_city", "westhaven"}:
            casino = QPushButton("CASINO")
            casino.clicked.connect(lambda: self.show_page("casino"))
            layout.addWidget(casino)

        if current != "millhaven" and current in {"redwater", "lake_mercy", "greybridge_city", "hollow_creek", "pine_ridge", "westhaven"}:
            room = QPushButton("RENT ROOM FOR THE NIGHT")
            room.clicked.connect(self.rent_regional_room)
            layout.addWidget(room)

        if current == "millhaven":
            furniture_store = QPushButton("MILLHAVEN FURNISHINGS")
            furniture_store.clicked.connect(lambda: self.show_page("furniture_store"))
            layout.addWidget(furniture_store)
            park = QPushButton("RIVER PARK")
            park.clicked.connect(lambda: self.show_page("park"))
            layout.addWidget(park)
            hall = QPushButton("COMMUNITY HALL")
            hall.clicked.connect(lambda: self.show_page("community"))
            layout.addWidget(hall)
            shady = QPushButton("THE GREY LANTERN")
            shady.clicked.connect(lambda: self.show_page("shady_bar"))
            layout.addWidget(shady)
            event = self.game_state.current_daily_event()
            self.add_card(layout, f"TODAY — {event['name']}", event['description'] + "\n\n" + event['modifier_text'])

        map_button = QPushButton("OPEN MAP")
        map_button.clicked.connect(lambda: self.show_page("map"))
        layout.addWidget(map_button)
        self.render_residents_here(layout)
        layout.addStretch()

    def render_residents_here(self, layout: QVBoxLayout) -> None:
        residents = self.game_state.load_npcs_here()
        if not residents:
            return
        self.add_body(layout, "PEOPLE HERE")
        for resident in residents:
            self.add_card(
                layout,
                resident["name"],
                f"{resident['occupation']}\n{resident['activity']}\nRelationship: {resident['relationship']}",
                "TALK",
                lambda checked=False, key=resident["key"]: self.open_npc(key),
            )

    def render_npc(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.npc_layout
        self.clear_layout(layout)
        if not self.selected_npc_key:
            self.add_heading(layout, "RESIDENT")
            self.add_body(layout, "Select someone from the current location to view them.", muted=True)
            layout.addStretch()
            return
        try:
            profile = self.game_state.get_npc_profile(self.selected_npc_key)
        except ValueError:
            self.selected_npc_key = None
            self.add_heading(layout, "RESIDENT")
            self.add_body(layout, "That resident could not be found.", muted=True)
            layout.addStretch()
            return

        self.add_heading(layout, profile["name"].upper())
        self.add_body(layout, f"{profile['occupation']}\n\n{profile['description']}")
        self.add_body(
            layout,
            f"Friendship: {profile['relationship']}  •  {profile['friendship']}\n"
            f"Romance: {profile['romance_label']}  •  {profile['romance']}\n"
            f"Current routine: {profile['activity']}\nHome area: {profile['home_area']}",
            muted=True,
        )
        if profile["context_line"]:
            self.add_card(layout, "OBSERVATION", profile["context_line"])

        current = normalize_location_key(character.current_location)
        is_here = profile["world_location"] == current and not travel and not combat
        if not is_here:
            self.add_body(layout, f"{profile['name']} is not here right now.", muted=True)
        elif profile["talked_today"]:
            self.add_body(layout, "You have already had a longer conversation today. You can speak again tomorrow.", muted=True)
        else:
            self.add_body(layout, "CONVERSATION")
            for option in profile["conversation"]:
                self.add_card(
                    layout,
                    option.label,
                    "A short conversation. Advances the clock by 10 minutes and improves Speech experience.",
                    "TALK",
                    lambda checked=False, key=profile["key"], choice=option.key: self.talk_to_npc(key, choice),
                    enabled=not job and not travel and not combat,
                )

        self.add_body(layout, "FAMILY")
        if profile["romantic_status"] == "married":
            family_text = "Married to you."
        elif profile["marital_status"] == "married" and profile["spouse_name"]:
            family_text = f"Married to {profile['spouse_name']}."
        elif profile["marital_status"] == "widowed" and profile["spouse_name"]:
            family_text = f"Widowed. Late spouse: {profile['spouse_name']}."
        else:
            family_text = "Not currently married."
        if profile["children"]:
            family_text += "\nChildren: " + ", ".join(f"{name} ({relation})" for name, relation in profile["children"])
        else:
            family_text += "\nChildren: None recorded."
        self.add_card(layout, "HOUSEHOLD", family_text)

        if is_here and profile["romanceable"] and profile["romantic_status"] == "none" and profile["friendship"] >= 25:
            self.add_card(
                layout,
                "ROMANCE",
                "Your friendship is strong enough to ask whether they want to begin a romantic relationship.",
                "ASK TO DATE",
                lambda checked=False, key=profile["key"]: self.ask_to_date(key),
                enabled=not job and not travel and not combat,
            )
        elif profile["romantic_status"] in ("dating", "married"):
            can_date = profile["last_date_day"] != character.day
            self.add_card(
                layout,
                "SPEND TIME TOGETHER",
                "Spend an hour together. This strengthens friendship and romance and costs 2 stamina.",
                "GO ON DATE" if profile["romantic_status"] == "dating" else "SPEND TIME TOGETHER",
                lambda checked=False, key=profile["key"]: self.go_on_date(key),
                enabled=not job and not travel and not combat and can_date,
            )
            if profile["romantic_status"] == "dating" and profile["friendship"] >= 40 and profile["romance"] >= 60 and is_here:
                self.add_card(
                    layout,
                    "MARRIAGE",
                    "A strong relationship and a permanent home allow you to ask them to marry you.",
                    "PROPOSE MARRIAGE",
                    lambda checked=False, key=profile["key"]: self.marry_npc(key),
                    enabled=not job and not travel and not combat,
                )
            if profile["romance"] >= 30 and normalize_location_key(character.current_location) == "home":
                intimacy_available = profile["last_intimacy_day"] != character.day
                self.add_card(
                    layout,
                    "PRIVATE TIME",
                    "Spend private time together. The interaction is private and restores some health and stamina.",
                    "INTIMACY",
                    lambda checked=False, key=profile["key"]: self.intimacy(key, False),
                    enabled=not job and not travel and not combat and intimacy_available,
                )
                if profile["romantic_status"] == "married":
                    self.add_card(
                        layout,
                        "START A FAMILY",
                        "Spend private time together with the intention of having a child. Conception is not guaranteed.",
                        "TRY FOR A CHILD",
                        lambda checked=False, key=profile["key"]: self.intimacy(key, True),
                        enabled=not job and not travel and not combat and intimacy_available,
                    )
        elif not profile["romanceable"]:
            self.add_body(layout, "This resident is not available for romance.", muted=True)

        favor = profile.get("favor")
        if favor and is_here:
            self.add_body(layout, "FAVOR")
            requirements = ", ".join(f"{name} x{qty}" for name, qty in favor["requirements"])
            body = (
                f"{favor['description']}\n\nRequired: {requirements}\n"
                f"Reward: ${favor['cash_reward']} and +{favor['friendship_reward']} friendship"
            )
            if favor["status"] == "available":
                self.add_card(
                    layout, favor["title"], body, "ACCEPT FAVOR",
                    lambda checked=False, key=profile["key"]: self.accept_favor(key),
                    enabled=not job and not travel and not combat,
                )
            elif favor["status"] == "accepted":
                self.add_card(
                    layout, favor["title"], body, "TURN IN",
                    lambda checked=False, key=profile["key"]: self.complete_favor(key),
                    enabled=not job and not travel and not combat,
                )
            else:
                self.add_card(layout, favor["title"], body + "\n\nCompleted.")

        back = QPushButton("BACK TO LOCATION")
        back.clicked.connect(lambda: self.show_page("location"))
        layout.addWidget(back)
        layout.addStretch()

    def render_combat(self, layout: QVBoxLayout, character, combat: dict) -> None:
        self.add_heading(layout, combat["enemy_name"].upper())
        self.add_body(
            layout,
            f"{combat['enemy_description']}\n\n"
            f"{combat['enemy_name']} HP: {combat['enemy_hp']}/{combat['enemy_max_hp']}\n"
            f"{character.name} HP: {character.hp}/{character.max_hp}\n"
            f"Equipped: {character.equipped_weapon}",
        )

        if combat["log_lines"]:
            self.add_body(layout, "COMBAT LOG")
            self.add_card(layout, "LAST ACTIONS", "\n".join(combat["log_lines"]))

        if self.combat_menu == "attack":
            self.add_body(layout, "ATTACK")
            for move in weapon_moves(character.equipped_weapon):
                self.add_card(
                    layout,
                    move.name,
                    f"{move.description}\nDamage: {move.min_damage}-{move.max_damage}\nAccuracy: {move.accuracy}%",
                    "USE",
                    lambda checked=False, key=move.key: self.combat_attack(key),
                )
            back = QPushButton("BACK")
            back.clicked.connect(lambda: self.set_combat_menu("root"))
            layout.addWidget(back)
            return

        if self.combat_menu == "skill":
            self.add_body(layout, "SKILL")
            self.add_card(
                layout,
                "Brace",
                "Reduce the next enemy hit by up to 3 damage. Uses your turn.",
                "BRACE",
                self.combat_brace,
            )
            back = QPushButton("BACK")
            back.clicked.connect(lambda: self.set_combat_menu("root"))
            layout.addWidget(back)
            return

        if self.combat_menu == "item":
            self.add_body(layout, "ITEM")
            usable = self.game_state.combat_usable_items()
            if not usable:
                self.add_body(layout, "You have no usable combat items.", muted=True)
            for item in usable:
                self.add_card(
                    layout,
                    f"{item['name']}  x{item['quantity']}",
                    f"{item['description']}\nHealing: {item['heal']} HP",
                    "USE",
                    lambda checked=False, name=item["name"]: self.combat_use_item(name),
                    enabled=character.hp < character.max_hp,
                )
            back = QPushButton("BACK")
            back.clicked.connect(lambda: self.set_combat_menu("root"))
            layout.addWidget(back)
            return

        attack = QPushButton("ATTACK")
        attack.clicked.connect(lambda: self.set_combat_menu("attack"))
        layout.addWidget(attack)
        skill = QPushButton("SKILL")
        skill.clicked.connect(lambda: self.set_combat_menu("skill"))
        layout.addWidget(skill)
        item = QPushButton("ITEM")
        item.clicked.connect(lambda: self.set_combat_menu("item"))
        layout.addWidget(item)
        run = QPushButton("RUN")
        run.clicked.connect(self.combat_run)
        layout.addWidget(run)
        self.add_body(layout, "Combat is turn-based. After most actions, the enemy immediately takes its turn.", muted=True)

    def render_character(self, character, plot: dict, inventory: list[dict], skills: list[dict], combat: dict | None, job: dict | None, travel: dict | None) -> None:
        layout = self.character_layout
        self.clear_layout(layout)
        self.character_section_widgets = {}
        self.add_heading(layout, character.name.upper())
        self.add_body(layout, "CHARACTER SHEET", muted=True)

        self.add_card(
            layout,
            "OVERVIEW",
            f"HP: {character.hp}/{character.max_hp}\n"
            f"Stamina: {character.stamina}/{character.max_stamina}\n"
            f"Cash: ${character.cash}\n"
            f"Equipped weapon: {character.equipped_weapon}\n"
            f"Home: {plot['code']}\n"
            f"Current location: {location_name(character.current_location, plot)}",
        )
        self.add_body(layout, "Stamina naturally regenerates by 1 every 5 real-world minutes. Combat damage persists until you heal or rest.", muted=True)

        career_heading = QLabel("CAREER")
        career_heading.setObjectName("Heading")
        career_heading.setStyleSheet("margin-top: 10px;")
        layout.addWidget(career_heading)
        self.character_section_widgets["career"] = career_heading
        shift = self.game_state.get_career_shift_state()
        career_profile = self.game_state.career_profile()
        if shift and career_profile:
            self.add_card(
                layout,
                f"{career_profile['name']} — {career_profile['employer']}",
                f"Eight-hour shift in progress.\n\nRank: {career_profile['rank']}\nShift pay: ${career_profile['daily_pay']}\nWorkday: {career_profile['weekday']}",
            )
            self.career_progress_bar = QProgressBar()
            self.career_progress_bar.setRange(0, shift["duration_seconds"])
            self.career_remaining_label = QLabel()
            layout.addWidget(self.career_progress_bar)
            layout.addWidget(self.career_remaining_label)
            self.update_activity_widgets()
        elif career_profile:
            next_text = "Highest current rank."
            if career_profile["next_rank"]:
                next_text = f"Next promotion: {career_profile['next_rank'][0]} in {career_profile['next_rank'][1]} completed shifts."
            self.add_card(
                layout,
                f"{career_profile['name']} — {career_profile['employer']}",
                f"Rank: {career_profile['rank']}\nDaily pay: ${career_profile['daily_pay']}\nCompleted shifts: {career_profile['shifts_worked']}\n"
                f"Reliability: {career_profile['reliability']}%\nMissed shifts: {career_profile['missed_shifts']}\n"
                f"Schedule: Monday through Friday\nToday: {career_profile['weekday']}\n\n{next_text}",
            )
            can_work = (
                not job and not travel and not combat and career_profile["scheduled_today"] and not career_profile["worked_today"]
                and character.stamina >= career_profile["stamina_cost"]
                and normalize_location_key(character.current_location) == career_profile["location_key"]
            )
            status = "Today's shift is available."
            if not career_profile["scheduled_today"]:
                status = "You are not scheduled today."
            elif career_profile["worked_today"]:
                status = "Today's shift is complete."
            elif normalize_location_key(character.current_location) != career_profile["location_key"]:
                status = f"Report to {LOCATIONS[career_profile['location_key']].name} for your shift."
            elif character.stamina < career_profile["stamina_cost"]:
                status = f"You need {career_profile['stamina_cost']} stamina to work the full shift."
            self.add_card(
                layout,
                "FULL-TIME SHIFT",
                f"{status}\n\nLength: 8 in-game hours\nStamina: {career_profile['stamina_cost']}\nPay: ${career_profile['daily_pay']}",
                "WORK 8-HOUR SHIFT",
                self.begin_career_shift,
                enabled=can_work,
            )
            resign = QPushButton("RESIGN POSITION")
            resign.clicked.connect(self.resign_career)
            resign.setEnabled(not job and not travel and not combat)
            layout.addWidget(resign)
        else:
            self.add_body(layout, "You do not currently have a full-time career.", muted=True)

        available = self.game_state.available_careers()
        if available:
            self.add_body(layout, "CAREERS AVAILABLE HERE")
            for career in available:
                reqs = []
                if career["required_skill"] and career["required_skill_level"]:
                    reqs.append(f"{career['required_skill']} level {career['required_skill_level']} (you: {career['current_skill_level']})")
                if career["required_reputation"]:
                    reqs.append(f"City reputation {career['required_reputation']} (you: {career['current_reputation']})")
                if career.get("required_certificate"):
                    reqs.append(f"{career['required_certificate']} certificate ({'earned' if career.get('has_certificate') else 'not earned'})")
                req_text = "None" if not reqs else "\n".join(reqs)
                self.add_card(
                    layout,
                    f"{career['name']} — {career['employer']}",
                    f"{career['description']}\n\nStarting daily pay: ${career['base_pay']}\nRequirements: {req_text}",
                    "APPLY",
                    lambda checked=False, key=career["key"]: self.apply_for_career(key),
                    enabled=career_profile is None and career["qualifies"] and not job and not travel and not combat,
                )
        career_history = self.game_state.career_history()
        if career_history:
            self.add_body(layout, "EMPLOYMENT HISTORY")
            for event in career_history:
                self.add_card(layout, f"Day {event['day']} — {event['event_type'].replace('_', ' ').title()}", event["description"])

        education_heading = QLabel("EDUCATION")
        education_heading.setObjectName("Heading")
        education_heading.setStyleSheet("margin-top: 10px;")
        layout.addWidget(education_heading)
        self.character_section_widgets["education"] = education_heading
        education_profile = self.game_state.education_profile()
        if education_profile["certificates"]:
            self.add_body(layout, "CERTIFICATES")
            for cert in education_profile["certificates"]:
                self.add_card(layout, cert["certificate"], f"Earned Day {cert['earned_day']}")
        else:
            self.add_body(layout, "No certificates earned yet.", muted=True)
        if education_profile["current"]:
            current_program = education_profile["current"]
            self.add_card(
                layout,
                current_program["name"],
                f"Progress: {current_program['sessions_completed']}/{current_program['sessions']} class sessions\nCredential: {current_program['certificate']}",
                "ATTEND 4-HOUR CLASS",
                self.study_education,
                enabled=normalize_location_key(character.current_location) == "greybridge_city" and character.stamina >= 3 and not job and not travel and not combat,
            )
        else:
            self.add_body(layout, "PROGRAMS — COMMUNITY COLLEGE")
            for program in EDUCATION_PROGRAMS.values():
                self.add_card(
                    layout,
                    f"{program.name}  •  ${program.tuition}",
                    f"{program.description}\n\nClass sessions: {program.sessions}\nCredential: {program.certificate}",
                    "ENROLL",
                    lambda checked=False, key=program.key: self.enroll_education(key),
                    enabled=normalize_location_key(character.current_location) == "greybridge_city" and character.cash >= program.tuition and not job and not travel and not combat,
                )

        family_heading = QLabel("FAMILY")
        family_heading.setObjectName("Heading")
        family_heading.setStyleSheet("margin-top: 10px;")
        layout.addWidget(family_heading)
        self.character_section_widgets["family"] = family_heading
        household = self.game_state.get_household()
        if household["spouse_name"]:
            self.add_card(
                layout,
                household["spouse_name"],
                f"Spouse\nMarried on Day {household['married_day']}",
                "VIEW RELATIONSHIP",
                lambda checked=False, key=household["spouse_key"]: self.open_npc(key),
            )
        else:
            self.add_body(layout, "You are not married.", muted=True)
        if household["expecting_child"]:
            remaining = max(0, int(household["child_due_day"]) - character.day)
            self.add_card(layout, "EXPECTED CHILD", f"Your household is expecting a child.\nApproximately {remaining} in-game day(s) remain.")
        self.add_body(layout, "CHILDREN")
        if household["children"]:
            schooling = self.game_state.schooling_profile()
            for child in household["children"]:
                school = next((x.get("school") for x in schooling if int(x["id"]) == int(child["id"])), None)
                school_text = f"\nSchool: {school['school_name']}  •  Attendance days: {school['attendance_days']}" if school else ""
                self.add_card(
                    layout,
                    child["name"],
                    f"{child['stage']}\nBorn on Day {child['birth_day']}\nAge in game days: {child['days_old']}{school_text}",
                    None if school or child["stage"] not in {"Young Child", "Older Child"} else "ENROLL IN SCHOOL",
                    None if school or child["stage"] not in {"Young Child", "Older Child"} else (lambda checked=False, cid=child["id"]: self.enroll_child_school(cid)),
                )
        else:
            self.add_body(layout, "No children are currently part of your household.", muted=True)

        inventory_heading = QLabel("INVENTORY & EQUIPMENT")
        inventory_heading.setObjectName("Heading")
        inventory_heading.setStyleSheet("margin-top: 10px;")
        layout.addWidget(inventory_heading)

        if inventory:
            for item in inventory:
                if item["item_name"] in WEAPONS:
                    equipped = item["item_name"] == character.equipped_weapon
                    self.add_card(
                        layout,
                        f"{item['item_name']}  x{item['quantity']}",
                        item["description"] + ("\n\nEQUIPPED" if equipped else ""),
                        None if equipped else "EQUIP",
                        None if equipped else (lambda checked=False, name=item["item_name"]: self.equip_weapon(name)),
                        enabled=not combat,
                    )
                elif item["item_name"] in PREPARED_FOODS:
                    food = PREPARED_FOODS[item["item_name"]]
                    self.add_card(
                        layout,
                        f"{item['item_name']}  x{item['quantity']}",
                        f"{item['description']}\n\nRestores up to {food.hp_restore} HP and {food.stamina_restore} stamina.",
                        "EAT",
                        lambda checked=False, name=item["item_name"]: self.eat_prepared_food(name),
                        enabled=not combat,
                    )
                else:
                    self.add_card(layout, f"{item['item_name']}  x{item['quantity']}", item["description"])
        else:
            self.add_body(layout, "Your inventory is empty.", muted=True)

        skills_heading = QLabel("SKILLS")
        skills_heading.setObjectName("Heading")
        skills_heading.setStyleSheet("margin-top: 10px;")
        layout.addWidget(skills_heading)

        skill_frame = QFrame()
        skill_grid = QGridLayout(skill_frame)
        skill_grid.setContentsMargins(0, 0, 0, 0)
        skill_grid.setHorizontalSpacing(12)
        skill_grid.setVerticalSpacing(8)
        for index, skill in enumerate(skills):
            skill_card = QWidget()
            skill_layout = QVBoxLayout(skill_card)
            skill_layout.setContentsMargins(1, 4, 12, 5)
            skill_layout.setSpacing(2)
            name = QLabel(skill["skill_name"])
            name.setStyleSheet("font-weight: 700; font-size: 14px;")
            skill_layout.addWidget(name)
            progress = QLabel(f"Level {skill['level']}   •   XP {skill['xp']} / {((skill['level'] + 1) * 10)}")
            progress.setObjectName("Muted")
            skill_layout.addWidget(progress)
            columns = 1 if IS_ANDROID else 2
            skill_grid.addWidget(skill_card, index // columns, index % columns)
        skill_grid.setColumnStretch(0, 1)
        if not IS_ANDROID:
            skill_grid.setColumnStretch(1, 1)
        layout.addWidget(skill_frame)
        self.add_body(layout, "Skills improve through the activities they represent rather than through assigned skill points.", muted=True)

        vice_heading = QLabel("VICE")
        vice_heading.setObjectName("Heading")
        vice_heading.setStyleSheet("margin-top: 10px;")
        layout.addWidget(vice_heading)
        profile = self.game_state.get_vice_profile()
        self.add_card(
            layout,
            "VICE SUMMARY",
            f"Alcohol: {profile['intoxication_label']}  •  Intoxication {profile['intoxication']}/100\n"
            f"Alcohol dependence: {profile['alcohol_dependence_label']}  •  {profile['alcohol_dependence']}/100\n\n"
            f"Drug effect: {profile['drug_effect_label']}  •  {profile['drug_effect']}/100\n"
            f"Drug dependence: {profile['drug_dependence_label']}  •  {profile['drug_dependence']}/100\n\n"
            f"Gambling dependence: {profile['gambling_dependence_label']}  •  {profile['gambling_dependence']}/100",
        )
        if profile["gambling_urge"]:
            self.add_card(layout, "GAMBLING URGE", "Gambling dependence is producing a recurring stress penalty while you abstain.")
        if profile["alcohol_withdrawal"] or profile["drug_withdrawal"]:
            parts = []
            if profile["alcohol_withdrawal"]:
                parts.append("alcohol")
            if profile["drug_withdrawal"]:
                parts.append("drug")
            self.add_card(layout, "WITHDRAWAL", f"Dependence is producing {' and '.join(parts)} withdrawal effects.")
        if profile["dealer_started"]:
            stock = self.game_state.dealer_stock()
            stock_text = "\n".join(f"{name}: {qty}" for name, qty in stock.items())
            self.add_card(layout, "DEALING OPERATION", f"Tier: {profile['dealer_tier']}\nReputation: {profile['dealer_reputation']}\n\nCurrent stock:\n{stock_text}")
        inventory_map = {row["item_name"]: int(row["quantity"]) for row in inventory}
        usable = []
        for item in list(ALCOHOL_ITEMS.values()) + list(DRUG_ITEMS.values()):
            qty = inventory_map.get(item.name, 0)
            if qty:
                usable.append((item, qty))
        if usable:
            self.add_body(layout, "ON HAND")
            for item, qty in usable:
                self.add_card(
                    layout,
                    f"{item.name}  x{qty}",
                    item.description,
                    "USE",
                    lambda checked=False, name=item.name: self.use_vice_item(name),
                    enabled=not combat,
                )
        else:
            self.add_body(layout, "You are not carrying alcohol or drugs.", muted=True)
        layout.addStretch()

    def render_career(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.career_layout
        self.clear_layout(layout)
        self.add_heading(layout, "CAREER")
        shift = self.game_state.get_career_shift_state()
        profile = self.game_state.career_profile()

        if shift and profile:
            self.add_card(
                layout,
                f"{profile['name']} — {profile['employer']}",
                f"Eight-hour shift in progress.\n\nRank: {profile['rank']}\nShift pay: ${profile['daily_pay']}\nWorkday: {profile['weekday']}",
            )
            self.career_progress_bar = QProgressBar()
            self.career_progress_bar.setRange(0, shift["duration_seconds"])
            self.career_remaining_label = QLabel()
            layout.addWidget(self.career_progress_bar)
            layout.addWidget(self.career_remaining_label)
            self.update_activity_widgets()
            self.add_body(layout, "The shift advances the in-game clock by eight hours when completed. It continues if you browse another screen or close the game.", muted=True)
            layout.addStretch()
            return

        if profile:
            next_text = "Highest current rank."
            if profile["next_rank"]:
                next_text = f"Next promotion: {profile['next_rank'][0]} in {profile['next_rank'][1]} completed shifts."
            self.add_card(
                layout,
                f"{profile['name']} — {profile['employer']}",
                f"Rank: {profile['rank']}\nDaily pay: ${profile['daily_pay']}\nCompleted shifts: {profile['shifts_worked']}\n"
                f"Reliability: {profile['reliability']}%\nMissed shifts: {profile['missed_shifts']}\n"
                f"Schedule: Monday through Friday\nToday: {profile['weekday']}\n\n{next_text}",
            )
            can_work = (
                not job and not travel and not combat and profile["scheduled_today"] and not profile["worked_today"]
                and character.stamina >= profile["stamina_cost"]
                and normalize_location_key(character.current_location) == profile["location_key"]
            )
            status = "Today's shift is available."
            if not profile["scheduled_today"]:
                status = "You are not scheduled today."
            elif profile["worked_today"]:
                status = "Today's shift is complete."
            elif normalize_location_key(character.current_location) != profile["location_key"]:
                status = f"Report to {LOCATIONS[profile['location_key']].name} for your shift."
            elif character.stamina < profile["stamina_cost"]:
                status = f"You need {profile['stamina_cost']} stamina to work the full shift."
            self.add_card(
                layout,
                "FULL-TIME SHIFT",
                f"{status}\n\nLength: 8 in-game hours\nPrototype real timer: 45 sec\nStamina: {profile['stamina_cost']}\nPay: ${profile['daily_pay']}",
                "WORK 8-HOUR SHIFT",
                self.begin_career_shift,
                enabled=can_work,
            )
            resign = QPushButton("RESIGN POSITION")
            resign.clicked.connect(self.resign_career)
            resign.setEnabled(not job and not travel and not combat)
            layout.addWidget(resign)
        else:
            self.add_body(layout, "You do not currently have a full-time career. Career positions are permanent jobs with weekday shifts, promotions, and an employment record.")

        self.add_body(layout, "CAREERS AVAILABLE HERE")
        available = self.game_state.available_careers()
        if not available:
            self.add_body(layout, "No full-time employers are hiring at this location.", muted=True)
        for career in available:
            reqs = []
            if career["required_skill"] and career["required_skill_level"]:
                reqs.append(f"{career['required_skill']} level {career['required_skill_level']} (you: {career['current_skill_level']})")
            if career["required_reputation"]:
                reqs.append(f"City reputation {career['required_reputation']} (you: {career['current_reputation']})")
            if career.get("required_certificate"):
                reqs.append(f"{career['required_certificate']} certificate ({'earned' if career.get('has_certificate') else 'not earned'})")
            req_text = "None" if not reqs else "\n".join(reqs)
            self.add_card(
                layout,
                f"{career['name']} — {career['employer']}",
                f"{career['description']}\n\nStarting daily pay: ${career['base_pay']}\nEight-hour weekday shifts\nStamina per shift: {career['stamina_cost']}\nRequirements: {req_text}",
                "APPLY",
                lambda checked=False, key=career["key"]: self.apply_for_career(key),
                enabled=profile is None and career["qualifies"] and not job and not travel and not combat,
            )

        history = self.game_state.career_history()
        if history:
            self.add_body(layout, "EMPLOYMENT HISTORY")
            for event in history:
                self.add_card(layout, f"Day {event['day']} — {event['event_type'].replace('_', ' ').title()}", event["description"])
        layout.addStretch()

    def render_people(self, character) -> None:
        layout = self.people_layout
        self.clear_layout(layout)
        self.add_heading(layout, "PEOPLE")
        self.add_body(layout, "Residents live and work throughout the wider region. Their routines change with the in-game clock.", muted=True)
        current = normalize_location_key(character.current_location)
        for resident in self.game_state.load_all_npcs():
            if resident["world_location"] == current and current != "home":
                where = "Here now"
            elif resident["world_location"] == "home":
                where = "At home"
            else:
                key = resident["world_location"]
                where = LOCATIONS[key].name if key in LOCATIONS else key.replace("_", " ").title()
            self.add_card(
                layout,
                resident["name"],
                f"{resident['occupation']}\nFriendship: {resident['relationship']}  •  {resident['friendship']}\nRomance: {resident['romance_label']}  •  {resident['romance']}\nCurrent: {resident['activity']}\n{where}",
                "VIEW",
                lambda checked=False, key=resident["key"]: self.open_npc(key),
            )
        layout.addStretch()

    def render_education(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.education_layout
        self.clear_layout(layout)
        self.add_heading(layout, "EDUCATION")
        profile = self.game_state.education_profile()
        if profile["certificates"]:
            self.add_body(layout, "CERTIFICATES")
            for cert in profile["certificates"]:
                self.add_card(layout, cert["certificate"], f"Earned Day {cert['earned_day']}")
        else:
            self.add_body(layout, "No certificates earned yet.", muted=True)
        if profile["current"]:
            current = profile["current"]
            self.add_card(layout, current["name"], f"Progress: {current['sessions_completed']}/{current['sessions']} class sessions\nCredential: {current['certificate']}", "ATTEND 4-HOUR CLASS", self.study_education, enabled=normalize_location_key(character.current_location) == "greybridge_city" and character.stamina >= 3 and not job and not travel and not combat)
        else:
            self.add_body(layout, "PROGRAMS — GREYBRIDGE COMMUNITY COLLEGE")
            for program in EDUCATION_PROGRAMS.values():
                self.add_card(layout, f"{program.name}  •  ${program.tuition}", f"{program.description}\n\nClass sessions: {program.sessions}\nCredential: {program.certificate}", "ENROLL", lambda checked=False, key=program.key: self.enroll_education(key), enabled=normalize_location_key(character.current_location) == "greybridge_city" and character.cash >= program.tuition and not job and not travel and not combat)
        layout.addStretch()

    def render_outdoors(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.outdoors_layout
        self.clear_layout(layout)
        self.add_heading(layout, "OUTDOORS & HOUSEHOLD ANIMALS")
        profile = self.game_state.season_weather_profile()
        self.add_body(layout, f"Season: {profile['season']} — Day {profile['day_in_season']}/30\nWeather: {profile['weather']}")
        self.add_body(layout, "Weather changes with the in-game day and region. Severe conditions reduce hunting success and make wilderness camping less effective.", muted=True)
        current = normalize_location_key(character.current_location)
        if current in {"blackwood_trail", "lake_mercy_north_shore", "pine_ridge"}:
            self.add_card(layout, "HUNTING", "Hunting uses a Hunting Rifle, 3 stamina, and 90 in-game minutes. Results are resolved abstractly and can provide game meat and hides.", "HUNT", self.hunt_game, enabled=character.stamina >= 3 and not job and not travel and not combat)
        if current in {"blackwood_trail", "lake_mercy_north_shore", "pine_ridge", "hollow_creek_sawmill"}:
            self.add_card(layout, "WILDERNESS CAMP", "A Camping Kit allows a six-hour wilderness rest. Weather affects recovery. Camping improves Survival.", "MAKE CAMP", self.camp_wilderness, enabled=not job and not travel and not combat)
        self.add_body(layout, "PETS")
        pets = self.game_state.load_pets()
        if not pets:
            self.add_body(layout, "No household pets.", muted=True)
        for pet in pets:
            self.add_card(layout, pet["name"], f"{pet.get('species', pet['pet_key'].title())}\nBond: {pet['bond']}/100\n{pet.get('description','')}", "SPEND TIME TOGETHER", lambda checked=False, pid=pet["id"]: self.interact_pet(pid), enabled=int(pet["last_interaction_day"]) != character.day and not job and not travel and not combat)
        if current == "millhaven":
            self.add_body(layout, "MILLHAVEN ANIMAL SHELTER")
            for pet in PETS.values():
                self.add_card(layout, f"Adopt {pet.name}  •  ${pet.adoption_fee}", pet.description, "ADOPT", lambda checked=False, key=pet.key: self.adopt_pet(key), enabled=character.cash >= pet.adoption_fee and not job and not travel and not combat)
        layout.addStretch()

    def render_properties(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.properties_layout
        self.clear_layout(layout)
        self.add_heading(layout, "PROPERTY PORTFOLIO")
        self.add_body(layout, "The world contains 100 persistent plots. You may own multiple plots, change your primary residence, and rent developed secondary homes to tenants.", muted=True)
        for plot in self.game_state.owned_plots():
            body = f"{plot['terrain']} — {plot['size']}\nBase land value: ${plot['base_value']}\nStructures: {', '.join(plot['structures']) if plot['structures'] else 'None'}"
            if plot["rental"]:
                body += f"\nTenant: {plot['rental']['tenant_name']}\nWeekly rent: ${plot['rental']['weekly_rent']}\nLifetime rent: ${plot['rental']['lifetime_rent']}"
            self.add_card(layout, plot["code"] + (" — PRIMARY HOME" if plot["is_home"] else ""), body)
            if not plot["is_home"]:
                if plot["rental"]:
                    self.add_card(layout, f"Rental — {plot['code']}", "End the current tenancy.", "END RENTAL", lambda checked=False, pid=plot["id"]: self.end_rental(pid), enabled=not job and not travel and not combat)
                else:
                    self.add_card(layout, f"Use — {plot['code']}", "A developed property can become your primary residence or be rented to a tenant.", "SET AS HOME", lambda checked=False, pid=plot["id"]: self.set_home_plot(pid), enabled=not job and not travel and not combat)
                    self.add_card(layout, f"Rent Out — {plot['code']}", "Requires a Wooden Shack or Small Cabin on the property.", "FIND TENANT", lambda checked=False, pid=plot["id"]: self.start_rental(pid), enabled=not job and not travel and not combat)
        self.add_body(layout, "LAND FOR SALE")
        for plot in self.game_state.plots_for_sale()[:12]:
            self.add_card(layout, f"{plot['code']} — ${plot['base_value']}", f"{plot['terrain']} — {plot['size']}\n{plot_summary(plot)}", "BUY PLOT", lambda checked=False, pid=plot["id"]: self.buy_plot(pid), enabled=character.cash >= int(plot['base_value']) and not job and not travel and not combat)
        layout.addStretch()

    def render_crafting(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.crafting_layout
        self.clear_layout(layout)
        self.add_heading(layout, "CRAFTING")
        at_home = normalize_location_key(character.current_location) == "home" and not travel
        self.add_body(layout, "Raw materials can be processed at your property. A Workbench handles timber and stone. A Stone Forge handles metalworking and forged tools.")
        if not at_home:
            self.add_body(layout, "Travel to your property to use crafting stations.", muted=True)
        for recipe in CRAFT_RECIPES.values():
            station_name = "Workbench" if recipe.station == "workbench" else "Stone Forge"
            station_ready = self.game_state.has_structure(recipe.station)
            requirements = []
            craftable = True
            for item_name, qty in recipe.inputs:
                available = self.game_state.available_material_quantity(item_name)
                requirements.append(f"{item_name}: {available}/{qty}")
                if available < qty:
                    craftable = False
            body = (
                f"{recipe.description}\n\nStation: {station_name} {'— available' if station_ready else '— not built'}\n"
                + "Materials: " + ", ".join(requirements)
                + f"\nCrafting XP: +{recipe.crafting_xp}"
            )
            self.add_card(
                layout, recipe.name, body, "CRAFT",
                lambda checked=False, key=recipe.key: self.craft_recipe(key),
                enabled=at_home and not job and not combat and station_ready and craftable,
            )
        layout.addStretch()

    def render_family(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.family_layout
        self.clear_layout(layout)
        self.add_heading(layout, "FAMILY")
        household = self.game_state.get_household()
        if household["spouse_name"]:
            self.add_card(
                layout,
                household["spouse_name"],
                f"Spouse\nMarried on Day {household['married_day']}",
                "VIEW RELATIONSHIP",
                lambda checked=False, key=household["spouse_key"]: self.open_npc(key),
            )
        else:
            self.add_body(layout, "You are not married.", muted=True)

        if household["expecting_child"]:
            remaining = max(0, int(household["child_due_day"]) - character.day)
            self.add_card(layout, "EXPECTED CHILD", f"Your household is expecting a child.\nApproximately {remaining} in-game day(s) remain.")

        self.add_body(layout, "CHILDREN")
        if household["children"]:
            for child in household["children"]:
                school = next((x.get("school") for x in self.game_state.schooling_profile() if int(x["id"]) == int(child["id"])), None)
                school_text = f"\nSchool: {school['school_name']}  •  Attendance days: {school['attendance_days']}" if school else ""
                self.add_card(
                    layout,
                    child["name"],
                    f"{child['stage']}\nBorn on Day {child['birth_day']}\nAge in game days: {child['days_old']}{school_text}",
                    None if school or child["stage"] not in {"Young Child", "Older Child"} else "ENROLL IN SCHOOL",
                    None if school or child["stage"] not in {"Young Child", "Older Child"} else (lambda checked=False, cid=child["id"]: self.enroll_child_school(cid)),
                )
        else:
            self.add_body(layout, "No children are currently part of your household.", muted=True)
        layout.addStretch()

    def render_property(self, character, plot: dict, structures: list[dict], construction: dict | None, travel: dict | None, job: dict | None, combat: dict | None) -> None:
        layout = self.property_layout
        self.clear_layout(layout)
        self.add_heading(layout, "HOME")
        self.add_body(
            layout,
            f"Terrain: {plot['terrain']}\nSize: {plot['size']}\n"
            f"Natural features: {plot_summary(plot)}\nProperty value: ${self.game_state.property_value()}",
        )

        at_home = normalize_location_key(character.current_location) == "home" and not travel
        if at_home:
            cooking = QPushButton("OPEN COOKING")
            cooking.setEnabled(not job and not combat)
            cooking.clicked.connect(lambda: self.show_page("cooking"))
            layout.addWidget(cooking)
        self.add_body(layout, "STRUCTURES")
        for structure in structures:
            definition = STRUCTURES.get(structure.get("definition_key") or "")
            body = f"Condition: {structure['condition_percent']}%"
            if definition:
                if definition.rooms:
                    body += "\nRooms: " + ", ".join(definition.rooms)
                body += f"\nStorage: +{definition.storage_capacity}" if definition.storage_capacity else ""
                body += f"\nComfort: {definition.comfort}" if definition.comfort else ""
            self.add_card(layout, structure["name"], body)

        if construction:
            definition = STRUCTURES[construction["structure_key"]]
            self.add_body(layout, "CONSTRUCTION IN PROGRESS")
            self.add_card(layout, definition.name, definition.description)
            self.construction_progress = QProgressBar()
            self.construction_progress.setRange(0, construction["duration_seconds"])
            self.construction_remaining_label = QLabel()
            layout.addWidget(self.construction_progress)
            layout.addWidget(self.construction_remaining_label)
            self.update_activity_widgets()
            self.add_body(layout, "Construction continues if you travel elsewhere or close the game.", muted=True)
        else:
            self.add_body(layout, "BUILD")
            existing_keys = {x.get("definition_key") for x in structures}
            for definition in STRUCTURES.values():
                already_built = definition.key in existing_keys
                body = (
                    f"{definition.description}\n\nCost: ${definition.cost}\n"
                    f"Build time: {definition.duration_seconds} sec"
                )
                missing_materials = self.game_state.missing_construction_materials(definition.key)
                if definition.materials:
                    material_lines = []
                    for item_name, qty in definition.materials:
                        available = self.game_state.available_material_quantity(item_name)
                        material_lines.append(f"{item_name} {available}/{qty}")
                    body += "\nMaterials: " + ", ".join(material_lines)
                if definition.rooms:
                    body += "\nRooms: " + ", ".join(definition.rooms)
                self.add_card(
                    layout,
                    definition.name,
                    body,
                    "BUILT" if already_built else "BUILD",
                    None if already_built else (lambda checked=False, key=definition.key: self.begin_construction(key)),
                    enabled=at_home and not job and not combat and not already_built and character.cash >= definition.cost and not missing_materials,
                )

        rooms = self.game_state.property_rooms()
        placed = self.game_state.load_furniture()
        furniture_inventory = [item for item in self.game_state.load_inventory() if item["item_name"] in FURNITURE]
        if rooms:
            self.add_body(layout, "ROOMS & FURNITURE")
            for room in rooms:
                furniture_names = room["furniture"]
                body = "Furniture: " + (", ".join(furniture_names) if furniture_names else "None")
                self.add_card(layout, f"{room['structure_name']} — {room['room_name']}", body)
                for item in furniture_inventory:
                    definition = FURNITURE[item["item_name"]]
                    if room["room_name"] in definition.allowed_rooms:
                        self.add_card(
                            layout,
                            f"Place {item['item_name']} in {room['room_name']}",
                            definition.description,
                            "PLACE",
                            lambda checked=False, name=item["item_name"], sid=room["structure_id"], rn=room["room_name"]: self.place_furniture(name, sid, rn),
                            enabled=at_home and not job and not combat,
                        )

        if placed:
            self.add_body(layout, "PLACED FURNITURE")
            for item in placed:
                definition = FURNITURE.get(item["item_name"])
                description = definition.description if definition else item["item_name"]
                self.add_card(
                    layout,
                    item["item_name"],
                    f"{description}\n\n{item['structure_name']} — {item['room_name']}",
                    "MOVE TO INVENTORY",
                    lambda checked=False, fid=item["id"]: self.remove_furniture(fid),
                    enabled=at_home and not job and not combat,
                )

        # Farming
        if self.game_state.has_garden_plot():
            self.add_body(layout, "GARDEN")
            crops = self.game_state.load_farm_crops()
            capacity = self.game_state.farm_capacity()
            self.add_body(layout, f"Planting beds in use: {len(crops)}/{capacity}", muted=True)
            for crop_row in crops:
                status = "Ready to harvest" if crop_row["ready"] else f"Growing — {crop_row['remaining_seconds']} sec remaining"
                water_status = "Watered" if crop_row["watered"] else "Not watered"
                body = f"{crop_row['description']}\n\n{status}\n{water_status}"
                if crop_row["ready"]:
                    self.add_card(
                        layout,
                        crop_row["crop_name"],
                        body,
                        "HARVEST",
                        lambda checked=False, cid=crop_row["id"]: self.harvest_crop(cid),
                        enabled=at_home and not job and not combat,
                    )
                elif not crop_row["watered"]:
                    self.add_card(
                        layout,
                        crop_row["crop_name"],
                        body,
                        "WATER  •  1 STAMINA",
                        lambda checked=False, cid=crop_row["id"]: self.water_crop(cid),
                        enabled=at_home and not job and not combat and character.stamina >= 1,
                    )
                else:
                    self.add_card(layout, crop_row["crop_name"], body)

            if len(crops) < capacity:
                seed_inventory = {item["item_name"]: item for item in self.game_state.load_inventory() if item["item_name"] in SEED_ITEMS}
                if seed_inventory:
                    self.add_body(layout, "PLANT")
                    for seed_name, item in seed_inventory.items():
                        crop = SEED_ITEMS[seed_name]
                        self.add_card(
                            layout,
                            f"{crop.name}  •  {seed_name} x{item['quantity']}",
                            f"{crop.description}\n\nGrowth time: {crop.grow_seconds} sec\nPlanting cost: 1 stamina",
                            "PLANT",
                            lambda checked=False, key=crop.key: self.plant_crop(key),
                            enabled=at_home and not job and not combat and character.stamina >= 1,
                        )
                elif at_home:
                    self.add_body(layout, "Buy seeds from Farm Supply to plant this garden.", muted=True)
        else:
            self.add_body(layout, "FARMING")
            self.add_body(layout, "Build a Garden Plot to begin growing crops on this property.", muted=True)

        # Livestock
        coop_capacity = self.game_state.animal_capacity("chicken")
        barn_capacity = max(
            self.game_state.animal_capacity("goat"),
            self.game_state.animal_capacity("cow"),
            self.game_state.animal_capacity("pig"),
        )
        stable_capacity = self.game_state.animal_capacity("horse")
        if coop_capacity or barn_capacity or stable_capacity:
            livestock = self.game_state.load_livestock()
            feed = self.game_state.farm_feed_quantity()
            self.add_body(layout, "LIVESTOCK")
            self.add_body(layout, f"Feed stored on property: {feed} portions", muted=True)
            if not livestock:
                self.add_body(layout, "No livestock are currently kept on this property.", muted=True)
            for animal_row in livestock:
                if animal_row.get("rideable"):
                    where = animal_row.get("current_location", "home")
                    where_text = "On this property" if where == "home" else f"Currently at: {where.replace('_', ' ').title()}"
                    status = f"Rideable mount\n{where_text}"
                    body = f"{animal_row['description']}\n\n{status}"
                elif animal_row["stored_output"] > 0:
                    status = f"{animal_row['product_item']} ready: {animal_row['stored_output']}"
                    body = f"{animal_row['description']}\n\n{status}\nStored output limit: {MAX_STORED_OUTPUT}"
                elif animal_row["needs_feed"]:
                    status = "Production paused — feed is required"
                    body = f"{animal_row['description']}\n\n{status}\nStored output limit: {MAX_STORED_OUTPUT}"
                else:
                    status = f"Next production: {animal_row['remaining_seconds']} sec"
                    body = f"{animal_row['description']}\n\n{status}\nStored output limit: {MAX_STORED_OUTPUT}"
                if animal_row["stored_output"] > 0 and animal_row.get("product_item"):
                    self.add_card(
                        layout,
                        animal_row["animal_name"],
                        body,
                        "COLLECT",
                        lambda checked=False, aid=animal_row["id"]: self.collect_animal_output(aid),
                        enabled=at_home and not job and not combat,
                    )
                else:
                    self.add_card(layout, animal_row["animal_name"], body)

            if coop_capacity:
                chicken_count = self.game_state.animal_count("chicken")
                self.add_body(layout, f"Chicken Coop: {chicken_count}/{coop_capacity}", muted=True)
            if barn_capacity:
                large_count = sum(self.game_state.animal_count(key) for key in ("goat", "cow", "pig"))
                self.add_body(layout, f"Small Barn: {large_count}/{barn_capacity}", muted=True)
            if stable_capacity:
                horse_count = self.game_state.animal_count("horse")
                self.add_body(layout, f"Stable: {horse_count}/{stable_capacity}", muted=True)
            if at_home:
                self.add_body(
                    layout,
                    "Buy livestock and feed from Farm Supply. Feed purchases are delivered to this property.",
                    muted=True,
                )
        else:
            self.add_body(layout, "LIVESTOCK")
            self.add_body(layout, "Build a Chicken Coop, Small Barn, or Stable before keeping livestock.", muted=True)

        businesses = self.game_state.load_businesses()
        self.add_body(layout, "BUSINESSES")
        if not businesses:
            self.add_body(layout, "Build a Farm Stand, Small Shop, or Roadside Bar to operate a business from this property.", muted=True)
        for business in businesses:
            status = "OPEN" if business["is_open"] else "CLOSED"
            body = (
                f"Status: {status}\nPricing: {business['price_label']}\n"
                f"Stock: {business['stock_count']} items\nTill: ${business['till']}\n"
                f"Customers served: {business['customers_served']}\nLifetime revenue: ${business['lifetime_revenue']}"
            )
            self.add_card(
                layout,
                business["business_name"],
                body,
                "MANAGE",
                lambda checked=False, bid=business["id"]: self.manage_business(bid),
                enabled=not combat,
            )

        capacity = self.game_state.property_storage_capacity()
        used = self.game_state.property_storage_used()
        self.add_body(layout, f"PROPERTY STORAGE  {used}/{capacity}")
        stored = self.game_state.load_property_storage()
        if stored:
            for item in stored:
                self.add_card(
                    layout,
                    f"{item['item_name']}  x{item['quantity']}",
                    item["description"],
                    "TAKE ONE",
                    lambda checked=False, name=item["item_name"]: self.take_storage_item(name),
                    enabled=at_home and not job and not combat,
                )
        else:
            self.add_body(layout, "Storage is empty.", muted=True)

        if at_home and used < capacity:
            inventory = self.game_state.load_inventory()
            storable = [x for x in inventory if x["item_name"] != character.equipped_weapon]
            if storable:
                self.add_body(layout, "STORE FROM INVENTORY")
                for item in storable:
                    self.add_card(
                        layout,
                        f"{item['item_name']}  x{item['quantity']}",
                        item["description"],
                        "STORE ONE",
                        lambda checked=False, name=item["item_name"]: self.store_inventory_item(name),
                        enabled=not job and not combat and used < capacity,
                    )

        self.add_body(layout, "PETS")
        pets = self.game_state.load_pets()
        if not pets:
            self.add_body(layout, "No household pets.", muted=True)
        for pet in pets:
            self.add_card(
                layout,
                pet["name"],
                f"{pet.get('species', pet['pet_key'].title())}\nBond: {pet['bond']}/100\n{pet.get('description','')}",
                "SPEND TIME TOGETHER",
                lambda checked=False, pid=pet["id"]: self.interact_pet(pid),
                enabled=int(pet["last_interaction_day"]) != character.day and not job and not travel and not combat,
            )
        if normalize_location_key(character.current_location) == "millhaven":
            self.add_body(layout, "MILLHAVEN ANIMAL SHELTER")
            for pet in PETS.values():
                self.add_card(
                    layout,
                    f"Adopt {pet.name}  •  ${pet.adoption_fee}",
                    pet.description,
                    "ADOPT",
                    lambda checked=False, key=pet.key: self.adopt_pet(key),
                    enabled=character.cash >= pet.adoption_fee and not job and not travel and not combat,
                )

        if not at_home:
            self.add_body(layout, "Travel to your home to build, place furniture, or use storage.", muted=True)
        layout.addStretch()

    def _vehicle_location_name(self, key: str) -> str:
        if key == "home":
            return "Home"
        location = LOCATIONS.get(key)
        return location.name if location else key.replace("_", " ").title()

    def render_vehicles(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.vehicles_layout
        self.clear_layout(layout)
        self.add_heading(layout, "VEHICLES")
        vehicles = self.game_state.load_vehicles()
        current = normalize_location_key(character.current_location)
        if not vehicles:
            self.add_body(layout, "You do not own a vehicle yet. Vehicles can be purchased from motors and service garages around Dong.")
            layout.addStretch()
            return

        for vehicle in vehicles:
            fuel_line = "Fuel: Not required" if not vehicle["motorized"] else f"Fuel: {vehicle['fuel']}/{vehicle['fuel_capacity']}"
            body = (
                f"{vehicle['description']}\n\n"
                f"Location: {self._vehicle_location_name(vehicle['current_location'])}\n"
                f"Condition: {vehicle['condition_percent']}%\n"
                f"{fuel_line}\n"
                f"Storage: {vehicle['storage_used']}/{vehicle['storage_capacity']}"
            )
            self.add_card(layout, vehicle["name"], body)

            is_here = vehicle["current_location"] == current and not travel
            if is_here and vehicle["storage_capacity"] > 0:
                self.add_body(layout, f"{vehicle['name'].upper()} STORAGE")
                stored = self.game_state.load_vehicle_storage(vehicle["id"])
                for item in stored:
                    self.add_card(
                        layout,
                        f"{item['item_name']}  x{item['quantity']}",
                        item["description"],
                        "TAKE 1",
                        lambda checked=False, vid=vehicle["id"], name=item["item_name"]: self.take_vehicle_item(vid, name),
                        enabled=not job and not combat,
                    )
                if vehicle["storage_used"] < vehicle["storage_capacity"]:
                    for item in self.game_state.load_inventory():
                        self.add_card(
                            layout,
                            f"Store {item['item_name']}",
                            f"Inventory quantity: {item['quantity']}",
                            "STORE 1",
                            lambda checked=False, vid=vehicle["id"], name=item["item_name"]: self.store_vehicle_item(vid, name),
                            enabled=not job and not combat and item["item_name"] != character.equipped_weapon,
                        )

            can_repair_here = is_here and (current in {"millhaven", "redwater", "greybridge_city", "westhaven"} or (current == "home" and self.game_state.has_structure("garage")))
            if can_repair_here and int(vehicle["condition_percent"]) < 100:
                location_text = "your Garage" if current == "home" else "the city service garage"
                self.add_card(
                    layout,
                    "REPAIRS",
                    f"Repair this vehicle at {location_text}. Home garage repairs cost less than commercial repairs.",
                    "REPAIR",
                    lambda checked=False, vid=vehicle["id"]: self.repair_vehicle(vid),
                    enabled=not job and not combat,
                )
        layout.addStretch()

    def render_motors(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.motors_layout
        self.clear_layout(layout)
        current = normalize_location_key(character.current_location)
        self.add_heading(layout, "MOTORS & SERVICE GARAGE")
        if current not in {"millhaven", "redwater", "greybridge_city", "westhaven", "lake_mercy"}:
            self.add_body(layout, "There is no full-service vehicle or marine dealer at your current location.")
            layout.addStretch()
            return
        self.add_body(layout, "Vehicles and boats are sold through dealers around Dong. Fuel and mechanical repairs are available for vehicles brought to the property.")
        self.add_body(layout, "VEHICLES FOR SALE")
        for definition in VEHICLES.values():
            if current == "lake_mercy" and definition.method not in {"Rowboat", "Motorboat"}:
                continue
            if current != "lake_mercy" and definition.method in {"Rowboat", "Motorboat"} and current != "westhaven":
                continue
            fuel = "No fuel required" if not definition.motorized else f"Fuel capacity: {definition.fuel_capacity}"
            self.add_card(
                layout,
                f"{definition.name}  •  ${definition.price}",
                f"{definition.description}\n\n{fuel}\nStorage capacity: {definition.storage_capacity}",
                "BUY VEHICLE",
                lambda checked=False, key=definition.key: self.buy_vehicle(key),
                enabled=not job and not travel and not combat and character.cash >= definition.price,
            )

        owned_here = [v for v in self.game_state.load_vehicles() if v["current_location"] == current]
        if owned_here:
            self.add_body(layout, "SERVICE")
        for vehicle in owned_here:
            if vehicle["motorized"]:
                missing = max(0, vehicle["fuel_capacity"] - vehicle["fuel"])
                self.add_card(
                    layout,
                    f"Refuel {vehicle['name']}",
                    f"Current fuel: {vehicle['fuel']}/{vehicle['fuel_capacity']}\nFuel: ${FUEL_PRICE_PER_UNIT} per unit",
                    "FILL TANK" if missing else "TANK FULL",
                    lambda checked=False, vid=vehicle["id"]: self.refuel_vehicle(vid),
                    enabled=missing > 0 and not job and not travel and not combat,
                )
            missing_condition = max(0, 100 - vehicle["condition_percent"])
            self.add_card(
                layout,
                f"Repair {vehicle['name']}",
                f"Condition: {vehicle['condition_percent']}%\nCommercial repair rate: ${REPAIR_PRICE_PER_CONDITION} per condition point",
                "REPAIR" if missing_condition else "NO REPAIRS NEEDED",
                lambda checked=False, vid=vehicle["id"]: self.repair_vehicle(vid),
                enabled=missing_condition > 0 and not job and not travel and not combat,
            )
        layout.addStretch()

    def render_world(self, character) -> None:
        layout = self.world_layout
        self.clear_layout(layout)
        self.add_heading(layout, "WORLD")
        self.add_body(layout, "City reputation changes as you work, help people, and build a history in different parts of the world.", muted=True)
        known = set(self.game_state.known_locations())
        for region in self.game_state.regional_reputations():
            if not region["discovered"]:
                continue
            locations = [LOCATIONS[key].name for key in known if key in LOCATIONS and LOCATIONS[key].region_key == region["key"]]
            body = (
                f"{region['description']}\n\n"
                f"Reputation: {region['label']} ({region['reputation']:+d})\n"
                f"Known locations: {', '.join(sorted(locations)) if locations else 'None'}"
            )
            self.add_card(layout, region["name"], body)
        layout.addStretch()

    def render_map(self, character, plot: dict, travel: dict | None, job: dict | None, combat: dict | None) -> None:
        layout = self.map_layout
        self.clear_layout(layout)
        self.add_heading(layout, "MAP")
        current = normalize_location_key(character.current_location)
        self.add_body(layout, f"Current location: {location_name(character.current_location, plot)}", muted=True)
        self.add_body(layout, "Choose what you want to do. Dong will show where that activity is located and how to get there.", muted=True)

        if travel:
            self.add_body(layout, "You are currently travelling. You can browse the directory, but cannot begin another trip until the current journey ends.", muted=True)
        elif job:
            self.add_body(layout, "You are currently working and cannot begin a trip until the shift ends.", muted=True)
        elif combat:
            self.add_body(layout, "You are currently in combat and cannot travel until the encounter ends.", muted=True)

        entries = [
            ("SHOPS & SERVICES", [
                ("General Market", "Food, tools, basic supplies, and city goods.", "millhaven", "store"),
                ("Farm Supply", "Seeds, livestock, feed, and farming supplies.", "millhaven", "farm_store"),
                ("Furnishings", "Furniture and household items for your home.", "millhaven", "furniture_store"),
                ("Motors & Service", "Buy, refuel, and repair vehicles.", "millhaven", "motors"),
                ("Marina", "Boats, marine service, and lake access.", "lake_mercy", "motors"),
                ("Medical Services", "Healing and dependence treatment.", "millhaven", "clinic"),
                ("Community College", "Education programs and professional certificates.", "greybridge_city", "education"),
                ("Casino", "Slots, blackjack, roulette, and gambling records.", "greybridge_city", "casino"),
            ]),
            ("WORK", [
                ("Job Board", "Temporary jobs and local paid work.", "millhaven", "employment"),
                ("Civic Employment", "Office, transit, hospital, airport, and permanent career opportunities.", "greybridge_city", "employment"),
                ("Industrial Employment", "Industrial, freight, factory, and salvage work.", "redwater", "employment"),
                ("Mining Employment", "Mining and highway work.", "pine_ridge", "employment"),
                ("Waterfront Employment", "Port, hotel, and fishing-industry work.", "westhaven", "employment"),
            ]),
            ("GATHERING & OUTDOORS", [
                ("Blackwood Trail", "Explore, cut timber, hunt, camp, and encounter wildlife.", "blackwood_trail", "location"),
                ("Lake Mercy", "Fish, hunt, camp, and use quiet shoreline access.", "lake_mercy_north_shore", "location"),
                ("Quarry", "Mine stone and iron ore.", "millhaven_quarry", "location"),
                ("Sawmill", "Cut marked timber and camp in the greenbelt forest.", "hollow_creek_sawmill", "location"),
                ("Mine", "Mine stone and ore.", "pine_ridge_mine", "location"),
                ("Salvage Yard", "Search industrial salvage for scrap and machine parts.", "redwater_industrial", "location"),
            ]),
            ("CRIME & VICE", [
                ("Crime", "Pickpocketing, shoplifting, burglary, robbery, murder, Heat, arrests, and court cases.", None, "crime"),
                ("The Grey Lantern", "Criminal jobs, masks, dealing connections, and underground work.", "millhaven", "shady_bar"),
                ("Casino Gambling", "Slots, blackjack, roulette, and gambling dependence.", "greybridge_city", "casino"),
            ]),
            ("COMBAT", [
                ("Fight Club", "Enter repeatable supervised bouts against local fighters.", "redwater_fight_club", "location"),
                ("Blackstone Dungeon", "Enter underground chambers and fight hostile creatures.", "blackstone_dungeon", "location"),
                ("Blackwood Trail", "Explore the forest for unpredictable creature encounters.", "blackwood_trail", "location"),
            ]),
            ("HOME & PROPERTY", [
                ("Home", f"Return to {plot['code']} and manage your residence, storage, pets, and structures.", "home", "property"),
                ("Property Portfolio", "Review all owned plots, rentals, and land for sale.", None, "properties"),
                ("Vehicles", "Review vehicle locations, cargo, fuel, and condition.", None, "vehicles"),
            ]),
        ]

        directory_targets: dict[str, tuple[str | None, str]] = {}
        description_label = QLabel("Tap an activity to view it or prepare travel." if IS_ANDROID else "Hover over an activity for details. Click it to open it or prepare travel.")
        description_label.setObjectName("Muted")
        description_label.setWordWrap(True)
        description_label.setMinimumHeight(38)

        for category, items in entries:
            heading = QLabel(category)
            heading.setObjectName("Heading")
            layout.addWidget(heading)
            grid = QGridLayout()
            grid.setHorizontalSpacing(28)
            grid.setVerticalSpacing(9)
            for index, (title, description, destination, page) in enumerate(items):
                directory_targets[title] = (destination, page)
                button = HoverRevealButton(
                    title,
                    description,
                    description_label,
                    lambda checked=False, t=title: self.select_directory_entry(t),
                )
                if not IS_ANDROID:
                    button.setMaximumWidth(390)
                columns = 1 if IS_ANDROID else 2
                grid.addWidget(button, index // columns, index % columns, Qt.AlignLeft)
            grid.setColumnStretch(0, 1)
            if not IS_ANDROID:
                grid.setColumnStretch(1, 1)
            layout.addLayout(grid)

        self._directory_targets = directory_targets
        layout.addWidget(description_label)

        layout.addStretch()

    def travel_choice_label(self, method: str, destination: str) -> str:
        current = normalize_location_key(self.game_state.load_character().current_location)
        home_region_key = self.game_state.load_home_plot().get("region_key", "millhaven_county")
        seconds = travel_seconds(current, destination, method, home_region_key)
        if method == "Horse":
            return f"Horse  •  {seconds} sec"
        if method == "Walking":
            return f"Walk  •  {seconds} sec"
        vehicles = [
            vehicle for vehicle in self.game_state.load_vehicles()
            if vehicle["current_location"] == current and vehicle["method"] == method and int(vehicle["condition_percent"]) > 0
        ]
        vehicle_name = vehicles[0]["name"] if vehicles else method
        extra = ""
        if method not in {"Bicycle", "Rowboat"}:
            fuel = route_fuel_units(current, destination, method, home_region_key)
            extra = f"  •  {fuel} fuel"
        return f"{vehicle_name}  •  {seconds} sec{extra}"

    def show_travel_dialog(self, destination: str, destination_title: str) -> None:
        character = self.game_state.load_character()
        current = normalize_location_key(character.current_location)
        if destination == current:
            return
        if self.game_state.get_travel_state() or self.game_state.get_job_state() or self.game_state.get_combat_state():
            QMessageBox.information(self, "Cannot travel", "You are busy and cannot begin another trip right now.")
            return

        home_region_key = self.game_state.load_home_plot().get("region_key", "millhaven_county")
        walking_seconds = travel_seconds(current, destination, "Walking", home_region_key)

        dialog = QDialog(self)
        dialog.setWindowTitle("Travel")
        dialog.setModal(True)
        if not IS_ANDROID:
            dialog.setMinimumWidth(430)
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(14 if IS_ANDROID else 22, 14 if IS_ANDROID else 20, 14 if IS_ANDROID else 22, 14 if IS_ANDROID else 20)
        layout.setSpacing(10)

        title = QLabel(f"Travel to {destination_title}?")
        title.setStyleSheet("font-size: 19px; font-weight: 800; color: #fff5e3;")
        layout.addWidget(title)

        info = QLabel(f"Walking will take about {walking_seconds} seconds.\nChoose how you want to travel.")
        info.setObjectName("Muted")
        info.setWordWrap(True)
        layout.addWidget(info)

        methods = []
        home_region_key = self.game_state.load_home_plot().get("region_key", "millhaven_county")
        vehicles_here = self.game_state.load_vehicles()
        for method in self.game_state.available_travel_methods():
            if not method_allowed_on_route(current, destination, method):
                continue
            if method not in {"Walking", "Horse", "Bicycle", "Rowboat"}:
                required_fuel = route_fuel_units(current, destination, method, home_region_key)
                usable = any(
                    vehicle["current_location"] == current
                    and vehicle["method"] == method
                    and int(vehicle["condition_percent"]) > 0
                    and int(vehicle["fuel"]) >= required_fuel
                    for vehicle in vehicles_here
                )
                if not usable:
                    continue
            methods.append(method)
        if "Walking" not in methods:
            methods.insert(0, "Walking")

        for method in methods:
            button = QPushButton(self.travel_choice_label(method, destination))
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.clicked.connect(lambda checked=False, m=method: self.confirm_travel_choice(dialog, destination, m))
            layout.addWidget(button)

        cancel = QPushButton("Cancel")
        cancel.setObjectName("NavUtility")
        cancel.clicked.connect(dialog.reject)
        layout.addWidget(cancel)
        dialog.exec()

    def confirm_travel_choice(self, dialog: QDialog, destination: str, method: str) -> None:
        dialog.accept()
        self.begin_travel(destination, method)

    def render_employment(self, character, job_state: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.employment_layout
        self.clear_layout(layout)
        current = normalize_location_key(character.current_location)
        location = LOCATIONS.get(current)
        self.add_heading(layout, f"{location.name.upper() if location else 'REGIONAL'} EMPLOYMENT")
        career_button = QPushButton("FULL-TIME CAREERS")
        career_button.clicked.connect(lambda: self.show_page("career"))
        layout.addWidget(career_button)

        if job_state:
            job = JOBS[job_state["job_key"]]
            self.add_body(layout, f"CURRENT SHIFT\n\n{job.name}\n{job.description}")
            self.job_progress = QProgressBar()
            self.job_progress.setRange(0, job_state["duration_seconds"])
            self.job_remaining_label = QLabel()
            layout.addWidget(self.job_progress)
            layout.addWidget(self.job_remaining_label)
            self.update_activity_widgets()
            self.add_body(layout, "The shift continues even if you browse another menu or close the game.", muted=True)
            layout.addStretch()
            return

        jobs_here = [job for job in JOBS.values() if job.location_key == current]
        if not jobs_here:
            self.add_body(layout, "There is no public job board at this location.", muted=True)
            back = QPushButton("BACK TO LOCATION")
            back.clicked.connect(lambda: self.show_page("location"))
            layout.addWidget(back)
            layout.addStretch()
            return

        self.add_body(layout, "AVAILABLE WORK")
        for job in jobs_here:
            body = (
                f"{job.description}\n\nPay: ${job.pay}\nStamina: {job.stamina_cost}\n"
                f"Real timer: {job.duration_seconds} sec\nWork XP: +{job.work_xp}\n"
                f"City reputation: +1"
            )
            if job.skill_name and job.skill_xp:
                body += f"\n{job.skill_name} XP: +{job.skill_xp}"
            if job.requires_motor_vehicle:
                body += "\nRequires: usable motor vehicle at this location"
            self.add_card(
                layout,
                job.name,
                body,
                "WORK",
                lambda checked=False, key=job.key: self.begin_job(key),
                enabled=not travel and not combat and character.stamina >= job.stamina_cost,
            )
        back = QPushButton("BACK TO LOCATION")
        back.clicked.connect(lambda: self.show_page("location"))
        layout.addWidget(back)
        layout.addStretch()

    def render_store(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.store_layout
        self.clear_layout(layout)
        current = normalize_location_key(character.current_location)
        title = "GENERAL MARKET" if current != "millhaven" else "MILLHAVEN GENERAL STORE"
        self.add_heading(layout, title)
        if current not in {"millhaven", "redwater", "lake_mercy", "greybridge_city", "hollow_creek", "pine_ridge", "westhaven"}:
            self.add_body(layout, "There is no general market at your current location.")
            back = QPushButton("BACK TO LOCATION")
            back.clicked.connect(lambda: self.show_page("location"))
            layout.addWidget(back)
            layout.addStretch()
            return
        self.add_body(layout, f"Cash: ${character.cash}")
        for item in STORE_ITEMS:
            self.add_card(
                layout,
                item.name,
                f"{item.description}\n\nPrice: ${item.price}",
                "BUY",
                lambda checked=False, name=item.name: self.buy_item(name),
                enabled=not travel and not job and not combat and character.cash >= item.price,
            )
        if current == "millhaven":
            profile = self.game_state.get_crime_profile()
            mask_text = "Mask worn" if profile["mask_worn"] else "No mask worn"
            self.add_card(
                layout,
                "CRIMINAL ACTION",
                f"Rob the General Store and attempt to escape with the register cash.\n{mask_text}.",
                "ROB GENERAL STORE",
                lambda checked=False: self.commit_crime("store_robbery"),
                enabled=not travel and not job and not combat and not self.game_state.get_jail_state() and character.stamina >= CRIMES["store_robbery"].stamina_cost,
            )

        regional_prices = {"Lake Perch": 6, "Rainbow Trout": 10, "Lake Whitefish": 14, "Scrap Metal": 4, "Machine Parts": 9, "Wire Bundle": 6}
        goods = [item for item in self.game_state.load_inventory() if item["item_name"] in regional_prices]
        if goods and current in {"lake_mercy", "redwater", "greybridge_city", "westhaven", "millhaven"}:
            self.add_body(layout, "SELL REGIONAL GOODS")
            for item in goods:
                self.add_card(
                    layout,
                    f"{item['item_name']}  x{item['quantity']}",
                    f"{item['description']}\n\nSale price: ${regional_prices[item['item_name']]} each",
                    "SELL ONE",
                    lambda checked=False, name=item["item_name"]: self.sell_regional_item(name),
                    enabled=not travel and not job and not combat,
                )
        layout.addStretch()

    def render_furniture_store(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.furniture_store_layout
        self.clear_layout(layout)
        self.add_heading(layout, "MILLHAVEN FURNISHINGS")
        if normalize_location_key(character.current_location) != "millhaven":
            self.add_body(layout, "You are not at Main Street.")
            back = QPushButton("BACK TO LOCATION")
            back.clicked.connect(lambda: self.show_page("location"))
            layout.addWidget(back)
            layout.addStretch()
            return
        self.add_body(layout, f"Cash: ${character.cash}")
        self.add_body(layout, "Purchased furniture is carried in your inventory until it is placed in a room at your property.", muted=True)
        for item in FURNITURE_STORE:
            bonuses = []
            if item.storage_capacity:
                bonuses.append(f"Storage +{item.storage_capacity}")
            if item.comfort:
                bonuses.append(f"Comfort +{item.comfort}")
            if item.rest_hp_bonus or item.rest_stamina_bonus:
                bonuses.append(f"Rest +{item.rest_hp_bonus} HP / +{item.rest_stamina_bonus} stamina")
            body = f"{item.description}\n\nPrice: ${item.price}"
            if bonuses:
                body += "\n" + " • ".join(bonuses)
            self.add_card(
                layout,
                item.name,
                body,
                "BUY",
                lambda checked=False, name=item.name: self.buy_furniture(name),
                enabled=not travel and not job and not combat and character.cash >= item.price,
            )
        layout.addStretch()

    def render_farm_store(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.farm_store_layout
        self.clear_layout(layout)
        current = normalize_location_key(character.current_location)
        self.add_heading(layout, "FARM SUPPLY MARKET")
        if current not in {"millhaven", "lake_mercy", "hollow_creek"}:
            self.add_body(layout, "There is no farm supply market at your current location.")
            back = QPushButton("BACK TO LOCATION")
            back.clicked.connect(lambda: self.show_page("location"))
            layout.addWidget(back)
            layout.addStretch()
            return

        self.add_body(layout, f"Cash: ${character.cash}")
        self.add_body(layout, "SEEDS")
        for crop in CROPS.values():
            body = (
                f"{crop.description}\n\nPrice: ${crop.seed_price}\n"
                f"Growth time: {crop.grow_seconds} sec\nExpected harvest: {crop.min_yield}-{crop.max_yield}"
            )
            self.add_card(
                layout,
                crop.seed_item,
                body,
                "BUY",
                lambda checked=False, name=crop.seed_item: self.buy_seed(name),
                enabled=not travel and not job and not combat and character.cash >= crop.seed_price,
            )

        self.add_body(layout, "LIVESTOCK FEED")
        self.add_card(
            layout,
            FEED_SACK_NAME,
            f"{FEED_SACK_DESCRIPTION}\n\nPrice: ${FEED_SACK_PRICE}\nFeed: +{FEED_SACK_PORTIONS} portions",
            "BUY & DELIVER",
            self.buy_feed_sack,
            enabled=not travel and not job and not combat and character.cash >= FEED_SACK_PRICE,
        )

        self.add_body(layout, "LIVESTOCK")
        for animal in ANIMALS.values():
            capacity = self.game_state.animal_capacity(animal.key)
            housing_used = self.game_state.animal_housing_used(animal.key)
            owned = self.game_state.animal_count(animal.key)
            required = STRUCTURES[animal.required_structure].name
            if animal.product_item:
                production = f"Produces: {animal.product_item}\nProduction cycle: {animal.production_seconds} sec\n"
            elif animal.rideable:
                production = "Use: Rideable transportation\n"
            else:
                production = ""
            body = (
                f"{animal.description}\n\nPrice: ${animal.price}\n"
                f"{production}Housing: {required}\nOwned: {owned}\nHousing used: {housing_used}/{capacity}"
            )
            self.add_card(
                layout,
                animal.name,
                body,
                "BUY",
                lambda checked=False, key=animal.key: self.buy_animal(key),
                enabled=(
                    not travel and not job and not combat and character.cash >= animal.price
                    and capacity > housing_used
                ),
            )

        inventory = self.game_state.load_inventory()
        produce = [item for item in inventory if item["item_name"] in PRODUCE_ITEMS]
        self.add_body(layout, "SELL PRODUCE")
        if not produce:
            self.add_body(layout, "You do not have any harvested produce to sell.", muted=True)
        for item in produce:
            crop = PRODUCE_ITEMS[item["item_name"]]
            self.add_card(
                layout,
                f"{item['item_name']}  x{item['quantity']}",
                f"{item['description']}\n\nSale price: ${max(1, math.ceil(crop.sale_price * produce_sale_multiplier(character.day)))} each",
                "SELL ONE",
                lambda checked=False, name=item["item_name"]: self.sell_produce(name),
                enabled=not travel and not job and not combat,
            )

        products = [item for item in inventory if item["item_name"] in ANIMAL_PRODUCTS]
        self.add_body(layout, "SELL LIVESTOCK PRODUCTS")
        if not products:
            self.add_body(layout, "You do not have any livestock products to sell.", muted=True)
        for item in products:
            animal = ANIMAL_PRODUCTS[item["item_name"]]
            self.add_card(
                layout,
                f"{item['item_name']}  x{item['quantity']}",
                f"{item['description']}\n\nSale price: ${animal.product_sale_price} each",
                "SELL ONE",
                lambda checked=False, name=item["item_name"]: self.sell_animal_product(name),
                enabled=not travel and not job and not combat,
            )
        layout.addStretch()

    def render_diner(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.diner_layout
        self.clear_layout(layout)
        current = normalize_location_key(character.current_location)
        self.add_heading(layout, "DINER / CAFE")
        if current not in {"millhaven", "redwater", "lake_mercy", "greybridge_city", "hollow_creek", "pine_ridge", "westhaven"}:
            self.add_body(layout, "There is no diner or cafe at your current location.")
            layout.addStretch()
            return
        event = daily_event(character.day)
        discount = diner_discount(character.day) if current == "millhaven" else 0
        self.add_body(layout, "A local place serving simple prepared meals and hot drinks throughout the day.")
        if discount:
            self.add_body(layout, f"{event.name}: meals cost ${discount} less today.", muted=True)
        for meal in DINER_MEALS:
            price = max(1, meal.price - discount)
            body = (
                f"{meal.description}\n\nPrice: ${price}\n"
                f"Restores up to {meal.hp_restore} HP and {meal.stamina_restore} stamina.\n"
                f"Time: {meal.game_minutes} minutes"
            )
            self.add_card(
                layout, meal.name, body, "ORDER & EAT",
                lambda checked=False, key=meal.key: self.eat_diner_meal(key),
                enabled=not job and not travel and not combat and character.cash >= price,
            )
        back = QPushButton("BACK TO LOCATION")
        back.clicked.connect(lambda: self.show_page("location"))
        layout.addWidget(back)
        layout.addStretch()

    def render_clinic(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.clinic_layout
        self.clear_layout(layout)
        current = normalize_location_key(character.current_location)
        heading = "GREYBRIDGE CENTRAL HOSPITAL" if current == "greybridge_city" else "MEDICAL SERVICES"
        self.add_heading(layout, heading)
        if current not in {"millhaven", "redwater", "lake_mercy", "greybridge_city", "hollow_creek", "pine_ridge", "westhaven"}:
            self.add_body(layout, "There are no medical services at your current location.")
            layout.addStretch()
            return
        price = clinic_price(character.day)
        if current == "greybridge_city":
            self.add_body(layout, "A large city hospital with emergency, inpatient, and outpatient services.")
        else:
            self.add_body(layout, "A local medical facility providing basic treatment and scheduled care.")
        self.add_card(
            layout,
            "Basic Treatment",
            f"Treat current injuries and restore HP to full.\n\nCost: ${price}\nTime: 45 minutes",
            "RECEIVE TREATMENT",
            self.receive_clinic_treatment,
            enabled=not job and not travel and not combat and character.hp < character.max_hp and character.cash >= price,
        )
        vice = self.game_state.get_vice_profile()
        dependence_total = int(vice["alcohol_dependence"]) + int(vice["drug_dependence"])
        self.add_card(
            layout,
            "Dependence Treatment",
            "A supervised three-hour treatment session reduces alcohol, drug, and gambling dependence and clears current intoxication/effects.\n\nCost: $75",
            "BEGIN TREATMENT",
            self.detox_treatment,
            enabled=not job and not travel and not combat and dependence_total > 0 and character.cash >= 75,
        )
        back = QPushButton("BACK TO LOCATION")
        back.clicked.connect(lambda: self.show_page("location"))
        layout.addWidget(back)
        layout.addStretch()

    def render_park(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.park_layout
        self.clear_layout(layout)
        self.add_heading(layout, "RIVER PARK")
        if normalize_location_key(character.current_location) != "millhaven":
            self.add_body(layout, "You are not at Main Street.")
            layout.addStretch()
            return
        self.add_body(layout, "A narrow public park follows the river behind Main Street. Benches sit beneath old trees beside a gravel walking path.")
        self.add_card(
            layout,
            "Sit by the River",
            "Spend half an hour resting away from work and traffic. This can restore up to 2 stamina once per in-game day.",
            "REST 30 MINUTES",
            self.rest_at_park,
            enabled=not job and not travel and not combat,
        )
        back = QPushButton("BACK TO LOCATION")
        back.clicked.connect(lambda: self.show_page("location"))
        layout.addWidget(back)
        layout.addStretch()

    def render_community(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.community_layout
        self.clear_layout(layout)
        self.add_heading(layout, "COMMUNITY HALL")
        if normalize_location_key(character.current_location) != "millhaven":
            self.add_body(layout, "You are not at Main Street.")
            layout.addStretch()
            return
        event = self.game_state.current_daily_event()
        self.add_card(layout, event["name"], event["description"] + "\n\n" + event["modifier_text"])
        self.add_card(
            layout,
            "Spend Time at the Hall",
            "Stay for forty-five minutes, speak with residents, and follow the day's notices. Grants 1 Speech XP once per in-game day.",
            "ATTEND",
            self.attend_community_hall,
            enabled=not job and not travel and not combat,
        )
        back = QPushButton("BACK TO LOCATION")
        back.clicked.connect(lambda: self.show_page("location"))
        layout.addWidget(back)
        layout.addStretch()

    def render_mail(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.mail_layout
        self.clear_layout(layout)
        self.add_heading(layout, "MAILBOX")
        if normalize_location_key(character.current_location) != "home":
            self.add_body(layout, "Your mailbox is at your property.")
            layout.addStretch()
            return
        letters = self.game_state.load_mail()
        if not letters:
            self.add_body(layout, "The mailbox is empty.", muted=True)
        for letter in letters:
            status = "UNREAD" if not letter["is_read"] else "READ"
            self.add_card(
                layout,
                f"{letter['subject']}  •  {status}",
                f"From: {letter['sender']}\nDay {letter['sent_day']}\n\n{letter['body']}",
                None if letter["is_read"] else "MARK READ",
                None if letter["is_read"] else (lambda checked=False, mid=letter["id"]: self.read_mail(mid)),
                enabled=not combat,
            )
        back = QPushButton("BACK TO PROPERTY")
        back.clicked.connect(lambda: self.show_page("location"))
        layout.addWidget(back)
        layout.addStretch()

    def render_cooking(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.cooking_layout
        self.clear_layout(layout)
        self.add_heading(layout, "COOKING")
        if normalize_location_key(character.current_location) != "home":
            self.add_body(layout, "You need to be at your property to cook.")
            layout.addStretch()
            return
        if not self.game_state.can_cook_at_home():
            self.add_body(layout, "Build a Fire Pit, Wooden Shack, or Small Cabin to prepare cooked meals.")
            layout.addStretch()
            return
        inventory = {item["item_name"]: item["quantity"] for item in self.game_state.load_inventory()}
        self.add_body(layout, "RECIPES")
        for recipe in RECIPES.values():
            ingredients = ", ".join(f"{name} x{qty}" for name, qty in recipe.ingredients)
            can_make = all(inventory.get(name, 0) >= qty for name, qty in recipe.ingredients)
            body = (
                f"{recipe.description}\n\nIngredients: {ingredients}\n"
                f"Restores up to {recipe.hp_restore} HP and {recipe.stamina_restore} stamina.\n"
                f"Time: {recipe.game_minutes} minutes"
            )
            self.add_card(
                layout, recipe.name, body, "COOK",
                lambda checked=False, key=recipe.key: self.cook_recipe(key),
                enabled=not job and not travel and not combat and can_make,
            )
        back = QPushButton("BACK TO PROPERTY")
        back.clicked.connect(lambda: self.show_page("location"))
        layout.addWidget(back)
        layout.addStretch()

    def render_business(self, character, job: dict | None, travel: dict | None, combat: dict | None) -> None:
        layout = self.business_layout
        self.clear_layout(layout)
        if self.selected_business_id is None:
            self.add_heading(layout, "BUSINESS")
            self.add_body(layout, "Select a business from the Property screen.", muted=True)
            layout.addStretch()
            return
        try:
            business = self.game_state.get_business(self.selected_business_id)
        except RuntimeError:
            self.selected_business_id = None
            self.add_heading(layout, "BUSINESS")
            self.add_body(layout, "This business is no longer available.", muted=True)
            layout.addStretch()
            return
        self.add_heading(layout, business["business_name"].upper())
        self.add_body(layout, business["description"])
        self.add_body(
            layout,
            f"Status: {'OPEN' if business['is_open'] else 'CLOSED'}\n"
            f"Pricing: {PRICE_TIERS[business['price_tier']]['label']}\n"
            f"Till: ${business['till']}\nLifetime revenue: ${business['lifetime_revenue']}\n"
            f"Customers served: {business['customers_served']}",
        )
        toggle = QPushButton("CLOSE BUSINESS" if business["is_open"] else "OPEN BUSINESS")
        toggle.setEnabled(not travel and not job and not combat)
        toggle.clicked.connect(lambda: self.toggle_business(business["id"], not bool(business["is_open"])))
        layout.addWidget(toggle)
        collect = QPushButton(f"COLLECT TILL  •  ${business['till']}")
        collect.setEnabled(business["till"] > 0 and normalize_location_key(character.current_location) == "home" and not travel and not job and not combat)
        collect.clicked.connect(lambda: self.collect_business_till(business["id"]))
        layout.addWidget(collect)

        self.add_body(layout, "PRICING")
        for tier_key, tier in PRICE_TIERS.items():
            button = QPushButton(f"{tier['label'].upper()}  •  {round(tier['multiplier'] * 100)}% PRICE")
            button.setEnabled(tier_key != business["price_tier"] and not travel and not job and not combat)
            button.clicked.connect(lambda checked=False, key=tier_key, bid=business["id"]: self.set_business_price(bid, key))
            layout.addWidget(button)

        self.add_body(layout, "STOCK")
        if not business["stock"]:
            self.add_body(layout, "No stock is currently available for sale.", muted=True)
        for item in business["stock"]:
            tier = PRICE_TIERS[business["price_tier"]]
            sale = max(1, round(item["base_price"] * tier["multiplier"]))
            self.add_card(layout, f"{item['item_name']}  x{item['quantity']}", f"{item['description']}\nCurrent sale price: ${sale}")

        visits = self.game_state.recent_business_visits(business["id"], 6)
        if visits:
            self.add_body(layout, "RECENT CUSTOMERS")
            for visit in visits:
                self.add_body(
                    layout,
                    f"{visit['npc_name']} purchased {visit['item_name']} for ${visit['sale_price']}.",
                    muted=True,
                )

        if business["wholesale"]:
            self.add_body(layout, "WHOLESALE STOCK")
            for item in business["wholesale"]:
                self.add_card(
                    layout,
                    item.name,
                    f"{item.description}\n\nOrder: 5 units for ${item.cost * 5}\nBase sale price: ${item.base_price}",
                    "ORDER 5",
                    lambda checked=False, bid=business["id"], name=item.name: self.buy_business_stock(bid, name),
                    enabled=not travel and not job and not combat and character.cash >= item.cost * 5,
                )

        if business["stockable_inventory"]:
            self.add_body(layout, "STOCK FROM INVENTORY")
            for item in business["stockable_inventory"]:
                self.add_card(
                    layout,
                    f"{item['item_name']}  x{item['quantity']}",
                    item["description"],
                    "STOCK ONE",
                    lambda checked=False, bid=business["id"], name=item["item_name"]: self.stock_business_item(bid, name),
                    enabled=normalize_location_key(character.current_location) == "home" and not travel and not job and not combat,
                )
        self.add_body(layout, "Open businesses continue serving customers while you travel or close the game, provided they have stock.", muted=True)
        back = QPushButton("BACK TO PROPERTY")
        back.clicked.connect(lambda: self.show_page("property"))
        layout.addWidget(back)
        layout.addStretch()

    def render_crime(self, character, job: dict | None, travel: dict | None, combat: dict | None, jail: dict | None) -> None:
        layout = self.crime_layout
        self.clear_layout(layout)
        self.add_heading(layout, "CRIME")
        profile = self.game_state.get_crime_profile()
        self.add_body(
            layout,
            f"Heat: {profile['heat']} / 100 — {profile['heat_label']}\n"
            f"Crimes committed: {profile['crimes_committed']}\n"
            f"Arrests: {profile['arrests']}\n"
            f"Murders: {profile['murders']}",
        )
        if profile["has_mask"]:
            mask_state = "WORN" if profile["mask_worn"] else "NOT WORN"
            self.add_card(
                layout,
                MASK_NAME,
                f"{MASK_DESCRIPTION}\n\nStatus: {mask_state}",
                "REMOVE MASK" if profile["mask_worn"] else "WEAR MASK",
                self.toggle_mask,
                enabled=not jail,
            )
        else:
            self.add_body(layout, "You do not own a mask. The Grey Lantern sells a simple face covering.", muted=True)

        if jail:
            self.add_card(layout, "IN CUSTODY", f"You are serving a sentence for {jail['reason']}. Criminal actions are unavailable until release.")
        else:
            self.add_body(layout, "AVAILABLE ACTIONS")
            for crime in self.game_state.available_crimes():
                body = (
                    f"{crime['description']}\n\nStamina: {crime['stamina_cost']}  •  Base heat: +{crime['heat_gain']}"
                )
                if crime["reason"]:
                    body += f"\n{crime['reason']}"
                self.add_card(
                    layout,
                    crime["name"],
                    body,
                    "ATTEMPT",
                    lambda checked=False, key=crime["key"]: self.commit_crime(key),
                    enabled=crime["available"] and not travel and not job and not combat,
                )

        cases = self.game_state.court_cases()
        if cases:
            self.add_body(layout, "COURT CASES")
            for case in cases[:8]:
                body = f"Filed Day {case['filed_day']}\nStatus: {case['status']}"
                if case['outcome']:
                    body += f"\n{case['outcome']}"
                self.add_card(
                    layout, case['charge'], body,
                    "ATTEND HEARING" if case['status'] == 'Pending' else None,
                    (lambda checked=False, cid=case['id']: self.attend_court(cid)) if case['status'] == 'Pending' else None,
                    enabled=case['status'] == 'Pending' and not jail and not travel and not job and not combat and normalize_location_key(character.current_location) in {"millhaven", "greybridge_city"},
                )

        self.add_body(layout, "RECENT RECORD")
        if profile["record"]:
            for entry in profile["record"]:
                cash_text = f"${entry['cash_change']:+d}" if entry["cash_change"] else "$0"
                self.add_card(
                    layout,
                    f"Day {entry['day']} — {entry['crime_name']}",
                    f"{entry['outcome']}\nCash change: {cash_text}  •  Heat: +{entry['heat_change']}",
                )
        else:
            self.add_body(layout, "No criminal record.", muted=True)
        layout.addStretch()

    def render_vice(self, character, job: dict | None, travel: dict | None, combat: dict | None, jail: dict | None) -> None:
        layout = self.vice_layout
        self.clear_layout(layout)
        self.add_heading(layout, "VICE")
        profile = self.game_state.get_vice_profile()
        self.add_body(
            layout,
            f"Alcohol: {profile['intoxication_label']}  •  Intoxication {profile['intoxication']}/100\n"
            f"Alcohol dependence: {profile['alcohol_dependence_label']}  •  {profile['alcohol_dependence']}/100\n\n"
            f"Drug effect: {profile['drug_effect_label']}  •  {profile['drug_effect']}/100\n"
            f"Drug dependence: {profile['drug_dependence_label']}  •  {profile['drug_dependence']}/100\n\n"
            f"Gambling dependence: {profile['gambling_dependence_label']}  •  {profile['gambling_dependence']}/100",
        )
        if profile["gambling_urge"]:
            self.add_card(
                layout,
                "GAMBLING URGE",
                "Gambling dependence is producing a recurring stress penalty while you abstain. This affects stamina rather than HP. The Clinic offers dependence treatment.",
            )

        if profile["alcohol_withdrawal"] or profile["drug_withdrawal"]:
            parts = []
            if profile["alcohol_withdrawal"]:
                parts.append("alcohol")
            if profile["drug_withdrawal"]:
                parts.append("drug")
            self.add_card(
                layout,
                "WITHDRAWAL",
                f"Dependence is producing {' and '.join(parts)} withdrawal effects. Untreated withdrawal causes a daily HP and stamina penalty. The Clinic offers dependence treatment.",
            )

        if profile["dealer_started"]:
            stock = self.game_state.dealer_stock()
            stock_text = "\n".join(f"{name}: {qty}" for name, qty in stock.items())
            self.add_card(
                layout,
                "DEALING OPERATION",
                f"Tier: {profile['dealer_tier']}\nReputation: {profile['dealer_reputation']}\n\nCurrent stock:\n{stock_text}",
            )
            if normalize_location_key(character.current_location) == "home":
                rep = int(profile["dealer_reputation"])
                batch = 3 if rep < 55 else 5 if rep < 110 else 8
                cost = 25 if batch == 3 else 40 if batch == 5 else 60
                self.add_card(
                    layout,
                    "MAKE DRUGS",
                    f"Run one abstract production cycle at your property. Generic operating supplies are consumed; no ingredients or recipe are modeled.\n\nOutput: {batch} Drugs\nCost: ${cost}\nTime: 90 in-game minutes\nStamina: 3",
                    "MAKE DRUGS",
                    self.make_drugs,
                    enabled=not job and not travel and not combat and not jail and character.cash >= cost and character.stamina >= 3,
                )

        inventory = {row["item_name"]: int(row["quantity"]) for row in self.game_state.load_inventory()}
        usable = []
        for item in list(ALCOHOL_ITEMS.values()) + list(DRUG_ITEMS.values()):
            qty = inventory.get(item.name, 0)
            if qty:
                usable.append((item, qty))
        if usable:
            self.add_body(layout, "ON HAND")
            for item, qty in usable:
                self.add_card(
                    layout,
                    f"{item.name}  x{qty}",
                    item.description,
                    "USE",
                    lambda checked=False, name=item.name: self.use_vice_item(name),
                    enabled=not job and not travel and not combat and not jail,
                )
        else:
            self.add_body(layout, "You are not carrying alcohol or drugs.", muted=True)

        self.add_body(layout, "RECENT HISTORY")
        if profile["record"]:
            for entry in profile["record"]:
                money = f"  •  Cash ${entry['cash_change']:+d}" if entry["cash_change"] else ""
                self.add_card(layout, f"Day {entry['day']} — {entry['event_type']}", entry["description"] + money)
        else:
            self.add_body(layout, "No vice history recorded.", muted=True)
        layout.addStretch()

    def render_casino(self, character, job: dict | None, travel: dict | None, combat: dict | None, jail: dict | None) -> None:
        layout = self.casino_layout
        self.clear_layout(layout)
        current = normalize_location_key(character.current_location)
        heading = "GREYBRIDGE GRAND CASINO" if current == "greybridge_city" else "WESTHAVEN CASINO" if current == "westhaven" else "MILLHAVEN CASINO"
        self.add_heading(layout, heading)
        if current not in {"millhaven", "greybridge_city", "westhaven"} or jail:
            self.add_body(layout, "You are not able to use a casino from your current location.")
            back = QPushButton("BACK TO LOCATION")
            back.clicked.connect(lambda: self.show_page("location"))
            layout.addWidget(back)
            layout.addStretch()
            return
        if current == "greybridge_city":
            self.add_body(layout, "A large city casino with slot machines, card tables, and a dedicated roulette floor.")
        elif current == "westhaven":
            self.add_body(layout, "A waterfront casino serving travellers, port workers, and local residents.")
        else:
            self.add_body(layout, "A compact casino near the highway with a small gaming floor, card tables, and a roulette pit.")
        stats = self.game_state.casino_profile()
        self.add_body(layout, f"Casino record: {stats['wins']} wins  •  {stats['losses']} losses  •  Net ${stats['net']:+d}", muted=True)

        self.add_body(layout, f"CURRENT WAGER: ${self.casino_wager}")
        wager_row = QHBoxLayout()
        for amount in (5, 10, 25, 50):
            button = QPushButton(f"${amount}")
            button.setCheckable(True)
            button.setChecked(self.casino_wager == amount)
            button.clicked.connect(lambda checked=False, value=amount: self.set_casino_wager(value))
            wager_row.addWidget(button)
        layout.addLayout(wager_row)

        busy = bool(job or travel or combat)
        blackjack = self.game_state.get_blackjack_state()
        if blackjack:
            dealer_visible = blackjack["dealer_cards"][0] if blackjack["dealer_cards"] else ""
            self.add_card(
                layout,
                "BLACKJACK — HAND IN PROGRESS",
                f"Wager: ${blackjack['wager']}\n"
                f"Your cards: {'  '.join(blackjack['player_cards'])}  •  Score {blackjack['player_score']}\n"
                f"Dealer: {dealer_visible}  ??",
            )
            row = QHBoxLayout()
            hit = QPushButton("HIT")
            hit.clicked.connect(self.blackjack_hit)
            stand = QPushButton("STAND")
            stand.clicked.connect(self.blackjack_stand)
            row.addWidget(hit)
            row.addWidget(stand)
            layout.addLayout(row)
        else:
            self.add_card(
                layout,
                "SLOT MACHINE",
                "Three reels. Three matching symbols pay 8× the wager. Two matching symbols return a smaller payout.",
                "SPIN",
                self.play_slots,
                enabled=not busy and character.cash >= self.casino_wager,
            )
            self.add_card(
                layout,
                "BLACKJACK",
                "Start a standard blackjack hand. Hit or stand while the dealer draws to 17. A natural blackjack pays 3:2.",
                "DEAL HAND",
                self.blackjack_start,
                enabled=not busy and character.cash >= self.casino_wager,
            )
            self.add_body(layout, "ROULETTE")
            roulette_row = QHBoxLayout()
            for label, bet in (("RED", "red"), ("BLACK", "black"), ("ODD", "odd"), ("EVEN", "even")):
                button = QPushButton(label)
                button.setEnabled(not busy and character.cash >= self.casino_wager)
                button.clicked.connect(lambda checked=False, b=bet: self.play_roulette(b))
                roulette_row.addWidget(button)
            layout.addLayout(roulette_row)
            number_button = QPushButton("BET SINGLE NUMBER 0–36")
            number_button.setEnabled(not busy and character.cash >= self.casino_wager)
            number_button.clicked.connect(self.play_roulette_number)
            layout.addWidget(number_button)

        back = QPushButton("BACK TO LOCATION")
        back.clicked.connect(lambda: self.show_page("location"))
        layout.addWidget(back)
        layout.addStretch()

    def render_shady_bar(self, character, job: dict | None, travel: dict | None, combat: dict | None, jail: dict | None) -> None:
        layout = self.shady_bar_layout
        self.clear_layout(layout)
        self.add_heading(layout, "THE GREY LANTERN")
        if normalize_location_key(character.current_location) != "millhaven" or jail:
            self.add_body(layout, "You are not able to enter the bar from your current location.")
            back = QPushButton("BACK TO LOCATION")
            back.clicked.connect(lambda: self.show_page("location"))
            layout.addWidget(back)
            layout.addStretch()
            return
        self.add_body(layout, "A narrow bar on a side street in Dong. The front room is dim, and private business is conducted in a small back room away from the main counter.")

        self.add_body(layout, "BAR")
        for item in ALCOHOL_ITEMS.values():
            self.add_card(
                layout,
                item.name,
                f"{item.description}\n\nPrice: ${item.price}",
                "BUY",
                lambda checked=False, key=item.key: self.buy_vice_item(key),
                enabled=not travel and not job and not combat and character.cash >= item.price,
            )

        vice = self.game_state.get_vice_profile()
        self.add_body(layout, "DARIUS VALE")
        self.add_body(layout, "Darius keeps drugs out of sight and sells only generic quantities. The trade is illegal and adds risk to an active criminal record.", muted=True)
        for item in DRUG_ITEMS.values():
            self.add_card(
                layout,
                item.name,
                f"{item.description}\n\nPrice: ${item.price}",
                "BUY ONE",
                lambda checked=False, key=item.key: self.buy_vice_item(key),
                enabled=not travel and not job and not combat and character.cash >= item.price,
            )

        if not vice["dealer_started"]:
            self.add_card(
                layout,
                "START DEALING OPERATION",
                "Darius can introduce you to a small drug-dealing operation. This requires Crime level 1 and $100 in starting cash. Production and distribution remain abstract: the game tracks stock, sales, heat, arrests, and reputation without modeling real substances, ingredients, or trafficking procedures.",
                "START OPERATION",
                self.start_dealer_operation,
                enabled=not travel and not job and not combat and character.cash >= 100,
            )
        else:
            self.add_body(layout, f"DEALING — {vice['dealer_tier'].upper()}  •  Reputation {vice['dealer_reputation']}")
            stock = self.game_state.dealer_stock()
            for item in DRUG_ITEMS.values():
                wholesale = max(1, int(round(item.price * 0.62))) * 5
                self.add_card(
                    layout,
                    f"{item.name}  •  Stock {stock.get(item.name, 0)}",
                    f"Buy 5 units for ${wholesale}. Street sales are resolved abstractly and increase Crime/Vice progression and Heat.",
                    "BUY 5 STOCK",
                    lambda checked=False, key=item.key: self.buy_dealer_stock(key),
                    enabled=not travel and not job and not combat and character.cash >= wholesale,
                )
                self.add_card(
                    layout,
                    f"SELL {item.name}",
                    "Attempt one street sale from current stock.",
                    "SELL ONE",
                    lambda checked=False, key=item.key: self.dealer_sale(key, 1),
                    enabled=not travel and not job and not combat and stock.get(item.name, 0) >= 1,
                )
                if int(vice["dealer_reputation"]) >= 20:
                    self.add_card(
                        layout,
                        f"MOVE {item.name} BATCH",
                        "Attempt to move a five-unit batch. Larger sales pay more and create substantially more risk and Heat.",
                        "SELL FIVE",
                        lambda checked=False, key=item.key: self.dealer_sale(key, 5),
                        enabled=not travel and not job and not combat and stock.get(item.name, 0) >= 5,
                    )

        profile = self.game_state.get_crime_profile()
        if not profile["has_mask"]:
            self.add_card(
                layout,
                MASK_NAME,
                f"{MASK_DESCRIPTION}\n\nPrice: ${MASK_PRICE}",
                "BUY MASK",
                self.buy_mask,
                enabled=not travel and not job and not combat and character.cash >= MASK_PRICE,
            )
        self.add_body(layout, "CRIMINAL WORK")
        for crime_job in self.game_state.crime_jobs():
            self.add_card(
                layout,
                crime_job["name"],
                f"{crime_job['description']}\n\nPay: ${crime_job['payout']}  •  Stamina: {crime_job['stamina_cost']}  •  Base heat: +{crime_job['heat_gain']}",
                "TAKE JOB",
                lambda checked=False, key=crime_job["key"]: self.take_crime_job(key),
                enabled=crime_job["available"] and not travel and not job and not combat,
            )
        back = QPushButton("BACK TO LOCATION")
        back.clicked.connect(lambda: self.show_page("location"))
        layout.addWidget(back)
        layout.addStretch()

    def hunt_game(self) -> None:
        try:
            result = self.game_state.hunt()
            self.set_notice(result["text"], 6000)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Hunting", str(exc))
        self.refresh_all()

    def camp_wilderness(self) -> None:
        try:
            result = self.game_state.camp_wilderness()
            self.set_notice(result["text"], 6000)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Camping", str(exc))
        self.refresh_all()

    def enroll_education(self, program_key: str) -> None:
        try:
            self.game_state.enroll_education(program_key)
            self.set_notice("Enrollment completed.")
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Education", str(exc))
        self.refresh_all(); self.show_page("education")

    def study_education(self) -> None:
        try:
            result = self.game_state.study_education()
            self.set_notice(f"{result['name']}: {result['completed']}/{result['sessions']} sessions complete." + (f" Certificate earned: {result['certificate']}." if result['finished'] else ""), 6000)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Education", str(exc))
        self.refresh_all(); self.show_page("education")

    def adopt_pet(self, pet_key: str) -> None:
        name, ok = QInputDialog.getText(self, "Adopt Pet", "Pet name:")
        if not ok: return
        try:
            self.game_state.adopt_pet(pet_key, name)
            self.set_notice("The adoption is complete.")
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Pet Adoption", str(exc))
        self.refresh_all(); self.show_page("outdoors")

    def interact_pet(self, pet_id: int) -> None:
        try:
            result = self.game_state.interact_pet(pet_id)
            self.set_notice(f"You spend time with {result['name']}. Bond: {result['bond']}/100.")
        except RuntimeError as exc:
            QMessageBox.warning(self, "Pet", str(exc))
        self.refresh_all(); self.show_page("outdoors")

    def enroll_child_school(self, child_id: int) -> None:
        try:
            self.game_state.enroll_child_school(child_id)
            self.set_notice(f"Enrollment completed at {SCHOOL_NAME}.")
        except RuntimeError as exc:
            QMessageBox.warning(self, "School", str(exc))
        self.refresh_all(); self.show_page("family")

    def attend_court(self, case_id: int) -> None:
        try:
            result = self.game_state.attend_court(case_id)
            self.set_notice(result["outcome"], 6500)
        except RuntimeError as exc:
            QMessageBox.warning(self, "Court", str(exc))
        self.refresh_all(); self.show_page("crime")

    def buy_plot(self, plot_id: int) -> None:
        try:
            self.game_state.buy_plot(plot_id)
            self.set_notice("Property purchase completed.")
        except RuntimeError as exc:
            QMessageBox.warning(self, "Property", str(exc))
        self.refresh_all(); self.show_page("properties")

    def set_home_plot(self, plot_id: int) -> None:
        try:
            self.game_state.set_home_plot(plot_id)
            self.set_notice("Primary residence changed.")
        except RuntimeError as exc:
            QMessageBox.warning(self, "Property", str(exc))
        self.refresh_all(); self.show_page("properties")

    def start_rental(self, plot_id: int) -> None:
        try:
            result = self.game_state.start_rental(plot_id)
            self.set_notice(f"{result['tenant']} has rented the property for ${result['weekly_rent']} per week.")
        except RuntimeError as exc:
            QMessageBox.warning(self, "Rental", str(exc))
        self.refresh_all(); self.show_page("properties")

    def end_rental(self, plot_id: int) -> None:
        self.game_state.end_rental(plot_id)
        self.set_notice("The tenancy has ended.")
        self.refresh_all(); self.show_page("properties")

    def sidebar_group_for_page(self, key: str) -> str:
        if key in {"character", "inventory", "skills", "vice", "career", "education", "family"}:
            return "character"
        if key in {"life_hub", "people", "mail", "npc"}:
            return "life_hub"
        if key in {"property_hub", "property", "properties", "crafting", "business", "cooking",
                   "furniture_store", "farm_store", "vehicles", "motors"}:
            return "property_hub"
        if key in {"crime", "shady_bar", "crime_hub"}:
            return "crime"
        if key in {"map", "world", "world_hub", "outdoors"}:
            return "map"
        return "location"

    def select_directory_entry(self, title: str) -> None:
        target = self._directory_targets.get(title)
        if target is None:
            return
        destination, page = target
        current = normalize_location_key(self.game_state.load_character().current_location)
        if destination is None:
            self.show_page(page)
            return
        if destination == current:
            self.show_page(page)
            return
        destination_title = "Home" if destination == "home" else LOCATIONS[destination].name
        self.show_travel_dialog(destination, destination_title)

    def toggle_mobile_menu(self) -> None:
        if not IS_ANDROID or self.mobile_sidebar is None:
            return
        opening = not self.mobile_sidebar.isVisible()
        self.mobile_sidebar.setVisible(opening)
        if self.mobile_menu_button is not None:
            self.mobile_menu_button.setText("CLOSE" if opening else "MENU")

    def close_mobile_menu(self) -> None:
        if not IS_ANDROID or self.mobile_sidebar is None:
            return
        self.mobile_sidebar.hide()
        if self.mobile_menu_button is not None:
            self.mobile_menu_button.setText("MENU")

    def keyPressEvent(self, event) -> None:
        if IS_ANDROID and event.key() == Qt.Key.Key_Back and self.mobile_sidebar is not None and self.mobile_sidebar.isVisible():
            self.close_mobile_menu()
            event.accept()
            return
        super().keyPressEvent(event)

    def show_page(self, key: str) -> None:
        requested_key = key
        character_section = requested_key if requested_key in {"career", "education", "family"} else None
        key = {
            "vice": "character",
            "career": "character",
            "education": "character",
            "family": "character",
            "crime_hub": "crime",
            "world_hub": "map",
            "world": "map",
            "outdoors": "property",
        }.get(key, key)
        self.pages.setCurrentIndex(self.page_order[key])
        active_group = self.sidebar_group_for_page(requested_key)
        for name, button in self.nav_buttons.items():
            button.setChecked(name == active_group)
        if IS_ANDROID:
            self.close_mobile_menu()
        if character_section and character_section in self.character_section_widgets:
            target = self.character_section_widgets[character_section]
            scroll = getattr(self, "character_scroll", None)
            if scroll is not None:
                QTimer.singleShot(0, lambda s=scroll, w=target: s.ensureWidgetVisible(w, 0, 18))

    def set_combat_menu(self, menu: str) -> None:
        self.combat_menu = menu
        self.refresh_all()
        self.show_page("location")

    def start_fight_club_bout(self) -> None:
        try:
            state = self.game_state.start_fight_club_bout()
            self.combat_menu = "root"
            self.set_notice(state.get("log_text", "The bout begins."), 5000)
        except RuntimeError as exc:
            QMessageBox.warning(self, "Fight Club", str(exc))
        self.refresh_all()
        self.show_page("location")

    def start_dungeon_encounter(self) -> None:
        try:
            state = self.game_state.start_dungeon_encounter()
            self.combat_menu = "root"
            self.set_notice(state.get("log_text", "Something moves in the chamber."), 5000)
        except RuntimeError as exc:
            QMessageBox.warning(self, "Dungeon", str(exc))
        self.refresh_all()
        self.show_page("location")

    def explore_blackwood(self) -> None:
        try:
            result = self.game_state.explore_blackwood()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot explore", str(exc))
            return
        self.combat_menu = "root"
        self.selected_business_id: int | None = None
        self._business_tick_counter = 0
        self.set_notice(result["text"], 6500)
        self.refresh_all()
        self.show_page("location")

    def combat_attack(self, move_key: str) -> None:
        try:
            result = self.game_state.combat_attack(move_key)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Combat", str(exc))
            return
        self.combat_menu = "root"
        self.selected_business_id: int | None = None
        self._business_tick_counter = 0
        self.set_notice(result["text"], 6500)
        self.refresh_all()
        self.show_page("location")

    def combat_brace(self) -> None:
        try:
            result = self.game_state.combat_brace()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Combat", str(exc))
            return
        self.combat_menu = "root"
        self.selected_business_id: int | None = None
        self._business_tick_counter = 0
        self.set_notice(result["text"], 6500)
        self.refresh_all()
        self.show_page("location")

    def combat_use_item(self, item_name: str) -> None:
        try:
            result = self.game_state.combat_use_item(item_name)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Combat", str(exc))
            return
        self.combat_menu = "root"
        self.selected_business_id: int | None = None
        self._business_tick_counter = 0
        self.set_notice(result["text"], 6500)
        self.refresh_all()
        self.show_page("location")

    def combat_run(self) -> None:
        try:
            result = self.game_state.combat_run()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Combat", str(exc))
            return
        self.combat_menu = "root"
        self.selected_business_id: int | None = None
        self._business_tick_counter = 0
        self.set_notice(result["text"], 6500)
        self.refresh_all()
        self.show_page("location")

    def equip_weapon(self, item_name: str) -> None:
        try:
            self.game_state.equip_weapon(item_name)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot equip", str(exc))
            return
        self.set_notice(f"Equipped {item_name}.")
        self.refresh_all()
        self.show_page("character")

    def begin_construction(self, structure_key: str) -> None:
        try:
            state = self.game_state.start_construction(structure_key)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot build", str(exc))
            return
        self.set_notice(f"Construction started: {state['structure_name']}.")
        self._last_construction_active = True
        self.refresh_all()
        self.show_page("property")

    def buy_furniture(self, item_name: str) -> None:
        try:
            self.game_state.buy_furniture(item_name)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot buy", str(exc))
            return
        self.set_notice(f"Bought {item_name}.")
        self.refresh_all()
        self.show_page("furniture_store")

    def place_furniture(self, item_name: str, structure_id: int, room_name: str) -> None:
        try:
            self.game_state.place_furniture(item_name, structure_id, room_name)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot place furniture", str(exc))
            return
        self.set_notice(f"Placed {item_name} in {room_name}.")
        self.refresh_all()
        self.show_page("property")

    def remove_furniture(self, furniture_id: int) -> None:
        try:
            self.game_state.remove_furniture(furniture_id)
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot move furniture", str(exc))
            return
        self.set_notice("Furniture moved to inventory.")
        self.refresh_all()
        self.show_page("property")

    def store_inventory_item(self, item_name: str) -> None:
        try:
            self.game_state.store_inventory_item(item_name)
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot store item", str(exc))
            return
        self.set_notice(f"Stored {item_name}.")
        self.refresh_all()
        self.show_page("property")

    def take_storage_item(self, item_name: str) -> None:
        try:
            self.game_state.take_storage_item(item_name)
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot take item", str(exc))
            return
        self.set_notice(f"Moved {item_name} to inventory.")
        self.refresh_all()
        self.show_page("property")

    def buy_seed(self, seed_item: str) -> None:
        try:
            self.game_state.buy_seed(seed_item)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot buy seeds", str(exc))
            return
        self.set_notice(f"Bought {seed_item}.")
        self.refresh_all()
        self.show_page("farm_store")

    def plant_crop(self, crop_key: str) -> None:
        try:
            self.game_state.plant_crop(crop_key)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot plant", str(exc))
            return
        self.set_notice(f"Planted {CROPS[crop_key].name}.")
        self.refresh_all()
        self.show_page("property")

    def water_crop(self, crop_id: int) -> None:
        try:
            self.game_state.water_crop(crop_id)
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot water crop", str(exc))
            return
        self.set_notice("The crop has been watered. Its harvest will be larger.")
        self.refresh_all()
        self.show_page("property")

    def harvest_crop(self, crop_id: int) -> None:
        try:
            result = self.game_state.harvest_crop(crop_id)
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot harvest", str(exc))
            return
        self.set_notice(f"Harvested {result['quantity']} {result['item']}.")
        self.refresh_all()
        self.show_page("property")

    def sell_produce(self, item_name: str) -> None:
        try:
            price = self.game_state.sell_produce(item_name)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot sell produce", str(exc))
            return
        self.set_notice(f"Sold one {item_name} for ${price}.")
        self.refresh_all()
        self.show_page("farm_store")

    def buy_feed_sack(self) -> None:
        try:
            portions = self.game_state.buy_feed_sack()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot buy feed", str(exc))
            return
        self.set_notice(f"Delivered {portions} portions of livestock feed to your property.")
        self.refresh_all()
        self.show_page("farm_store")

    def buy_animal(self, animal_key: str) -> None:
        try:
            self.game_state.buy_animal(animal_key)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot buy livestock", str(exc))
            return
        self.set_notice(f"Purchased {ANIMALS[animal_key].name}. The animal has been delivered to your property.")
        self.refresh_all()
        self.show_page("farm_store")

    def collect_animal_output(self, animal_id: int) -> None:
        try:
            result = self.game_state.collect_animal_output(animal_id)
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot collect", str(exc))
            return
        self.set_notice(f"Collected {result['quantity']} {result['item']}.")
        self.refresh_all()
        self.show_page("property")

    def sell_animal_product(self, item_name: str) -> None:
        try:
            price = self.game_state.sell_animal_product(item_name)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot sell farm product", str(exc))
            return
        self.set_notice(f"Sold one {item_name} for ${price}.")
        self.refresh_all()
        self.show_page("farm_store")

    def open_npc(self, npc_key: str) -> None:
        self.selected_npc_key = npc_key
        self.refresh_all()
        self.show_page("npc")

    def talk_to_npc(self, npc_key: str, option_key: str) -> None:
        try:
            result = self.game_state.talk_to_npc(npc_key, option_key)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot talk", str(exc))
            return
        self.set_notice(f"{result['name']}: {result['response']}  Relationship: {result['relationship']}.", duration_ms=9000)
        self.refresh_all()
        self.show_page("npc")

    def ask_to_date(self, npc_key: str) -> None:
        try:
            result = self.game_state.ask_to_date(npc_key)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot start relationship", str(exc))
            return
        self.set_notice(f"You and {result['name']} are now dating.")
        self.refresh_all()
        self.show_page("npc")

    def go_on_date(self, npc_key: str) -> None:
        try:
            result = self.game_state.go_on_date(npc_key)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot spend time together", str(exc))
            return
        self.set_notice(f"You spend time with {result['name']}. Romance is now {result['romance']}.")
        self.refresh_all()
        self.show_page("npc")

    def marry_npc(self, npc_key: str) -> None:
        try:
            result = self.game_state.marry_npc(npc_key)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot marry", str(exc))
            return
        self.set_notice(f"You and {result['name']} are now married.", duration_ms=8000)
        self.refresh_all()
        self.show_page("family")

    def intimacy(self, npc_key: str, try_for_child: bool) -> None:
        try:
            result = self.game_state.intimacy(npc_key, try_for_child)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot spend private time together", str(exc))
            return
        text = f"You spend private time with {result['name']}. Recovered {result['hp_restored']} HP and {result['stamina_restored']} stamina."
        if try_for_child:
            text += " Your household is now expecting a child." if result["expecting_child"] else " No pregnancy resulted."
        self.set_notice(text, duration_ms=8000)
        self.refresh_all()
        self.show_page("family" if try_for_child else "npc")

    def cook_recipe(self, recipe_key: str) -> None:
        try:
            result = self.game_state.cook_recipe(recipe_key)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot cook", str(exc))
            return
        self.set_notice(f"Prepared {result['result']}.")
        self.refresh_all()
        self.show_page("cooking")

    def eat_prepared_food(self, item_name: str) -> None:
        try:
            result = self.game_state.eat_prepared_food(item_name)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot eat", str(exc))
            return
        self.set_notice(f"Ate {item_name}. Recovered {result['hp']} HP and {result['stamina']} stamina.")
        self.refresh_all()
        self.show_page("character")

    def eat_diner_meal(self, meal_key: str) -> None:
        try:
            result = self.game_state.eat_at_diner(meal_key)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot order meal", str(exc))
            return
        self.set_notice(f"Finished {result['name']}. Paid ${result['price']}.")
        self.refresh_all()
        self.show_page("diner")

    def receive_clinic_treatment(self) -> None:
        try:
            price = self.game_state.clinic_treatment()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot receive treatment", str(exc))
            return
        self.set_notice(f"Treatment complete. Paid ${price}.")
        self.refresh_all()
        self.show_page("clinic")

    def detox_treatment(self) -> None:
        try:
            result = self.game_state.detox_treatment()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot receive treatment", str(exc))
            return
        self.set_notice(f"Dependence treatment complete. Paid ${result['cost']}.")
        self.refresh_all()
        self.show_page("clinic")

    def buy_vice_item(self, item_key: str) -> None:
        try:
            self.game_state.buy_vice_item(item_key)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot buy item", str(exc))
            return
        self.set_notice("Purchase completed.")
        self.refresh_all()
        self.show_page("shady_bar")

    def use_vice_item(self, item_name: str) -> None:
        try:
            result = self.game_state.use_vice_item(item_name)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot use item", str(exc))
            return
        self.set_notice(f"Used {result['name']}.")
        self.refresh_all()
        self.show_page("vice")

    def make_drugs(self) -> None:
        try:
            result = self.game_state.make_drugs()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot make drugs", str(exc))
            return
        self.set_notice(
            f"Produced {result['quantity']} Drugs. Operating cost ${result['cost']}. Heat increased by {result['heat_gain']}."
        )
        self.refresh_all()
        self.show_page("vice")

    def start_dealer_operation(self) -> None:
        try:
            self.game_state.start_dealer_operation()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot start operation", str(exc))
            return
        self.set_notice("A small dealing operation has been established.")
        self.refresh_all()
        self.show_page("shady_bar")

    def buy_dealer_stock(self, item_key: str) -> None:
        try:
            result = self.game_state.buy_dealer_stock(item_key, 5)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot buy stock", str(exc))
            return
        self.set_notice(f"Purchased {result['quantity']} units of {result['item']} for ${result['cost']}.")
        self.refresh_all()
        self.show_page("shady_bar")

    def dealer_sale(self, item_key: str, quantity: int) -> None:
        try:
            result = self.game_state.dealer_sale(item_key, quantity)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot make sale", str(exc))
            return
        if result["arrested"]:
            text = f"Distribution attempt ended in arrest. Fine: ${result['fine']}."
            page = "location"
        elif result["success"]:
            text = f"Sale completed. Received ${result['cash_gain']}. Heat increased by {result['heat_gain']}."
            page = "shady_bar"
        else:
            text = f"Sale failed. Heat increased by {result['heat_gain']}."
            page = "shady_bar"
        self.set_notice(text)
        self.refresh_all()
        self.show_page(page)

    def set_casino_wager(self, amount: int) -> None:
        self.casino_wager = int(amount)
        self.refresh_all()
        self.show_page("casino")

    def play_slots(self) -> None:
        try:
            result = self.game_state.play_slots(self.casino_wager)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Slots", str(exc))
            return
        reels = " | ".join(result["reels"])
        self.set_notice(f"Slots: {reels}. {result['result']}. Net ${result['net']:+d}.")
        self.refresh_all()
        self.show_page("casino")

    def blackjack_start(self) -> None:
        try:
            result = self.game_state.blackjack_start(self.casino_wager)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Blackjack", str(exc))
            return
        if result.get("ended"):
            self.set_notice(f"Blackjack: {result['result']}. Net ${result['net']:+d}.")
        else:
            self.set_notice("Blackjack hand dealt.")
        self.refresh_all()
        self.show_page("casino")

    def blackjack_hit(self) -> None:
        try:
            result = self.game_state.blackjack_hit()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Blackjack", str(exc))
            return
        if result.get("ended"):
            self.set_notice(f"Blackjack: {result['result']}. Net ${result['net']:+d}.")
        else:
            self.set_notice(f"Card drawn. Hand total: {result['player_score']}.")
        self.refresh_all()
        self.show_page("casino")

    def blackjack_stand(self) -> None:
        try:
            result = self.game_state.blackjack_stand()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Blackjack", str(exc))
            return
        self.set_notice(
            f"Blackjack: {result['result']}. Your hand {result['player_score']}; dealer {result['dealer_score']}. Net ${result['net']:+d}."
        )
        self.refresh_all()
        self.show_page("casino")

    def play_roulette(self, bet_type: str) -> None:
        try:
            result = self.game_state.play_roulette(self.casino_wager, bet_type)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Roulette", str(exc))
            return
        self.set_notice(
            f"Roulette: {result['spin']} {result['color']}. Bet {result['bet']}. Net ${result['net']:+d}."
        )
        self.refresh_all()
        self.show_page("casino")

    def play_roulette_number(self) -> None:
        number, ok = QInputDialog.getInt(self, "Roulette", "Choose a number from 0 to 36:", 0, 0, 36, 1)
        if not ok:
            return
        try:
            result = self.game_state.play_roulette(self.casino_wager, "number", number)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Roulette", str(exc))
            return
        self.set_notice(
            f"Roulette: {result['spin']} {result['color']}. Bet {result['bet']}. Net ${result['net']:+d}."
        )
        self.refresh_all()
        self.show_page("casino")

    def rest_at_park(self) -> None:
        try:
            restored = self.game_state.rest_at_park()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot rest", str(exc))
            return
        self.set_notice(f"You spend time by the river and recover {restored} stamina.")
        self.refresh_all()
        self.show_page("park")

    def attend_community_hall(self) -> None:
        try:
            event = self.game_state.attend_community_hall()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot attend", str(exc))
            return
        self.set_notice(f"You spend time at the community hall during {event['name']}. +1 Speech XP.")
        self.refresh_all()
        self.show_page("community")

    def read_mail(self, mail_id: int) -> None:
        try:
            self.game_state.read_mail(mail_id)
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot read mail", str(exc))
            return
        self.refresh_all()
        self.show_page("mail")

    def accept_favor(self, npc_key: str) -> None:
        try:
            result = self.game_state.accept_favor(npc_key)
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot accept favor", str(exc))
            return
        self.set_notice(f"Accepted favor: {result['title']}.")
        self.refresh_all()
        self.show_page("npc")

    def complete_favor(self, npc_key: str) -> None:
        try:
            result = self.game_state.complete_favor(npc_key)
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot complete favor", str(exc))
            return
        self.set_notice(
            f"Completed {result['title']}. Earned ${result['cash']} and +{result['friendship']} friendship."
        )
        self.refresh_all()
        self.show_page("npc")

    def buy_mask(self) -> None:
        try:
            self.game_state.buy_mask()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot buy mask", str(exc))
            return
        self.set_notice("Bought Black Cloth Mask.")
        self.refresh_all()
        self.show_page("shady_bar")

    def toggle_mask(self) -> None:
        try:
            worn = self.game_state.toggle_mask()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot change mask", str(exc))
            return
        self.set_notice("Mask worn." if worn else "Mask removed.")
        self.refresh_all()
        self.show_page("crime")

    def commit_crime(self, crime_key: str) -> None:
        try:
            result = self.game_state.commit_crime(crime_key)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot commit crime", str(exc))
            return
        if result["arrested"]:
            text = f"{result['name']}: {'completed' if result['success'] else 'failed'}. You were arrested. Fine: ${result['fine']}."
        elif result["success"]:
            text = f"{result['name']} completed."
            if result["cash_gain"]:
                text += f" Gained ${result['cash_gain']}."
        else:
            text = f"{result['name']} failed, but you escaped arrest."
        self.set_notice(text)
        self.refresh_all()
        self.show_page("location" if result["arrested"] else "crime")

    def take_crime_job(self, job_key: str) -> None:
        try:
            result = self.game_state.take_crime_job(job_key)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot take job", str(exc))
            return
        if result["arrested"]:
            text = f"{result['name']}: {'completed' if result['success'] else 'failed'}. You were arrested."
        elif result["success"]:
            text = f"{result['name']} completed. Payment received: ${result['cash_gain']}."
        else:
            text = f"{result['name']} failed. You escaped arrest."
        self.set_notice(text)
        self.refresh_all()
        self.show_page("location" if result["arrested"] else "shady_bar")

    def manage_business(self, business_id: int) -> None:
        self.selected_business_id = business_id
        self.refresh_all()
        self.show_page("business")

    def toggle_business(self, business_id: int, is_open: bool) -> None:
        try:
            self.game_state.set_business_open(business_id, is_open)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot change business", str(exc))
            return
        self.set_notice("Business opened." if is_open else "Business closed.")
        self.refresh_all()
        self.show_page("business")

    def set_business_price(self, business_id: int, tier: str) -> None:
        try:
            self.game_state.set_business_price_tier(business_id, tier)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot change pricing", str(exc))
            return
        self.set_notice("Business pricing updated.")
        self.refresh_all()
        self.show_page("business")

    def buy_business_stock(self, business_id: int, item_name: str) -> None:
        try:
            cost = self.game_state.buy_business_wholesale(business_id, item_name, 5)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot order stock", str(exc))
            return
        self.set_notice(f"Wholesale stock ordered for ${cost}.")
        self.refresh_all()
        self.show_page("business")

    def stock_business_item(self, business_id: int, item_name: str) -> None:
        try:
            self.game_state.stock_business_from_inventory(business_id, item_name)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot stock business", str(exc))
            return
        self.set_notice(f"Added one {item_name} to business stock.")
        self.refresh_all()
        self.show_page("business")

    def collect_business_till(self, business_id: int) -> None:
        try:
            amount = self.game_state.collect_business_till(business_id)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot collect income", str(exc))
            return
        self.set_notice(f"Collected ${amount} from the business till." if amount else "The business till is empty.")
        self.refresh_all()
        self.show_page("business")

    def gather_wood(self) -> None:
        try:
            result = self.game_state.gather_wood()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot cut timber", str(exc))
            return
        self.set_notice(f"Collected {result['quantity']} logs using {result['tool']}.")
        self.refresh_all()
        self.show_page("location")

    def mine_quarry(self) -> None:
        try:
            result = self.game_state.mine_quarry()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot mine", str(exc))
            return
        text = f"Collected {result['stone']} stone"
        if result['ore']:
            text += f" and {result['ore']} iron ore"
        self.set_notice(text + ".")
        self.refresh_all()
        self.show_page("location")

    def fish_lake_mercy(self) -> None:
        try:
            result = self.game_state.fish_lake_mercy()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot fish", str(exc))
            return
        self.set_notice(f"Caught {result['quantity']} {result['item']}.")
        self.refresh_all()
        self.show_page("location")

    def salvage_redwater(self) -> None:
        try:
            result = self.game_state.salvage_redwater()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot salvage", str(exc))
            return
        self.set_notice(f"Recovered {result['quantity']} {result['item']}.")
        self.refresh_all()
        self.show_page("location")

    def rent_regional_room(self) -> None:
        try:
            result = self.game_state.rent_regional_room()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot rent room", str(exc))
            return
        self.set_notice(f"Stayed overnight in {result['location']} for ${result['price']}.")
        self.refresh_all()
        self.show_page("location")

    def craft_recipe(self, recipe_key: str) -> None:
        try:
            result = self.game_state.craft_recipe(recipe_key)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot craft", str(exc))
            return
        self.set_notice(f"Crafted {result['quantity']} {result['output']}. +{result['xp']} Crafting XP.")
        self.refresh_all()
        self.show_page("crafting")

    def buy_vehicle(self, vehicle_key: str) -> None:
        try:
            vehicle_id = self.game_state.buy_vehicle(vehicle_key)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot buy vehicle", str(exc))
            return
        definition = VEHICLES[vehicle_key]
        current = normalize_location_key(self.game_state.load_character().current_location)
        place = LOCATIONS[current].name if current in LOCATIONS else "the dealer"
        self.set_notice(f"Bought {definition.name}. It is parked at {place}.")
        self.selected_vehicle_id = vehicle_id
        self.refresh_all()
        self.show_page("vehicles")

    def refuel_vehicle(self, vehicle_id: int) -> None:
        try:
            cost = self.game_state.refuel_vehicle(vehicle_id)
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot refuel", str(exc))
            return
        self.set_notice("Fuel tank filled." if cost else "The fuel tank is already full.")
        self.refresh_all()
        self.show_page("motors")

    def repair_vehicle(self, vehicle_id: int) -> None:
        try:
            cost = self.game_state.repair_vehicle(vehicle_id)
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot repair", str(exc))
            return
        self.set_notice("Vehicle repaired." if cost else "The vehicle does not need repairs.")
        self.refresh_all()
        self.show_page("vehicles")

    def store_vehicle_item(self, vehicle_id: int, item_name: str) -> None:
        try:
            self.game_state.store_item_in_vehicle(vehicle_id, item_name)
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot store item", str(exc))
            return
        self.set_notice(f"Stored {item_name} in the vehicle.")
        self.refresh_all()
        self.show_page("vehicles")

    def take_vehicle_item(self, vehicle_id: int, item_name: str) -> None:
        try:
            self.game_state.take_item_from_vehicle(vehicle_id, item_name)
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot take item", str(exc))
            return
        self.set_notice(f"Took {item_name} from the vehicle.")
        self.refresh_all()
        self.show_page("vehicles")

    def begin_travel(self, destination: str, method: str = "Walking") -> None:
        try:
            self.game_state.start_travel(destination, method)
        except (ValueError, RuntimeError) as exc:
            QMessageBox.warning(self, "Cannot travel", str(exc))
            return
        self.set_notice(f"Trip started by {method.lower()}. You can browse other menus while the timer runs.")
        self.refresh_all()
        self.show_page("location")
        self._last_travel_active = True

    def cancel_travel(self) -> None:
        self.game_state.cancel_travel()
        self.set_notice("Trip cancelled. You remain where you started.")
        self.refresh_all()
        self.show_page("location")
        self._last_travel_active = False

    def begin_job(self, job_key: str) -> None:
        try:
            self.game_state.start_job(job_key)
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot work", str(exc))
            return
        self.set_notice("Shift started. The timer keeps running even if you leave this screen.")
        self.refresh_all()
        self.show_page("employment")
        self._last_job_active = True

    def apply_for_career(self, career_key: str) -> None:
        try:
            self.game_state.apply_for_career(career_key)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot apply", str(exc))
            return
        self.set_notice("Application accepted. You now have a full-time position.")
        self.refresh_all()
        self.show_page("career")

    def begin_career_shift(self) -> None:
        try:
            self.game_state.start_career_shift()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot work shift", str(exc))
            return
        self.set_notice("Eight-hour shift started. The timer continues if you browse other menus or close the game.")
        self._last_career_active = True
        self.refresh_all()
        self.show_page("career")

    def resign_career(self) -> None:
        answer = QMessageBox.question(self, "Resign", "Resign from your current full-time position?")
        if answer != QMessageBox.Yes:
            return
        try:
            self.game_state.resign_career()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot resign", str(exc))
            return
        self.set_notice("You resigned from your position.")
        self.refresh_all()
        self.show_page("career")

    def sell_regional_item(self, item_name: str) -> None:
        try:
            price = self.game_state.sell_regional_item(item_name)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot sell item", str(exc))
            return
        self.set_notice(f"Sold one {item_name} for ${price}.")
        self.refresh_all()
        self.show_page("store")

    def buy_item(self, item_name: str) -> None:
        try:
            self.game_state.buy_store_item(item_name)
        except (RuntimeError, ValueError) as exc:
            QMessageBox.warning(self, "Cannot buy", str(exc))
            return
        self.set_notice(f"Bought {item_name}.")
        self.refresh_all()
        self.show_page("store")

    def rest_in_tent(self) -> None:
        before = self.game_state.load_character()
        profile = self.game_state.home_rest_profile()
        try:
            self.game_state.rest_at_home()
        except RuntimeError as exc:
            QMessageBox.warning(self, "Cannot rest", str(exc))
            return
        after = self.game_state.load_character()
        hp = after.hp - before.hp
        stamina = after.stamina - before.stamina
        if hp or stamina:
            pieces = []
            if hp:
                pieces.append(f"{hp} HP")
            if stamina:
                pieces.append(f"{stamina} stamina")
            self.set_notice(f"You rest in the {profile['name']} and recover " + " and ".join(pieces) + ".")
        else:
            self.set_notice("You are already fully rested.")
        self.refresh_all()
        self.show_page("location")

    def update_activity_widgets(self) -> None:
        travel = self.game_state.get_travel_state()
        if travel and self.travel_remaining_label and self.travel_progress:
            elapsed = max(0, travel["duration_seconds"] - travel["remaining_seconds"])
            self.travel_progress.setValue(elapsed)
            self.travel_remaining_label.setText(f"{travel['remaining_seconds']} seconds remaining")

        job = self.game_state.get_job_state()
        if job and self.job_remaining_label and self.job_progress:
            elapsed = max(0, job["duration_seconds"] - job["remaining_seconds"])
            self.job_progress.setValue(elapsed)
            self.job_remaining_label.setText(f"{job['remaining_seconds']} seconds remaining")

        career_shift = self.game_state.get_career_shift_state()
        if career_shift and self.career_remaining_label and self.career_progress_bar:
            elapsed = max(0, career_shift["duration_seconds"] - career_shift["remaining_seconds"])
            self.career_progress_bar.setValue(elapsed)
            self.career_remaining_label.setText(f"{career_shift['remaining_seconds']} seconds remaining")

        jail = self.game_state.get_jail_state()
        if jail and self.jail_remaining_label:
            self.jail_remaining_label.setText(f"Release in {jail['remaining_seconds']} seconds")

        construction = self.game_state.get_construction_state()
        if construction and self.construction_remaining_label and self.construction_progress:
            elapsed = max(0, construction["duration_seconds"] - construction["remaining_seconds"])
            self.construction_progress.setValue(elapsed)
            self.construction_remaining_label.setText(f"{construction['remaining_seconds']} seconds remaining")

    def tick_activities(self) -> None:
        self._business_tick_counter += 1
        if self._business_tick_counter >= 10:
            self._business_tick_counter = 0
            self.game_state.load_businesses()
            if self.pages.currentIndex() in {self.page_order["business"], self.page_order["property"]}:
                self.refresh_all()
                return
        travel = self.game_state.get_travel_state()
        job = self.game_state.get_job_state()
        career_shift = self.game_state.get_career_shift_state()
        construction = self.game_state.get_construction_state()
        jail = self.game_state.get_jail_state()
        travel_active = bool(travel)
        job_active = bool(job)
        career_active = bool(career_shift)
        construction_active = bool(construction)
        jail_active = bool(jail)
        farm_ready_ids = {crop["id"] for crop in self.game_state.load_farm_crops() if crop["ready"]}
        animal_ready_ids = {
            animal["id"] for animal in self.game_state.load_livestock() if animal["stored_output"] > 0
        }
        new_ready = farm_ready_ids - self._farm_ready_ids
        new_animal_ready = animal_ready_ids - self._animal_ready_ids

        if new_ready:
            self.set_notice("A crop is ready to harvest.")
            self.refresh_all()
        elif new_animal_ready:
            self.set_notice("A livestock product is ready to collect.")
            self.refresh_all()
        elif self._last_travel_active and not travel_active:
            self.set_notice("You have arrived.")
            self.refresh_all()
            self.show_page("location")
        elif self._last_job_active and not job_active:
            self.set_notice("Shift complete. Pay and Work XP have been added.")
            self.refresh_all()
            self.show_page("employment")
        elif self._last_career_active and not career_active:
            self.set_notice("Full-time shift complete. Eight in-game hours have passed and your wages were paid.")
            self.refresh_all()
            self.show_page("career")
        elif self._last_construction_active and not construction_active:
            self.set_notice("Construction complete.")
            self.refresh_all()
            self.show_page("property")
        elif self._last_jail_active and not jail_active:
            self.set_notice("You have been released from Dong City Jail.")
            self.refresh_all()
            self.show_page("location")
        else:
            self.update_activity_widgets()

        self._last_travel_active = travel_active
        self._last_job_active = job_active
        self._last_career_active = career_active
        self._last_construction_active = construction_active
        self._last_jail_active = jail_active
        self._farm_ready_ids = farm_ready_ids
        self._animal_ready_ids = animal_ready_ids

    def save_game(self) -> None:
        self.game_state.save_now()
        if IS_ANDROID:
            self.close_mobile_menu()
        self.set_notice("Saved.")
        self.refresh_all()

    def return_to_menu(self) -> None:
        self.game_state.save_now()
        self.on_return_to_menu()

    def closeEvent(self, event) -> None:
        try:
            self.game_state.save_now()
        except Exception:
            pass
        event.accept()
