from __future__ import annotations

from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QLabel,
    QLineEdit,
    QMessageBox,
    QVBoxLayout,
)

from platform_support import IS_ANDROID


class NewGameDialog(QDialog):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("New Game")
        if not IS_ANDROID:
            self.setMinimumWidth(460)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18 if IS_ANDROID else 24, 18 if IS_ANDROID else 22, 18 if IS_ANDROID else 24, 18 if IS_ANDROID else 22)
        layout.setSpacing(10 if IS_ANDROID else 12)

        title = QLabel("CREATE CHARACTER")
        title.setStyleSheet("font-size: 22px; font-weight: 850; color: #f2d5a1; border-bottom: 1px solid #334047; padding-bottom: 8px;")
        layout.addWidget(title)

        intro = QLabel("Begin with a name, a tent, and one undeveloped piece of the world.")
        intro.setWordWrap(True)
        intro.setStyleSheet("color: #8c969a; margin-bottom: 6px;")
        layout.addWidget(intro)

        name_label = QLabel("CHARACTER NAME")
        name_label.setStyleSheet("font-size: 9px; font-weight: 800; color: #b58b4b; letter-spacing: 2px;")
        layout.addWidget(name_label)
        self.name_input = QLineEdit()
        self.name_input.setMaxLength(24)
        if IS_ANDROID:
            self.name_input.setMinimumHeight(48)
        self.name_input.setPlaceholderText("Enter a name")
        self.name_input.returnPressed.connect(self.try_accept)
        layout.addWidget(self.name_input)

        note = QLabel(
            "You will receive one random undeveloped starter plot from the 100-plot world.\n"
            "Every starter property begins with a basic tent."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: #8c989e; padding: 8px 0px;")
        layout.addWidget(note)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.try_accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self.name_input.setFocus()

    def character_name(self) -> str:
        return " ".join(self.name_input.text().strip().split())

    def try_accept(self) -> None:
        if not self.character_name():
            QMessageBox.warning(self, "Missing name", "Enter a character name first.")
            return
        self.accept()
