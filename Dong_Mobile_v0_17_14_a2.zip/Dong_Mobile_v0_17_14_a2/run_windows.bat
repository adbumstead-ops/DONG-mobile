@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Dong - Windows Launcher

set "LOG=%~dp0dong_windows_log.txt"
set "VENV=%~dp0.venv"
set "VENV_PY=%VENV%\Scripts\python.exe"

> "%LOG%" echo Dong Windows launcher log
>>"%LOG%" echo Started: %DATE% %TIME%
>>"%LOG%" echo Folder: %CD%
>>"%LOG%" echo.

echo ==========================================
echo              DONG WINDOWS
echo ==========================================
echo.

rem Reuse a working local environment first.
if exist "%VENV_PY%" (
    "%VENV_PY%" -c "import PySide6" >>"%LOG%" 2>&1
    if not errorlevel 1 goto launch
    echo Existing Dong environment needs repair.
    >>"%LOG%" echo Existing venv found, but PySide6 import failed.
)

set "PY_CMD="

rem Prefer a known-compatible Python 3.13 runtime if already installed.
where py >nul 2>&1
if not errorlevel 1 (
    py -3.13 -c "import sys; print(sys.version)" >>"%LOG%" 2>&1
    if not errorlevel 1 set "PY_CMD=py -3.13"
)

rem If the modern Python manager is present, use it to install 3.13.
if not defined PY_CMD (
    where pymanager >nul 2>&1
    if not errorlevel 1 (
        echo Installing Python 3.13 for Dong...
        pymanager install 3.13 >>"%LOG%" 2>&1
        if not errorlevel 1 set "PY_CMD=py -3.13"
    )
)

rem A modern py command may itself support runtime installation.
if not defined PY_CMD (
    where py >nul 2>&1
    if not errorlevel 1 (
        echo Installing Python 3.13 for Dong...
        py install 3.13 >>"%LOG%" 2>&1
        py -3.13 -c "import sys; print(sys.version)" >>"%LOG%" 2>&1
        if not errorlevel 1 set "PY_CMD=py -3.13"
    )
)

rem No useful Python manager found. Install the official manager with WinGet.
if not defined PY_CMD (
    where winget >nul 2>&1
    if not errorlevel 1 (
        echo Python is not set up on this PC.
        echo Installing the official Python Install Manager...
        >>"%LOG%" echo Installing Python Install Manager with WinGet.
        winget install 9NQ7512CXL7T -e --accept-package-agreements --accept-source-agreements --disable-interactivity >>"%LOG%" 2>&1

        rem Refresh the WindowsApps location for this same launcher session.
        set "PATH=%LOCALAPPDATA%\Microsoft\WindowsApps;%PATH%"

        if exist "%LOCALAPPDATA%\Microsoft\WindowsApps\pymanager.exe" (
            "%LOCALAPPDATA%\Microsoft\WindowsApps\pymanager.exe" install 3.13 >>"%LOG%" 2>&1
        ) else (
            where pymanager >nul 2>&1
            if not errorlevel 1 pymanager install 3.13 >>"%LOG%" 2>&1
        )

        where py >nul 2>&1
        if not errorlevel 1 (
            py -3.13 -c "import sys; print(sys.version)" >>"%LOG%" 2>&1
            if not errorlevel 1 set "PY_CMD=py -3.13"
        )
    )
)

rem Final fallback: use an existing python.exe if it is Python 3.10+.
if not defined PY_CMD (
    where python >nul 2>&1
    if not errorlevel 1 (
        python -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >>"%LOG%" 2>&1
        if not errorlevel 1 set "PY_CMD=python"
    )
)

if not defined PY_CMD goto no_python

echo Creating Dong's private Python environment...
>>"%LOG%" echo Python command: %PY_CMD%
if exist "%VENV%" rmdir /s /q "%VENV%"
%PY_CMD% -m venv "%VENV%" >>"%LOG%" 2>&1
if errorlevel 1 goto venv_failed

:install_deps
echo Installing required game files. First launch can take a minute...
"%VENV_PY%" -m pip install --upgrade pip >>"%LOG%" 2>&1
if errorlevel 1 goto pip_failed
"%VENV_PY%" -m pip install -r requirements.txt >>"%LOG%" 2>&1
if errorlevel 1 goto pip_failed
"%VENV_PY%" -c "import PySide6; print(PySide6.__version__)" >>"%LOG%" 2>&1
if errorlevel 1 goto pip_failed

:launch
echo Starting Dong...
>>"%LOG%" echo Launching game.
"%VENV_PY%" main.py >>"%LOG%" 2>&1
if errorlevel 1 goto game_failed
exit /b 0

:no_python
echo.
echo Dong could not find or install Python automatically.
echo This launcher works best on Windows 10 or Windows 11 with internet access.
echo.
echo Open WINDOWS_TROUBLESHOOTING.txt in this folder for the manual fix.
>>"%LOG%" echo ERROR: No usable Python runtime or install manager found.
pause
exit /b 1

:venv_failed
echo.
echo Dong could not create its local Python environment.
echo Delete the .venv folder if one exists, then run this launcher again.
echo Details are in dong_windows_log.txt.
>>"%LOG%" echo ERROR: venv creation failed.
pause
exit /b 1

:pip_failed
echo.
echo Dong could not install PySide6.
echo Make sure this PC has internet access, then run this launcher again.
echo Details are in dong_windows_log.txt.
>>"%LOG%" echo ERROR: dependency installation failed.
pause
exit /b 1

:game_failed
echo.
echo Dong started but encountered an error.
echo The error has been saved to:
echo %LOG%
echo.
echo Keep that file if you need to send me the error.
>>"%LOG%" echo ERROR: game process exited with an error.
pause
exit /b 1
