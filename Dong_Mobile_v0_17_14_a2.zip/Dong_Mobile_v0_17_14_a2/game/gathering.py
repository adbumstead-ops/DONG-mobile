from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class GatheringTool:
    name: str
    activity: str
    yield_bonus: int
    stamina_reduction: int


@dataclass(frozen=True)
class CraftRecipe:
    key: str
    name: str
    description: str
    station: str
    inputs: tuple[tuple[str, int], ...]
    output_name: str
    output_quantity: int
    output_description: str
    crafting_xp: int
    game_minutes: int


ITEM_DESCRIPTIONS = {
    "Log": "A cut section of timber suitable for processing or construction.",
    "Stone": "A piece of quarried stone suitable for cutting and construction.",
    "Iron Ore": "Dense ore containing enough iron to be refined in a forge.",
    "Lumber": "Processed construction lumber cut to useful dimensions.",
    "Stone Block": "A squared block of stone prepared for construction.",
    "Iron Ingot": "Refined iron formed into a solid ingot for toolmaking and construction.",
    "Wood Axe": "A practical axe designed for felling and trimming small trees.",
    "Mining Pick": "A steel-headed pick designed for breaking stone and exposing ore.",
    "Forged Axe": "A reinforced axe with a forged iron head and fitted wooden handle.",
    "Forged Mining Pick": "A reinforced mining pick with a forged iron head and fitted wooden handle.",
}


TOOLS = {
    "Wood Axe": GatheringTool("Wood Axe", "woodcutting", 0, 0),
    "Forged Axe": GatheringTool("Forged Axe", "woodcutting", 2, 1),
    "Mining Pick": GatheringTool("Mining Pick", "mining", 0, 0),
    "Forged Mining Pick": GatheringTool("Forged Mining Pick", "mining", 2, 1),
}


CRAFT_RECIPES = {
    "lumber": CraftRecipe(
        "lumber", "Cut Lumber", "Saw two logs into construction lumber.", "workbench",
        (("Log", 2),), "Lumber", 1, ITEM_DESCRIPTIONS["Lumber"], 1, 20,
    ),
    "stone_block": CraftRecipe(
        "stone_block", "Cut Stone Block", "Shape two pieces of stone into one construction block.", "workbench",
        (("Stone", 2),), "Stone Block", 1, ITEM_DESCRIPTIONS["Stone Block"], 1, 25,
    ),
    "iron_ingot": CraftRecipe(
        "iron_ingot", "Forge Iron Ingot", "Refine iron ore into a usable iron ingot.", "forge",
        (("Iron Ore", 2),), "Iron Ingot", 1, ITEM_DESCRIPTIONS["Iron Ingot"], 2, 35,
    ),
    "forged_axe": CraftRecipe(
        "forged_axe", "Forge Reinforced Axe", "Fit a forged iron axe head to a prepared wooden handle.", "forge",
        (("Lumber", 2), ("Iron Ingot", 2)), "Forged Axe", 1, ITEM_DESCRIPTIONS["Forged Axe"], 4, 60,
    ),
    "forged_pick": CraftRecipe(
        "forged_pick", "Forge Reinforced Mining Pick", "Fit a forged iron pick head to a prepared wooden handle.", "forge",
        (("Lumber", 2), ("Iron Ingot", 3)), "Forged Mining Pick", 1, ITEM_DESCRIPTIONS["Forged Mining Pick"], 5, 70,
    ),
}

RAW_MATERIALS = {"Log", "Stone", "Iron Ore"}
PROCESSED_MATERIALS = {"Lumber", "Stone Block", "Iron Ingot"}
