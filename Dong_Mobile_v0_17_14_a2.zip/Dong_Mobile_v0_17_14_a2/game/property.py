from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class StructureDef:
    key: str
    name: str
    description: str
    cost: int
    duration_seconds: int
    game_minutes: int
    rooms: tuple[str, ...]
    storage_capacity: int
    comfort: int
    rest_hp: int
    rest_stamina: int
    animal_capacity: int = 0
    allowed_animals: tuple[str, ...] = ()
    materials: tuple[tuple[str, int], ...] = ()


@dataclass(frozen=True)
class FurnitureDef:
    name: str
    price: int
    description: str
    allowed_rooms: tuple[str, ...]
    comfort: int = 0
    storage_capacity: int = 0
    rest_hp_bonus: int = 0
    rest_stamina_bonus: int = 0


STRUCTURES = {
    "garage": StructureDef(
        "garage",
        "Garage",
        "A timber-framed garage with a reinforced floor, enclosed vehicle bay, work area, and lockable storage.",
        850,
        45,
        300,
        ("Garage",),
        25,
        0,
        0,
        0,
        materials=(("Lumber", 10), ("Stone Block", 5), ("Iron Ingot", 2)),
    ),
    "workbench": StructureDef(
        "workbench",
        "Workbench",
        "A heavy timber workbench fitted for cutting, shaping, and assembling construction materials.",
        50,
        18,
        90,
        ("Workshop",),
        10,
        0,
        0,
        0,
        materials=(("Log", 6),),
    ),
    "forge": StructureDef(
        "forge",
        "Stone Forge",
        "A masonry forge with a firebox, anvil space, and basic metalworking tools.",
        200,
        35,
        180,
        ("Forge",),
        10,
        0,
        0,
        0,
        materials=(("Lumber", 2), ("Stone Block", 6)),
    ),
    "stable": StructureDef(
        "stable",
        "Stable",
        "A timber stable with two enclosed stalls, a tack area, and protected feed storage.",
        950,
        45,
        300,
        ("Tack Room",),
        15,
        0,
        0,
        0,
        animal_capacity=2,
        allowed_animals=("horse",),
        materials=(("Lumber", 12), ("Stone Block", 4)),
    ),
    "farm_stand": StructureDef(
        "farm_stand",
        "Farm Stand",
        "A small roadside sales building with a counter and covered display area.",
        450,
        30,
        180,
        ("Sales Counter",),
        10,
        0,
        0,
        0,
        materials=(("Lumber", 6),),
    ),
    "small_shop": StructureDef(
        "small_shop",
        "Small Shop",
        "A compact retail building with a sales floor and rear stock room.",
        1200,
        55,
        420,
        ("Sales Floor", "Stock Room"),
        30,
        0,
        0,
        0,
        materials=(("Lumber", 12), ("Stone Block", 4)),
    ),
    "roadside_bar": StructureDef(
        "roadside_bar",
        "Roadside Bar",
        "A public house with a service counter, seating area, and rear storage room.",
        1800,
        70,
        540,
        ("Bar Room", "Back Room"),
        25,
        1,
        0,
        0,
        materials=(("Lumber", 14), ("Stone Block", 6)),
    ),
    "chicken_coop": StructureDef(
        "chicken_coop",
        "Chicken Coop",
        "A sheltered timber coop with nesting boxes and a small enclosed run.",
        250,
        25,
        120,
        (),
        5,
        0,
        0,
        0,
        animal_capacity=6,
        allowed_animals=("chicken",),
        materials=(("Lumber", 5),),
    ),
    "small_barn": StructureDef(
        "small_barn",
        "Small Barn",
        "A compact livestock barn with stalls, feed space, and basic shelter from weather.",
        700,
        40,
        240,
        ("Barn Storage",),
        25,
        0,
        0,
        0,
        animal_capacity=4,
        allowed_animals=("goat", "cow", "pig"),
        materials=(("Lumber", 10), ("Stone Block", 4)),
    ),
    "garden_plot": StructureDef(
        "garden_plot",
        "Garden Plot",
        "A cleared and prepared section of soil divided into four planting beds.",
        75,
        12,
        60,
        (),
        0,
        0,
        0,
        0,
    ),
    "storage_shed": StructureDef(
        "storage_shed",
        "Storage Shed",
        "A small timber shed for tools, supplies, and stored goods.",
        120,
        20,
        60,
        ("Storage",),
        40,
        0,
        0,
        0,
        materials=(("Lumber", 4),),
    ),
    "wooden_shack": StructureDef(
        "wooden_shack",
        "Wooden Shack",
        "A simple one-room wooden shelter with a solid roof and lockable door.",
        350,
        30,
        180,
        ("Main Room",),
        15,
        2,
        5,
        7,
        materials=(("Lumber", 8),),
    ),
    "small_cabin": StructureDef(
        "small_cabin",
        "Small Cabin",
        "A permanent timber home with a living area and separate bedroom.",
        900,
        45,
        360,
        ("Living Area", "Bedroom"),
        30,
        4,
        8,
        10,
        materials=(("Lumber", 12), ("Stone Block", 4)),
    ),
    "fire_pit": StructureDef(
        "fire_pit",
        "Fire Pit",
        "A stone-lined outdoor fire pit for warmth and basic cooking.",
        40,
        8,
        30,
        (),
        0,
        1,
        0,
        1,
        materials=(("Stone", 5),),
    ),
}


FURNITURE = {
    "Cheap Bed": FurnitureDef(
        "Cheap Bed",
        90,
        "A basic bed frame with a thin mattress.",
        ("Bedroom", "Main Room"),
        comfort=1,
        rest_hp_bonus=1,
        rest_stamina_bonus=2,
    ),
    "Wooden Chair": FurnitureDef(
        "Wooden Chair",
        25,
        "A plain wooden chair built for everyday use.",
        ("Living Area", "Bedroom", "Main Room", "Storage"),
        comfort=1,
    ),
    "Small Table": FurnitureDef(
        "Small Table",
        40,
        "A compact wooden table suitable for meals, work, or storage.",
        ("Living Area", "Bedroom", "Main Room", "Storage"),
        comfort=1,
    ),
    "Old Couch": FurnitureDef(
        "Old Couch",
        75,
        "A worn but usable upholstered couch.",
        ("Living Area", "Main Room"),
        comfort=2,
    ),
    "Bookshelf": FurnitureDef(
        "Bookshelf",
        60,
        "A tall wooden shelf for books and small objects.",
        ("Living Area", "Bedroom", "Main Room"),
        comfort=1,
    ),
    "Storage Chest": FurnitureDef(
        "Storage Chest",
        50,
        "A wooden chest with a hinged lid and simple latch.",
        ("Living Area", "Bedroom", "Main Room", "Storage"),
        storage_capacity=10,
    ),
    "Floor Lamp": FurnitureDef(
        "Floor Lamp",
        30,
        "A standing electric lamp with a fabric shade.",
        ("Living Area", "Bedroom", "Main Room"),
        comfort=1,
    ),
}


FURNITURE_STORE = tuple(FURNITURE.values())
