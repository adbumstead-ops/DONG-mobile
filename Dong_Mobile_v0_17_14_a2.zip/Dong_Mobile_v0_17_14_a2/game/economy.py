from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Job:
    key: str
    name: str
    description: str
    pay: int
    stamina_cost: int
    duration_seconds: int
    work_xp: int
    game_minutes: int
    skill_name: str | None = None
    skill_xp: int = 0
    location_key: str = "millhaven"
    requires_motor_vehicle: bool = False


JOBS = {
    # Millhaven
    "flyers": Job("flyers", "Flyer Delivery", "Deliver local advertising to residential mailboxes throughout Millhaven.", 12, 2, 10, 1, 45),
    "dishwashing": Job("dishwashing", "Dishwashing", "Wash dishes and clean work surfaces in a local restaurant kitchen.", 20, 4, 20, 2, 90),
    "warehouse": Job("warehouse", "Warehouse Shift", "Move, sort, and stack boxed goods in a small distribution warehouse.", 35, 7, 30, 4, 180),
    "roadside": Job("roadside", "Roadside Cleanup", "Collect litter and roadside debris along the county approach to Millhaven.", 16, 3, 15, 2, 60),
    "forestry": Job("forestry", "Forestry Crew", "Cut and move marked timber on a managed forestry site outside Millhaven.", 28, 4, 20, 3, 120, "Woodcutting", 3),
    "quarry": Job("quarry", "Quarry Hand", "Break, sort, and load stone at the county quarry.", 32, 5, 25, 3, 150, "Mining", 3),
    "workshop": Job("workshop", "Workshop Assistant", "Prepare materials, maintain tools, and assist with basic fabrication work.", 24, 3, 18, 2, 105, "Crafting", 3),
    "delivery_driver": Job("delivery_driver", "Independent Delivery Route", "Collect local parcels and complete a scheduled delivery route using your own motor vehicle.", 48, 3, 24, 4, 120, "Driving", 3, "millhaven", True),

    # Redwater
    "redwater_factory": Job("redwater_factory", "Factory Line Worker", "Work a production shift in one of Redwater's older manufacturing plants.", 56, 6, 30, 5, 240, None, 0, "redwater"),
    "redwater_freight": Job("redwater_freight", "Freight Loader", "Load palletized freight and secure outbound cargo at the river warehouses.", 62, 7, 32, 5, 240, None, 0, "redwater"),
    "redwater_salvage": Job("redwater_salvage", "Salvage Yard Hand", "Sort reusable metal, mechanical parts, and scrap at a commercial salvage yard.", 52, 5, 26, 4, 180, "Crafting", 2, "redwater"),

    # Lake Mercy
    "lake_marina": Job("lake_marina", "Marina Hand", "Move supplies, clean slips, and assist with small boats at the Lake Mercy marina.", 42, 4, 22, 3, 150, None, 0, "lake_mercy"),
    "lake_lodge": Job("lake_lodge", "Lodge Housekeeper", "Clean guest rooms and common areas at a lakeside lodge.", 38, 3, 20, 3, 135, None, 0, "lake_mercy"),
    "lake_grounds": Job("lake_grounds", "Grounds Crew", "Maintain paths, lawns, and shoreline access around public lake facilities.", 44, 5, 24, 4, 165, "Woodcutting", 1, "lake_mercy"),

    # Greybridge
    "greybridge_office": Job("greybridge_office", "Office Temp", "Process files and basic administrative work for a downtown office contractor.", 72, 3, 28, 5, 240, None, 0, "greybridge_city"),
    "greybridge_hospital": Job("greybridge_hospital", "Hospital Porter", "Move supplies and equipment between departments at Greybridge Central Hospital.", 78, 5, 30, 5, 240, None, 0, "greybridge_city"),
    "greybridge_courier": Job("greybridge_courier", "City Courier", "Deliver documents and small parcels across the central business district.", 84, 5, 28, 6, 210, "Driving", 2, "greybridge_city"),
    "airport_baggage": Job("airport_baggage", "Airport Baggage Handler", "Load and transfer passenger baggage between terminal and aircraft service areas.", 92, 7, 34, 6, 270, None, 0, "greybridge_airport"),

    # Hollow Creek
    "hollow_orchard": Job("hollow_orchard", "Orchard Hand", "Pick, sort, and load produce on a commercial orchard outside Hollow Creek.", 46, 5, 24, 4, 180, "Farming", 3, "hollow_creek"),
    "hollow_sawmill": Job("hollow_sawmill", "Sawmill Crew", "Handle cut timber and finished lumber at the valley sawmill.", 58, 6, 28, 5, 210, "Woodcutting", 3, "hollow_creek"),

    # Pine Ridge
    "ridge_road": Job("ridge_road", "Highland Road Crew", "Clear drainage, repair shoulders, and maintain safety barriers along the mountain highway.", 68, 7, 30, 5, 225, None, 0, "pine_ridge"),
    "ridge_mine": Job("ridge_mine", "Mine Crew", "Work a supervised extraction and material-handling shift at Pine Ridge Mine.", 82, 8, 34, 6, 270, "Mining", 4, "pine_ridge"),

    # Westhaven
    "westhaven_dock": Job("westhaven_dock", "Dock Worker", "Move cargo and secure loads at the Westhaven commercial harbour.", 88, 7, 32, 6, 240, None, 0, "westhaven"),
    "westhaven_fishplant": Job("westhaven_fishplant", "Fish Plant Worker", "Sort, pack, and move processed catch at a waterfront plant.", 74, 5, 28, 5, 210, None, 0, "westhaven"),
    "westhaven_hotel": Job("westhaven_hotel", "Hotel Housekeeper", "Clean rooms and service public areas at a busy waterfront hotel.", 66, 4, 26, 5, 195, None, 0, "westhaven"),
}


@dataclass(frozen=True)
class StoreItem:
    name: str
    price: int
    description: str


STORE_ITEMS = [
    StoreItem("Granola Bar", 3, "A wrapped granola bar. Restores 4 HP during combat."),
    StoreItem("Water Bottle", 2, "A sealed bottle of drinking water."),
    StoreItem("Bandage", 8, "A basic sterile bandage. Restores 7 HP during combat."),
    StoreItem("Cheap Flashlight", 12, "A small plastic flashlight powered by replaceable batteries."),
    StoreItem("Work Gloves", 15, "Thick work gloves that protect the hands from dirt and rough surfaces."),
    StoreItem("Pocket Knife", 20, "A small folding knife that can be equipped as a weapon."),
    StoreItem("Basic Tool Kit", 30, "A compact set of common hand tools."),
    StoreItem("Wood Axe", 30, "A practical axe designed for felling and trimming small trees."),
    StoreItem("Mining Pick", 35, "A steel-headed pick designed for breaking stone and exposing ore."),
    StoreItem("Fishing Rod", 45, "A basic freshwater rod with line, reel, and a small tackle set."),
    StoreItem("Camping Chair", 18, "A folding fabric chair with a lightweight metal frame."),
    StoreItem("Camping Kit", 55, "A compact tent, groundsheet, and basic camp equipment for temporary wilderness shelter."),
    StoreItem("Hunting Rifle", 180, "A legally sold hunting firearm used by licensed hunters. Hunting actions are resolved abstractly."),
]
