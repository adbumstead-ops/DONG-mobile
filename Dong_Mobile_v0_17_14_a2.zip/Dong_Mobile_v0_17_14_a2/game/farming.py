from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CropDef:
    key: str
    name: str
    seed_item: str
    seed_price: int
    produce_item: str
    produce_description: str
    description: str
    grow_seconds: int
    min_yield: int
    max_yield: int
    sale_price: int


CROPS = {
    "carrot": CropDef(
        "carrot",
        "Carrots",
        "Carrot Seeds",
        3,
        "Carrot",
        "A fresh carrot harvested from cultivated soil.",
        "A hardy root crop suited to a small garden plot.",
        25,
        2,
        4,
        2,
    ),
    "potato": CropDef(
        "potato",
        "Potatoes",
        "Potato Seed Pieces",
        4,
        "Potato",
        "A firm potato harvested from the garden.",
        "A reliable field crop that grows well in cool soil.",
        35,
        2,
        4,
        3,
    ),
    "tomato": CropDef(
        "tomato",
        "Tomatoes",
        "Tomato Seeds",
        6,
        "Tomato",
        "A ripe tomato harvested from a garden plant.",
        "A warm-season crop that takes longer to mature but produces several fruits.",
        45,
        3,
        5,
        3,
    ),
    "corn": CropDef(
        "corn",
        "Corn",
        "Corn Seed",
        8,
        "Corn",
        "A mature ear of corn harvested from the garden.",
        "A taller crop with a longer growing period and a dependable harvest.",
        60,
        2,
        4,
        4,
    ),
}

SEED_ITEMS = {crop.seed_item: crop for crop in CROPS.values()}
PRODUCE_ITEMS = {crop.produce_item: crop for crop in CROPS.values()}
GARDEN_CAPACITY = 4
