from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ConversationOption:
    key: str
    label: str
    response: str
    friendship: int = 1
    speech_xp: int = 1


@dataclass(frozen=True)
class ScheduleBlock:
    start_minute: int
    end_minute: int
    world_location: str
    activity: str


@dataclass(frozen=True)
class NPCDef:
    key: str
    name: str
    occupation: str
    description: str
    home_area: str
    schedule: tuple[ScheduleBlock, ...]
    conversation: tuple[ConversationOption, ...]
    marital_status: str = "single"
    spouse_name: str | None = None
    children: tuple[tuple[str, str], ...] = ()
    romanceable: bool = True
    age_group: str = "adult"


def _standard_conversation(work_response: str, town_response: str, personal_response: str) -> tuple[ConversationOption, ...]:
    return (
        ConversationOption("work", "Ask about their work", work_response, friendship=1, speech_xp=1),
        ConversationOption("town", "Ask about Millhaven", town_response, friendship=1, speech_xp=1),
        ConversationOption("personal", "Ask how they are doing", personal_response, friendship=2, speech_xp=1),
    )


NPCS: dict[str, NPCDef] = {
    "mara_venn": NPCDef(
        "mara_venn",
        "Mara Venn",
        "General Store Proprietor",
        "Mara has run the general store for most of her adult life. She knows the rhythms of Millhaven and keeps careful track of what the town needs.",
        "Millhaven North",
        (
            ScheduleBlock(420, 1140, "millhaven", "Working at the General Store"),
            ScheduleBlock(1140, 1260, "millhaven", "Walking home through Main Street"),
        ),
        _standard_conversation(
            "Mara says supply deliveries have been reliable, though prices have been rising on some goods.",
            "Mara says Millhaven has changed slowly. Most people still know each other, even if they do not always agree.",
            "Mara says she is tired but well. She has been trying to keep the store stocked without carrying more debt than necessary.",
        ),
        marital_status="married", spouse_name="Gideon Venn", children=(("Elise Venn", "Adult Daughter"),), romanceable=False,
    ),
    "eli_mercer": NPCDef(
        "eli_mercer",
        "Eli Mercer",
        "Employment Office Clerk",
        "Eli handles temporary work placements and keeps records for local contractors. He speaks carefully and rarely wastes words.",
        "Millhaven West",
        (
            ScheduleBlock(480, 1020, "millhaven", "Working at the Employment Office"),
            ScheduleBlock(1020, 1110, "millhaven", "Finishing paperwork on Main Street"),
        ),
        _standard_conversation(
            "Eli says there is usually work for anyone willing to take short shifts, especially around warehouses and road crews.",
            "Eli says the town depends on the highway and the old industrial lots more than most residents like to admit.",
            "Eli says he is doing well enough. The office has been busier since more people began settling outside town.",
        ),
        marital_status="married", spouse_name="Hannah Mercer", children=(("Noah Mercer", "Young Son"),), romanceable=False,
    ),
    "ruth_calder": NPCDef(
        "ruth_calder",
        "Ruth Calder",
        "Farm Supply Owner",
        "Ruth grew up on a farm south of Millhaven and now supplies seed, feed, tools, and livestock to properties throughout the county.",
        "South Fields",
        (
            ScheduleBlock(360, 1020, "millhaven", "Working at Millhaven Farm Supply"),
            ScheduleBlock(1020, 1140, "millhaven", "Checking deliveries near the south road"),
        ),
        _standard_conversation(
            "Ruth says the season has been steady so far. Feed is moving quickly, and several new plots have begun producing vegetables.",
            "Ruth says the land around Millhaven is varied. Some plots are easy to work, while others need years of clearing and drainage.",
            "Ruth says she still prefers being outside the store when she can manage it. She misses working land full time.",
        ),
        marital_status="single", romanceable=True,
    ),
    "daniel_rowe": NPCDef(
        "daniel_rowe",
        "Daniel Rowe",
        "Furniture Maker",
        "Daniel builds and restores practical furniture in a workshop behind Millhaven Furnishings. Much of his stock is made locally.",
        "Millhaven East",
        (
            ScheduleBlock(540, 1080, "millhaven", "Working at Millhaven Furnishings"),
            ScheduleBlock(1080, 1200, "millhaven", "Closing the workshop"),
        ),
        _standard_conversation(
            "Daniel says most orders are simple beds, tables, and storage pieces. He prefers repairs when customers are willing to wait for them.",
            "Daniel says the older houses in town were built to last, but many have needed major work in recent years.",
            "Daniel says he has been sleeping poorly. The workshop is busy enough that he has been staying late most nights.",
        ),
        marital_status="single", romanceable=True,
    ),
    "lena_voss": NPCDef(
        "lena_voss",
        "Lena Voss",
        "Clinic Nurse",
        "Lena works at the small clinic near Main Street. She is direct, observant, and accustomed to dealing with injuries from farms, roads, and the forest.",
        "Millhaven Centre",
        (
            ScheduleBlock(420, 900, "millhaven", "Working at the clinic"),
            ScheduleBlock(1020, 1140, "blackwood_trail", "Walking the lower section of Blackwood Trail"),
            ScheduleBlock(1140, 1260, "millhaven", "Returning through Millhaven"),
        ),
        _standard_conversation(
            "Lena says most injuries she treats come from tools, animals, and road accidents. She advises keeping proper bandages close at hand.",
            "Lena says Millhaven is quiet until it is not. The clinic sees the consequences of nearly every bad decision made within twenty kilometres.",
            "Lena says she has been trying to walk more after work. The lower trail is usually quiet before dark.",
        ),
        marital_status="single", romanceable=True,
    ),
    "owen_pike": NPCDef(
        "owen_pike",
        "Owen Pike",
        "Mechanic",
        "Owen repairs farm equipment, older cars, and small engines from a garage on the edge of town. He keeps most conversations practical.",
        "Old County Road",
        (
            ScheduleBlock(450, 1110, "millhaven", "Working at the roadside garage"),
            ScheduleBlock(1110, 1230, "millhaven", "Cleaning the garage and closing for the night"),
        ),
        _standard_conversation(
            "Owen says older vehicles are easier to keep running if their owners pay attention before something fails completely.",
            "Owen says traffic on the county road has increased since more land began changing hands outside town.",
            "Owen says he is fine. He has several engines waiting for parts and expects a long week.",
        ),
        marital_status="married", spouse_name="Priya Pike", children=(("Megan Pike", "Teenage Daughter"),), romanceable=False,
    ),
    "nora_bell": NPCDef(
        "nora_bell",
        "Nora Bell",
        "Retired Teacher",
        "Nora taught at Millhaven's school for more than thirty years. She still walks into town most mornings and knows several generations of local families.",
        "Lake Mercy",
        (
            ScheduleBlock(540, 690, "millhaven", "Walking along Main Street"),
            ScheduleBlock(840, 990, "blackwood_trail", "Walking near the trail entrance"),
            ScheduleBlock(990, 1080, "millhaven", "Returning through town"),
        ),
        _standard_conversation(
            "Nora says retirement has given her time to read again. She still helps a few former students with paperwork when they ask.",
            "Nora says Millhaven has survived because people tend to stay connected, even when work and families pull them in different directions.",
            "Nora says she is content with a quieter life. She walks most days and visits the lake whenever the weather is clear.",
        ),
        marital_status="widowed", spouse_name="Arthur Bell", children=(("Clara Bell", "Adult Daughter"), ("Stephen Bell", "Adult Son")), romanceable=True,
    ),
    "darius_vale": NPCDef(
        "darius_vale",
        "Darius Vale",
        "Grey Lantern Regular",
        "Darius spends most evenings at the Grey Lantern. He speaks quietly, keeps his business private, and is known to people involved in Millhaven's illicit trade.",
        "Millhaven South",
        (
            ScheduleBlock(0, 120, "millhaven", "At the Grey Lantern"),
            ScheduleBlock(1200, 1440, "millhaven", "At the Grey Lantern"),
        ),
        _standard_conversation(
            "Darius says most people who chase quick money eventually learn that every arrangement carries a cost.",
            "Darius says Millhaven looks quiet from the highway, but there is more movement after dark than most residents notice.",
            "Darius says he keeps his circle small and does not discuss private business without a reason.",
        ),
        marital_status="single", romanceable=False,
    ),
    "thomas_hale": NPCDef(
        "thomas_hale",
        "Thomas Hale",
        "County Ranger",
        "Thomas patrols the wooded roads and public trails north of Millhaven. He spends more time outside town than in it.",
        "Pine Ridge",
        (
            ScheduleBlock(360, 720, "blackwood_trail", "Patrolling Blackwood Trail"),
            ScheduleBlock(720, 810, "millhaven", "Stopping in Millhaven for supplies"),
            ScheduleBlock(810, 1140, "blackwood_trail", "Patrolling the northern trail"),
        ),
        _standard_conversation(
            "Thomas says animal movement has been heavier near the trail this week. He recommends staying on known paths after dark.",
            "Thomas says Millhaven is close enough to the forest that changes in one quickly affect the other.",
            "Thomas says the work has been routine. He has been checking damaged markers and watching for signs of illegal dumping.",
        ),
        marital_status="single", romanceable=True,
    ),
}


def _regional_conversation(place: str, work_response: str, place_response: str, personal_response: str) -> tuple[ConversationOption, ...]:
    return (
        ConversationOption("work", "Ask about their work", work_response, friendship=1, speech_xp=1),
        ConversationOption("town", f"Ask about {place}", place_response, friendship=1, speech_xp=1),
        ConversationOption("personal", "Ask how they are doing", personal_response, friendship=2, speech_xp=1),
    )


# v0.15 regional residents. These people have their own households and routines before the
# player arrives; single adults can become romance candidates through the existing system.
NPCS.update({
    "mina_cross": NPCDef(
        "mina_cross", "Mina Cross", "Factory Supervisor",
        "Mina supervises one of Redwater's surviving manufacturing lines and has spent most of her working life around heavy industry.",
        "Redwater North",
        (ScheduleBlock(360, 960, "redwater", "Working at the factory office"), ScheduleBlock(960, 1080, "redwater_industrial", "Checking the loading yard")),
        _regional_conversation("Redwater",
            "Mina says the plant is short of experienced workers and loses time whenever freight arrives late.",
            "Mina says Redwater has always been built around work. When the factories slow down, the entire town feels it.",
            "Mina says the hours have been long but manageable. She is trying to spend more evenings at home."),
        marital_status="married", spouse_name="Andre Cross", children=(("Leah Cross", "Teenage Daughter"),), romanceable=False,
    ),
    "joel_strickland": NPCDef(
        "joel_strickland", "Joel Strickland", "Salvage Yard Owner",
        "Joel owns a large salvage yard near the industrial rail line. He buys damaged equipment, scrap metal, and unwanted machinery from across the district.",
        "Redwater South",
        (ScheduleBlock(480, 1080, "redwater_industrial", "Working at the salvage yard"), ScheduleBlock(1080, 1200, "redwater", "Closing accounts in town")),
        _regional_conversation("Redwater",
            "Joel says nearly everything has value if it can be sorted, repaired, or stripped for usable parts.",
            "Joel says Redwater looks worn because people replace less than they used to. A great deal of the town is repaired rather than rebuilt.",
            "Joel says business has been steady. He spends most of his free time restoring an old truck."),
        marital_status="single", romanceable=True,
    ),
    "claire_benton": NPCDef(
        "claire_benton", "Claire Benton", "Lakeside Lodge Manager",
        "Claire manages a small lodge overlooking Lake Mercy. She handles bookings, staff, maintenance, and the seasonal changes in tourism.",
        "Lake Mercy",
        (ScheduleBlock(420, 1020, "lake_mercy", "Working at the lakeside lodge"), ScheduleBlock(1020, 1140, "lake_mercy_north_shore", "Walking the north shoreline")),
        _regional_conversation("Lake Mercy",
            "Claire says summer bookings support most of the lodge's quieter months and every room has to be ready before the weekend traffic arrives.",
            "Claire says the lake changes character with the season. The north shore is still quiet enough to feel removed from town.",
            "Claire says she is doing well. She has been considering whether to stay at the lodge year-round."),
        marital_status="single", romanceable=True,
    ),
    "silas_reed": NPCDef(
        "silas_reed", "Silas Reed", "Marina Keeper",
        "Silas maintains slips, fuel equipment, storage sheds, and small rental boats at the Lake Mercy marina.",
        "Lake Mercy West",
        (ScheduleBlock(360, 1080, "lake_mercy", "Working at the marina"),),
        _regional_conversation("Lake Mercy",
            "Silas says the marina has been busy since the roads improved. Most problems still come from weather and neglected equipment.",
            "Silas says the lake is safest when people respect how quickly wind and visibility can change.",
            "Silas says he is looking forward to a quiet evening with his family after closing."),
        marital_status="married", spouse_name="Maya Reed", children=(("Evan Reed", "Young Son"),), romanceable=False,
    ),
    "jae_moreno": NPCDef(
        "jae_moreno", "Jae Moreno", "Department Store Manager",
        "Jae manages a large downtown department store and coordinates staff, inventory, deliveries, and security across several floors.",
        "Greybridge Central",
        (ScheduleBlock(540, 1140, "greybridge_city", "Working downtown"),),
        _regional_conversation("Greybridge",
            "Jae says the store moves more inventory in a day than some smaller towns sell in a week.",
            "Jae says Greybridge can feel anonymous at first, but every neighbourhood develops its own routines and familiar faces.",
            "Jae says work has been demanding but satisfying. They have been trying to make more time outside the city centre."),
        marital_status="single", romanceable=True,
    ),
    "amara_chen": NPCDef(
        "amara_chen", "Dr. Amara Chen", "Hospital Physician",
        "Amara works long rotations at Greybridge Central Hospital and regularly sees patients transferred from smaller regional clinics.",
        "Greybridge East",
        (ScheduleBlock(420, 960, "greybridge_city", "Working at Greybridge Central Hospital"),),
        _regional_conversation("Greybridge",
            "Amara says the hospital receives everything from routine injuries to serious transfers from remote towns.",
            "Amara says the city offers resources smaller communities cannot, but the pace can be exhausting.",
            "Amara says she is tired but well and expects another long shift tomorrow."),
        marital_status="married", spouse_name="Nadia Chen", children=(), romanceable=False,
    ),
    "tessa_ward": NPCDef(
        "tessa_ward", "Tessa Ward", "Airport Operations Coordinator",
        "Tessa works across the passenger and freight terminals at Greybridge International Airport, coordinating ground operations and delayed movements.",
        "Greybridge South",
        (ScheduleBlock(360, 960, "greybridge_airport", "Working in airport operations"), ScheduleBlock(960, 1080, "greybridge_city", "Returning through the city")),
        _regional_conversation("Greybridge",
            "Tessa says the airport never truly closes. Passenger traffic slows overnight, but freight movements continue.",
            "Tessa says Greybridge feels smaller after enough time working at the airport because every road eventually seems to lead back to the terminals.",
            "Tessa says she enjoys the work despite the schedule and tries to leave the city whenever she gets several days off."),
        marital_status="single", romanceable=True,
    ),
    "hazel_quinn": NPCDef(
        "hazel_quinn", "Hazel Quinn", "Sawmill Bookkeeper",
        "Hazel manages payroll, purchasing, and shipping records for the Hollow Creek sawmill. She has lived in the valley for most of her life.",
        "Hollow Creek",
        (ScheduleBlock(450, 990, "hollow_creek_sawmill", "Working at the sawmill office"), ScheduleBlock(990, 1110, "hollow_creek", "Buying supplies in town")),
        _regional_conversation("Hollow Creek",
            "Hazel says timber prices have been stable, but transport costs decide whether a good month remains profitable.",
            "Hazel says the valley changes slowly. Families leave and return, while the orchards and mills keep much the same rhythm.",
            "Hazel says she has learned to appreciate a quiet house after years of caring for other people."),
        marital_status="widowed", spouse_name="David Quinn", children=(("Rose Quinn", "Adult Daughter"),), romanceable=True,
    ),
    "iris_shaw": NPCDef(
        "iris_shaw", "Iris Shaw", "Highland Ranger",
        "Iris patrols mountain roads and public land around Pine Ridge, checking trail conditions, weather damage, and isolated access routes.",
        "Pine Ridge",
        (ScheduleBlock(360, 780, "pine_ridge", "Checking highland roads"), ScheduleBlock(780, 1080, "pine_ridge_mine", "Inspecting the mine access corridor")),
        _regional_conversation("Pine Ridge",
            "Iris says mountain conditions punish poor preparation quickly, even when the weather looks stable in the valley.",
            "Iris says Pine Ridge is isolated but not empty. Mining, road crews, and forestry keep people moving through the pass year-round.",
            "Iris says she prefers the quiet of the highlands and has never seriously considered leaving."),
        marital_status="single", romanceable=True,
    ),
    "caleb_north": NPCDef(
        "caleb_north", "Caleb North", "Mine Foreman",
        "Caleb supervises crews at Pine Ridge Mine and is responsible for shift assignments, equipment access, and production targets.",
        "Pine Ridge",
        (ScheduleBlock(300, 960, "pine_ridge_mine", "Supervising the mine shift"), ScheduleBlock(960, 1080, "pine_ridge", "Returning to town")),
        _regional_conversation("Pine Ridge",
            "Caleb says the mine pays well because the work is difficult and the weather complicates nearly every operation.",
            "Caleb says Pine Ridge survives on the mine, road crews, and the people willing to live far from larger towns.",
            "Caleb says his family has adapted to the highlands and has no plan to move."),
        marital_status="married", spouse_name="Elena North", children=(("Cole North", "Young Son"), ("Anna North", "Young Daughter")), romanceable=False,
    ),
    "sofia_vale": NPCDef(
        "sofia_vale", "Sofia Vale", "Dock Coordinator",
        "Sofia coordinates loading windows and vehicle access at Westhaven's commercial docks. Her work follows ship schedules more than ordinary business hours.",
        "Westhaven Harbour",
        (ScheduleBlock(420, 1020, "westhaven_terminal", "Coordinating dock traffic"), ScheduleBlock(1020, 1140, "westhaven", "Walking the waterfront")),
        _regional_conversation("Westhaven",
            "Sofia says the port can move smoothly for hours and then become crowded within minutes when several ships arrive together.",
            "Sofia says Westhaven has always faced outward. News, goods, and people arrive by water before the rest of the region hears about them.",
            "Sofia says she likes the harbour but sometimes wants a place where she cannot hear machinery at night."),
        marital_status="single", romanceable=True,
    ),
    "martin_ross": NPCDef(
        "martin_ross", "Martin Ross", "Waterfront Hotel Manager",
        "Martin manages a large hotel near Westhaven harbour and handles staff, guests, events, and the constant turnover of coastal travel.",
        "Westhaven Central",
        (ScheduleBlock(480, 1080, "westhaven", "Working at the waterfront hotel"),),
        _regional_conversation("Westhaven",
            "Martin says the hotel fills whenever port traffic or regional events bring people into the city.",
            "Martin says Westhaven is expensive, crowded, and difficult to leave once someone becomes used to the coast.",
            "Martin says his family rarely sees him during the busiest travel weeks."),
        marital_status="married", spouse_name="Evelyn Ross", children=(("Liam Ross", "Teenage Son"),), romanceable=False,
    ),
})



def npc_schedule_state(npc: NPCDef, time_minutes: int) -> tuple[str, str]:
    minute = time_minutes % 1440
    for block in npc.schedule:
        if block.start_minute <= minute < block.end_minute:
            return block.world_location, block.activity
    return "home", f"At home in {npc.home_area}"


def relationship_label(friendship: int) -> str:
    if friendship >= 40:
        return "Close Friend"
    if friendship >= 25:
        return "Friend"
    if friendship >= 12:
        return "Familiar"
    if friendship >= 4:
        return "Acquaintance"
    return "Stranger"


def customer_npc_keys() -> tuple[str, ...]:
    return tuple(NPCS.keys())
