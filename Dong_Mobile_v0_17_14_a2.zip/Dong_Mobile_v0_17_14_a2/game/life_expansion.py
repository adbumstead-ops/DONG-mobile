from __future__ import annotations

from dataclasses import dataclass


SEASON_LENGTH_DAYS = 30
SEASONS = ("Spring", "Summer", "Autumn", "Winter")

WEATHER_BY_SEASON = {
    "Spring": ("Light Rain", "Cloudy", "Clear", "Heavy Rain", "Fog"),
    "Summer": ("Clear", "Clear", "Warm", "Cloudy", "Thunderstorms"),
    "Autumn": ("Cloudy", "Light Rain", "Windy", "Fog", "Clear"),
    "Winter": ("Cold", "Snow", "Overcast", "Clear", "Heavy Snow"),
}


def season_for_day(day: int) -> str:
    return SEASONS[((max(1, day) - 1) // SEASON_LENGTH_DAYS) % len(SEASONS)]


def weather_for_day(day: int, region_key: str) -> str:
    season = season_for_day(day)
    options = WEATHER_BY_SEASON[season]
    salt = sum(ord(ch) for ch in region_key)
    return options[(day * 7 + salt) % len(options)]


@dataclass(frozen=True)
class EducationProgram:
    key: str
    name: str
    description: str
    tuition: int
    sessions: int
    certificate: str


EDUCATION_PROGRAMS = {
    "general_studies": EducationProgram("general_studies", "General Studies Certificate", "A broad adult-education program covering communication, mathematics, records, and workplace fundamentals.", 240, 5, "General Studies"),
    "criminal_justice": EducationProgram("criminal_justice", "Criminal Justice Certificate", "A formal program covering law, public safety, report writing, ethics, and justice-system procedure.", 520, 7, "Criminal Justice"),
    "emergency_care": EducationProgram("emergency_care", "Emergency Care Certificate", "A practical healthcare program covering patient support, emergency response, documentation, and clinical safety.", 480, 7, "Emergency Care"),
    "mechanics": EducationProgram("mechanics", "Automotive Mechanics Certificate", "A technical program covering vehicle systems, inspection, maintenance, and workshop practice.", 460, 6, "Automotive Mechanics"),
    "business": EducationProgram("business", "Small Business Certificate", "A business program covering bookkeeping, inventory, staffing, purchasing, and basic commercial management.", 420, 6, "Small Business"),
    "forestry": EducationProgram("forestry", "Forestry Certificate", "A land-management program covering timber operations, conservation, worksite safety, and forestry planning.", 400, 6, "Forestry"),
    "mining": EducationProgram("mining", "Mining Operations Certificate", "A technical program covering extraction work, site safety, material handling, and mine operations.", 440, 6, "Mining Operations"),
}


HUNTING_LOCATIONS = {
    "blackwood_trail": (
        ("Rabbit", "Game Meat", 1, "Small Hide", 1, 68),
        ("Deer", "Game Meat", 3, "Hide", 1, 42),
        ("Wild Boar", "Game Meat", 2, "Hide", 1, 32),
    ),
    "lake_mercy_north_shore": (
        ("Rabbit", "Game Meat", 1, "Small Hide", 1, 65),
        ("Deer", "Game Meat", 3, "Hide", 1, 46),
    ),
    "pine_ridge": (
        ("Mountain Deer", "Game Meat", 3, "Hide", 1, 40),
        ("Elk", "Game Meat", 5, "Large Hide", 1, 24),
    ),
}

HUNTING_ITEM_DESCRIPTIONS = {
    "Game Meat": "Fresh game meat taken during a successful hunt.",
    "Small Hide": "A small cleaned animal hide suitable for sale or later crafting.",
    "Hide": "A preserved animal hide suitable for sale or later crafting.",
    "Large Hide": "A large preserved hide from highland game.",
}


@dataclass(frozen=True)
class PetDef:
    key: str
    name: str
    adoption_fee: int
    description: str


PETS = {
    "dog": PetDef("dog", "Dog", 90, "A domestic dog adopted as a household companion."),
    "cat": PetDef("cat", "Cat", 70, "A domestic cat adopted as a household companion."),
    "rabbit": PetDef("rabbit", "Rabbit", 45, "A small domestic rabbit kept as a household pet."),
}


SCHOOL_NAME = "Dong Public School"


WATER_ROUTES = {
    frozenset(("lake_mercy", "lake_mercy_north_shore")),
    frozenset(("westhaven", "westhaven_terminal")),
}


def water_route_allowed(origin: str, destination: str) -> bool:
    return frozenset((origin, destination)) in WATER_ROUTES
