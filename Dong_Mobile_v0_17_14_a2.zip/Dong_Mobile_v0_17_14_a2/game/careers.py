from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Career:
    key: str
    name: str
    employer: str
    location_key: str
    description: str
    base_pay: int
    stamina_cost: int
    primary_skill: str | None = None
    required_skill_level: int = 0
    required_reputation: int = 0
    skill_xp: int = 0
    required_certificate: str | None = None


CAREERS = {
    # Millhaven County
    "millhaven_store_clerk": Career(
        "millhaven_store_clerk", "Store Clerk", "General Market", "millhaven",
        "Work a permanent retail position handling stock, customers, cleaning, and routine store duties.",
        112, 5, "Speech", 0, 0, 2,
    ),
    "millhaven_county_maintenance": Career(
        "millhaven_county_maintenance", "County Maintenance Worker", "Dong Public Works", "millhaven",
        "Maintain roads, drainage, public grounds, and county facilities as part of a permanent public works crew.",
        148, 7, "Work", 2, 0, 2,
    ),
    "millhaven_clinic_assistant": Career(
        "millhaven_clinic_assistant", "Clinic Assistant", "Dong Clinic", "millhaven",
        "Support reception, supplies, records, patient movement, and routine clinic operations.",
        142, 5, "Speech", 1, 0, 3,
    ),

    # Lake Mercy District
    "lake_lodge_staff": Career(
        "lake_lodge_staff", "Lodge Staff", "Lakeside Lodge", "lake_mercy",
        "Work a permanent guest-services position covering rooms, common areas, supplies, and visitor support.",
        136, 5, "Work", 1, 0, 2,
    ),
    "lake_marina_technician": Career(
        "lake_marina_technician", "Marina Technician", "Marina", "lake_mercy",
        "Maintain docks, small equipment, fuel systems, storage areas, and marina facilities.",
        168, 6, "Crafting", 2, 10, 3,
    ),
    "lake_fisheries_worker": Career(
        "lake_fisheries_worker", "Fisheries Worker", "Dong Fisheries Cooperative", "lake_mercy",
        "Handle catches, maintain fishing equipment, assist local crews, and support the district fisheries operation.",
        158, 6, "Fishing", 2, 10, 3,
    ),

    # Redwater
    "redwater_factory_operator": Career(
        "redwater_factory_operator", "Factory Operator", "Dong Manufacturing", "redwater",
        "Operate production equipment, inspect output, move materials, and maintain a full factory shift.",
        184, 7, "Work", 2, 0, 3,
    ),
    "redwater_freight_coordinator": Career(
        "redwater_freight_coordinator", "Freight Coordinator", "Dong Freight Company", "redwater",
        "Coordinate warehouse loads, manifests, outgoing freight, and loading crews across the river district.",
        198, 6, "Work", 3, 10, 3,
    ),
    "redwater_salvage_technician": Career(
        "redwater_salvage_technician", "Salvage Technician", "Salvage Yard", "redwater_industrial",
        "Sort machinery, recover reusable components, process scrap, and maintain salvage equipment.",
        205, 7, "Crafting", 3, 10, 4,
    ),

    # Greybridge
    "greybridge_administrator": Career(
        "greybridge_administrator", "Office Administrator", "Dong Civic Services", "greybridge_city",
        "Work a permanent administrative position processing records, schedules, correspondence, and public requests.",
        202, 4, "Speech", 2, 0, 3,
    ),
    "greybridge_hospital_orderly": Career(
        "greybridge_hospital_orderly", "Hospital Orderly", "Dong Central Hospital", "greybridge_city",
        "Move patients, equipment, supplies, and records throughout the hospital during a full scheduled shift.",
        214, 6, "Work", 2, 10, 3,
    ),
    "greybridge_transit_driver": Career(
        "greybridge_transit_driver", "Transit Driver", "Dong Transit Authority", "greybridge_city",
        "Operate scheduled city transit routes and complete vehicle inspections, passenger service, and route paperwork.",
        226, 6, "Driving", 3, 15, 4,
    ),
    "airport_ground_crew": Career(
        "airport_ground_crew", "Airport Ground Crew", "Dong International Airport", "greybridge_airport",
        "Work aircraft turnaround, baggage movement, ground equipment, and terminal-side logistics.",
        238, 8, "Work", 3, 10, 3,
    ),

    # Hollow Creek
    "hollow_sawmill_operator": Career(
        "hollow_sawmill_operator", "Sawmill Operator", "Dong Timber Company", "hollow_creek_sawmill",
        "Operate sawmill equipment, grade timber, move finished lumber, and maintain production areas.",
        188, 7, "Woodcutting", 3, 10, 4,
    ),
    "hollow_agricultural_worker": Career(
        "hollow_agricultural_worker", "Agricultural Worker", "Dong Growers Cooperative", "hollow_creek",
        "Work full days across orchards, crop handling, equipment, packing, and seasonal field operations.",
        176, 7, "Farming", 3, 10, 4,
    ),

    # Pine Ridge
    "ridge_mine_technician": Career(
        "ridge_mine_technician", "Mine Technician", "Dong Mining Company", "pine_ridge_mine",
        "Support extraction crews, inspect work areas, handle ore, and maintain equipment during a full mine shift.",
        244, 9, "Mining", 3, 15, 5,
    ),
    "ridge_highway_worker": Career(
        "ridge_highway_worker", "Highway Maintenance Worker", "Highlands Transportation Department", "pine_ridge",
        "Maintain mountain roads, barriers, drainage, and seasonal highway access across the highlands.",
        218, 8, "Work", 3, 10, 3,
    ),

    # Westhaven
    "westhaven_dockworker": Career(
        "westhaven_dockworker", "Dock Worker", "Dong Port Authority", "westhaven_terminal",
        "Work scheduled cargo operations, secure freight, handle dock equipment, and service incoming vessels.",
        228, 8, "Work", 3, 10, 3,
    ),
    "westhaven_fishing_crew": Career(
        "westhaven_fishing_crew", "Commercial Fishing Crew", "Dong Fisheries Cooperative", "westhaven",
        "Work full shifts supporting commercial fishing operations, catch handling, gear, and vessel preparation.",
        212, 8, "Fishing", 3, 10, 5,
    ),
    "westhaven_hotel_staff": Career(
        "westhaven_hotel_staff", "Hotel Staff", "Harbour Hotel", "westhaven",
        "Work a permanent hotel position supporting rooms, guests, supplies, and public areas.",
        184, 5, "Speech", 2, 0, 3,
    ),
    # Public safety
    "millhaven_police_constable": Career(
        "millhaven_police_constable", "Police Constable", "Dong Police Department", "millhaven",
        "Work patrol, public assistance, reports, traffic enforcement, and routine county policing during a scheduled shift.",
        236, 7, "Speech", 3, 20, 4, "Criminal Justice",
    ),
    "greybridge_police_officer": Career(
        "greybridge_police_officer", "Police Officer", "Dong Police Department", "greybridge_city",
        "Work a full metropolitan patrol shift handling calls, reports, public safety, and enforcement across the city.",
        286, 8, "Speech", 4, 25, 5, "Criminal Justice",
    ),
    "westhaven_port_officer": Career(
        "westhaven_port_officer", "Port Police Officer", "Dong Port Police", "westhaven_terminal",
        "Patrol port property, respond to incidents, support terminal security, and complete enforcement reports.",
        294, 8, "Work", 4, 20, 4, "Criminal Justice",
    ),

}


RANKS = [
    (0, "Probationary", 1.00),
    (5, "Staff", 1.12),
    (15, "Senior", 1.28),
    (30, "Lead", 1.45),
    (50, "Supervisor", 1.65),
]


def career_rank(shifts_worked: int) -> tuple[str, float]:
    result = RANKS[0][1], RANKS[0][2]
    for threshold, name, multiplier in RANKS:
        if shifts_worked >= threshold:
            result = name, multiplier
        else:
            break
    return result


def next_rank(shifts_worked: int) -> tuple[str, int] | None:
    for threshold, name, _ in RANKS:
        if threshold > shifts_worked:
            return name, threshold - shifts_worked
    return None


def weekday_name(day: int) -> str:
    names = ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
    return names[(max(1, day) - 1) % 7]


def is_scheduled_workday(day: int) -> bool:
    return ((max(1, day) - 1) % 7) < 5
