from __future__ import annotations

from dataclasses import dataclass
import heapq
import math


@dataclass(frozen=True)
class Region:
    key: str
    name: str
    description: str


@dataclass(frozen=True)
class Location:
    key: str
    name: str
    description: str
    region_key: str
    kind: str = "settlement"


@dataclass(frozen=True)
class TransitOption:
    method: str
    fare: int
    game_minutes: int
    real_seconds: int
    description: str


REGIONS = {
    "millhaven_county": Region("millhaven_county", "Central Dong", "The older central streets of Dong, where public services, markets, homes, and civic buildings are concentrated."),
    "lake_mercy_district": Region("lake_mercy_district", "Lakeside Dong", "The lakefront side of Dong, with public shoreline, a marina, recreation areas, and residential streets."),
    "redwater_district": Region("redwater_district", "Industrial Dong", "Dong's freight, manufacturing, salvage, warehouse, and heavy-work corridor."),
    "greybridge_metro": Region("greybridge_metro", "Downtown Dong", "The dense urban core of Dong, with offices, hospitals, transit, education, entertainment, and the airport link."),
    "hollow_creek_valley": Region("hollow_creek_valley", "Greenbelt Dong", "A broad greenbelt within Dong containing farms, timber operations, parks, and lower-density development."),
    "pine_ridge_highlands": Region("pine_ridge_highlands", "Highland Dong", "The elevated outer reaches of Dong, with steep roads, mines, wilderness access, and older underground works."),
    "westhaven_coast": Region("westhaven_coast", "Waterfront Dong", "Dong's working waterfront, with hotels, docks, fishing operations, cargo facilities, and passenger terminals."),
}


LOCATIONS = {
    "millhaven": Location("millhaven", "Main Street", "A busy central street lined with shops, services, offices, restaurants, and older mixed-use buildings.", "millhaven_county"),
    "blackwood_trail": Location("blackwood_trail", "Blackwood Trail", "A wooded public trail running through one of Dong's largest undeveloped green spaces.", "millhaven_county", "wilderness"),
    "millhaven_quarry": Location("millhaven_quarry", "Quarry", "A working stone quarry inside Dong's industrial fringe, with exposed rock faces, gravel tracks, and sorted material yards.", "millhaven_county", "worksite"),
    "lake_mercy": Location("lake_mercy", "Marina", "Dong's public marina on Lake Mercy, with docks, service buildings, boat storage, and shoreline access.", "lake_mercy_district"),
    "lake_mercy_north_shore": Location("lake_mercy_north_shore", "Lake Mercy", "A long public stretch of shoreline used for fishing, hunting access, camping, and quiet recreation.", "lake_mercy_district", "wilderness"),
    "redwater": Location("redwater", "Industrial Centre", "A dense concentration of warehouses, freight offices, repair shops, factories, and worker services.", "redwater_district"),
    "redwater_industrial": Location("redwater_industrial", "Salvage Yard", "A large salvage and recycling yard filled with scrap metal, machinery, loading areas, and reusable industrial material.", "redwater_district", "worksite"),
    "redwater_fight_club": Location("redwater_fight_club", "Fight Club", "A licensed basement fighting venue where supervised bouts are held before a small crowd.", "redwater_district", "combat"),
    "greybridge_city": Location("greybridge_city", "Civic Centre", "The dense civic and commercial core of Dong, surrounded by offices, hospitals, transit, entertainment, and public institutions.", "greybridge_metro", "city"),
    "greybridge_airport": Location("greybridge_airport", "International Airport", "Dong's passenger and freight airport, with terminals, cargo buildings, parking structures, and service roads.", "greybridge_metro", "transport"),
    "hollow_creek": Location("hollow_creek", "Greenmarket", "A large produce and agricultural market serving Dong's greenbelt farms and food businesses.", "hollow_creek_valley"),
    "hollow_creek_sawmill": Location("hollow_creek_sawmill", "Sawmill", "A working timber yard with log storage, equipment sheds, sawmill buildings, and forest access roads.", "hollow_creek_valley", "worksite"),
    "pine_ridge": Location("pine_ridge", "Highland Station", "A transport and service stop near Dong's elevated highland roads, mining sites, and wilderness access.", "pine_ridge_highlands"),
    "pine_ridge_mine": Location("pine_ridge_mine", "Mine", "A large mine reached by a graded service road, with ore-processing buildings and heavy equipment.", "pine_ridge_highlands", "worksite"),
    "blackstone_dungeon": Location("blackstone_dungeon", "Blackstone Dungeon", "A sealed stone complex beneath the highland edge of Dong. Old passages open into deeper chambers occupied by hostile creatures.", "pine_ridge_highlands", "combat"),
    "westhaven": Location("westhaven", "Harbourfront", "Dong's waterfront commercial strip, crowded with hotels, restaurants, fishing businesses, towers, and working docks.", "westhaven_coast", "city"),
    "westhaven_terminal": Location("westhaven_terminal", "Port Terminal", "Dong's main waterfront terminal for freight carriers, fishing vessels, passenger service, and warehouses.", "westhaven_coast", "transport"),
}



REGION_HUBS = {
    "millhaven_county": "millhaven",
    "lake_mercy_district": "lake_mercy",
    "redwater_district": "redwater",
    "greybridge_metro": "greybridge_city",
    "hollow_creek_valley": "hollow_creek",
    "pine_ridge_highlands": "pine_ridge",
    "westhaven_coast": "westhaven",
}


# Road graph values are walking minutes. Travel methods reduce those times.
# The network makes regional travel extensible without maintaining every possible pair.
ROAD_EDGES: dict[frozenset[str], int] = {
    frozenset(("home", "millhaven")): 25,
    frozenset(("home", "blackwood_trail")): 12,
    frozenset(("home", "millhaven_quarry")): 20,
    frozenset(("millhaven", "blackwood_trail")): 20,
    frozenset(("millhaven", "millhaven_quarry")): 15,
    frozenset(("blackwood_trail", "millhaven_quarry")): 25,
    frozenset(("millhaven", "lake_mercy")): 150,
    frozenset(("lake_mercy", "lake_mercy_north_shore")): 28,
    frozenset(("millhaven", "redwater")): 210,
    frozenset(("redwater", "redwater_industrial")): 22,
    frozenset(("redwater", "redwater_fight_club")): 8,
    frozenset(("millhaven", "hollow_creek")): 180,
    frozenset(("hollow_creek", "hollow_creek_sawmill")): 24,
    frozenset(("hollow_creek", "pine_ridge")): 240,
    frozenset(("pine_ridge", "pine_ridge_mine")): 32,
    frozenset(("pine_ridge", "blackstone_dungeon")): 26,
    frozenset(("redwater", "greybridge_city")): 300,
    frozenset(("millhaven", "greybridge_city")): 480,
    frozenset(("greybridge_city", "greybridge_airport")): 35,
    frozenset(("greybridge_city", "westhaven")): 720,
    frozenset(("westhaven", "westhaven_terminal")): 20,
    frozenset(("pine_ridge", "greybridge_city")): 420,
    frozenset(("lake_mercy", "hollow_creek")): 210,
    frozenset(("lake_mercy", "redwater")): 260,
}


_METHOD_GAME_MULTIPLIERS = {
    "Walking": 1.0,
    "Horse": 0.65,
    "Bicycle": 0.45,
    "Motorcycle": 0.22,
    "Car": 0.18,
    "Pickup Truck": 0.21,
    "Rowboat": 0.55,
    "Motorboat": 0.16,
}

# Convert game minutes into a short real development timer. This keeps long journeys meaningful
# without forcing the player to wait for real-world hours during the prototype phase.
_REAL_SECONDS_PER_GAME_MINUTE = 0.25


def _build_adjacency() -> dict[str, list[tuple[str, int]]]:
    graph: dict[str, list[tuple[str, int]]] = {}
    for edge, minutes in ROAD_EDGES.items():
        a, b = tuple(edge)
        graph.setdefault(a, []).append((b, minutes))
        graph.setdefault(b, []).append((a, minutes))
    return graph


_ADJACENCY = _build_adjacency()


def road_minutes(origin: str, destination: str, home_region_key: str = "millhaven_county") -> int:
    if origin == destination:
        return 0
    if origin == "home" or destination == "home":
        other = destination if origin == "home" else origin
        hub = REGION_HUBS.get(home_region_key, "millhaven")
        if other == hub:
            return 25
        if other == "home":
            return 0
        return 25 + road_minutes(hub, other, "millhaven_county")
    queue: list[tuple[int, str]] = [(0, origin)]
    best: dict[str, int] = {origin: 0}
    while queue:
        total, node = heapq.heappop(queue)
        if node == destination:
            return total
        if total != best.get(node):
            continue
        for nxt, weight in _ADJACENCY.get(node, []):
            candidate = total + weight
            if candidate < best.get(nxt, 10**9):
                best[nxt] = candidate
                heapq.heappush(queue, (candidate, nxt))
    return 360


# Public transit is deliberately route-specific. It does not require owning a vehicle.
# Each tuple is (origin, destination, method, fare, game_minutes, real_seconds, description).
_TRANSIT_ROUTES = [
    ("millhaven", "lake_mercy", "Bus", 8, 45, 22, "City bus"),
    ("millhaven", "redwater", "Bus", 12, 60, 28, "City bus"),
    ("millhaven", "hollow_creek", "Bus", 10, 55, 26, "City bus"),
    ("millhaven", "greybridge_city", "Bus", 22, 120, 45, "Express bus"),
    ("redwater", "greybridge_city", "Bus", 16, 75, 32, "Express bus"),
    ("hollow_creek", "pine_ridge", "Bus", 14, 70, 30, "Highland bus"),
    ("greybridge_city", "westhaven", "Bus", 35, 190, 60, "Waterfront express"),
    ("millhaven", "redwater", "Train", 18, 38, 16, "City rail"),
    ("redwater", "greybridge_city", "Train", 24, 48, 18, "City rail"),
    ("millhaven", "greybridge_city", "Train", 34, 72, 24, "City rail"),
    ("greybridge_city", "westhaven", "Train", 52, 115, 34, "Waterfront rail"),
    ("greybridge_city", "greybridge_airport", "Train", 6, 18, 8, "Airport rail link"),
    ("greybridge_airport", "westhaven", "Plane", 95, 55, 12, "Passenger flight"),
    ("millhaven", "blackwood_trail", "Taxi", 14, 12, 7, "Local taxi"),
    ("millhaven", "millhaven_quarry", "Taxi", 16, 14, 7, "Local taxi"),
    ("lake_mercy", "lake_mercy_north_shore", "Taxi", 12, 16, 7, "Local taxi"),
    ("redwater", "redwater_industrial", "Taxi", 11, 14, 7, "Local taxi"),
    ("hollow_creek", "hollow_creek_sawmill", "Taxi", 10, 15, 7, "Local taxi"),
    ("pine_ridge", "pine_ridge_mine", "Taxi", 15, 20, 8, "Local taxi"),
    ("westhaven", "westhaven_terminal", "Taxi", 12, 12, 7, "Local taxi"),
]


def _transit_lookup() -> dict[frozenset[str], list[TransitOption]]:
    data: dict[frozenset[str], list[TransitOption]] = {}
    for origin, destination, method, fare, game_minutes, real_seconds, description in _TRANSIT_ROUTES:
        data.setdefault(frozenset((origin, destination)), []).append(
            TransitOption(method, fare, game_minutes, real_seconds, description)
        )
    return data


_TRANSIT_LOOKUP = _transit_lookup()
PUBLIC_METHODS = {"Bus", "Train", "Plane", "Taxi"}


def public_transport_options(origin: str, destination: str) -> list[TransitOption]:
    if origin == destination:
        return []
    return list(_TRANSIT_LOOKUP.get(frozenset((origin, destination)), []))


def public_transport_option(origin: str, destination: str, method: str) -> TransitOption | None:
    for option in public_transport_options(origin, destination):
        if option.method == method:
            return option
    return None


def plot_summary(plot: dict) -> str:
    features = []
    if plot.get("natural_feature"):
        features.append(plot["natural_feature"])
    if plot.get("water_access"):
        features.append(plot["water_access"])
    if plot.get("road_access"):
        features.append(plot["road_access"])
    return " • ".join(features) if features else "No notable features"


def normalize_location_key(current_location: str) -> str:
    return "home" if current_location.startswith("plot:") else current_location


def region_key_for_location(location_key: str) -> str:
    if location_key == "home":
        return "millhaven_county"
    location = LOCATIONS.get(location_key)
    return location.region_key if location else "millhaven_county"


def region_name_for_location(location_key: str) -> str:
    return REGIONS[region_key_for_location(location_key)].name


def location_name(current_location: str, home_plot: dict) -> str:
    normalized = normalize_location_key(current_location)
    if normalized == "home":
        return "Home"
    location = LOCATIONS.get(normalized)
    return location.name if location else normalized.replace("_", " ").title()


def method_allowed_on_route(origin: str, destination: str, method: str) -> bool:
    if method not in {"Rowboat", "Motorboat"}:
        return True
    from game.life_expansion import water_route_allowed
    return water_route_allowed(origin, destination)


def travel_game_minutes(origin: str, destination: str, method: str = "Walking", home_region_key: str = "millhaven_county") -> int:
    if origin == destination:
        return 0
    if not method_allowed_on_route(origin, destination, method):
        return 9999
    public = public_transport_option(origin, destination, method)
    if public:
        return public.game_minutes
    base = road_minutes(origin, destination, home_region_key)
    multiplier = _METHOD_GAME_MULTIPLIERS.get(method, 1.0)
    return max(2, round(base * multiplier))


def travel_seconds(origin: str, destination: str, method: str = "Walking", home_region_key: str = "millhaven_county") -> int:
    if origin == destination:
        return 0
    public = public_transport_option(origin, destination, method)
    if public:
        return public.real_seconds
    minutes = travel_game_minutes(origin, destination, method, home_region_key)
    return max(3, min(180, round(minutes * _REAL_SECONDS_PER_GAME_MINUTE)))


def route_fuel_units(origin: str, destination: str, method: str, home_region_key: str = "millhaven_county") -> int:
    if method in ("Walking", "Horse", "Bicycle", "Rowboat") or method in PUBLIC_METHODS or origin == destination:
        return 0
    driving_minutes = travel_game_minutes(origin, destination, method, home_region_key)
    factor = {"Motorcycle": 0.65, "Car": 1.0, "Pickup Truck": 1.25, "Motorboat": 1.1}.get(method, 1.0)
    return max(1, round((driving_minutes / 12) * factor))
