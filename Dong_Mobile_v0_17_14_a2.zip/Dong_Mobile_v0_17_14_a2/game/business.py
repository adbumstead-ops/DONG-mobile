from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class BusinessDef:
    key: str
    name: str
    description: str
    structure_key: str
    customer_interval_seconds: int


@dataclass(frozen=True)
class WholesaleItem:
    business_key: str
    name: str
    cost: int
    base_price: int
    description: str


BUSINESSES = {
    "farm_stand": BusinessDef(
        "farm_stand",
        "Farm Stand",
        "A small roadside stand for selling produce and farm goods directly to passing customers.",
        "farm_stand",
        18,
    ),
    "small_shop": BusinessDef(
        "small_shop",
        "Small Shop",
        "A compact retail building with a sales floor, counter, and stock room.",
        "small_shop",
        16,
    ),
    "roadside_bar": BusinessDef(
        "roadside_bar",
        "Roadside Bar",
        "A modest public house with a service counter, seating area, and storage room.",
        "roadside_bar",
        14,
    ),
}

PRICE_TIERS = {
    "low": {"label": "Low", "multiplier": 0.85, "sale_chance": 0.95},
    "standard": {"label": "Standard", "multiplier": 1.0, "sale_chance": 0.75},
    "high": {"label": "High", "multiplier": 1.30, "sale_chance": 0.45},
}

WHOLESALE_ITEMS = (
    WholesaleItem("small_shop", "Packaged Snack", 2, 4, "A sealed packaged snack intended for retail sale."),
    WholesaleItem("small_shop", "Bottled Water", 1, 3, "A sealed bottle of drinking water intended for retail sale."),
    WholesaleItem("small_shop", "Basic Bandage", 5, 9, "A sterile basic bandage packaged for retail sale."),
    WholesaleItem("small_shop", "Battery Pack", 4, 8, "A small pack of general-purpose batteries."),
    WholesaleItem("roadside_bar", "Bottled Beer", 3, 6, "A sealed bottle of standard beer supplied for bar service."),
    WholesaleItem("roadside_bar", "Coffee", 1, 3, "Ground coffee and service supplies for one customer order."),
    WholesaleItem("roadside_bar", "Simple Meal", 4, 9, "Basic ingredients for one prepared meal."),
    WholesaleItem("roadside_bar", "Soda", 1, 3, "A bottled soft drink supplied for bar service."),
)

WHOLESALE_BY_BUSINESS = {
    key: tuple(item for item in WHOLESALE_ITEMS if item.business_key == key)
    for key in BUSINESSES
}
