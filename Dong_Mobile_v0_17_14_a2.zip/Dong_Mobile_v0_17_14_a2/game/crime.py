from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CrimeAction:
    key: str
    name: str
    description: str
    base_success: int
    base_arrest: int
    min_cash: int
    max_cash: int
    stamina_cost: int
    heat_gain: int
    crime_xp: int
    game_minutes: int
    violent: bool = False
    murder: bool = False
    night_only: bool = False


@dataclass(frozen=True)
class CrimeJob:
    key: str
    name: str
    description: str
    base_success: int
    base_arrest: int
    payout: int
    stamina_cost: int
    heat_gain: int
    crime_xp: int
    game_minutes: int
    violent: bool = False
    murder: bool = False


CRIMES: dict[str, CrimeAction] = {
    "pickpocket": CrimeAction(
        "pickpocket",
        "Pickpocket",
        "Attempt to steal cash from a passerby in Dong without being noticed.",
        68,
        20,
        5,
        22,
        1,
        4,
        1,
        10,
    ),
    "shoplift": CrimeAction(
        "shoplift",
        "Shoplift",
        "Attempt to take a small item from the General Store without paying.",
        72,
        18,
        8,
        20,
        1,
        5,
        1,
        10,
    ),
    "burglary": CrimeAction(
        "burglary",
        "Residential Burglary",
        "Break into an unoccupied residence and search for valuables.",
        52,
        34,
        35,
        90,
        3,
        12,
        3,
        45,
        night_only=True,
    ),
    "store_robbery": CrimeAction(
        "store_robbery",
        "Rob the General Store",
        "Threaten the clerk and demand cash from the register.",
        45,
        48,
        70,
        160,
        4,
        24,
        5,
        35,
        violent=True,
    ),
    "murder": CrimeAction(
        "murder",
        "Murder",
        "Kill a person in Dong and attempt to leave the area before authorities identify you.",
        28,
        72,
        0,
        0,
        6,
        55,
        8,
        60,
        violent=True,
        murder=True,
    ),
}


CRIME_JOBS: dict[str, CrimeJob] = {
    "package_run": CrimeJob(
        "package_run",
        "Package Run",
        "Carry a sealed package across Dong and leave it at a designated address.",
        82,
        12,
        45,
        2,
        5,
        2,
        35,
    ),
    "burglary_contract": CrimeJob(
        "burglary_contract",
        "Burglary Contract",
        "Enter a marked property and recover a specific item for a local buyer.",
        56,
        34,
        95,
        4,
        14,
        4,
        55,
    ),
    "store_job": CrimeJob(
        "store_job",
        "Store Robbery",
        "Take part in a planned robbery against a small commercial property.",
        46,
        48,
        160,
        5,
        24,
        6,
        50,
        violent=True,
    ),
    "contract_killing": CrimeJob(
        "contract_killing",
        "Contract Killing",
        "Accept payment to kill a marked target and leave the area without being identified.",
        31,
        69,
        300,
        7,
        60,
        9,
        80,
        violent=True,
        murder=True,
    ),
}


MASK_NAME = "Black Cloth Mask"
MASK_PRICE = 25
MASK_DESCRIPTION = "A plain cloth face covering intended to conceal identifying features."


def heat_label(heat: int) -> str:
    if heat <= 0:
        return "Clear"
    if heat < 10:
        return "Low"
    if heat < 25:
        return "Noticeable"
    if heat < 45:
        return "High"
    if heat < 70:
        return "Severe"
    return "Extreme"
