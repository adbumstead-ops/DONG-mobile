from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class AnimalDef:
    key: str
    name: str
    price: int
    description: str
    required_structure: str
    production_seconds: int
    product_item: str
    product_description: str
    product_sale_price: int
    rideable: bool = False


ANIMALS = {
    "horse": AnimalDef(
        "horse",
        "Horse",
        350,
        "A sound riding horse suitable for road travel and light farm use.",
        "stable",
        0,
        "",
        "",
        0,
        rideable=True,
    ),
    "chicken": AnimalDef(
        "chicken",
        "Chicken",
        25,
        "A healthy laying hen suited to a small coop.",
        "chicken_coop",
        30,
        "Egg",
        "A fresh egg collected from a laying hen.",
        3,
    ),
    "goat": AnimalDef(
        "goat",
        "Goat",
        85,
        "A hardy dairy goat suitable for a small barn and fenced pasture.",
        "small_barn",
        45,
        "Goat Milk",
        "Fresh goat milk collected from a healthy dairy animal.",
        7,
    ),
    "cow": AnimalDef(
        "cow",
        "Cow",
        180,
        "A dairy cow that requires barn space and a steady supply of feed.",
        "small_barn",
        60,
        "Milk",
        "Fresh cow's milk collected on the property.",
        9,
    ),
    "pig": AnimalDef(
        "pig",
        "Pig",
        110,
        "A farm pig kept for breeding and agricultural use.",
        "small_barn",
        50,
        "Manure",
        "Collected livestock manure suitable for later use as fertilizer.",
        4,
    ),
}

ANIMAL_PRODUCTS = {animal.product_item: animal for animal in ANIMALS.values() if animal.product_item}

FEED_SACK_NAME = "Livestock Feed Sack"
FEED_SACK_PRICE = 12
FEED_SACK_PORTIONS = 10
FEED_SACK_DESCRIPTION = (
    "A sealed sack containing ten portions of mixed livestock feed. "
    "Purchases are delivered to the feed store on your property."
)

MAX_STORED_OUTPUT = 3
