from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class VehicleDef:
    key: str
    name: str
    method: str
    price: int
    description: str
    fuel_capacity: int
    storage_capacity: int
    wear_per_trip: int

    @property
    def motorized(self) -> bool:
        return self.fuel_capacity > 0


VEHICLES = {
    "bicycle": VehicleDef(
        "bicycle",
        "Road Bicycle",
        "Bicycle",
        160,
        "A practical road bicycle with a rear cargo rack and simple mechanical brakes.",
        0,
        3,
        1,
    ),
    "motorcycle": VehicleDef(
        "motorcycle",
        "Used Motorcycle",
        "Motorcycle",
        900,
        "A used road motorcycle with a small fuel tank and limited cargo space.",
        12,
        5,
        2,
    ),
    "compact_car": VehicleDef(
        "compact_car",
        "Used Compact Car",
        "Car",
        1800,
        "An older compact car suited to everyday road travel. The rear compartment provides useful storage.",
        40,
        20,
        1,
    ),
    "rowboat": VehicleDef(
        "rowboat",
        "Rowboat",
        "Rowboat",
        700,
        "A small human-powered boat suitable for protected lake and harbour water.",
        0,
        8,
        1,
    ),
    "motorboat": VehicleDef(
        "motorboat",
        "Small Motorboat",
        "Motorboat",
        3200,
        "A small motorboat with enclosed fuel storage and room for supplies and fishing gear.",
        45,
        18,
        2,
    ),
    "pickup_truck": VehicleDef(
        "pickup_truck",
        "Used Pickup Truck",
        "Pickup Truck",
        3000,
        "A used pickup truck with a full cargo bed and enough capacity for tools, supplies, and building materials.",
        55,
        40,
        1,
    ),
}

FUEL_PRICE_PER_UNIT = 2
REPAIR_PRICE_PER_CONDITION = 3
