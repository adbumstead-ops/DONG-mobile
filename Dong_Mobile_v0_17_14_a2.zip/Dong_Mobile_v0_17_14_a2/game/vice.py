from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ViceItem:
    key: str
    name: str
    price: int
    description: str
    kind: str
    intoxication: int = 0
    drug_effect: int = 0
    hp_change: int = 0
    stamina_change: int = 0
    dependence_gain: int = 0


ALCOHOL_ITEMS: dict[str, ViceItem] = {
    "beer": ViceItem(
        "beer",
        "Bottled Beer",
        6,
        "A sealed bottle of beer sold at the Grey Lantern.",
        "alcohol",
        intoxication=18,
        stamina_change=2,
        dependence_gain=2,
    ),
    "whiskey": ViceItem(
        "whiskey",
        "Whiskey",
        14,
        "A measure of whiskey served from behind the Grey Lantern bar.",
        "alcohol",
        intoxication=34,
        stamina_change=3,
        dependence_gain=4,
    ),
}


DRUG_ITEMS: dict[str, ViceItem] = {
    "drugs": ViceItem(
        "drugs",
        "Drugs",
        45,
        "An illegal quantity of drugs circulated through Dong's criminal market. The substance is intentionally unspecified.",
        "drug",
        drug_effect=30,
        hp_change=-2,
        stamina_change=8,
        dependence_gain=8,
    ),
}

# Backward-compatible internal alias for saves/code created during the v0.13 prototype.
ILLICIT_ITEMS = DRUG_ITEMS

ALL_VICE_ITEMS: dict[str, ViceItem] = {**ALCOHOL_ITEMS, **DRUG_ITEMS}
ITEM_BY_NAME = {item.name: item for item in ALL_VICE_ITEMS.values()}


def intoxication_label(value: int) -> str:
    if value >= 80:
        return "Heavily Intoxicated"
    if value >= 50:
        return "Drunk"
    if value >= 20:
        return "Buzzed"
    return "Sober"


def drug_effect_label(value: int) -> str:
    if value >= 70:
        return "Strong Effect"
    if value >= 35:
        return "Affected"
    if value > 0:
        return "Mild Effect"
    return "Clear"


def dependence_label(value: int) -> str:
    if value >= 75:
        return "Severe Dependence"
    if value >= 50:
        return "Dependent"
    if value >= 25:
        return "Habitual Use"
    if value > 0:
        return "Occasional Use"
    return "None"


DEALER_TIERS = (
    (0, "Street Dealer"),
    (20, "Local Supplier"),
    (55, "Crew Leader"),
    (110, "Distribution Network"),
    (190, "Regional Operation"),
)


def dealer_tier(rep: int) -> str:
    current = DEALER_TIERS[0][1]
    for threshold, name in DEALER_TIERS:
        if rep >= threshold:
            current = name
    return current


CASINO_SYMBOLS = ("BAR", "7", "BELL", "CHERRY", "CROWN")
ROULETTE_RED = {
    1, 3, 5, 7, 9, 12, 14, 16, 18,
    19, 21, 23, 25, 27, 30, 32, 34, 36,
}
