from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class FamilyMember:
    name: str
    relation: str
    age_stage: str = "Adult"


ROMANCE_FRIENDSHIP_REQUIRED = 25
INTIMACY_ROMANCE_REQUIRED = 30
MARRIAGE_FRIENDSHIP_REQUIRED = 40
MARRIAGE_ROMANCE_REQUIRED = 60
DATE_STAMINA_COST = 2
DATE_GAME_MINUTES = 60
INTIMACY_GAME_MINUTES = 60
INTIMACY_HP_RESTORE = 6
INTIMACY_STAMINA_RESTORE = 8
PROCREATION_CHANCE = 0.25
CHILD_DUE_DAYS = 20

CHILD_NAMES = (
    "Alex", "Casey", "Jordan", "Morgan", "Riley", "Taylor", "Avery", "Jamie",
    "Rowan", "Quinn", "Cameron", "Parker", "Reese", "Sam", "Drew", "Robin",
)


def romance_label(status: str, romance: int) -> str:
    if status == "married":
        return "Spouse"
    if status == "dating":
        if romance >= 60:
            return "Committed Partner"
        if romance >= 35:
            return "Partner"
        return "Dating"
    return "Not Romantic"


def child_stage(days_old: int) -> str:
    if days_old < 30:
        return "Baby"
    if days_old < 90:
        return "Young Child"
    return "Older Child"
