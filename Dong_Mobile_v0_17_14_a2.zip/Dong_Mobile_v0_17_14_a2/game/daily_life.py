from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Recipe:
    key: str
    name: str
    description: str
    ingredients: tuple[tuple[str, int], ...]
    result_name: str
    result_description: str
    hp_restore: int
    stamina_restore: int
    game_minutes: int = 30


@dataclass(frozen=True)
class DinerMeal:
    key: str
    name: str
    description: str
    price: int
    hp_restore: int
    stamina_restore: int
    game_minutes: int = 30


@dataclass(frozen=True)
class Favor:
    key: str
    npc_key: str
    title: str
    description: str
    requirements: tuple[tuple[str, int], ...]
    cash_reward: int
    friendship_reward: int
    speech_xp: int = 1


@dataclass(frozen=True)
class DailyEvent:
    key: str
    name: str
    description: str
    modifier_text: str


RECIPES: dict[str, Recipe] = {
    "fried_eggs": Recipe(
        "fried_eggs",
        "Fried Eggs",
        "Eggs cooked simply over steady heat.",
        (("Egg", 2),),
        "Fried Eggs",
        "A plate of two cooked eggs.",
        4,
        5,
        20,
    ),
    "vegetable_stew": Recipe(
        "vegetable_stew",
        "Vegetable Stew",
        "A thick stew made from root vegetables and tomatoes.",
        (("Potato", 1), ("Carrot", 1), ("Tomato", 1)),
        "Vegetable Stew",
        "A warm bowl of vegetables cooked together until tender.",
        6,
        8,
        40,
    ),
    "corn_egg_skillet": Recipe(
        "corn_egg_skillet",
        "Corn and Egg Skillet",
        "Corn and eggs cooked together in a heavy pan.",
        (("Corn", 1), ("Egg", 1)),
        "Corn and Egg Skillet",
        "A simple hot meal of corn and eggs.",
        5,
        7,
        30,
    ),
}

PREPARED_FOODS = {
    recipe.result_name: recipe for recipe in RECIPES.values()
}

DINER_MEALS: tuple[DinerMeal, ...] = (
    DinerMeal(
        "breakfast_plate",
        "Breakfast Plate",
        "Eggs, fried potatoes, toast, and coffee served as a full breakfast.",
        9,
        5,
        7,
        35,
    ),
    DinerMeal(
        "soup_bread",
        "Soup and Bread",
        "A bowl of vegetable soup served with thick slices of bread.",
        7,
        4,
        6,
        30,
    ),
    DinerMeal(
        "coffee",
        "Coffee",
        "A hot mug of black coffee.",
        3,
        0,
        3,
        15,
    ),
)

FAVORS: dict[str, Favor] = {
    "mara_water_delivery": Favor(
        "mara_water_delivery",
        "mara_venn",
        "Water for the Store",
        "Mara asks you to bring two sealed water bottles for a delivery that arrived short.",
        (("Water Bottle", 2),),
        12,
        4,
    ),
    "ruth_carrots": Favor(
        "ruth_carrots",
        "ruth_calder",
        "Fresh Carrots",
        "Ruth wants three fresh carrots to compare with a new seed lot she is considering for next season.",
        (("Carrot", 3),),
        24,
        5,
    ),
    "lena_bandages": Favor(
        "lena_bandages",
        "lena_voss",
        "Clinic Supplies",
        "Lena asks for two unopened bandages while the clinic waits for its next supply order.",
        (("Bandage", 2),),
        20,
        5,
    ),
    "daniel_leather": Favor(
        "daniel_leather",
        "daniel_rowe",
        "Leather for a Repair",
        "Daniel needs two usable pieces of scrap leather for a chair repair in his workshop.",
        (("Scrap Leather", 2),),
        28,
        5,
    ),
    "owen_tools": Favor(
        "owen_tools",
        "owen_pike",
        "Borrowed Tools",
        "Owen asks for a basic tool kit for a roadside repair while part of his own kit is out on another job.",
        (("Basic Tool Kit", 1),),
        45,
        5,
    ),
    "nora_tomatoes": Favor(
        "nora_tomatoes",
        "nora_bell",
        "Tomatoes for Supper",
        "Nora asks whether you can spare two tomatoes for a meal she is preparing at home.",
        (("Tomato", 2),),
        18,
        5,
    ),
    "thomas_cloth": Favor(
        "thomas_cloth",
        "thomas_hale",
        "Trail Markers",
        "Thomas needs two strips of torn cloth to mark a damaged section of trail until new tape arrives.",
        (("Torn Cloth", 2),),
        25,
        5,
    ),
}

FAVOR_BY_NPC = {favor.npc_key: favor for favor in FAVORS.values()}

DAILY_EVENTS: tuple[DailyEvent, ...] = (
    DailyEvent(
        "market_day",
        "Market Day",
        "Temporary produce tables have been set up near Main Street. Farmers and small growers are bringing goods into town throughout the day.",
        "Farm Supply pays 20% more for harvested produce today.",
    ),
    DailyEvent(
        "community_supper",
        "Community Supper",
        "The community hall is hosting an evening meal with food supplied by local residents and businesses.",
        "Meals at the Diner cost $2 less today.",
    ),
    DailyEvent(
        "clinic_outreach",
        "Clinic Outreach",
        "The Clinic is running a county health day and has extended basic treatment services.",
        "Full treatment at the clinic costs $8 today.",
    ),
    DailyEvent(
        "quiet_day",
        "A Quiet Day",
        "There are no scheduled public events in Dong today. Shops and services are operating on their usual routines.",
        "No special town modifier today.",
    ),
)


def daily_event(day: int) -> DailyEvent:
    return DAILY_EVENTS[(max(1, day) - 1) % len(DAILY_EVENTS)]


def produce_sale_multiplier(day: int) -> float:
    return 1.2 if daily_event(day).key == "market_day" else 1.0


def diner_discount(day: int) -> int:
    return 2 if daily_event(day).key == "community_supper" else 0


def clinic_price(day: int) -> int:
    return 8 if daily_event(day).key == "clinic_outreach" else 15
