from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
import random
import math
import json

from database.database import Database
from game.combat import ENEMIES, HEALING_ITEMS, WEAPONS, weapon_moves
from game.crime import CRIMES, CRIME_JOBS, MASK_DESCRIPTION, MASK_NAME, MASK_PRICE, heat_label
from game.business import BUSINESSES, PRICE_TIERS, WHOLESALE_BY_BUSINESS
from game.economy import JOBS, STORE_ITEMS
from game.careers import CAREERS, career_rank, next_rank, weekday_name, is_scheduled_workday
from game.daily_life import (
    DINER_MEALS, FAVOR_BY_NPC, FAVORS, PREPARED_FOODS, RECIPES, clinic_price,
    daily_event, diner_discount, produce_sale_multiplier,
)
from game.farming import CROPS, GARDEN_CAPACITY, PRODUCE_ITEMS, SEED_ITEMS
from game.gathering import CRAFT_RECIPES, ITEM_DESCRIPTIONS as GATHERING_ITEM_DESCRIPTIONS, TOOLS as GATHERING_TOOLS
from game.npcs import NPCS, customer_npc_keys, npc_schedule_state, relationship_label
from game.relationships import (
    CHILD_DUE_DAYS, CHILD_NAMES, DATE_GAME_MINUTES, DATE_STAMINA_COST,
    INTIMACY_GAME_MINUTES, INTIMACY_HP_RESTORE, INTIMACY_ROMANCE_REQUIRED,
    INTIMACY_STAMINA_RESTORE, MARRIAGE_FRIENDSHIP_REQUIRED, MARRIAGE_ROMANCE_REQUIRED,
    PROCREATION_CHANCE, ROMANCE_FRIENDSHIP_REQUIRED, child_stage, romance_label,
)
from game.livestock import (
    ANIMALS, ANIMAL_PRODUCTS, FEED_SACK_DESCRIPTION, FEED_SACK_NAME, FEED_SACK_PORTIONS,
    FEED_SACK_PRICE, MAX_STORED_OUTPUT,
)
from game.property import FURNITURE, FURNITURE_STORE, STRUCTURES
from game.world import (LOCATIONS, REGIONS, PUBLIC_METHODS, method_allowed_on_route, normalize_location_key, public_transport_option, public_transport_options, region_key_for_location, route_fuel_units, travel_game_minutes, travel_seconds)
from game.vehicles import FUEL_PRICE_PER_UNIT, REPAIR_PRICE_PER_CONDITION, VEHICLES
from game.life_expansion import (EDUCATION_PROGRAMS, HUNTING_ITEM_DESCRIPTIONS, HUNTING_LOCATIONS, PETS, SCHOOL_NAME, season_for_day, weather_for_day)
from game.vice import (
    ALCOHOL_ITEMS, DRUG_ITEMS, ITEM_BY_NAME, CASINO_SYMBOLS, ROULETTE_RED,
    dealer_tier, dependence_label, drug_effect_label, intoxication_label,
)


@dataclass(frozen=True)
class Character:
    id: int
    name: str
    hp: int
    max_hp: int
    stamina: int
    max_stamina: int
    cash: int
    home_plot_id: int
    current_location: str
    day: int
    time_minutes: int
    weather: str
    equipped_weapon: str


class GameState:
    STAMINA_REGEN_SECONDS = 300
    EXPLORE_STAMINA_COST = 2
    EXPLORE_GAME_MINUTES = 20

    def __init__(self, database: Database) -> None:
        self.db = database
        if self.has_save():
            self._ensure_save_defaults()

    def _ensure_save_defaults(self) -> None:
        row = self.db.fetchone("SELECT * FROM character LIMIT 1")
        if row is None:
            return
        character_id = row["id"]
        with self.db.transaction() as con:
            for skill in ("Work", "Exploration", "Combat", "Farming", "Fishing", "Speech", "Crime", "Mining", "Woodcutting", "Crafting", "Driving", "Vice", "Hunting", "Survival", "Education"):
                con.execute(
                    "INSERT OR IGNORE INTO skills (character_id, skill_name, xp) VALUES (?, ?, 0)",
                    (character_id, skill),
                )
            for location_key in LOCATIONS:
                con.execute(
                    "INSERT OR IGNORE INTO known_locations (character_id, location_key) VALUES (?, ?)",
                    (character_id, location_key),
                )
            for region_key in REGIONS:
                con.execute(
                    "INSERT OR IGNORE INTO regional_reputation (character_id, region_key, reputation) VALUES (?, ?, 0)",
                    (character_id, region_key),
                )
            for region_key in REGIONS:
                con.execute(
                    "INSERT OR IGNORE INTO regional_reputation (character_id, region_key, reputation) VALUES (?, ?, 0)",
                    (character_id, region_key),
                )
            for npc_key in NPCS:
                con.execute(
                    "INSERT OR IGNORE INTO npc_relationships (character_id, npc_key, friendship, talk_count) VALUES (?, ?, 0, 0)",
                    (character_id, npc_key),
                )
            con.execute(
                "INSERT OR IGNORE INTO crime_profile (character_id, heat, crimes_committed, arrests, murders, mask_worn, last_heat_day) VALUES (?, 0, 0, 0, 0, 0, ?)",
                (character_id, int(row["day"])),
            )
            con.execute(
                """
                INSERT OR IGNORE INTO vice_profile (
                    character_id, last_processed_day, last_processed_minute
                ) VALUES (?, ?, ?)
                """,
                (character_id, int(row["day"]), int(row["time_minutes"])),
            )
            con.execute(
                "INSERT OR IGNORE INTO household (character_id, spouse_npc_key, married_day, expecting_child, child_due_day) VALUES (?, NULL, NULL, 0, NULL)",
                (character_id,),
            )
            con.execute(
                """
                INSERT OR IGNORE INTO mail (character_id, mail_key, sender, subject, body, sent_day, is_read)
                VALUES (?, 'county_deed', 'Millhaven County Land Office', 'Property Deed Registered',
                        'Your ownership of the assigned property has been registered with the county. The parcel may be developed for residential, agricultural, or approved commercial use.',
                        ?, 0)
                """,
                (character_id, int(row["day"])),
            )
            con.execute(
                """
                INSERT OR IGNORE INTO mail (character_id, mail_key, sender, subject, body, sent_day, is_read)
                VALUES (?, 'employment_notice', 'Millhaven Employment Office', 'Temporary Work Available',
                        'The employment office maintains a list of short local shifts. Bring identification to the front desk if you want to take available work.',
                        ?, 0)
                """,
                (character_id, int(row["day"])),
            )

            shovel = con.execute(
                "SELECT id FROM inventory WHERE character_id = ? AND item_name = 'Old Shovel'",
                (character_id,),
            ).fetchone()
            if shovel is None:
                con.execute(
                    "INSERT INTO inventory (character_id, item_name, quantity, description) VALUES (?, 'Old Shovel', 1, ?)",
                    (character_id, WEAPONS["Old Shovel"].description),
                )
            if not row["equipped_weapon"]:
                con.execute(
                    "UPDATE character SET equipped_weapon = 'Old Shovel' WHERE id = ?",
                    (character_id,),
                )


            # Normalize known item descriptions so older saves follow the current serious prose style.
            descriptions = {name: weapon.description for name, weapon in WEAPONS.items()}
            descriptions.update({name: item.description for name, item in HEALING_ITEMS.items()})
            descriptions.update({item.name: item.description for item in STORE_ITEMS})
            descriptions.update({item.name: item.description for item in FURNITURE_STORE})
            descriptions.update(GATHERING_ITEM_DESCRIPTIONS)
            descriptions.update({item.name: item.description for item in ITEM_BY_NAME.values()})
            descriptions.update({crop.seed_item: crop.description for crop in CROPS.values()})
            descriptions.update({crop.produce_item: crop.produce_description for crop in CROPS.values()})
            descriptions.update({animal.product_item: animal.product_description for animal in ANIMALS.values()})
            descriptions.update({
                "Sleeping Bag": "A basic synthetic sleeping bag.",
                "Loose Change": "A few coins collected from the mud.",
                "Wild Berries": "A handful of ripe wild berries gathered beside the trail.",
                "Scrap Metal": "A bent piece of metal that might eventually be useful.",
                "Old Rope": "Several metres of weathered rope.",
            })
            for enemy in ENEMIES.values():
                for item_name, _chance, description in enemy.loot:
                    descriptions[item_name] = description
            for item_name, description in descriptions.items():
                con.execute(
                    "UPDATE inventory SET description = ? WHERE character_id = ? AND item_name = ?",
                    (description, character_id, item_name),
                )

            combat = con.execute(
                "SELECT enemy_key, log_text FROM combat_state WHERE character_id = ?", (character_id,)
            ).fetchone()
            if combat and combat["enemy_key"] in ENEMIES:
                old_lines = [line for line in (combat["log_text"] or "").split("\n") if line]
                old_descriptions = {
                    "A lean dog steps onto the trail and decides you are now a problem.",
                    "A raccoon erupts from the brush with the confidence of something that has never paid taxes.",
                }
                old_lines = [line for line in old_lines if line not in old_descriptions]
                enemy = ENEMIES[combat["enemy_key"]]
                con.execute(
                    "UPDATE combat_state SET log_text = ? WHERE character_id = ?",
                    ("\n".join([enemy.description] + old_lines[-7:]), character_id),
                )

    def has_save(self) -> bool:
        return self.db.fetchone("SELECT id FROM character LIMIT 1") is not None

    def create_new_game(self, name: str) -> Character:
        clean_name = " ".join(name.strip().split())
        if not clean_name:
            raise ValueError("Character name cannot be empty.")
        if len(clean_name) > 24:
            raise ValueError("Character name must be 24 characters or fewer.")

        starter_plots = self.db.fetchall(
            """
            SELECT id FROM plots
            WHERE starter_eligible = 1 AND owner_character_id IS NULL
            ORDER BY id
            """
        )
        if not starter_plots:
            raise RuntimeError("No starter plots are available.")

        chosen_plot_id = random.SystemRandom().choice(starter_plots)["id"]
        now = datetime.now().isoformat(timespec="seconds")

        with self.db.transaction() as con:
            con.execute("DELETE FROM child_schooling")
            con.execute("DELETE FROM pets")
            con.execute("DELETE FROM court_cases")
            con.execute("DELETE FROM property_rentals")
            con.execute("DELETE FROM education_certificates")
            con.execute("DELETE FROM education_enrollment")
            con.execute("DELETE FROM combat_state")
            con.execute("DELETE FROM career_shift_log")
            con.execute("DELETE FROM career_history")
            con.execute("DELETE FROM career_shift_state")
            con.execute("DELETE FROM career_progress")
            con.execute("DELETE FROM career_employment")
            con.execute("DELETE FROM job_state")
            con.execute("DELETE FROM travel_state")
            con.execute("DELETE FROM vehicle_storage")
            con.execute("DELETE FROM vehicles")
            con.execute("DELETE FROM construction_state")
            con.execute("DELETE FROM furniture")
            con.execute("DELETE FROM property_storage")
            con.execute("DELETE FROM jail_state")
            con.execute("DELETE FROM crime_record")
            con.execute("DELETE FROM blackjack_state")
            con.execute("DELETE FROM vice_record")
            con.execute("DELETE FROM vice_profile")
            con.execute("DELETE FROM household_children")
            con.execute("DELETE FROM household")
            con.execute("DELETE FROM crime_profile")
            con.execute("DELETE FROM business_visits")
            con.execute("DELETE FROM npc_favors")
            con.execute("DELETE FROM mail")
            con.execute("DELETE FROM daily_actions")
            con.execute("DELETE FROM npc_relationships")
            con.execute("DELETE FROM business_stock")
            con.execute("DELETE FROM businesses")
            con.execute("DELETE FROM farm_animals")
            con.execute("DELETE FROM farm_feed")
            con.execute("DELETE FROM farm_crops")
            con.execute("DELETE FROM known_locations")
            con.execute("DELETE FROM regional_reputation")
            con.execute("DELETE FROM skills")
            con.execute("DELETE FROM inventory")
            con.execute("DELETE FROM structures")
            con.execute("UPDATE plots SET owner_character_id = NULL")
            con.execute("DELETE FROM character")

            cursor = con.execute(
                """
                INSERT INTO character (
                    name, hp, max_hp, stamina, max_stamina, cash,
                    home_plot_id, current_location, day, time_minutes,
                    weather, created_at, updated_at, stamina_updated_at, equipped_weapon
                ) VALUES (?, 20, 20, 20, 20, 25, ?, ?, 1, 480, ?, ?, ?, ?, 'Old Shovel')
                """,
                (
                    clean_name,
                    chosen_plot_id,
                    f"plot:{chosen_plot_id}",
                    "Light Rain",
                    now,
                    now,
                    now,
                ),
            )
            character_id = cursor.lastrowid
            con.execute(
                "UPDATE plots SET owner_character_id = ? WHERE id = ?",
                (character_id, chosen_plot_id),
            )
            con.execute(
                """
                INSERT INTO structures (plot_id, structure_type, name, condition_percent, definition_key, built_at)
                VALUES (?, 'shelter', 'Basic Tent', 100, 'basic_tent', ?)
                """,
                (chosen_plot_id, now),
            )
            starter_items = [
                (character_id, "Sleeping Bag", 1, "A basic synthetic sleeping bag."),
                (character_id, "Water Bottle", 1, "A reusable bottle containing drinking water."),
                (character_id, "Old Shovel", 1, WEAPONS["Old Shovel"].description),
                (character_id, "Granola Bar", 1, HEALING_ITEMS["Granola Bar"].description),
            ]
            con.executemany(
                """
                INSERT INTO inventory (character_id, item_name, quantity, description)
                VALUES (?, ?, ?, ?)
                """,
                starter_items,
            )
            for skill in ("Work", "Exploration", "Combat", "Farming", "Fishing", "Speech", "Crime", "Mining", "Woodcutting", "Crafting", "Driving", "Vice", "Hunting", "Survival", "Education"):
                con.execute(
                    "INSERT INTO skills (character_id, skill_name, xp) VALUES (?, ?, 0)",
                    (character_id, skill),
                )
            for location_key in LOCATIONS:
                con.execute(
                    "INSERT INTO known_locations (character_id, location_key) VALUES (?, ?)",
                    (character_id, location_key),
                )
            for npc_key in NPCS:
                con.execute(
                    "INSERT INTO npc_relationships (character_id, npc_key, friendship, talk_count) VALUES (?, ?, 0, 0)",
                    (character_id, npc_key),
                )
            con.execute(
                "INSERT INTO crime_profile (character_id, heat, crimes_committed, arrests, murders, mask_worn, last_heat_day) VALUES (?, 0, 0, 0, 0, 0, 1)",
                (character_id,),
            )
            con.execute(
                """
                INSERT INTO vice_profile (
                    character_id, last_processed_day, last_processed_minute
                ) VALUES (?, 1, 480)
                """,
                (character_id,),
            )
            con.execute(
                "INSERT INTO household (character_id, spouse_npc_key, married_day, expecting_child, child_due_day) VALUES (?, NULL, NULL, 0, NULL)",
                (character_id,),
            )
            con.execute(
                """
                INSERT INTO mail (character_id, mail_key, sender, subject, body, sent_day, is_read)
                VALUES (?, 'county_deed', 'Millhaven County Land Office', 'Property Deed Registered',
                        'Your ownership of the assigned property has been registered with the county. The parcel may be developed for residential, agricultural, or approved commercial use.',
                        1, 0)
                """,
                (character_id,),
            )
            con.execute(
                """
                INSERT INTO mail (character_id, mail_key, sender, subject, body, sent_day, is_read)
                VALUES (?, 'employment_notice', 'Millhaven Employment Office', 'Temporary Work Available',
                        'The employment office maintains a list of short local shifts. Bring identification to the front desk if you want to take available work.',
                        1, 0)
                """,
                (character_id,),
            )

        return self.load_character()

    def _apply_stamina_regen(self) -> None:
        row = self.db.fetchone("SELECT * FROM character LIMIT 1")
        if row is None or row["stamina"] >= row["max_stamina"]:
            return
        stamp = row["stamina_updated_at"] or row["updated_at"] or row["created_at"]
        if not stamp:
            return
        last = datetime.fromisoformat(stamp)
        now = datetime.now()
        elapsed = max(0, int((now - last).total_seconds()))
        gained = elapsed // self.STAMINA_REGEN_SECONDS
        if gained <= 0:
            return
        new_stamina = min(row["max_stamina"], row["stamina"] + gained)
        advanced = last + timedelta(seconds=gained * self.STAMINA_REGEN_SECONDS)
        if new_stamina >= row["max_stamina"]:
            advanced = now
        self.db.execute(
            "UPDATE character SET stamina = ?, stamina_updated_at = ? WHERE id = ?",
            (new_stamina, advanced.isoformat(timespec="seconds"), row["id"]),
        )

    def _finish_elapsed_states(self) -> None:
        if not self.has_save():
            return
        now = datetime.now()
        character = self.db.fetchone("SELECT * FROM character LIMIT 1")
        if character is None:
            return

        jail = self.db.fetchone("SELECT * FROM jail_state WHERE character_id = ?", (character["id"],))
        if jail and now >= datetime.fromisoformat(jail["release_at"]):
            self._release_from_jail(dict(jail))
            character = self.db.fetchone("SELECT * FROM character LIMIT 1")
            if character is None:
                return

        travel = self.db.fetchone("SELECT * FROM travel_state WHERE character_id = ?", (character["id"],))
        if travel and now >= datetime.fromisoformat(travel["arrives_at"]):
            destination = travel["destination_key"]
            current_location = f"plot:{character['home_plot_id']}" if destination == "home" else destination
            self._advance_time(character["id"], travel["game_minutes"], current_location=current_location)
            if "mount_animal_id" in travel.keys() and travel["mount_animal_id"]:
                self.db.execute(
                    "UPDATE farm_animals SET current_location = ? WHERE id = ?",
                    (destination, travel["mount_animal_id"]),
                )
            if "vehicle_id" in travel.keys() and travel["vehicle_id"]:
                self.db.execute(
                    """
                    UPDATE vehicles
                    SET current_location = ?,
                        fuel = MAX(0, fuel - ?),
                        condition_percent = MAX(0, condition_percent - ?)
                    WHERE id = ?
                    """,
                    (destination, int(travel["fuel_used"] or 0), int(travel["condition_used"] or 0), travel["vehicle_id"]),
                )
                self.db.execute(
                    "UPDATE skills SET xp = xp + 1 WHERE character_id = ? AND skill_name = 'Driving'",
                    (character["id"],),
                )
            self.db.execute("DELETE FROM travel_state WHERE character_id = ?", (character["id"],))

        job = self.db.fetchone("SELECT * FROM job_state WHERE character_id = ?", (character["id"],))
        if job and now >= datetime.fromisoformat(job["completes_at"]):
            self._complete_job_row(dict(job))

        career_shift = self.db.fetchone("SELECT * FROM career_shift_state WHERE character_id = ?", (character["id"],))
        if career_shift and now >= datetime.fromisoformat(career_shift["completes_at"]):
            self._complete_career_shift_row(dict(career_shift))

        construction = self.db.fetchone(
            "SELECT * FROM construction_state WHERE character_id = ?", (character["id"],)
        )
        if construction and now >= datetime.fromisoformat(construction["completes_at"]):
            self._complete_construction_row(dict(construction))

    def load_character(self) -> Character:
        self._apply_stamina_regen()
        self._finish_elapsed_states()
        row = self.db.fetchone("SELECT * FROM character LIMIT 1")
        if row is None:
            raise RuntimeError("No saved character exists.")
        self._process_family_events(int(row["id"]), int(row["day"]))
        self._process_vice_state(row)
        self._process_rent_income(int(row["id"]), int(row["day"]))
        self._process_child_schooling(int(row["id"]), int(row["day"]))
        row = self.db.fetchone("SELECT * FROM character LIMIT 1")
        normalized = normalize_location_key(row["current_location"])
        if normalized == "home":
            plot_row = self.db.fetchone("SELECT region_key FROM plots WHERE id = ?", (row["home_plot_id"],))
            region_key = plot_row["region_key"] if plot_row else "millhaven_county"
        else:
            region_key = region_key_for_location(normalized)
        expected_weather = weather_for_day(int(row["day"]), region_key)
        if row["weather"] != expected_weather:
            self.db.execute("UPDATE character SET weather = ? WHERE id = ?", (expected_weather, row["id"]))
            row = self.db.fetchone("SELECT * FROM character LIMIT 1")
        return Character(
            id=row["id"],
            name=row["name"],
            hp=row["hp"],
            max_hp=row["max_hp"],
            stamina=row["stamina"],
            max_stamina=row["max_stamina"],
            cash=row["cash"],
            home_plot_id=row["home_plot_id"],
            current_location=row["current_location"],
            day=row["day"],
            time_minutes=row["time_minutes"],
            weather=row["weather"],
            equipped_weapon=row["equipped_weapon"] or "Old Shovel",
        )

    def load_home_plot(self) -> dict:
        character = self.load_character()
        row = self.db.fetchone("SELECT * FROM plots WHERE id = ?", (character.home_plot_id,))
        if row is None:
            raise RuntimeError("Home plot is missing.")
        return dict(row)

    def load_structures(self) -> list[dict]:
        character = self.load_character()
        rows = self.db.fetchall(
            "SELECT * FROM structures WHERE plot_id = ? ORDER BY id", (character.home_plot_id,)
        )
        return [dict(row) for row in rows]

    def load_inventory(self) -> list[dict]:
        character = self.load_character()
        rows = self.db.fetchall(
            "SELECT * FROM inventory WHERE character_id = ? ORDER BY item_name", (character.id,)
        )
        return [dict(row) for row in rows]

    def load_skills(self) -> list[dict]:
        character = self.load_character()
        rows = self.db.fetchall(
            "SELECT skill_name, xp FROM skills WHERE character_id = ? ORDER BY skill_name",
            (character.id,),
        )
        return [
            {"skill_name": row["skill_name"], "xp": row["xp"], "level": row["xp"] // 10}
            for row in rows
        ]

    def skill_level(self, skill_name: str) -> int:
        character = self.load_character()
        row = self.db.fetchone(
            "SELECT xp FROM skills WHERE character_id = ? AND skill_name = ?",
            (character.id, skill_name),
        )
        return int(row["xp"] // 10) if row else 0

    def known_locations(self) -> list[str]:
        character = self.load_character()
        return [
            row["location_key"]
            for row in self.db.fetchall(
                "SELECT location_key FROM known_locations WHERE character_id = ? ORDER BY id",
                (character.id,),
            )
        ]

    def current_normalized_location(self) -> str:
        return normalize_location_key(self.load_character().current_location)

    def is_busy(self) -> bool:
        return bool(
            self.get_travel_state() or self.get_job_state() or self.get_career_shift_state() or self.get_combat_state()
            or self.get_jail_state() or self.get_blackjack_state()
        )

    # ---------- Travel ----------
    def get_travel_state(self) -> dict | None:
        character = self.db.fetchone("SELECT id FROM character LIMIT 1")
        if not character:
            return None
        row = self.db.fetchone("SELECT * FROM travel_state WHERE character_id = ?", (character["id"],))
        if row is None:
            return None
        if datetime.now() >= datetime.fromisoformat(row["arrives_at"]):
            self._finish_elapsed_states()
            return None
        result = dict(row)
        result["remaining_seconds"] = max(
            0, int((datetime.fromisoformat(row["arrives_at"]) - datetime.now()).total_seconds()) + 1
        )
        return result

    def start_travel(self, destination: str, method: str = "Walking") -> dict:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You are already busy.")
        origin = normalize_location_key(character.current_location)
        if destination == origin:
            raise ValueError("You are already there.")
        allowed = set(self.known_locations()) | {"home"}
        if destination not in allowed:
            raise ValueError("That destination is not known yet.")

        home_region_key = self.load_home_plot().get("region_key", "millhaven_county")
        if not method_allowed_on_route(origin, destination, method):
            raise RuntimeError("That transportation method cannot be used on this route.")
        mount_animal_id = None
        vehicle_id = None
        fuel_used = 0
        condition_used = 0
        fare = 0

        public_option = public_transport_option(origin, destination, method) if method in PUBLIC_METHODS else None
        if method in PUBLIC_METHODS:
            if public_option is None:
                raise RuntimeError("That public transport service does not operate on this route.")
            fare = int(public_option.fare)
            if character.cash < fare:
                raise RuntimeError("You do not have enough cash for the fare.")
        elif method == "Horse":
            horse = self.db.fetchone(
                "SELECT id FROM farm_animals WHERE plot_id = ? AND animal_key = 'horse' AND COALESCE(current_location, 'home') = ? ORDER BY id LIMIT 1",
                (character.home_plot_id, origin),
            )
            if horse is None:
                raise RuntimeError("You do not have a horse at your current location.")
            mount_animal_id = horse["id"]
        elif method != "Walking":
            found = None
            fuel_used = route_fuel_units(origin, destination, method, home_region_key)
            matching_exists = False
            for row in self.db.fetchall(
                "SELECT * FROM vehicles WHERE character_id = ? AND current_location = ? ORDER BY id",
                (character.id, origin),
            ):
                definition = VEHICLES.get(row["vehicle_key"])
                if not definition or definition.method != method:
                    continue
                matching_exists = True
                if int(row["condition_percent"]) <= 0:
                    continue
                if definition.motorized and int(row["fuel"]) < fuel_used:
                    continue
                found = (row, definition)
                break
            if found is None:
                if matching_exists:
                    raise RuntimeError("No usable vehicle of that type has enough fuel and condition for the trip.")
                raise RuntimeError("You do not have that vehicle at your current location.")
            vehicle, definition = found
            vehicle_id = int(vehicle["id"])
            condition_used = int(definition.wear_per_trip)

        duration = travel_seconds(origin, destination, method, home_region_key)
        game_minutes = travel_game_minutes(origin, destination, method, home_region_key)
        started = datetime.now()
        arrives = started + timedelta(seconds=duration)
        with self.db.transaction() as con:
            if fare:
                con.execute("UPDATE character SET cash = cash - ? WHERE id = ?", (fare, character.id))
            con.execute(
                """
                INSERT OR REPLACE INTO travel_state (
                    character_id, origin_key, destination_key, method,
                    started_at, arrives_at, duration_seconds, game_minutes, mount_animal_id,
                    vehicle_id, fuel_used, condition_used
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    character.id, origin, destination, method,
                    started.isoformat(timespec="seconds"),
                    arrives.isoformat(timespec="seconds"),
                    duration, game_minutes, mount_animal_id, vehicle_id, fuel_used, condition_used,
                ),
            )
        return self.get_travel_state() or {}

    def public_transport_options(self, destination: str) -> list[dict]:
        character = self.load_character()
        origin = normalize_location_key(character.current_location)
        return [
            {
                "method": option.method,
                "fare": option.fare,
                "game_minutes": option.game_minutes,
                "real_seconds": option.real_seconds,
                "description": option.description,
            }
            for option in public_transport_options(origin, destination)
        ]

    def cancel_travel(self) -> None:
        character = self.load_character()
        self.db.execute("DELETE FROM travel_state WHERE character_id = ?", (character.id,))

    def available_travel_methods(self) -> list[str]:
        character = self.load_character()
        origin = normalize_location_key(character.current_location)
        methods = ["Walking"]
        horse = self.db.fetchone(
            "SELECT id FROM farm_animals WHERE plot_id = ? AND animal_key = 'horse' AND COALESCE(current_location, 'home') = ? LIMIT 1",
            (character.home_plot_id, origin),
        )
        if horse is not None:
            methods.append("Horse")
        for row in self.db.fetchall(
            "SELECT vehicle_key, fuel, condition_percent FROM vehicles WHERE character_id = ? AND current_location = ? ORDER BY id",
            (character.id, origin),
        ):
            definition = VEHICLES.get(row["vehicle_key"])
            if not definition or int(row["condition_percent"]) <= 0:
                continue
            if definition.method not in methods:
                methods.append(definition.method)
        return methods

    # ---------- Vehicles ----------
    def load_vehicles(self) -> list[dict]:
        character = self.load_character()
        rows = self.db.fetchall(
            "SELECT * FROM vehicles WHERE character_id = ? ORDER BY id",
            (character.id,),
        )
        result: list[dict] = []
        for row in rows:
            definition = VEHICLES.get(row["vehicle_key"])
            if not definition:
                continue
            data = dict(row)
            data.update({
                "name": definition.name,
                "method": definition.method,
                "description": definition.description,
                "fuel_capacity": definition.fuel_capacity,
                "storage_capacity": definition.storage_capacity,
                "motorized": definition.motorized,
                "storage_used": self.vehicle_storage_used(int(row["id"])),
            })
            result.append(data)
        return result

    def buy_vehicle(self, vehicle_key: str) -> int:
        character = self.load_character()
        current = normalize_location_key(character.current_location)
        if current not in {"millhaven", "redwater", "greybridge_city", "westhaven", "lake_mercy"}:
            raise RuntimeError("You need to be at a vehicle or marine dealer to buy a vehicle.")
        if self.is_busy():
            raise RuntimeError("You cannot buy a vehicle while occupied with another activity.")
        definition = VEHICLES.get(vehicle_key)
        if definition and definition.method in {"Rowboat", "Motorboat"} and current not in {"lake_mercy", "westhaven"}:
            raise RuntimeError("Boats are sold at Lake Mercy Marina and Westhaven Harbour.")
        if definition and definition.method not in {"Rowboat", "Motorboat"} and current == "lake_mercy":
            raise RuntimeError("The marina only sells boats.")
        if not definition:
            raise ValueError("Unknown vehicle.")
        if character.cash < definition.price:
            raise RuntimeError("You do not have enough cash.")
        now = datetime.now().isoformat(timespec="seconds")
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? WHERE id = ?", (definition.price, character.id))
            cursor = con.execute(
                "INSERT INTO vehicles (character_id, vehicle_key, current_location, fuel, condition_percent, purchased_at) VALUES (?, ?, ?, ?, 100, ?)",
                (character.id, vehicle_key, current, definition.fuel_capacity, now),
            )
            return int(cursor.lastrowid)

    def refuel_vehicle(self, vehicle_id: int) -> int:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You cannot refuel a vehicle while occupied with another activity.")
        current = normalize_location_key(character.current_location)
        if current not in {"millhaven", "redwater", "greybridge_city", "westhaven", "lake_mercy"}:
            raise RuntimeError("Fuel is only available at a service garage or marina.")
        row = self.db.fetchone("SELECT * FROM vehicles WHERE id = ? AND character_id = ?", (vehicle_id, character.id))
        if not row:
            raise RuntimeError("Vehicle not found.")
        definition = VEHICLES[row["vehicle_key"]]
        if not definition.motorized:
            raise RuntimeError("That vehicle does not use fuel.")
        if row["current_location"] != current:
            raise RuntimeError("The vehicle needs to be at your current service garage for refuelling.")
        missing = max(0, definition.fuel_capacity - int(row["fuel"]))
        if missing <= 0:
            return 0
        affordable = min(missing, character.cash // FUEL_PRICE_PER_UNIT)
        if affordable <= 0:
            raise RuntimeError("You do not have enough cash to buy fuel.")
        cost = affordable * FUEL_PRICE_PER_UNIT
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? WHERE id = ?", (cost, character.id))
            con.execute("UPDATE vehicles SET fuel = fuel + ? WHERE id = ?", (affordable, vehicle_id))
        return cost

    def repair_vehicle(self, vehicle_id: int) -> int:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You cannot repair a vehicle while occupied with another activity.")
        current = normalize_location_key(character.current_location)
        row = self.db.fetchone("SELECT * FROM vehicles WHERE id = ? AND character_id = ?", (vehicle_id, character.id))
        if not row:
            raise RuntimeError("Vehicle not found.")
        if row["current_location"] != current:
            raise RuntimeError("The vehicle is not at your current location.")
        home_garage = current == "home" and self.has_structure("garage")
        if current not in {"millhaven", "redwater", "greybridge_city", "westhaven", "lake_mercy"} and not home_garage:
            raise RuntimeError("Repairs require a city service garage or a Garage on your property.")
        missing = max(0, 100 - int(row["condition_percent"]))
        if missing <= 0:
            return 0
        price_per_point = 1 if home_garage else REPAIR_PRICE_PER_CONDITION
        affordable_points = min(missing, character.cash // price_per_point)
        if affordable_points <= 0:
            raise RuntimeError("You do not have enough cash for repairs.")
        cost = affordable_points * price_per_point
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? WHERE id = ?", (cost, character.id))
            con.execute("UPDATE vehicles SET condition_percent = condition_percent + ? WHERE id = ?", (affordable_points, vehicle_id))
        return cost

    def load_vehicle_storage(self, vehicle_id: int) -> list[dict]:
        character = self.load_character()
        vehicle = self.db.fetchone("SELECT id FROM vehicles WHERE id = ? AND character_id = ?", (vehicle_id, character.id))
        if not vehicle:
            return []
        return [dict(row) for row in self.db.fetchall(
            "SELECT * FROM vehicle_storage WHERE vehicle_id = ? ORDER BY item_name",
            (vehicle_id,),
        )]

    def vehicle_storage_used(self, vehicle_id: int) -> int:
        row = self.db.fetchone("SELECT COALESCE(SUM(quantity), 0) AS total FROM vehicle_storage WHERE vehicle_id = ?", (vehicle_id,))
        return int(row["total"] or 0)

    def store_item_in_vehicle(self, vehicle_id: int, item_name: str) -> None:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You cannot move cargo while occupied with another activity.")
        current = normalize_location_key(character.current_location)
        vehicle = self.db.fetchone("SELECT * FROM vehicles WHERE id = ? AND character_id = ?", (vehicle_id, character.id))
        if not vehicle or vehicle["current_location"] != current:
            raise RuntimeError("That vehicle is not at your current location.")
        definition = VEHICLES[vehicle["vehicle_key"]]
        if self.vehicle_storage_used(vehicle_id) >= definition.storage_capacity:
            raise RuntimeError("Vehicle storage is full.")
        if item_name == character.equipped_weapon:
            raise RuntimeError("Equip a different weapon before storing this item.")
        item = self.db.fetchone("SELECT description FROM inventory WHERE character_id = ? AND item_name = ? AND quantity > 0", (character.id, item_name))
        if not item:
            raise RuntimeError("You do not have that item.")
        with self.db.transaction() as con:
            if not self._remove_inventory_item(con, character.id, item_name):
                raise RuntimeError("You do not have that item.")
            row = con.execute("SELECT id FROM vehicle_storage WHERE vehicle_id = ? AND item_name = ?", (vehicle_id, item_name)).fetchone()
            if row:
                con.execute("UPDATE vehicle_storage SET quantity = quantity + 1 WHERE id = ?", (row["id"],))
            else:
                con.execute("INSERT INTO vehicle_storage (vehicle_id, item_name, quantity, description) VALUES (?, ?, 1, ?)", (vehicle_id, item_name, item["description"]))

    def take_item_from_vehicle(self, vehicle_id: int, item_name: str) -> None:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You cannot move cargo while occupied with another activity.")
        current = normalize_location_key(character.current_location)
        vehicle = self.db.fetchone("SELECT * FROM vehicles WHERE id = ? AND character_id = ?", (vehicle_id, character.id))
        if not vehicle or vehicle["current_location"] != current:
            raise RuntimeError("That vehicle is not at your current location.")
        row = self.db.fetchone("SELECT * FROM vehicle_storage WHERE vehicle_id = ? AND item_name = ? AND quantity > 0", (vehicle_id, item_name))
        if not row:
            raise RuntimeError("That item is not stored in the vehicle.")
        with self.db.transaction() as con:
            if int(row["quantity"]) <= 1:
                con.execute("DELETE FROM vehicle_storage WHERE id = ?", (row["id"],))
            else:
                con.execute("UPDATE vehicle_storage SET quantity = quantity - 1 WHERE id = ?", (row["id"],))
            self._add_inventory_item(con, character.id, item_name, row["description"])

    # ---------- Jobs ----------
    def get_job_state(self) -> dict | None:
        character = self.db.fetchone("SELECT id FROM character LIMIT 1")
        if not character:
            return None
        row = self.db.fetchone("SELECT * FROM job_state WHERE character_id = ?", (character["id"],))
        if row is None:
            return None
        if datetime.now() >= datetime.fromisoformat(row["completes_at"]):
            self._finish_elapsed_states()
            return None
        result = dict(row)
        result["remaining_seconds"] = max(
            0, int((datetime.fromisoformat(row["completes_at"]) - datetime.now()).total_seconds()) + 1
        )
        return result

    def start_job(self, job_key: str) -> dict:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You are already busy.")
        job = JOBS[job_key]
        current = normalize_location_key(character.current_location)
        if current != job.location_key:
            raise RuntimeError(f"You need to be in {LOCATIONS[job.location_key].name} to take this job.")
        delivery_vehicle_id = None
        if job.requires_motor_vehicle:
            for row in self.db.fetchall(
                "SELECT * FROM vehicles WHERE character_id = ? AND current_location = ? ORDER BY id",
                (character.id, current),
            ):
                definition = VEHICLES.get(row["vehicle_key"])
                if definition and definition.motorized and int(row["condition_percent"]) > 0 and int(row["fuel"]) >= 2:
                    delivery_vehicle_id = int(row["id"])
                    break
            if delivery_vehicle_id is None:
                raise RuntimeError("This job requires a motor vehicle here with at least 2 fuel and usable condition.")
        if character.stamina < job.stamina_cost:
            raise RuntimeError("You do not have enough stamina for that job.")
        now = datetime.now()
        completes = now + timedelta(seconds=job.duration_seconds)
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET stamina = stamina - ?, stamina_updated_at = ?, updated_at = ? WHERE id = ?",
                (job.stamina_cost, now.isoformat(timespec="seconds"), now.isoformat(timespec="seconds"), character.id),
            )
            if delivery_vehicle_id is not None:
                con.execute(
                    "UPDATE vehicles SET fuel = fuel - 2, condition_percent = MAX(0, condition_percent - 1) WHERE id = ?",
                    (delivery_vehicle_id,),
                )
            con.execute(
                """
                INSERT OR REPLACE INTO job_state (
                    character_id, job_key, started_at, completes_at, duration_seconds
                ) VALUES (?, ?, ?, ?, ?)
                """,
                (character.id, job.key, now.isoformat(timespec="seconds"), completes.isoformat(timespec="seconds"), job.duration_seconds),
            )
        return self.get_job_state() or {}

    def _complete_job_row(self, state: dict) -> None:
        character = self.db.fetchone("SELECT * FROM character WHERE id = ?", (state["character_id"],))
        if character is None:
            return
        job = JOBS[state["job_key"]]
        day, minutes = self._time_after(character["day"], character["time_minutes"], job.game_minutes)
        now = datetime.now().isoformat(timespec="seconds")
        region_key = region_key_for_location(job.location_key)
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET cash = cash + ?, day = ?, time_minutes = ?, updated_at = ? WHERE id = ?",
                (job.pay, day, minutes, now, character["id"]),
            )
            con.execute(
                "UPDATE skills SET xp = xp + ? WHERE character_id = ? AND skill_name = 'Work'",
                (job.work_xp, character["id"]),
            )
            if job.skill_name and job.skill_xp:
                con.execute(
                    "UPDATE skills SET xp = xp + ? WHERE character_id = ? AND skill_name = ?",
                    (job.skill_xp, character["id"], job.skill_name),
                )
            con.execute(
                "INSERT OR IGNORE INTO regional_reputation (character_id, region_key, reputation) VALUES (?, ?, 0)",
                (character["id"], region_key),
            )
            con.execute(
                "UPDATE regional_reputation SET reputation = MIN(100, reputation + 1) WHERE character_id = ? AND region_key = ?",
                (character["id"], region_key),
            )
            con.execute("DELETE FROM job_state WHERE character_id = ?", (character["id"],))

    # ---------- Careers ----------
    def _process_career_attendance(self) -> None:
        character = self.db.fetchone("SELECT * FROM character LIMIT 1")
        if character is None:
            return
        employment = self.db.fetchone("SELECT * FROM career_employment WHERE character_id = ?", (character["id"],))
        if employment is None:
            return
        current_day = int(character["day"])
        last_checked = int(employment["last_checked_day"])
        reliability = int(employment["reliability"])
        missed = int(employment["missed_shifts"])
        career_key = employment["career_key"]
        fired = False
        for day in range(last_checked, current_day):
            if day < int(employment["hired_day"]):
                continue
            if not is_scheduled_workday(day):
                continue
            worked = self.db.fetchone(
                "SELECT 1 FROM career_shift_log WHERE character_id = ? AND career_key = ? AND shift_day = ?",
                (character["id"], career_key, day),
            )
            if worked:
                reliability = min(100, reliability + 2)
            else:
                reliability = max(0, reliability - 15)
                missed += 1
        with self.db.transaction() as con:
            con.execute(
                "UPDATE career_employment SET last_checked_day = ?, reliability = ?, missed_shifts = ? WHERE character_id = ?",
                (current_day, reliability, missed, character["id"]),
            )
            if reliability <= 20:
                career = CAREERS.get(career_key)
                if career:
                    con.execute(
                        "INSERT INTO career_history (character_id, career_key, day, event_type, description) VALUES (?, ?, ?, 'terminated', ?)",
                        (character["id"], career_key, current_day, f"Employment with {career.employer} ended because of repeated missed shifts."),
                    )
                con.execute("DELETE FROM career_employment WHERE character_id = ?", (character["id"],))
                fired = True
        return fired

    def career_profile(self) -> dict | None:
        self._process_career_attendance()
        character = self.db.fetchone("SELECT * FROM character LIMIT 1")
        if character is None:
            return None
        employment = self.db.fetchone("SELECT * FROM career_employment WHERE character_id = ?", (character["id"],))
        if employment is None:
            return None
        career = CAREERS.get(employment["career_key"])
        if career is None:
            return None
        progress = self.db.fetchone(
            "SELECT * FROM career_progress WHERE character_id = ? AND career_key = ?",
            (character["id"], career.key),
        )
        shifts = int(progress["shifts_worked"]) if progress else 0
        rank_name, multiplier = career_rank(shifts)
        nxt = next_rank(shifts)
        worked_today = self.db.fetchone(
            "SELECT 1 FROM career_shift_log WHERE character_id = ? AND career_key = ? AND shift_day = ?",
            (character["id"], career.key, int(character["day"])),
        ) is not None
        return {
            "key": career.key,
            "name": career.name,
            "employer": career.employer,
            "location_key": career.location_key,
            "description": career.description,
            "base_pay": career.base_pay,
            "daily_pay": int(round(career.base_pay * multiplier)),
            "rank": rank_name,
            "shifts_worked": shifts,
            "career_xp": int(progress["career_xp"]) if progress else 0,
            "reliability": int(employment["reliability"]),
            "missed_shifts": int(employment["missed_shifts"]),
            "hired_day": int(employment["hired_day"]),
            "worked_today": worked_today,
            "scheduled_today": is_scheduled_workday(int(character["day"])),
            "weekday": weekday_name(int(character["day"])),
            "next_rank": nxt,
            "stamina_cost": career.stamina_cost,
            "primary_skill": career.primary_skill,
            "skill_xp": career.skill_xp,
        }

    def available_careers(self) -> list[dict]:
        character = self.load_character()
        current = normalize_location_key(character.current_location)
        region = region_key_for_location(current) if current in LOCATIONS else "millhaven_county"
        rep_row = self.db.fetchone(
            "SELECT reputation FROM regional_reputation WHERE character_id = ? AND region_key = ?",
            (character.id, region),
        )
        reputation = int(rep_row["reputation"]) if rep_row else 0
        results = []
        for career in CAREERS.values():
            if career.location_key != current:
                continue
            skill_level = self.skill_level(career.primary_skill) if career.primary_skill else 0
            has_certificate = (not career.required_certificate) or self.has_certificate(career.required_certificate)
            qualifies = skill_level >= career.required_skill_level and reputation >= career.required_reputation and has_certificate
            results.append({
                "key": career.key,
                "name": career.name,
                "employer": career.employer,
                "description": career.description,
                "base_pay": career.base_pay,
                "stamina_cost": career.stamina_cost,
                "required_skill": career.primary_skill,
                "required_skill_level": career.required_skill_level,
                "current_skill_level": skill_level,
                "required_reputation": career.required_reputation,
                "current_reputation": reputation,
                "required_certificate": career.required_certificate,
                "has_certificate": has_certificate,
                "qualifies": qualifies,
            })
        return results

    def apply_for_career(self, career_key: str) -> None:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You cannot apply while occupied with another activity.")
        if self.db.fetchone("SELECT 1 FROM career_employment WHERE character_id = ?", (character.id,)):
            raise RuntimeError("You already have a full-time career. Resign before accepting another position.")
        career = CAREERS.get(career_key)
        if career is None:
            raise ValueError("Unknown career.")
        current = normalize_location_key(character.current_location)
        if current != career.location_key:
            raise RuntimeError(f"You need to be in {LOCATIONS[career.location_key].name} to apply for this position.")
        region = region_key_for_location(current)
        rep_row = self.db.fetchone(
            "SELECT reputation FROM regional_reputation WHERE character_id = ? AND region_key = ?",
            (character.id, region),
        )
        reputation = int(rep_row["reputation"]) if rep_row else 0
        skill_level = self.skill_level(career.primary_skill) if career.primary_skill else 0
        if skill_level < career.required_skill_level:
            raise RuntimeError(f"This position requires {career.primary_skill} level {career.required_skill_level}.")
        if reputation < career.required_reputation:
            raise RuntimeError(f"This employer requires city reputation of at least {career.required_reputation}.")
        if career.required_certificate and not self.has_certificate(career.required_certificate):
            raise RuntimeError(f"This position requires the {career.required_certificate} certificate.")
        with self.db.transaction() as con:
            con.execute(
                "INSERT INTO career_employment (character_id, career_key, hired_day, last_checked_day, reliability, missed_shifts) VALUES (?, ?, ?, ?, 100, 0)",
                (character.id, career.key, character.day, character.day),
            )
            con.execute(
                "INSERT OR IGNORE INTO career_progress (character_id, career_key, shifts_worked, career_xp, best_rank) VALUES (?, ?, 0, 0, 'Probationary')",
                (character.id, career.key),
            )
            con.execute(
                "INSERT INTO career_history (character_id, career_key, day, event_type, description) VALUES (?, ?, ?, 'hired', ?)",
                (character.id, career.key, character.day, f"Hired by {career.employer} as {career.name}."),
            )

    def resign_career(self) -> None:
        character = self.load_character()
        if self.get_career_shift_state():
            raise RuntimeError("You cannot resign during an active shift.")
        employment = self.db.fetchone("SELECT * FROM career_employment WHERE character_id = ?", (character.id,))
        if employment is None:
            raise RuntimeError("You do not currently have a full-time career.")
        career = CAREERS.get(employment["career_key"])
        with self.db.transaction() as con:
            if career:
                con.execute(
                    "INSERT INTO career_history (character_id, career_key, day, event_type, description) VALUES (?, ?, ?, 'resigned', ?)",
                    (character.id, career.key, character.day, f"Resigned from {career.employer}."),
                )
            con.execute("DELETE FROM career_employment WHERE character_id = ?", (character.id,))

    def get_career_shift_state(self) -> dict | None:
        character = self.db.fetchone("SELECT id FROM character LIMIT 1")
        if not character:
            return None
        row = self.db.fetchone("SELECT * FROM career_shift_state WHERE character_id = ?", (character["id"],))
        if row is None:
            return None
        if datetime.now() >= datetime.fromisoformat(row["completes_at"]):
            self._finish_elapsed_states()
            return None
        result = dict(row)
        result["remaining_seconds"] = max(0, int((datetime.fromisoformat(row["completes_at"]) - datetime.now()).total_seconds()) + 1)
        return result

    def start_career_shift(self) -> dict:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You are already busy.")
        profile = self.career_profile()
        if profile is None:
            raise RuntimeError("You do not currently have a full-time career.")
        career = CAREERS[profile["key"]]
        current = normalize_location_key(character.current_location)
        if current != career.location_key:
            raise RuntimeError(f"Your job is based in {LOCATIONS[career.location_key].name}.")
        if not profile["scheduled_today"]:
            raise RuntimeError("You are not scheduled to work today. Full-time shifts run Monday through Friday.")
        if profile["worked_today"]:
            raise RuntimeError("You have already completed today's shift.")
        if character.stamina < career.stamina_cost:
            raise RuntimeError("You do not have enough stamina for an eight-hour shift.")
        now = datetime.now()
        duration_seconds = 45
        completes = now + timedelta(seconds=duration_seconds)
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET stamina = stamina - ?, stamina_updated_at = ?, updated_at = ? WHERE id = ?",
                (career.stamina_cost, now.isoformat(timespec="seconds"), now.isoformat(timespec="seconds"), character.id),
            )
            con.execute(
                "INSERT OR REPLACE INTO career_shift_state (character_id, career_key, shift_day, started_at, completes_at, duration_seconds) VALUES (?, ?, ?, ?, ?, ?)",
                (character.id, career.key, character.day, now.isoformat(timespec="seconds"), completes.isoformat(timespec="seconds"), duration_seconds),
            )
        return self.get_career_shift_state() or {}

    def _complete_career_shift_row(self, state: dict) -> None:
        character = self.db.fetchone("SELECT * FROM character WHERE id = ?", (state["character_id"],))
        if character is None:
            return
        career = CAREERS.get(state["career_key"])
        if career is None:
            self.db.execute("DELETE FROM career_shift_state WHERE character_id = ?", (state["character_id"],))
            return
        progress = self.db.fetchone(
            "SELECT * FROM career_progress WHERE character_id = ? AND career_key = ?",
            (character["id"], career.key),
        )
        shifts_before = int(progress["shifts_worked"]) if progress else 0
        rank_before, multiplier = career_rank(shifts_before)
        pay = int(round(career.base_pay * multiplier))
        shifts_after = shifts_before + 1
        rank_after, _ = career_rank(shifts_after)
        day, minutes = self._time_after(int(character["day"]), int(character["time_minutes"]), 480)
        region_key = region_key_for_location(career.location_key)
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET cash = cash + ?, day = ?, time_minutes = ?, updated_at = ? WHERE id = ?",
                (pay, day, minutes, datetime.now().isoformat(timespec="seconds"), character["id"]),
            )
            con.execute("UPDATE skills SET xp = xp + 5 WHERE character_id = ? AND skill_name = 'Work'", (character["id"],))
            if career.primary_skill and career.skill_xp:
                con.execute(
                    "UPDATE skills SET xp = xp + ? WHERE character_id = ? AND skill_name = ?",
                    (career.skill_xp, character["id"], career.primary_skill),
                )
            con.execute(
                "INSERT INTO career_progress (character_id, career_key, shifts_worked, career_xp, best_rank) VALUES (?, ?, 1, 5, ?) "
                "ON CONFLICT(character_id, career_key) DO UPDATE SET shifts_worked = shifts_worked + 1, career_xp = career_xp + 5, best_rank = excluded.best_rank",
                (character["id"], career.key, rank_after),
            )
            con.execute(
                "INSERT OR REPLACE INTO career_shift_log (character_id, career_key, shift_day, pay, rank_name) VALUES (?, ?, ?, ?, ?)",
                (character["id"], career.key, int(state["shift_day"]), pay, rank_before),
            )
            con.execute(
                "UPDATE career_employment SET reliability = MIN(100, reliability + 2), last_checked_day = MAX(last_checked_day, ?) WHERE character_id = ?",
                (int(state["shift_day"]), character["id"]),
            )
            con.execute(
                "INSERT OR IGNORE INTO regional_reputation (character_id, region_key, reputation) VALUES (?, ?, 0)",
                (character["id"], region_key),
            )
            con.execute(
                "UPDATE regional_reputation SET reputation = MIN(100, reputation + 2) WHERE character_id = ? AND region_key = ?",
                (character["id"], region_key),
            )
            if rank_after != rank_before:
                con.execute(
                    "INSERT INTO career_history (character_id, career_key, day, event_type, description) VALUES (?, ?, ?, 'promotion', ?)",
                    (character["id"], career.key, day, f"Promoted to {rank_after} at {career.employer}."),
                )
            con.execute("DELETE FROM career_shift_state WHERE character_id = ?", (character["id"],))

    def career_history(self, limit: int = 12) -> list[dict]:
        character = self.load_character()
        rows = self.db.fetchall(
            "SELECT * FROM career_history WHERE character_id = ? ORDER BY id DESC LIMIT ?",
            (character.id, limit),
        )
        return [dict(row) for row in rows]

    # ---------- Regional world ----------
    @staticmethod
    def reputation_label(value: int) -> str:
        if value >= 75:
            return "Revered"
        if value >= 40:
            return "Respected"
        if value >= 15:
            return "Known"
        if value <= -60:
            return "Hated"
        if value <= -30:
            return "Hostile"
        if value <= -10:
            return "Distrusted"
        return "Neutral"

    def regional_reputations(self) -> list[dict]:
        character = self.load_character()
        rows = {
            row["region_key"]: int(row["reputation"])
            for row in self.db.fetchall(
                "SELECT region_key, reputation FROM regional_reputation WHERE character_id = ?",
                (character.id,),
            )
        }
        result = []
        for key, region in REGIONS.items():
            value = rows.get(key, 0)
            discovered = any(region_key_for_location(loc) == key for loc in self.known_locations())
            result.append({
                "key": key, "name": region.name, "description": region.description,
                "reputation": value, "label": self.reputation_label(value), "discovered": discovered,
            })
        return result

    def adjust_region_reputation(self, region_key: str, amount: int) -> None:
        character = self.load_character()
        with self.db.transaction() as con:
            con.execute(
                "INSERT OR IGNORE INTO regional_reputation (character_id, region_key, reputation) VALUES (?, ?, 0)",
                (character.id, region_key),
            )
            con.execute(
                "UPDATE regional_reputation SET reputation = MAX(-100, MIN(100, reputation + ?)) WHERE character_id = ? AND region_key = ?",
                (amount, character.id, region_key),
            )

    # ---------- Store / Inventory ----------
    def _add_inventory_item(self, con, character_id: int, name: str, description: str, quantity: int = 1) -> None:
        row = con.execute(
            "SELECT id FROM inventory WHERE character_id = ? AND item_name = ?",
            (character_id, name),
        ).fetchone()
        if row:
            con.execute("UPDATE inventory SET quantity = quantity + ? WHERE id = ?", (quantity, row["id"]))
        else:
            con.execute(
                "INSERT INTO inventory (character_id, item_name, quantity, description) VALUES (?, ?, ?, ?)",
                (character_id, name, quantity, description),
            )

    def _remove_inventory_item(self, con, character_id: int, name: str, quantity: int = 1) -> bool:
        row = con.execute(
            "SELECT id, quantity FROM inventory WHERE character_id = ? AND item_name = ?",
            (character_id, name),
        ).fetchone()
        if row is None or row["quantity"] < quantity:
            return False
        if row["quantity"] == quantity:
            con.execute("DELETE FROM inventory WHERE id = ?", (row["id"],))
        else:
            con.execute("UPDATE inventory SET quantity = quantity - ? WHERE id = ?", (quantity, row["id"]))
        return True

    def buy_store_item(self, item_name: str) -> None:
        character = self.load_character()
        if normalize_location_key(character.current_location) not in {"millhaven", "redwater", "lake_mercy", "greybridge_city", "hollow_creek", "pine_ridge", "westhaven"}:
            raise RuntimeError("You need to be in a settlement with a general market to shop here.")
        if self.get_combat_state():
            raise RuntimeError("You cannot shop while fighting something.")
        item = next((x for x in STORE_ITEMS if x.name == item_name), None)
        if item is None:
            raise ValueError("Unknown store item.")
        if character.cash < item.price:
            raise RuntimeError("You do not have enough cash.")
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? WHERE id = ?", (item.price, character.id))
            self._add_inventory_item(con, character.id, item.name, item.description)

    def equip_weapon(self, item_name: str) -> None:
        character = self.load_character()
        if self.get_combat_state():
            raise RuntimeError("You cannot change weapons in the middle of a fight yet.")
        if item_name not in WEAPONS:
            raise ValueError("That item is not a weapon.")
        owned = self.db.fetchone(
            "SELECT id FROM inventory WHERE character_id = ? AND item_name = ? AND quantity > 0",
            (character.id, item_name),
        )
        if not owned:
            raise RuntimeError("You do not own that weapon.")
        self.db.execute("UPDATE character SET equipped_weapon = ? WHERE id = ?", (item_name, character.id))

    def sell_regional_item(self, item_name: str) -> int:
        character = self.load_character()
        current = normalize_location_key(character.current_location)
        prices = {
            "Lake Perch": 6, "Rainbow Trout": 10, "Lake Whitefish": 14,
            "Scrap Metal": 4, "Machine Parts": 9, "Wire Bundle": 6,
        }
        if item_name not in prices:
            raise ValueError("That item is not bought by city markets.")
        if current not in {"lake_mercy", "redwater", "greybridge_city", "westhaven", "millhaven"}:
            raise RuntimeError("There is no suitable buyer for that item here.")
        with self.db.transaction() as con:
            if not self._remove_inventory_item(con, character.id, item_name, 1):
                raise RuntimeError("You do not have that item.")
            price = prices[item_name]
            con.execute("UPDATE character SET cash = cash + ? WHERE id = ?", (price, character.id))
        return prices[item_name]

    # ---------- Rest ----------
    def home_rest_profile(self) -> dict:
        structures = self.load_structures()
        best = {"name": "Basic Tent", "hp": 4, "stamina": 5, "comfort": 1}
        for structure in structures:
            definition = STRUCTURES.get(structure.get("definition_key") or "")
            if definition and definition.rest_stamina > best["stamina"]:
                best = {
                    "name": definition.name,
                    "hp": definition.rest_hp,
                    "stamina": definition.rest_stamina,
                    "comfort": definition.comfort,
                }

        furniture = self.load_furniture()
        rest_items = [FURNITURE.get(x["item_name"]) for x in furniture if FURNITURE.get(x["item_name"])]
        best["hp"] += max((item.rest_hp_bonus for item in rest_items), default=0)
        best["stamina"] += max((item.rest_stamina_bonus for item in rest_items), default=0)
        if any((x.get("definition_key") == "fire_pit") for x in structures):
            best["stamina"] += 1
        return best

    def rest_at_home(self) -> int:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "home":
            raise RuntimeError("You need to be at your property to rest.")
        if self.get_combat_state():
            raise RuntimeError("You cannot rest while in combat.")
        missing_stamina = character.max_stamina - character.stamina
        missing_hp = character.max_hp - character.hp
        if missing_stamina <= 0 and missing_hp <= 0:
            return 0
        profile = self.home_rest_profile()
        stamina_restored = min(profile["stamina"], max(0, missing_stamina))
        hp_restored = min(profile["hp"], max(0, missing_hp))
        now = datetime.now().isoformat(timespec="seconds")
        day, minutes = self._time_after(character.day, character.time_minutes, 120)
        self.db.execute(
            """
            UPDATE character
            SET stamina = stamina + ?, hp = hp + ?, day = ?, time_minutes = ?,
                stamina_updated_at = ?, updated_at = ?
            WHERE id = ?
            """,
            (stamina_restored, hp_restored, day, minutes, now, now, character.id),
        )
        return stamina_restored + hp_restored

    def rest_in_tent(self) -> int:
        return self.rest_at_home()

    # ---------- Property / Construction ----------
    def get_construction_state(self) -> dict | None:
        character = self.db.fetchone("SELECT id FROM character LIMIT 1")
        if not character:
            return None
        row = self.db.fetchone(
            "SELECT * FROM construction_state WHERE character_id = ?", (character["id"],)
        )
        if row is None:
            return None
        if datetime.now() >= datetime.fromisoformat(row["completes_at"]):
            self._finish_elapsed_states()
            return None
        result = dict(row)
        result["remaining_seconds"] = max(
            0, int((datetime.fromisoformat(row["completes_at"]) - datetime.now()).total_seconds()) + 1
        )
        definition = STRUCTURES[result["structure_key"]]
        result["structure_name"] = definition.name
        return result

    def start_construction(self, structure_key: str) -> dict:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "home":
            raise RuntimeError("You need to be at your property to begin construction.")
        if self.get_combat_state() or self.get_travel_state() or self.get_job_state() or self.get_career_shift_state():
            raise RuntimeError("You cannot begin construction while occupied with another activity.")
        if self.get_construction_state():
            raise RuntimeError("A construction project is already in progress.")
        definition = STRUCTURES.get(structure_key)
        if definition is None:
            raise ValueError("Unknown structure.")
        existing = self.db.fetchone(
            "SELECT id FROM structures WHERE plot_id = ? AND definition_key = ?",
            (character.home_plot_id, structure_key),
        )
        if existing:
            raise RuntimeError("That structure has already been built on this property.")
        if character.cash < definition.cost:
            raise RuntimeError("You do not have enough cash for this construction project.")
        missing = self.missing_construction_materials(structure_key)
        if missing:
            text = ", ".join(f"{name} x{qty}" for name, qty in missing.items())
            raise RuntimeError(f"Required construction materials are missing: {text}.")
        started = datetime.now()
        completes = started + timedelta(seconds=definition.duration_seconds)
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? WHERE id = ?", (definition.cost, character.id))
            for item_name, quantity in definition.materials:
                self._consume_material_from_inventory_and_storage(con, character.id, character.home_plot_id, item_name, quantity)
            con.execute(
                """
                INSERT OR REPLACE INTO construction_state (
                    character_id, plot_id, structure_key, started_at, completes_at, duration_seconds, game_minutes
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    character.id, character.home_plot_id, definition.key,
                    started.isoformat(timespec="seconds"), completes.isoformat(timespec="seconds"),
                    definition.duration_seconds, definition.game_minutes,
                ),
            )
        return self.get_construction_state() or {}

    def _complete_construction_row(self, state: dict) -> None:
        definition = STRUCTURES.get(state["structure_key"])
        if definition is None:
            self.db.execute("DELETE FROM construction_state WHERE character_id = ?", (state["character_id"],))
            return
        character = self.db.fetchone("SELECT * FROM character WHERE id = ?", (state["character_id"],))
        if character is None:
            return
        day, minutes = self._time_after(character["day"], character["time_minutes"], definition.game_minutes)
        now = datetime.now().isoformat(timespec="seconds")
        structure_type = "improvement" if definition.key in {"fire_pit", "garden_plot"} else "building"
        with self.db.transaction() as con:
            exists = con.execute(
                "SELECT id FROM structures WHERE plot_id = ? AND definition_key = ?",
                (state["plot_id"], definition.key),
            ).fetchone()
            structure_id = exists["id"] if exists else None
            if not exists:
                cursor = con.execute(
                    """
                    INSERT INTO structures (plot_id, structure_type, name, condition_percent, definition_key, built_at)
                    VALUES (?, ?, ?, 100, ?, ?)
                    """,
                    (state["plot_id"], structure_type, definition.name, definition.key, now),
                )
                structure_id = cursor.lastrowid
            if definition.key in BUSINESSES and structure_id is not None:
                con.execute(
                    """
                    INSERT OR IGNORE INTO businesses
                        (plot_id, structure_id, business_key, is_open, price_tier, till, lifetime_revenue, customers_served, last_processed_at)
                    VALUES (?, ?, ?, 0, 'standard', 0, 0, 0, ?)
                    """,
                    (state["plot_id"], structure_id, definition.key, now),
                )
            con.execute(
                "UPDATE character SET day = ?, time_minutes = ?, updated_at = ? WHERE id = ?",
                (day, minutes, now, state["character_id"]),
            )
            con.execute("DELETE FROM construction_state WHERE character_id = ?", (state["character_id"],))

    def load_furniture(self) -> list[dict]:
        character = self.load_character()
        rows = self.db.fetchall(
            """
            SELECT furniture.*, structures.name AS structure_name, structures.definition_key
            FROM furniture
            JOIN structures ON structures.id = furniture.structure_id
            WHERE structures.plot_id = ?
            ORDER BY structures.id, furniture.room_name, furniture.id
            """,
            (character.home_plot_id,),
        )
        return [dict(row) for row in rows]

    def property_rooms(self) -> list[dict]:
        furniture = self.load_furniture()
        by_room: dict[tuple[int, str], list[str]] = {}
        for item in furniture:
            by_room.setdefault((item["structure_id"], item["room_name"]), []).append(item["item_name"])
        result: list[dict] = []
        for structure in self.load_structures():
            definition = STRUCTURES.get(structure.get("definition_key") or "")
            if not definition:
                continue
            for room in definition.rooms:
                result.append({
                    "structure_id": structure["id"],
                    "structure_name": structure["name"],
                    "room_name": room,
                    "furniture": by_room.get((structure["id"], room), []),
                })
        return result

    def buy_furniture(self, item_name: str) -> None:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "millhaven":
            raise RuntimeError("You need to be in Millhaven to shop here.")
        if self.is_busy():
            raise RuntimeError("You cannot make a purchase while occupied with another activity.")
        item = FURNITURE.get(item_name)
        if item is None:
            raise ValueError("Unknown furniture item.")
        if character.cash < item.price:
            raise RuntimeError("You do not have enough cash.")
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? WHERE id = ?", (item.price, character.id))
            self._add_inventory_item(con, character.id, item.name, item.description)

    def place_furniture(self, item_name: str, structure_id: int, room_name: str) -> None:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "home":
            raise RuntimeError("You need to be at your property to place furniture.")
        if self.is_busy():
            raise RuntimeError("You cannot place furniture while occupied with another activity.")
        item = FURNITURE.get(item_name)
        if item is None:
            raise ValueError("That item is not furniture.")
        structure = self.db.fetchone(
            "SELECT * FROM structures WHERE id = ? AND plot_id = ?",
            (structure_id, character.home_plot_id),
        )
        if not structure:
            raise RuntimeError("That structure is not on your property.")
        definition = STRUCTURES.get(structure["definition_key"] or "")
        if not definition or room_name not in definition.rooms:
            raise RuntimeError("That room does not exist in this structure.")
        if room_name not in item.allowed_rooms:
            raise RuntimeError("That furniture cannot be placed in this room.")
        with self.db.transaction() as con:
            if not self._remove_inventory_item(con, character.id, item_name):
                raise RuntimeError("You do not own that furniture item.")
            con.execute(
                "INSERT INTO furniture (structure_id, room_name, item_name) VALUES (?, ?, ?)",
                (structure_id, room_name, item_name),
            )

    def remove_furniture(self, furniture_id: int) -> None:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "home":
            raise RuntimeError("You need to be at your property to move furniture.")
        row = self.db.fetchone(
            """
            SELECT furniture.*, structures.plot_id
            FROM furniture JOIN structures ON structures.id = furniture.structure_id
            WHERE furniture.id = ?
            """,
            (furniture_id,),
        )
        if not row or row["plot_id"] != character.home_plot_id:
            raise RuntimeError("Furniture not found on your property.")
        item = FURNITURE.get(row["item_name"])
        description = item.description if item else "Furniture removed from your property."
        with self.db.transaction() as con:
            con.execute("DELETE FROM furniture WHERE id = ?", (furniture_id,))
            self._add_inventory_item(con, character.id, row["item_name"], description)

    def property_storage_capacity(self) -> int:
        capacity = 5  # Basic tent storage.
        for structure in self.load_structures():
            definition = STRUCTURES.get(structure.get("definition_key") or "")
            if definition:
                capacity += definition.storage_capacity
        for placed in self.load_furniture():
            item = FURNITURE.get(placed["item_name"])
            if item:
                capacity += item.storage_capacity
        return capacity

    def load_property_storage(self) -> list[dict]:
        character = self.load_character()
        rows = self.db.fetchall(
            "SELECT * FROM property_storage WHERE plot_id = ? ORDER BY item_name",
            (character.home_plot_id,),
        )
        return [dict(row) for row in rows]

    def property_storage_used(self) -> int:
        return sum(int(row["quantity"]) for row in self.load_property_storage())

    def store_inventory_item(self, item_name: str) -> None:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "home":
            raise RuntimeError("You need to be at your property to use property storage.")
        if item_name == character.equipped_weapon:
            raise RuntimeError("Equip a different weapon before storing this item.")
        if self.property_storage_used() >= self.property_storage_capacity():
            raise RuntimeError("Property storage is full.")
        row = self.db.fetchone(
            "SELECT description FROM inventory WHERE character_id = ? AND item_name = ? AND quantity > 0",
            (character.id, item_name),
        )
        if not row:
            raise RuntimeError("You do not have that item.")
        with self.db.transaction() as con:
            if not self._remove_inventory_item(con, character.id, item_name):
                raise RuntimeError("You do not have that item.")
            stored = con.execute(
                "SELECT id FROM property_storage WHERE plot_id = ? AND item_name = ?",
                (character.home_plot_id, item_name),
            ).fetchone()
            if stored:
                con.execute("UPDATE property_storage SET quantity = quantity + 1 WHERE id = ?", (stored["id"],))
            else:
                con.execute(
                    "INSERT INTO property_storage (plot_id, item_name, quantity, description) VALUES (?, ?, 1, ?)",
                    (character.home_plot_id, item_name, row["description"]),
                )

    def take_storage_item(self, item_name: str) -> None:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "home":
            raise RuntimeError("You need to be at your property to use property storage.")
        row = self.db.fetchone(
            "SELECT * FROM property_storage WHERE plot_id = ? AND item_name = ? AND quantity > 0",
            (character.home_plot_id, item_name),
        )
        if not row:
            raise RuntimeError("That item is not in property storage.")
        with self.db.transaction() as con:
            if row["quantity"] <= 1:
                con.execute("DELETE FROM property_storage WHERE id = ?", (row["id"],))
            else:
                con.execute("UPDATE property_storage SET quantity = quantity - 1 WHERE id = ?", (row["id"],))
            self._add_inventory_item(con, character.id, item_name, row["description"])

    def property_value(self) -> int:
        plot = self.load_home_plot()
        total = int(plot["base_value"])
        for structure in self.load_structures():
            definition = STRUCTURES.get(structure.get("definition_key") or "")
            if definition:
                total += definition.cost
        for item in self.load_furniture():
            definition = FURNITURE.get(item["item_name"])
            if definition:
                total += definition.price
        character = self.load_character()
        for row in self.db.fetchall("SELECT animal_key FROM farm_animals WHERE plot_id = ?", (character.home_plot_id,)):
            animal = ANIMALS.get(row["animal_key"])
            if animal:
                total += animal.price
        return total

    # ---------- Farming ----------
    def has_garden_plot(self) -> bool:
        character = self.load_character()
        row = self.db.fetchone(
            "SELECT id FROM structures WHERE plot_id = ? AND definition_key = 'garden_plot'",
            (character.home_plot_id,),
        )
        return row is not None

    def load_farm_crops(self) -> list[dict]:
        character = self.load_character()
        rows = self.db.fetchall(
            "SELECT * FROM farm_crops WHERE plot_id = ? ORDER BY id",
            (character.home_plot_id,),
        )
        now = datetime.now()
        result: list[dict] = []
        for row in rows:
            crop = CROPS.get(row["crop_key"])
            if crop is None:
                continue
            ready_at = datetime.fromisoformat(row["ready_at"])
            remaining = max(0, int((ready_at - now).total_seconds()) + (1 if ready_at > now else 0))
            data = dict(row)
            data.update({
                "crop_name": crop.name,
                "description": crop.description,
                "produce_item": crop.produce_item,
                "remaining_seconds": remaining,
                "ready": remaining <= 0,
            })
            result.append(data)
        return result

    def farm_capacity(self) -> int:
        return GARDEN_CAPACITY if self.has_garden_plot() else 0

    def buy_seed(self, seed_item: str) -> None:
        character = self.load_character()
        if normalize_location_key(character.current_location) not in {"millhaven", "lake_mercy", "hollow_creek"}:
            raise RuntimeError("You need to be at a farm supply market to buy seeds.")
        if self.is_busy():
            raise RuntimeError("You cannot make a purchase while occupied with another activity.")
        crop = SEED_ITEMS.get(seed_item)
        if crop is None:
            raise ValueError("Unknown seed item.")
        if character.cash < crop.seed_price:
            raise RuntimeError("You do not have enough cash.")
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? WHERE id = ?", (crop.seed_price, character.id))
            self._add_inventory_item(con, character.id, crop.seed_item, crop.description)

    def plant_crop(self, crop_key: str) -> None:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "home":
            raise RuntimeError("You need to be at your property to plant crops.")
        if self.is_busy():
            raise RuntimeError("You cannot plant while occupied with another activity.")
        if not self.has_garden_plot():
            raise RuntimeError("Build a Garden Plot before planting crops.")
        crop = CROPS.get(crop_key)
        if crop is None:
            raise ValueError("Unknown crop.")
        active = self.db.fetchone(
            "SELECT COUNT(*) AS count FROM farm_crops WHERE plot_id = ?",
            (character.home_plot_id,),
        )["count"]
        if active >= GARDEN_CAPACITY:
            raise RuntimeError("All four garden beds are currently in use.")
        if character.stamina < 1:
            raise RuntimeError("You need at least 1 stamina to plant a crop.")
        now = datetime.now()
        ready = now + timedelta(seconds=crop.grow_seconds)
        day, minutes = self._time_after(character.day, character.time_minutes, 10)
        with self.db.transaction() as con:
            if not self._remove_inventory_item(con, character.id, crop.seed_item):
                raise RuntimeError(f"You need {crop.seed_item} to plant this crop.")
            stamp = now.isoformat(timespec="seconds")
            con.execute(
                "UPDATE character SET stamina = stamina - 1, day = ?, time_minutes = ?, stamina_updated_at = ?, updated_at = ? WHERE id = ?",
                (day, minutes, stamp, stamp, character.id),
            )
            con.execute(
                "INSERT INTO farm_crops (plot_id, crop_key, planted_at, ready_at, watered) VALUES (?, ?, ?, ?, 0)",
                (character.home_plot_id, crop.key, stamp, ready.isoformat(timespec="seconds")),
            )
            con.execute(
                "UPDATE skills SET xp = xp + 1 WHERE character_id = ? AND skill_name = 'Farming'",
                (character.id,),
            )

    def water_crop(self, crop_id: int) -> None:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "home":
            raise RuntimeError("You need to be at your property to water crops.")
        if self.is_busy():
            raise RuntimeError("You cannot water crops while occupied with another activity.")
        if character.stamina < 1:
            raise RuntimeError("You need at least 1 stamina to water the crop.")
        row = self.db.fetchone(
            "SELECT * FROM farm_crops WHERE id = ? AND plot_id = ?",
            (crop_id, character.home_plot_id),
        )
        if row is None:
            raise RuntimeError("That crop is no longer growing here.")
        if row["watered"]:
            raise RuntimeError("That crop has already been watered.")
        now = datetime.now().isoformat(timespec="seconds")
        day, minutes = self._time_after(character.day, character.time_minutes, 5)
        with self.db.transaction() as con:
            con.execute(
                "UPDATE farm_crops SET watered = 1 WHERE id = ?",
                (crop_id,),
            )
            con.execute(
                "UPDATE character SET stamina = stamina - 1, day = ?, time_minutes = ?, stamina_updated_at = ?, updated_at = ? WHERE id = ?",
                (day, minutes, now, now, character.id),
            )
            con.execute(
                "UPDATE skills SET xp = xp + 1 WHERE character_id = ? AND skill_name = 'Farming'",
                (character.id,),
            )

    def harvest_crop(self, crop_id: int) -> dict:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "home":
            raise RuntimeError("You need to be at your property to harvest crops.")
        if self.is_busy():
            raise RuntimeError("You cannot harvest while occupied with another activity.")
        row = self.db.fetchone(
            "SELECT * FROM farm_crops WHERE id = ? AND plot_id = ?",
            (crop_id, character.home_plot_id),
        )
        if row is None:
            raise RuntimeError("That crop is no longer growing here.")
        if datetime.now() < datetime.fromisoformat(row["ready_at"]):
            raise RuntimeError("That crop is not ready to harvest.")
        crop = CROPS[row["crop_key"]]
        quantity = random.SystemRandom().randint(crop.min_yield, crop.max_yield)
        if row["watered"]:
            quantity += 1
        xp = 2 + (1 if row["watered"] else 0)
        with self.db.transaction() as con:
            con.execute("DELETE FROM farm_crops WHERE id = ?", (crop_id,))
            self._add_inventory_item(con, character.id, crop.produce_item, crop.produce_description, quantity)
            con.execute(
                "UPDATE skills SET xp = xp + ? WHERE character_id = ? AND skill_name = 'Farming'",
                (xp, character.id),
            )
        return {"item": crop.produce_item, "quantity": quantity, "xp": xp}

    def sell_produce(self, item_name: str) -> int:
        character = self.load_character()
        if normalize_location_key(character.current_location) not in {"millhaven", "lake_mercy", "hollow_creek"}:
            raise RuntimeError("You need to be at a farm market to sell produce.")
        if self.is_busy():
            raise RuntimeError("You cannot sell goods while occupied with another activity.")
        crop = PRODUCE_ITEMS.get(item_name)
        if crop is None:
            raise ValueError("That item is not accepted as produce.")
        sale_price = max(1, math.ceil(crop.sale_price * produce_sale_multiplier(character.day)))
        with self.db.transaction() as con:
            if not self._remove_inventory_item(con, character.id, item_name):
                raise RuntimeError("You do not have that produce.")
            con.execute("UPDATE character SET cash = cash + ? WHERE id = ?", (sale_price, character.id))
        return sale_price

    # ---------- Livestock ----------
    def farm_feed_quantity(self) -> int:
        character = self.load_character()
        row = self.db.fetchone(
            "SELECT quantity FROM farm_feed WHERE plot_id = ?",
            (character.home_plot_id,),
        )
        return int(row["quantity"]) if row else 0

    def buy_feed_sack(self) -> int:
        character = self.load_character()
        if normalize_location_key(character.current_location) not in {"millhaven", "lake_mercy", "hollow_creek"}:
            raise RuntimeError("You need to be at a farm supply market to buy livestock feed.")
        if self.is_busy():
            raise RuntimeError("You cannot make a purchase while occupied with another activity.")
        if character.cash < FEED_SACK_PRICE:
            raise RuntimeError("You do not have enough cash.")
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET cash = cash - ? WHERE id = ?",
                (FEED_SACK_PRICE, character.id),
            )
            con.execute(
                """
                INSERT INTO farm_feed (plot_id, quantity) VALUES (?, ?)
                ON CONFLICT(plot_id) DO UPDATE SET quantity = quantity + excluded.quantity
                """,
                (character.home_plot_id, FEED_SACK_PORTIONS),
            )
        return FEED_SACK_PORTIONS

    def animal_capacity(self, animal_key: str) -> int:
        animal = ANIMALS.get(animal_key)
        if animal is None:
            return 0
        capacity = 0
        for structure in self.load_structures():
            definition = STRUCTURES.get(structure.get("definition_key") or "")
            if definition and animal_key in definition.allowed_animals:
                capacity += definition.animal_capacity
        return capacity

    def animal_count(self, animal_key: str) -> int:
        character = self.load_character()
        row = self.db.fetchone(
            "SELECT COUNT(*) AS count FROM farm_animals WHERE plot_id = ? AND animal_key = ?",
            (character.home_plot_id, animal_key),
        )
        return int(row["count"]) if row else 0

    def animal_housing_used(self, animal_key: str) -> int:
        animal = ANIMALS.get(animal_key)
        if animal is None:
            return 0
        character = self.load_character()
        housed_keys = [key for key, definition in ANIMALS.items() if definition.required_structure == animal.required_structure]
        placeholders = ",".join("?" for _ in housed_keys)
        row = self.db.fetchone(
            f"SELECT COUNT(*) AS count FROM farm_animals WHERE plot_id = ? AND animal_key IN ({placeholders})",
            (character.home_plot_id, *housed_keys),
        )
        return int(row["count"]) if row else 0

    def buy_animal(self, animal_key: str) -> None:
        character = self.load_character()
        if normalize_location_key(character.current_location) not in {"millhaven", "lake_mercy", "hollow_creek"}:
            raise RuntimeError("You need to be at a livestock market to buy animals.")
        if self.is_busy():
            raise RuntimeError("You cannot make a purchase while occupied with another activity.")
        animal = ANIMALS.get(animal_key)
        if animal is None:
            raise ValueError("Unknown livestock type.")
        capacity = self.animal_capacity(animal_key)
        if capacity <= 0:
            required = STRUCTURES[animal.required_structure].name
            raise RuntimeError(f"Build a {required} before purchasing this animal.")
        if self.animal_housing_used(animal_key) >= capacity:
            raise RuntimeError("There is no available livestock space in the required structure.")
        if character.cash < animal.price:
            raise RuntimeError("You do not have enough cash.")
        now = datetime.now()
        next_output = now + timedelta(seconds=animal.production_seconds)
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET cash = cash - ? WHERE id = ?",
                (animal.price, character.id),
            )
            con.execute(
                """
                INSERT INTO farm_animals
                    (plot_id, animal_key, purchased_at, next_output_at, stored_output, current_location)
                VALUES (?, ?, ?, ?, 0, 'home')
                """,
                (
                    character.home_plot_id,
                    animal.key,
                    now.isoformat(timespec="seconds"),
                    next_output.isoformat(timespec="seconds"),
                ),
            )

    def _process_livestock(self) -> None:
        character_row = self.db.fetchone("SELECT home_plot_id FROM character LIMIT 1")
        if character_row is None:
            return
        plot_id = character_row["home_plot_id"]
        rows = self.db.fetchall(
            "SELECT * FROM farm_animals WHERE plot_id = ? ORDER BY id",
            (plot_id,),
        )
        if not rows:
            return

        feed_row = self.db.fetchone("SELECT quantity FROM farm_feed WHERE plot_id = ?", (plot_id,))
        feed = int(feed_row["quantity"]) if feed_row else 0
        now = datetime.now()
        updates: list[tuple[int, str, int]] = []

        for row in rows:
            animal = ANIMALS.get(row["animal_key"])
            if animal is None or animal.production_seconds <= 0 or not animal.product_item:
                continue
            stored = int(row["stored_output"])
            next_at = datetime.fromisoformat(row["next_output_at"])
            if next_at > now:
                continue

            if stored >= MAX_STORED_OUTPUT:
                next_at = now + timedelta(seconds=animal.production_seconds)
                updates.append((row["id"], next_at.isoformat(timespec="seconds"), stored))
                continue

            elapsed = max(0, int((now - next_at).total_seconds()))
            due = 1 + elapsed // animal.production_seconds
            due = min(due, MAX_STORED_OUTPUT - stored)
            produced = min(due, feed)
            stored += produced
            feed -= produced

            if produced < due or stored >= MAX_STORED_OUTPUT:
                next_at = now + timedelta(seconds=animal.production_seconds)
            else:
                next_at = next_at + timedelta(seconds=animal.production_seconds * due)

            updates.append((row["id"], next_at.isoformat(timespec="seconds"), stored))

        if not updates:
            return
        with self.db.transaction() as con:
            for animal_id, next_stamp, stored in updates:
                con.execute(
                    "UPDATE farm_animals SET next_output_at = ?, stored_output = ? WHERE id = ?",
                    (next_stamp, stored, animal_id),
                )
            con.execute(
                """
                INSERT INTO farm_feed (plot_id, quantity) VALUES (?, ?)
                ON CONFLICT(plot_id) DO UPDATE SET quantity = excluded.quantity
                """,
                (plot_id, feed),
            )

    def load_livestock(self) -> list[dict]:
        self._process_livestock()
        character = self.load_character()
        rows = self.db.fetchall(
            "SELECT * FROM farm_animals WHERE plot_id = ? ORDER BY id",
            (character.home_plot_id,),
        )
        now = datetime.now()
        feed = self.farm_feed_quantity()
        result: list[dict] = []
        for row in rows:
            animal = ANIMALS.get(row["animal_key"])
            if animal is None:
                continue
            next_at = datetime.fromisoformat(row["next_output_at"])
            remaining = 0 if animal.production_seconds <= 0 else max(0, int((next_at - now).total_seconds()) + (1 if next_at > now else 0))
            stored = int(row["stored_output"])
            data = dict(row)
            data.update(
                {
                    "animal_name": animal.name,
                    "description": animal.description,
                    "product_item": animal.product_item,
                    "stored_output": stored,
                    "remaining_seconds": remaining,
                    "needs_feed": bool(animal.product_item) and feed <= 0 and stored < MAX_STORED_OUTPUT,
                    "capacity": self.animal_capacity(animal.key),
                    "rideable": animal.rideable,
                    "current_location": row["current_location"] or "home",
                }
            )
            result.append(data)
        return result

    def collect_animal_output(self, animal_id: int) -> dict:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "home":
            raise RuntimeError("You need to be at your property to collect livestock products.")
        if self.is_busy():
            raise RuntimeError("You cannot collect products while occupied with another activity.")
        self._process_livestock()
        row = self.db.fetchone(
            "SELECT * FROM farm_animals WHERE id = ? AND plot_id = ?",
            (animal_id, character.home_plot_id),
        )
        if row is None:
            raise RuntimeError("That animal is no longer on this property.")
        animal = ANIMALS.get(row["animal_key"])
        if animal is None:
            raise RuntimeError("Unknown livestock type.")
        if not animal.product_item:
            raise RuntimeError("This animal does not produce a collectable farm product.")
        quantity = int(row["stored_output"])
        if quantity <= 0:
            raise RuntimeError("There is nothing ready to collect from this animal.")
        with self.db.transaction() as con:
            con.execute("UPDATE farm_animals SET stored_output = 0 WHERE id = ?", (animal_id,))
            self._add_inventory_item(
                con,
                character.id,
                animal.product_item,
                animal.product_description,
                quantity,
            )
            con.execute(
                "UPDATE skills SET xp = xp + ? WHERE character_id = ? AND skill_name = 'Farming'",
                (quantity, character.id),
            )
        return {"item": animal.product_item, "quantity": quantity, "xp": quantity}

    def sell_animal_product(self, item_name: str) -> int:
        character = self.load_character()
        if normalize_location_key(character.current_location) not in {"millhaven", "lake_mercy", "hollow_creek"}:
            raise RuntimeError("You need to be at a farm market to sell farm products.")
        if self.is_busy():
            raise RuntimeError("You cannot sell goods while occupied with another activity.")
        animal = ANIMAL_PRODUCTS.get(item_name)
        if animal is None:
            raise ValueError("That item is not accepted as a livestock product.")
        with self.db.transaction() as con:
            if not self._remove_inventory_item(con, character.id, item_name):
                raise RuntimeError("You do not have that farm product.")
            con.execute(
                "UPDATE character SET cash = cash + ? WHERE id = ?",
                (animal.product_sale_price, character.id),
            )
        return animal.product_sale_price

    # ---------- Daily life, town services, mail, and favors ----------
    def current_daily_event(self) -> dict:
        character = self.load_character()
        event = daily_event(character.day)
        return {
            "key": event.key,
            "name": event.name,
            "description": event.description,
            "modifier_text": event.modifier_text,
        }

    def can_cook_at_home(self) -> bool:
        structures = self.load_structures()
        allowed = {"fire_pit", "wooden_shack", "small_cabin"}
        return any((row.get("definition_key") or "") in allowed for row in structures)

    def cook_recipe(self, recipe_key: str) -> dict:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "home":
            raise RuntimeError("You need to be at your property to cook.")
        if self.is_busy():
            raise RuntimeError("You cannot cook while occupied with another activity.")
        if not self.can_cook_at_home():
            raise RuntimeError("You need a fire pit, wooden shack, or small cabin before you can cook meals.")
        recipe = RECIPES.get(recipe_key)
        if recipe is None:
            raise ValueError("Unknown recipe.")
        with self.db.transaction() as con:
            for item_name, quantity in recipe.ingredients:
                row = con.execute(
                    "SELECT quantity FROM inventory WHERE character_id = ? AND item_name = ?",
                    (character.id, item_name),
                ).fetchone()
                if row is None or int(row["quantity"]) < quantity:
                    raise RuntimeError("You do not have the required ingredients.")
            for item_name, quantity in recipe.ingredients:
                self._remove_inventory_item(con, character.id, item_name, quantity)
            self._add_inventory_item(con, character.id, recipe.result_name, recipe.result_description, 1)
        self._advance_time(character.id, recipe.game_minutes)
        return {"name": recipe.name, "result": recipe.result_name}

    def eat_prepared_food(self, item_name: str) -> dict:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You cannot eat a prepared meal while occupied with another activity.")
        recipe = PREPARED_FOODS.get(item_name)
        if recipe is None:
            raise ValueError("That item is not a prepared meal.")
        with self.db.transaction() as con:
            if not self._remove_inventory_item(con, character.id, item_name, 1):
                raise RuntimeError("You do not have that meal.")
            hp_gain = min(recipe.hp_restore, character.max_hp - character.hp)
            stamina_gain = min(recipe.stamina_restore, character.max_stamina - character.stamina)
            con.execute(
                "UPDATE character SET hp = hp + ?, stamina = stamina + ?, stamina_updated_at = ? WHERE id = ?",
                (hp_gain, stamina_gain, datetime.now().isoformat(timespec="seconds"), character.id),
            )
        return {"name": item_name, "hp": hp_gain, "stamina": stamina_gain}

    def eat_at_diner(self, meal_key: str) -> dict:
        character = self.load_character()
        if normalize_location_key(character.current_location) not in {"millhaven", "redwater", "lake_mercy", "greybridge_city", "hollow_creek", "pine_ridge", "westhaven"}:
            raise RuntimeError("You need to be in a settlement with a diner or cafe.")
        if self.is_busy():
            raise RuntimeError("You cannot stop for a meal while occupied with another activity.")
        meal = next((x for x in DINER_MEALS if x.key == meal_key), None)
        if meal is None:
            raise ValueError("Unknown diner meal.")
        current = normalize_location_key(character.current_location)
        discount = diner_discount(character.day) if current == "millhaven" else 0
        price = max(1, meal.price - discount)
        if character.cash < price:
            raise RuntimeError("You do not have enough cash.")
        hp_gain = min(meal.hp_restore, character.max_hp - character.hp)
        stamina_gain = min(meal.stamina_restore, character.max_stamina - character.stamina)
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET cash = cash - ?, hp = hp + ?, stamina = stamina + ?, stamina_updated_at = ? WHERE id = ?",
                (price, hp_gain, stamina_gain, datetime.now().isoformat(timespec="seconds"), character.id),
            )
        self._advance_time(character.id, meal.game_minutes)
        return {"name": meal.name, "price": price, "hp": hp_gain, "stamina": stamina_gain}

    def clinic_treatment(self) -> int:
        character = self.load_character()
        if normalize_location_key(character.current_location) not in {"millhaven", "redwater", "lake_mercy", "greybridge_city", "hollow_creek", "pine_ridge", "westhaven"}:
            raise RuntimeError("You need to be in a settlement with medical services.")
        if self.is_busy():
            raise RuntimeError("You cannot receive treatment while occupied with another activity.")
        if character.hp >= character.max_hp:
            raise RuntimeError("You do not need treatment right now.")
        price = clinic_price(character.day)
        if character.cash < price:
            raise RuntimeError("You do not have enough cash for treatment.")
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET cash = cash - ?, hp = max_hp WHERE id = ?",
                (price, character.id),
            )
        self._advance_time(character.id, 45)
        return price

    def _daily_action_used(self, character_id: int, action_key: str, day: int) -> bool:
        row = self.db.fetchone(
            "SELECT day FROM daily_actions WHERE character_id = ? AND action_key = ?",
            (character_id, action_key),
        )
        return bool(row and int(row["day"]) == day)

    def _mark_daily_action(self, con, character_id: int, action_key: str, day: int) -> None:
        con.execute(
            """
            INSERT INTO daily_actions (character_id, action_key, day) VALUES (?, ?, ?)
            ON CONFLICT(character_id, action_key) DO UPDATE SET day = excluded.day
            """,
            (character_id, action_key, day),
        )

    def rest_at_park(self) -> int:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "millhaven":
            raise RuntimeError("You need to be in Millhaven to visit the park.")
        if self.is_busy():
            raise RuntimeError("You cannot rest here while occupied with another activity.")
        if self._daily_action_used(character.id, "park_rest", character.day):
            raise RuntimeError("You have already spent time resting in the park today.")
        restored = min(2, character.max_stamina - character.stamina)
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET stamina = stamina + ?, stamina_updated_at = ? WHERE id = ?",
                (restored, datetime.now().isoformat(timespec="seconds"), character.id),
            )
            self._mark_daily_action(con, character.id, "park_rest", character.day)
        self._advance_time(character.id, 30)
        return restored

    def attend_community_hall(self) -> dict:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "millhaven":
            raise RuntimeError("You need to be in Millhaven to visit the community hall.")
        if self.is_busy():
            raise RuntimeError("You cannot attend while occupied with another activity.")
        if self._daily_action_used(character.id, "community_hall", character.day):
            raise RuntimeError("You have already spent time at the community hall today.")
        with self.db.transaction() as con:
            con.execute(
                "UPDATE skills SET xp = xp + 1 WHERE character_id = ? AND skill_name = 'Speech'",
                (character.id,),
            )
            self._mark_daily_action(con, character.id, "community_hall", character.day)
        self._advance_time(character.id, 45)
        return self.current_daily_event()

    def load_mail(self) -> list[dict]:
        character = self.load_character()
        rows = self.db.fetchall(
            "SELECT * FROM mail WHERE character_id = ? ORDER BY sent_day DESC, id DESC",
            (character.id,),
        )
        return [dict(row) for row in rows]

    def unread_mail_count(self) -> int:
        character = self.load_character()
        row = self.db.fetchone(
            "SELECT COUNT(*) AS count FROM mail WHERE character_id = ? AND is_read = 0",
            (character.id,),
        )
        return int(row["count"]) if row else 0

    def read_mail(self, mail_id: int) -> dict:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "home":
            raise RuntimeError("You need to be at your property to check the mailbox.")
        row = self.db.fetchone(
            "SELECT * FROM mail WHERE id = ? AND character_id = ?",
            (mail_id, character.id),
        )
        if row is None:
            raise RuntimeError("That letter is no longer available.")
        self.db.execute("UPDATE mail SET is_read = 1 WHERE id = ?", (mail_id,))
        return dict(row)

    def get_favor_state(self, npc_key: str) -> dict | None:
        character = self.load_character()
        favor = FAVOR_BY_NPC.get(npc_key)
        if favor is None:
            return None
        row = self.db.fetchone(
            "SELECT * FROM npc_favors WHERE character_id = ? AND favor_key = ?",
            (character.id, favor.key),
        )
        status = row["status"] if row else "available"
        return {
            "key": favor.key,
            "title": favor.title,
            "description": favor.description,
            "requirements": favor.requirements,
            "cash_reward": favor.cash_reward,
            "friendship_reward": favor.friendship_reward,
            "status": status,
        }

    def accept_favor(self, npc_key: str) -> dict:
        character = self.load_character()
        favor = FAVOR_BY_NPC.get(npc_key)
        if favor is None:
            raise RuntimeError("This resident does not have a favor available.")
        profile = self.get_npc_profile(npc_key)
        current = normalize_location_key(character.current_location)
        if profile["world_location"] != current or current == "home":
            raise RuntimeError("That resident is not here right now.")
        row = self.db.fetchone(
            "SELECT status FROM npc_favors WHERE character_id = ? AND favor_key = ?",
            (character.id, favor.key),
        )
        if row:
            raise RuntimeError("You have already accepted this favor.")
        self.db.execute(
            "INSERT INTO npc_favors (character_id, favor_key, status, accepted_day) VALUES (?, ?, 'accepted', ?)",
            (character.id, favor.key, character.day),
        )
        return self.get_favor_state(npc_key) or {}

    def complete_favor(self, npc_key: str) -> dict:
        character = self.load_character()
        favor = FAVOR_BY_NPC.get(npc_key)
        if favor is None:
            raise RuntimeError("This resident does not have a favor available.")
        profile = self.get_npc_profile(npc_key)
        current = normalize_location_key(character.current_location)
        if profile["world_location"] != current or current == "home":
            raise RuntimeError("That resident is not here right now.")
        state = self.db.fetchone(
            "SELECT status FROM npc_favors WHERE character_id = ? AND favor_key = ?",
            (character.id, favor.key),
        )
        if state is None or state["status"] != "accepted":
            raise RuntimeError("You have not accepted this favor.")
        with self.db.transaction() as con:
            for item_name, quantity in favor.requirements:
                row = con.execute(
                    "SELECT quantity FROM inventory WHERE character_id = ? AND item_name = ?",
                    (character.id, item_name),
                ).fetchone()
                if row is None or int(row["quantity"]) < quantity:
                    raise RuntimeError("You do not have everything needed to complete this favor.")
            for item_name, quantity in favor.requirements:
                self._remove_inventory_item(con, character.id, item_name, quantity)
            con.execute("UPDATE character SET cash = cash + ? WHERE id = ?", (favor.cash_reward, character.id))
            con.execute(
                "UPDATE npc_relationships SET friendship = MIN(100, friendship + ?) WHERE character_id = ? AND npc_key = ?",
                (favor.friendship_reward, character.id, npc_key),
            )
            con.execute(
                "UPDATE skills SET xp = xp + ? WHERE character_id = ? AND skill_name = 'Speech'",
                (favor.speech_xp, character.id),
            )
            con.execute(
                "UPDATE npc_favors SET status = 'completed', completed_day = ? WHERE character_id = ? AND favor_key = ?",
                (character.day, character.id, favor.key),
            )
            con.execute(
                """
                INSERT OR IGNORE INTO mail (character_id, mail_key, sender, subject, body, sent_day, is_read)
                VALUES (?, ?, ?, ?, ?, ?, 0)
                """,
                (
                    character.id,
                    f"favor_complete_{favor.key}",
                    profile["name"],
                    f"Regarding: {favor.title}",
                    "Thank you for helping with the supplies I needed. I appreciate that you followed through.",
                    character.day,
                ),
            )
        return {
            "title": favor.title,
            "cash": favor.cash_reward,
            "friendship": favor.friendship_reward,
        }

    # ---------- NPCs and relationships ----------
    def _npc_relationship_row(self, character_id: int, npc_key: str) -> dict:
        if npc_key not in NPCS:
            raise ValueError("Unknown resident.")
        self.db.execute(
            "INSERT OR IGNORE INTO npc_relationships (character_id, npc_key, friendship, talk_count) VALUES (?, ?, 0, 0)",
            (character_id, npc_key),
        )
        row = self.db.fetchone(
            "SELECT * FROM npc_relationships WHERE character_id = ? AND npc_key = ?",
            (character_id, npc_key),
        )
        return dict(row)

    def _npc_context_line(self, npc_key: str) -> str:
        character = self.load_character()
        if npc_key == "ruth_calder":
            if self.load_farm_crops() or self.load_livestock():
                return "Ruth asks how the property is developing and whether your crops and animals have been settling in."
        elif npc_key == "thomas_hale":
            xp = self.db.fetchone(
                "SELECT xp FROM skills WHERE character_id = ? AND skill_name = 'Exploration'",
                (character.id,),
            )
            if xp and int(xp["xp"]) >= 3:
                return "Thomas recognizes that you have been spending time beyond the maintained section of Blackwood Trail."
        elif npc_key == "eli_mercer":
            xp = self.db.fetchone(
                "SELECT xp FROM skills WHERE character_id = ? AND skill_name = 'Work'",
                (character.id,),
            )
            if xp and int(xp["xp"]) >= 5:
                return "Eli has seen your name on several completed work slips and treats you as a dependable casual worker."
        elif npc_key == "daniel_rowe":
            row = self.db.fetchone(
                "SELECT COUNT(*) AS count FROM furniture f JOIN structures s ON s.id = f.structure_id WHERE s.plot_id = ?",
                (character.home_plot_id,),
            )
            if row and int(row["count"]) > 0:
                return "Daniel remembers some of the pieces you have bought for your property."
        elif npc_key == "mara_venn":
            row = self.db.fetchone("SELECT COUNT(*) AS count FROM businesses WHERE plot_id = ?", (character.home_plot_id,))
            if row and int(row["count"]) > 0:
                return "Mara has heard that you are operating a business from your property and asks how trade has been."
        elif npc_key == "lena_voss" and character.hp < character.max_hp:
            return "Lena notices that you are carrying an injury and asks whether it has been properly cleaned and dressed."
        elif npc_key == "owen_pike":
            row = self.db.fetchone(
                "SELECT COUNT(*) AS count FROM farm_animals WHERE plot_id = ? AND animal_key = 'horse'",
                (character.home_plot_id,),
            )
            if row and int(row["count"]) > 0:
                return "Owen asks whether the roads near your property have been suitable for riding after the recent weather."
        elif npc_key == "nora_bell":
            row = self.db.fetchone(
                "SELECT COUNT(*) AS count FROM structures WHERE plot_id = ? AND definition_key != 'basic_tent'",
                (character.home_plot_id,),
            )
            if row and int(row["count"]) > 0:
                return "Nora has noticed the work on your property and asks how long you plan to stay in the county."
        return ""

    def load_npcs_here(self) -> list[dict]:
        character = self.load_character()
        if self.get_travel_state() or self.get_combat_state():
            return []
        current = normalize_location_key(character.current_location)
        result = []
        for npc_key, npc in NPCS.items():
            world_location, activity = npc_schedule_state(npc, character.time_minutes)
            rel = self._npc_relationship_row(character.id, npc_key)
            if rel["romantic_status"] == "married" and world_location == "home":
                activity = "At home at your property"
            if world_location != current:
                continue
            if current == "home" and rel["romantic_status"] != "married":
                continue
            result.append({
                "key": npc_key,
                "name": npc.name,
                "occupation": npc.occupation,
                "description": npc.description,
                "activity": activity,
                "friendship": int(rel["friendship"]),
                "relationship": relationship_label(int(rel["friendship"])),
                "talked_today": rel["last_talk_day"] == character.day,
                "romance": int(rel["romance"]),
                "romantic_status": rel["romantic_status"],
                "romance_label": romance_label(rel["romantic_status"], int(rel["romance"])),
            })
        return sorted(result, key=lambda x: x["name"])

    def load_all_npcs(self) -> list[dict]:
        character = self.load_character()
        result = []
        for npc_key, npc in NPCS.items():
            world_location, activity = npc_schedule_state(npc, character.time_minutes)
            rel = self._npc_relationship_row(character.id, npc_key)
            result.append({
                "key": npc_key,
                "name": npc.name,
                "occupation": npc.occupation,
                "activity": activity,
                "world_location": world_location,
                "friendship": int(rel["friendship"]),
                "relationship": relationship_label(int(rel["friendship"])),
                "romance": int(rel["romance"]),
                "romantic_status": rel["romantic_status"],
                "romance_label": romance_label(rel["romantic_status"], int(rel["romance"])),
            })
        return sorted(result, key=lambda x: x["name"])

    def get_npc_profile(self, npc_key: str) -> dict:
        if npc_key not in NPCS:
            raise ValueError("Unknown resident.")
        character = self.load_character()
        npc = NPCS[npc_key]
        world_location, activity = npc_schedule_state(npc, character.time_minutes)
        rel = self._npc_relationship_row(character.id, npc_key)
        if rel["romantic_status"] == "married" and world_location == "home":
            activity = "At home at your property"
        return {
            "key": npc_key,
            "name": npc.name,
            "occupation": npc.occupation,
            "description": npc.description,
            "home_area": npc.home_area,
            "world_location": world_location,
            "activity": activity,
            "friendship": int(rel["friendship"]),
            "relationship": relationship_label(int(rel["friendship"])),
            "talk_count": int(rel["talk_count"]),
            "talked_today": rel["last_talk_day"] == character.day,
            "romance": int(rel["romance"]),
            "romantic_status": rel["romantic_status"],
            "romance_label": romance_label(rel["romantic_status"], int(rel["romance"])),
            "last_date_day": rel["last_date_day"],
            "last_intimacy_day": rel["last_intimacy_day"],
            "marital_status": npc.marital_status,
            "spouse_name": npc.spouse_name,
            "children": npc.children,
            "romanceable": npc.romanceable,
            "context_line": self._npc_context_line(npc_key),
            "conversation": npc.conversation,
            "favor": self.get_favor_state(npc_key),
        }

    def talk_to_npc(self, npc_key: str, option_key: str) -> dict:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You cannot stop for a conversation while occupied with another activity.")
        npc = NPCS.get(npc_key)
        if npc is None:
            raise ValueError("Unknown resident.")
        world_location, _activity = npc_schedule_state(npc, character.time_minutes)
        current = normalize_location_key(character.current_location)
        rel = self._npc_relationship_row(character.id, npc_key)
        if world_location != current or (current == "home" and rel["romantic_status"] != "married"):
            raise RuntimeError(f"{npc.name} is not here right now.")
        if rel["last_talk_day"] == character.day:
            raise RuntimeError(f"You have already had a longer conversation with {npc.name} today.")
        option = next((x for x in npc.conversation if x.key == option_key), None)
        if option is None:
            raise ValueError("Unknown conversation choice.")
        new_day, new_minutes = self._time_after(character.day, character.time_minutes, 10)
        now = datetime.now().isoformat(timespec="seconds")
        with self.db.transaction() as con:
            con.execute(
                """
                UPDATE npc_relationships
                SET friendship = MIN(100, friendship + ?), talk_count = talk_count + 1, last_talk_day = ?
                WHERE character_id = ? AND npc_key = ?
                """,
                (option.friendship, new_day, character.id, npc_key),
            )
            con.execute(
                "UPDATE skills SET xp = xp + ? WHERE character_id = ? AND skill_name = 'Speech'",
                (option.speech_xp, character.id),
            )
            region_key = region_key_for_location(current)
            con.execute(
                "INSERT OR IGNORE INTO regional_reputation (character_id, region_key, reputation) VALUES (?, ?, 0)",
                (character.id, region_key),
            )
            con.execute(
                "UPDATE regional_reputation SET reputation = MIN(100, reputation + 1) WHERE character_id = ? AND region_key = ?",
                (character.id, region_key),
            )
            con.execute(
                "UPDATE character SET day = ?, time_minutes = ?, updated_at = ? WHERE id = ?",
                (new_day, new_minutes, now, character.id),
            )
        profile = self.get_npc_profile(npc_key)
        return {
            "name": npc.name,
            "response": option.response,
            "friendship_gained": option.friendship,
            "relationship": profile["relationship"],
        }

    def _has_permanent_home(self, plot_id: int) -> bool:
        row = self.db.fetchone(
            "SELECT COUNT(*) AS count FROM structures WHERE plot_id = ? AND definition_key IN ('wooden_shack', 'small_cabin')",
            (plot_id,),
        )
        return bool(row and int(row["count"]) > 0)

    def _current_romantic_partner(self, character_id: int) -> str | None:
        row = self.db.fetchone(
            "SELECT npc_key FROM npc_relationships WHERE character_id = ? AND romantic_status IN ('dating', 'married') ORDER BY CASE romantic_status WHEN 'married' THEN 0 ELSE 1 END LIMIT 1",
            (character_id,),
        )
        return row["npc_key"] if row else None

    def ask_to_date(self, npc_key: str) -> dict:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You cannot start this conversation while occupied with another activity.")
        npc = NPCS.get(npc_key)
        if npc is None:
            raise ValueError("Unknown resident.")
        rel = self._npc_relationship_row(character.id, npc_key)
        if npc.age_group != "adult" or not npc.romanceable or npc.marital_status == "married":
            raise RuntimeError(f"{npc.name} is not available for a romantic relationship.")
        if rel["romantic_status"] != "none":
            raise RuntimeError(f"Your relationship with {npc.name} has already moved beyond friendship.")
        current_partner = self._current_romantic_partner(character.id)
        if current_partner and current_partner != npc_key:
            raise RuntimeError("You are already in a romantic relationship.")
        if int(rel["friendship"]) < ROMANCE_FRIENDSHIP_REQUIRED:
            raise RuntimeError(f"You need a stronger friendship before asking {npc.name} to date.")
        world_location, _ = npc_schedule_state(npc, character.time_minutes)
        if normalize_location_key(character.current_location) == "home" or world_location != normalize_location_key(character.current_location):
            raise RuntimeError(f"{npc.name} is not here right now.")
        self.db.execute(
            "UPDATE npc_relationships SET romantic_status = 'dating', romance = MAX(romance, 10) WHERE character_id = ? AND npc_key = ?",
            (character.id, npc_key),
        )
        return {"name": npc.name, "status": "dating", "romance": 10}

    def go_on_date(self, npc_key: str) -> dict:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You cannot go on a date while occupied with another activity.")
        npc = NPCS.get(npc_key)
        if npc is None:
            raise ValueError("Unknown resident.")
        rel = self._npc_relationship_row(character.id, npc_key)
        if rel["romantic_status"] not in ("dating", "married"):
            raise RuntimeError(f"You are not dating {npc.name}.")
        if rel["last_date_day"] == character.day:
            raise RuntimeError("You have already spent dedicated time together today.")
        if character.stamina < DATE_STAMINA_COST:
            raise RuntimeError("You do not have enough stamina.")
        if rel["romantic_status"] != "married":
            world_location, _ = npc_schedule_state(npc, character.time_minutes)
            if world_location != normalize_location_key(character.current_location):
                raise RuntimeError(f"{npc.name} is not here right now.")
        new_day, new_minutes = self._time_after(character.day, character.time_minutes, DATE_GAME_MINUTES)
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET stamina = stamina - ?, day = ?, time_minutes = ?, updated_at = ? WHERE id = ?",
                (DATE_STAMINA_COST, new_day, new_minutes, datetime.now().isoformat(timespec="seconds"), character.id),
            )
            con.execute(
                "UPDATE npc_relationships SET romance = MIN(100, romance + 8), friendship = MIN(100, friendship + 2), last_date_day = ? WHERE character_id = ? AND npc_key = ?",
                (new_day, character.id, npc_key),
            )
        updated = self._npc_relationship_row(character.id, npc_key)
        return {"name": npc.name, "romance": int(updated["romance"]), "friendship": int(updated["friendship"])}

    def marry_npc(self, npc_key: str) -> dict:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You cannot marry while occupied with another activity.")
        npc = NPCS.get(npc_key)
        if npc is None:
            raise ValueError("Unknown resident.")
        rel = self._npc_relationship_row(character.id, npc_key)
        if rel["romantic_status"] != "dating":
            raise RuntimeError(f"You need to be dating {npc.name} first.")
        if int(rel["friendship"]) < MARRIAGE_FRIENDSHIP_REQUIRED or int(rel["romance"]) < MARRIAGE_ROMANCE_REQUIRED:
            raise RuntimeError("The relationship is not yet strong enough for marriage.")
        if not self._has_permanent_home(character.home_plot_id):
            raise RuntimeError("You need a Wooden Shack or Small Cabin before starting a household together.")
        world_location, _ = npc_schedule_state(npc, character.time_minutes)
        if world_location != normalize_location_key(character.current_location):
            raise RuntimeError(f"{npc.name} is not here right now.")
        with self.db.transaction() as con:
            con.execute(
                "UPDATE npc_relationships SET romantic_status = 'married', romance = MIN(100, romance + 10) WHERE character_id = ? AND npc_key = ?",
                (character.id, npc_key),
            )
            con.execute(
                "INSERT INTO household (character_id, spouse_npc_key, married_day, expecting_child, child_due_day) VALUES (?, ?, ?, 0, NULL) ON CONFLICT(character_id) DO UPDATE SET spouse_npc_key = excluded.spouse_npc_key, married_day = excluded.married_day",
                (character.id, npc_key, character.day),
            )
        return {"name": npc.name, "married_day": character.day}

    def intimacy(self, npc_key: str, try_for_child: bool = False) -> dict:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You cannot spend private time together while occupied with another activity.")
        npc = NPCS.get(npc_key)
        if npc is None:
            raise ValueError("Unknown resident.")
        rel = self._npc_relationship_row(character.id, npc_key)
        if rel["romantic_status"] not in ("dating", "married") or int(rel["romance"]) < INTIMACY_ROMANCE_REQUIRED:
            raise RuntimeError("Your romantic relationship is not yet close enough for intimacy.")
        if rel["last_intimacy_day"] == character.day:
            raise RuntimeError("You have already spent private time together today.")
        if normalize_location_key(character.current_location) != "home":
            raise RuntimeError("You need to be at your property.")
        if not self._has_permanent_home(character.home_plot_id):
            raise RuntimeError("You need a permanent home first.")
        if try_for_child and rel["romantic_status"] != "married":
            raise RuntimeError("Trying for a child is available after marriage.")
        household = self.db.fetchone("SELECT * FROM household WHERE character_id = ?", (character.id,))
        if try_for_child and household and int(household["expecting_child"]):
            raise RuntimeError("Your household is already expecting a child.")
        new_day, new_minutes = self._time_after(character.day, character.time_minutes, INTIMACY_GAME_MINUTES)
        new_hp = min(character.max_hp, character.hp + INTIMACY_HP_RESTORE)
        new_sta = min(character.max_stamina, character.stamina + INTIMACY_STAMINA_RESTORE)
        expecting = False
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET hp = ?, stamina = ?, day = ?, time_minutes = ?, updated_at = ?, stamina_updated_at = ? WHERE id = ?",
                (new_hp, new_sta, new_day, new_minutes, datetime.now().isoformat(timespec="seconds"), datetime.now().isoformat(timespec="seconds"), character.id),
            )
            con.execute(
                "UPDATE npc_relationships SET romance = MIN(100, romance + 3), last_intimacy_day = ? WHERE character_id = ? AND npc_key = ?",
                (new_day, character.id, npc_key),
            )
            if try_for_child and random.random() < PROCREATION_CHANCE:
                due = new_day + CHILD_DUE_DAYS
                con.execute(
                    "INSERT INTO household (character_id, spouse_npc_key, married_day, expecting_child, child_due_day) VALUES (?, ?, ?, 1, ?) ON CONFLICT(character_id) DO UPDATE SET expecting_child = 1, child_due_day = excluded.child_due_day",
                    (character.id, npc_key, character.day, due),
                )
                expecting = True
        return {
            "name": npc.name,
            "hp_restored": new_hp - character.hp,
            "stamina_restored": new_sta - character.stamina,
            "expecting_child": expecting,
        }

    def get_household(self) -> dict:
        character = self.load_character()
        row = self.db.fetchone("SELECT * FROM household WHERE character_id = ?", (character.id,))
        if row is None:
            self.db.execute(
                "INSERT INTO household (character_id, spouse_npc_key, married_day, expecting_child, child_due_day) VALUES (?, NULL, NULL, 0, NULL)",
                (character.id,),
            )
            row = self.db.fetchone("SELECT * FROM household WHERE character_id = ?", (character.id,))
        spouse = NPCS.get(row["spouse_npc_key"]) if row and row["spouse_npc_key"] else None
        children = []
        for child in self.db.fetchall("SELECT * FROM household_children WHERE character_id = ? ORDER BY birth_day, id", (character.id,)):
            days_old = max(0, character.day - int(child["birth_day"]))
            children.append({"id": child["id"], "name": child["name"], "birth_day": child["birth_day"], "days_old": days_old, "stage": child_stage(days_old)})
        return {
            "spouse_key": row["spouse_npc_key"] if row else None,
            "spouse_name": spouse.name if spouse else None,
            "married_day": row["married_day"] if row else None,
            "expecting_child": bool(row and row["expecting_child"]),
            "child_due_day": row["child_due_day"] if row else None,
            "children": children,
        }

    def _process_family_events(self, character_id: int, day: int) -> None:
        household = self.db.fetchone("SELECT * FROM household WHERE character_id = ?", (character_id,))
        if not household or not int(household["expecting_child"] or 0) or household["child_due_day"] is None:
            return
        if day < int(household["child_due_day"]):
            return
        name = random.SystemRandom().choice(CHILD_NAMES)
        with self.db.transaction() as con:
            con.execute(
                "INSERT INTO household_children (character_id, name, birth_day) VALUES (?, ?, ?)",
                (character_id, name, day),
            )
            con.execute(
                "UPDATE household SET expecting_child = 0, child_due_day = NULL WHERE character_id = ?",
                (character_id,),
            )
            con.execute(
                "INSERT OR IGNORE INTO mail (character_id, mail_key, sender, subject, body, sent_day, is_read) VALUES (?, ?, 'Millhaven County Records', 'Household Record Updated', ?, ?, 0)",
                (character_id, f"child_birth_{day}_{name}", f"The birth of {name} has been entered into the county household record.", day),
            )

    def recent_business_visits(self, business_id: int, limit: int = 8) -> list[dict]:
        rows = self.db.fetchall(
            "SELECT * FROM business_visits WHERE business_id = ? ORDER BY id DESC LIMIT ?",
            (business_id, max(1, min(20, int(limit)))),
        )
        result = []
        for row in rows:
            data = dict(row)
            npc = NPCS.get(data["npc_key"])
            data["npc_name"] = npc.name if npc else data["npc_key"]
            result.append(data)
        return result

    # ---------- Businesses ----------
    def _business_inventory_stock_info(self, business_key: str, item_name: str) -> tuple[int, str] | None:
        if business_key != "farm_stand":
            return None
        crop = PRODUCE_ITEMS.get(item_name)
        if crop is not None:
            return max(1, crop.sale_price * 2), crop.produce_description
        animal = ANIMAL_PRODUCTS.get(item_name)
        if animal is not None:
            return max(1, animal.product_sale_price * 2), animal.product_description
        return None

    def _process_businesses(self) -> None:
        character_row = self.db.fetchone("SELECT home_plot_id FROM character LIMIT 1")
        if character_row is None:
            return
        rows = self.db.fetchall(
            "SELECT * FROM businesses WHERE plot_id = ? AND is_open = 1 ORDER BY id",
            (character_row["home_plot_id"],),
        )
        now = datetime.now()
        for row in rows:
            definition = BUSINESSES.get(row["business_key"])
            if definition is None:
                continue
            last = datetime.fromisoformat(row["last_processed_at"])
            elapsed = max(0, int((now - last).total_seconds()))
            cycles = min(40, elapsed // definition.customer_interval_seconds)
            if cycles <= 0:
                continue
            stock_rows = [dict(x) for x in self.db.fetchall(
                "SELECT * FROM business_stock WHERE business_id = ? AND quantity > 0 ORDER BY id",
                (row["id"],),
            )]
            if not stock_rows:
                self.db.execute(
                    "UPDATE businesses SET last_processed_at = ? WHERE id = ?",
                    (now.isoformat(timespec="seconds"), row["id"]),
                )
                continue
            tier = PRICE_TIERS.get(row["price_tier"], PRICE_TIERS["standard"])
            till_added = 0
            customers = 0
            visits = []
            named_customers = customer_npc_keys()
            quantities = {x["id"]: int(x["quantity"]) for x in stock_rows}
            for cycle_index in range(cycles):
                available = [x for x in stock_rows if quantities.get(x["id"], 0) > 0]
                if not available:
                    break
                if random.random() > tier["sale_chance"]:
                    continue
                item = random.choice(available)
                quantities[item["id"]] -= 1
                sale_price = max(1, round(int(item["base_price"]) * tier["multiplier"]))
                till_added += sale_price
                customers += 1
                if named_customers:
                    visitor = random.choice(named_customers)
                    visit_time = last + timedelta(seconds=(cycle_index + 1) * definition.customer_interval_seconds)
                    visits.append((row["id"], visitor, item["item_name"], sale_price, visit_time.isoformat(timespec="seconds")))
            advanced = last + timedelta(seconds=cycles * definition.customer_interval_seconds)
            with self.db.transaction() as con:
                for stock_id, quantity in quantities.items():
                    con.execute("UPDATE business_stock SET quantity = ? WHERE id = ?", (quantity, stock_id))
                con.execute(
                    """
                    UPDATE businesses
                    SET till = till + ?, lifetime_revenue = lifetime_revenue + ?,
                        customers_served = customers_served + ?, last_processed_at = ?
                    WHERE id = ?
                    """,
                    (till_added, till_added, customers, advanced.isoformat(timespec="seconds"), row["id"]),
                )
                if visits:
                    con.executemany(
                        "INSERT INTO business_visits (business_id, npc_key, item_name, sale_price, visited_at) VALUES (?, ?, ?, ?, ?)",
                        visits,
                    )
                    con.execute(
                        "DELETE FROM business_visits WHERE business_id = ? AND id NOT IN (SELECT id FROM business_visits WHERE business_id = ? ORDER BY id DESC LIMIT 30)",
                        (row["id"], row["id"]),
                    )

    def load_businesses(self) -> list[dict]:
        self._process_businesses()
        character = self.load_character()
        rows = self.db.fetchall(
            """
            SELECT b.*, s.name AS structure_name
            FROM businesses b JOIN structures s ON s.id = b.structure_id
            WHERE b.plot_id = ? ORDER BY b.id
            """,
            (character.home_plot_id,),
        )
        result = []
        for row in rows:
            data = dict(row)
            definition = BUSINESSES.get(data["business_key"])
            data["business_name"] = definition.name if definition else data["structure_name"]
            data["description"] = definition.description if definition else ""
            data["price_label"] = PRICE_TIERS.get(data["price_tier"], PRICE_TIERS["standard"])["label"]
            data["stock_count"] = sum(x["quantity"] for x in self.load_business_stock(data["id"]))
            result.append(data)
        return result

    def load_business_stock(self, business_id: int) -> list[dict]:
        rows = self.db.fetchall(
            "SELECT * FROM business_stock WHERE business_id = ? AND quantity > 0 ORDER BY item_name",
            (business_id,),
        )
        return [dict(row) for row in rows]

    def get_business(self, business_id: int) -> dict:
        self._process_businesses()
        character = self.load_character()
        row = self.db.fetchone(
            "SELECT * FROM businesses WHERE id = ? AND plot_id = ?",
            (business_id, character.home_plot_id),
        )
        if row is None:
            raise RuntimeError("That business is not on your property.")
        data = dict(row)
        definition = BUSINESSES[data["business_key"]]
        data["business_name"] = definition.name
        data["description"] = definition.description
        data["stock"] = self.load_business_stock(business_id)
        data["wholesale"] = WHOLESALE_BY_BUSINESS.get(data["business_key"], ())
        inventory = self.load_inventory()
        data["stockable_inventory"] = [
            item for item in inventory
            if self._business_inventory_stock_info(data["business_key"], item["item_name"]) is not None
        ]
        return data

    def set_business_open(self, business_id: int, is_open: bool) -> None:
        business = self.get_business(business_id)
        now = datetime.now().isoformat(timespec="seconds")
        self.db.execute(
            "UPDATE businesses SET is_open = ?, last_processed_at = ? WHERE id = ?",
            (1 if is_open else 0, now, business["id"]),
        )

    def set_business_price_tier(self, business_id: int, tier: str) -> None:
        if tier not in PRICE_TIERS:
            raise ValueError("Unknown price setting.")
        business = self.get_business(business_id)
        self.db.execute("UPDATE businesses SET price_tier = ? WHERE id = ?", (tier, business["id"]))

    def buy_business_wholesale(self, business_id: int, item_name: str, quantity: int = 5) -> int:
        character = self.load_character()
        business = self.get_business(business_id)
        if self.is_busy():
            raise RuntimeError("You cannot order stock while occupied with another activity.")
        item = next((x for x in WHOLESALE_BY_BUSINESS.get(business["business_key"], ()) if x.name == item_name), None)
        if item is None:
            raise ValueError("That wholesale item is not available to this business.")
        cost = item.cost * quantity
        if character.cash < cost:
            raise RuntimeError("You do not have enough cash for that stock order.")
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? WHERE id = ?", (cost, character.id))
            con.execute(
                """
                INSERT INTO business_stock (business_id, item_name, quantity, base_price, description)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(business_id, item_name) DO UPDATE SET quantity = quantity + excluded.quantity
                """,
                (business_id, item.name, quantity, item.base_price, item.description),
            )
        return cost

    def stock_business_from_inventory(self, business_id: int, item_name: str) -> None:
        character = self.load_character()
        business = self.get_business(business_id)
        if normalize_location_key(character.current_location) != "home":
            raise RuntimeError("You need to be at your property to stock this business from inventory.")
        if self.is_busy():
            raise RuntimeError("You cannot stock a business while occupied with another activity.")
        info = self._business_inventory_stock_info(business["business_key"], item_name)
        if info is None:
            raise RuntimeError("That item cannot be stocked in this business.")
        base_price, description = info
        with self.db.transaction() as con:
            if not self._remove_inventory_item(con, character.id, item_name, 1):
                raise RuntimeError("You do not have that item.")
            con.execute(
                """
                INSERT INTO business_stock (business_id, item_name, quantity, base_price, description)
                VALUES (?, ?, 1, ?, ?)
                ON CONFLICT(business_id, item_name) DO UPDATE SET quantity = quantity + 1
                """,
                (business_id, item_name, base_price, description),
            )

    def collect_business_till(self, business_id: int) -> int:
        character = self.load_character()
        business = self.get_business(business_id)
        if normalize_location_key(character.current_location) != "home":
            raise RuntimeError("You need to be at your property to collect business income.")
        amount = int(business["till"])
        if amount <= 0:
            return 0
        with self.db.transaction() as con:
            con.execute("UPDATE businesses SET till = 0 WHERE id = ?", (business_id,))
            con.execute("UPDATE character SET cash = cash + ? WHERE id = ?", (amount, character.id))
        return amount

    # ---------- Exploration ----------
    def explore_blackwood(self) -> dict:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "blackwood_trail":
            raise RuntimeError("You need to be on Blackwood Trail to explore it.")
        if self.is_busy():
            raise RuntimeError("You are already busy.")
        if character.stamina < self.EXPLORE_STAMINA_COST:
            raise RuntimeError("You need at least 2 stamina to explore.")

        now = datetime.now().isoformat(timespec="seconds")
        day, minutes = self._time_after(character.day, character.time_minutes, self.EXPLORE_GAME_MINUTES)
        with self.db.transaction() as con:
            con.execute(
                """
                UPDATE character
                SET stamina = stamina - ?, day = ?, time_minutes = ?, stamina_updated_at = ?, updated_at = ?
                WHERE id = ?
                """,
                (self.EXPLORE_STAMINA_COST, day, minutes, now, now, character.id),
            )
            con.execute(
                "UPDATE skills SET xp = xp + 1 WHERE character_id = ? AND skill_name = 'Exploration'",
                (character.id,),
            )

        roll = random.SystemRandom().randint(1, 100)
        if roll <= 50:
            enemy_key = random.SystemRandom().choice(tuple(ENEMIES.keys()))
            self.start_combat(enemy_key, allow_busy=True)
            enemy = ENEMIES[enemy_key]
            return {"type": "combat", "text": enemy.description, "enemy": enemy.name}
        if roll <= 68:
            finds = [
                ("Loose Change", 1, "A few coins collected from the mud."),
                ("Wild Berries", 1, "A handful of ripe wild berries gathered beside the trail."),
                ("Scrap Metal", 1, "A bent piece of metal that might eventually be useful."),
                ("Old Rope", 1, "Several metres of weathered rope."),
            ]
            name, quantity, description = random.SystemRandom().choice(finds)
            with self.db.transaction() as con:
                self._add_inventory_item(con, character.id, name, description, quantity)
            return {"type": "loot", "text": f"You search the trail and find: {name}."}
        if roll <= 78:
            cash = random.SystemRandom().randint(1, 6)
            self.db.execute("UPDATE character SET cash = cash + ? WHERE id = ?", (cash, character.id))
            return {"type": "cash", "text": f"You find ${cash} tucked inside a waterlogged wallet."}
        if roll <= 90:
            return {
                "type": "scene",
                "text": "You find an old hunting blind partly covered by brush. Nothing useful remains inside. The words 'DON'T FOLLOW THE BELLS' have been carved into one wall.",
            }
        return {"type": "nothing", "text": "You search the surrounding forest but find nothing of immediate use."}

    # ---------- Combat ----------
    def start_fight_club_bout(self) -> dict:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "redwater_fight_club":
            raise RuntimeError("You need to be at the Redwater Fight Club.")
        if self.is_busy():
            raise RuntimeError("You are already busy.")
        enemy_key = random.SystemRandom().choice(("redwater_brawler", "club_veteran"))
        return self.start_combat(enemy_key)

    def start_dungeon_encounter(self) -> dict:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "blackstone_dungeon":
            raise RuntimeError("You need to be inside Blackstone Dungeon.")
        if self.is_busy():
            raise RuntimeError("You are already busy.")
        enemy_key = random.SystemRandom().choices(
            ("cave_crawler", "dungeon_knoblin", "tunnel_horror"),
            weights=(50, 35, 15),
            k=1,
        )[0]
        return self.start_combat(enemy_key)

    def start_combat(self, enemy_key: str, allow_busy: bool = False) -> dict:
        character = self.load_character()
        if enemy_key not in ENEMIES:
            raise ValueError("Unknown enemy.")
        if not allow_busy and self.is_busy():
            raise RuntimeError("You are already busy.")
        if self.get_travel_state() or self.get_job_state() or self.get_career_shift_state() or self.get_combat_state():
            raise RuntimeError("You cannot start another fight right now.")
        enemy = ENEMIES[enemy_key]
        self.db.execute(
            """
            INSERT OR REPLACE INTO combat_state (
                character_id, enemy_key, enemy_hp, enemy_max_hp, guard_amount, log_text, started_at
            ) VALUES (?, ?, ?, ?, 0, ?, ?)
            """,
            (
                character.id,
                enemy.key,
                enemy.max_hp,
                enemy.max_hp,
                enemy.description,
                datetime.now().isoformat(timespec="seconds"),
            ),
        )
        return self.get_combat_state() or {}

    def get_combat_state(self) -> dict | None:
        character = self.db.fetchone("SELECT id FROM character LIMIT 1")
        if not character:
            return None
        row = self.db.fetchone("SELECT * FROM combat_state WHERE character_id = ?", (character["id"],))
        if row is None:
            return None
        result = dict(row)
        enemy = ENEMIES[result["enemy_key"]]
        result["enemy_name"] = enemy.name
        result["enemy_description"] = enemy.description
        result["log_lines"] = [line for line in result["log_text"].split("\n") if line][-6:]
        return result

    def _append_combat_log(self, con, character_id: int, lines: list[str]) -> None:
        row = con.execute(
            "SELECT log_text FROM combat_state WHERE character_id = ?", (character_id,)
        ).fetchone()
        existing = [line for line in (row["log_text"] if row else "").split("\n") if line]
        combined = (existing + lines)[-8:]
        con.execute(
            "UPDATE combat_state SET log_text = ? WHERE character_id = ?",
            ("\n".join(combined), character_id),
        )

    def _enemy_turn(self, con, character_id: int, enemy_key: str) -> tuple[list[str], bool]:
        enemy = ENEMIES[enemy_key]
        state = con.execute(
            "SELECT guard_amount FROM combat_state WHERE character_id = ?", (character_id,)
        ).fetchone()
        guard = state["guard_amount"] if state else 0
        roll = random.SystemRandom().randint(1, 100)
        if roll > enemy.accuracy:
            con.execute("UPDATE combat_state SET guard_amount = 0 WHERE character_id = ?", (character_id,))
            return [f"{enemy.name} attacks and misses."], False

        damage = random.SystemRandom().randint(enemy.min_damage, enemy.max_damage)
        blocked = min(guard, damage)
        damage -= blocked
        con.execute(
            "UPDATE character SET hp = MAX(0, hp - ?) WHERE id = ?",
            (damage, character_id),
        )
        con.execute("UPDATE combat_state SET guard_amount = 0 WHERE character_id = ?", (character_id,))
        text = f"{enemy.name} hits you for {damage} damage."
        if blocked:
            text += f" Brace blocks {blocked}."
        hp_row = con.execute("SELECT hp FROM character WHERE id = ?", (character_id,)).fetchone()
        return [text], bool(hp_row and hp_row["hp"] <= 0)

    def _handle_defeat(self, con, character_id: int) -> str:
        character = con.execute("SELECT * FROM character WHERE id = ?", (character_id,)).fetchone()
        recovered_hp = max(1, character["max_hp"] // 2)
        day, minutes = self._time_after(character["day"], character["time_minutes"], 360)
        home_location = f"plot:{character['home_plot_id']}"
        now = datetime.now().isoformat(timespec="seconds")
        con.execute(
            """
            UPDATE character
            SET hp = ?, stamina = MAX(5, stamina), current_location = ?, day = ?, time_minutes = ?, updated_at = ?
            WHERE id = ?
            """,
            (recovered_hp, home_location, day, minutes, now, character_id),
        )
        con.execute("DELETE FROM combat_state WHERE character_id = ?", (character_id,))
        return f"You lose consciousness. Six hours later you wake at your property with {recovered_hp} HP."

    def _handle_victory(self, con, character_id: int, enemy_key: str) -> str:
        enemy = ENEMIES[enemy_key]
        cash = random.SystemRandom().randint(enemy.cash_min, enemy.cash_max) if enemy.cash_max else 0
        con.execute("UPDATE character SET cash = cash + ? WHERE id = ?", (cash, character_id))
        con.execute(
            "UPDATE skills SET xp = xp + ? WHERE character_id = ? AND skill_name = 'Combat'",
            (enemy.combat_xp, character_id),
        )
        loot_found: list[str] = []
        for item_name, chance, description in enemy.loot:
            if random.SystemRandom().randint(1, 100) <= chance:
                self._add_inventory_item(con, character_id, item_name, description)
                loot_found.append(item_name)
        con.execute("DELETE FROM combat_state WHERE character_id = ?", (character_id,))
        parts = [f"{enemy.name} is defeated. +{enemy.combat_xp} Combat XP."]
        if cash:
            parts.append(f"You find ${cash}.")
        if loot_found:
            parts.append("Loot: " + ", ".join(loot_found) + ".")
        else:
            parts.append("It has nothing useful on it.")
        return " ".join(parts)

    def combat_attack(self, move_key: str) -> dict:
        character = self.load_character()
        state = self.get_combat_state()
        if not state:
            raise RuntimeError("You are not in combat.")
        moves = {move.key: move for move in weapon_moves(character.equipped_weapon)}
        move = moves.get(move_key)
        if move is None:
            raise ValueError("That move is not available with your equipped weapon.")

        enemy = ENEMIES[state["enemy_key"]]
        lines: list[str] = []
        with self.db.transaction() as con:
            if random.SystemRandom().randint(1, 100) <= move.accuracy:
                damage = random.SystemRandom().randint(move.min_damage, move.max_damage)
                con.execute(
                    "UPDATE combat_state SET enemy_hp = MAX(0, enemy_hp - ?) WHERE character_id = ?",
                    (damage, character.id),
                )
                lines.append(f"You use {move.name} with your {character.equipped_weapon} for {damage} damage.")
            else:
                lines.append(f"You use {move.name} and miss.")

            hp_row = con.execute(
                "SELECT enemy_hp FROM combat_state WHERE character_id = ?", (character.id,)
            ).fetchone()
            if hp_row and hp_row["enemy_hp"] <= 0:
                victory = self._handle_victory(con, character.id, enemy.key)
                return {"ended": True, "victory": True, "text": " ".join(lines + [victory])}

            enemy_lines, defeated = self._enemy_turn(con, character.id, enemy.key)
            lines.extend(enemy_lines)
            if defeated:
                defeat = self._handle_defeat(con, character.id)
                return {"ended": True, "victory": False, "text": " ".join(lines + [defeat])}
            self._append_combat_log(con, character.id, lines)
        return {"ended": False, "text": " ".join(lines)}

    def combat_brace(self) -> dict:
        character = self.load_character()
        state = self.get_combat_state()
        if not state:
            raise RuntimeError("You are not in combat.")
        enemy = ENEMIES[state["enemy_key"]]
        lines = ["You brace yourself. The next hit is reduced by up to 3 damage."]
        with self.db.transaction() as con:
            con.execute("UPDATE combat_state SET guard_amount = 3 WHERE character_id = ?", (character.id,))
            enemy_lines, defeated = self._enemy_turn(con, character.id, enemy.key)
            lines.extend(enemy_lines)
            if defeated:
                defeat = self._handle_defeat(con, character.id)
                return {"ended": True, "victory": False, "text": " ".join(lines + [defeat])}
            self._append_combat_log(con, character.id, lines)
        return {"ended": False, "text": " ".join(lines)}

    def combat_use_item(self, item_name: str) -> dict:
        character = self.load_character()
        state = self.get_combat_state()
        if not state:
            raise RuntimeError("You are not in combat.")
        healing = HEALING_ITEMS.get(item_name)
        if healing is None:
            raise ValueError("That item cannot be used in combat yet.")
        if character.hp >= character.max_hp:
            raise RuntimeError("Your HP is already full.")
        enemy = ENEMIES[state["enemy_key"]]
        lines: list[str] = []
        with self.db.transaction() as con:
            if not self._remove_inventory_item(con, character.id, item_name):
                raise RuntimeError("You do not have that item.")
            restored = min(healing.heal, character.max_hp - character.hp)
            con.execute("UPDATE character SET hp = hp + ? WHERE id = ?", (restored, character.id))
            lines.append(f"You use {item_name} and recover {restored} HP.")
            enemy_lines, defeated = self._enemy_turn(con, character.id, enemy.key)
            lines.extend(enemy_lines)
            if defeated:
                defeat = self._handle_defeat(con, character.id)
                return {"ended": True, "victory": False, "text": " ".join(lines + [defeat])}
            self._append_combat_log(con, character.id, lines)
        return {"ended": False, "text": " ".join(lines)}

    def combat_run(self) -> dict:
        character = self.load_character()
        state = self.get_combat_state()
        if not state:
            raise RuntimeError("You are not in combat.")
        enemy = ENEMIES[state["enemy_key"]]
        if random.SystemRandom().randint(1, 100) <= 75:
            self.db.execute("DELETE FROM combat_state WHERE character_id = ?", (character.id,))
            return {"ended": True, "escaped": True, "text": f"You get away from {enemy.name}."}
        lines = ["You try to run, but fail."]
        with self.db.transaction() as con:
            enemy_lines, defeated = self._enemy_turn(con, character.id, enemy.key)
            lines.extend(enemy_lines)
            if defeated:
                defeat = self._handle_defeat(con, character.id)
                return {"ended": True, "escaped": False, "text": " ".join(lines + [defeat])}
            self._append_combat_log(con, character.id, lines)
        return {"ended": False, "escaped": False, "text": " ".join(lines)}

    def combat_usable_items(self) -> list[dict]:
        character = self.load_character()
        rows = self.db.fetchall(
            "SELECT item_name, quantity FROM inventory WHERE character_id = ? AND quantity > 0 ORDER BY item_name",
            (character.id,),
        )
        usable = []
        for row in rows:
            healing = HEALING_ITEMS.get(row["item_name"])
            if healing:
                usable.append(
                    {
                        "name": row["item_name"],
                        "quantity": row["quantity"],
                        "heal": healing.heal,
                        "description": healing.description,
                    }
                )
        return usable


    # ---------- Crime / Law ----------
    def _apply_heat_decay(self) -> None:
        row = self.db.fetchone("SELECT * FROM character LIMIT 1")
        if row is None:
            return
        profile = self.db.fetchone("SELECT * FROM crime_profile WHERE character_id = ?", (row["id"],))
        if profile is None:
            self.db.execute(
                "INSERT INTO crime_profile (character_id, heat, crimes_committed, arrests, murders, mask_worn, last_heat_day) VALUES (?, 0, 0, 0, 0, 0, ?)",
                (row["id"], row["day"]),
            )
            return
        elapsed_days = max(0, int(row["day"]) - int(profile["last_heat_day"]))
        if elapsed_days <= 0:
            return
        new_heat = max(0, int(profile["heat"]) - elapsed_days * 4)
        self.db.execute(
            "UPDATE crime_profile SET heat = ?, last_heat_day = ? WHERE character_id = ?",
            (new_heat, row["day"], row["id"]),
        )

    def get_crime_profile(self) -> dict:
        character = self.load_character()
        self._apply_heat_decay()
        row = self.db.fetchone("SELECT * FROM crime_profile WHERE character_id = ?", (character.id,))
        if row is None:
            self.db.execute(
                "INSERT INTO crime_profile (character_id, heat, crimes_committed, arrests, murders, mask_worn, last_heat_day) VALUES (?, 0, 0, 0, 0, 0, ?)",
                (character.id, character.day),
            )
            row = self.db.fetchone("SELECT * FROM crime_profile WHERE character_id = ?", (character.id,))
        result = dict(row)
        result["heat_label"] = heat_label(int(result["heat"]))
        result["record"] = [dict(x) for x in self.db.fetchall(
            "SELECT * FROM crime_record WHERE character_id = ? ORDER BY id DESC LIMIT 12", (character.id,)
        )]
        result["has_mask"] = bool(self.db.fetchone(
            "SELECT id FROM inventory WHERE character_id = ? AND item_name = ? AND quantity > 0",
            (character.id, MASK_NAME),
        ))
        return result

    def buy_mask(self) -> None:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "millhaven":
            raise RuntimeError("You need to be in Millhaven.")
        if character.cash < MASK_PRICE:
            raise RuntimeError("You do not have enough cash.")
        owned = self.db.fetchone(
            "SELECT id FROM inventory WHERE character_id = ? AND item_name = ? AND quantity > 0",
            (character.id, MASK_NAME),
        )
        if owned:
            raise RuntimeError("You already own a mask.")
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? WHERE id = ?", (MASK_PRICE, character.id))
            self._add_inventory_item(con, character.id, MASK_NAME, MASK_DESCRIPTION)

    def toggle_mask(self) -> bool:
        character = self.load_character()
        profile = self.get_crime_profile()
        if not profile["has_mask"]:
            raise RuntimeError("You do not own a mask.")
        new_value = 0 if profile["mask_worn"] else 1
        self.db.execute("UPDATE crime_profile SET mask_worn = ? WHERE character_id = ?", (new_value, character.id))
        return bool(new_value)

    def get_jail_state(self) -> dict | None:
        row = self.db.fetchone("SELECT id FROM character LIMIT 1")
        if not row:
            return None
        jail = self.db.fetchone("SELECT * FROM jail_state WHERE character_id = ?", (row["id"],))
        if jail is None:
            return None
        if datetime.now() >= datetime.fromisoformat(jail["release_at"]):
            self._release_from_jail(dict(jail))
            return None
        result = dict(jail)
        result["remaining_seconds"] = max(0, int((datetime.fromisoformat(jail["release_at"]) - datetime.now()).total_seconds()) + 1)
        return result

    def _release_from_jail(self, jail: dict) -> None:
        character = self.db.fetchone("SELECT * FROM character WHERE id = ?", (jail["character_id"],))
        if character is None:
            return
        sentence_game_minutes = max(60, int(jail["duration_seconds"]) * 4)
        day, minutes = self._time_after(character["day"], character["time_minutes"], sentence_game_minutes)
        now = datetime.now().isoformat(timespec="seconds")
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET current_location = 'millhaven', day = ?, time_minutes = ?, updated_at = ? WHERE id = ?",
                (day, minutes, now, character["id"]),
            )
            con.execute("DELETE FROM jail_state WHERE character_id = ?", (character["id"],))

    def _arrest(self, con, character, reason: str, severity: int) -> tuple[int, int]:
        fine = min(character["cash"], max(10, severity * 3))
        duration = min(150, 20 + severity * 2)
        now = datetime.now()
        release = now + timedelta(seconds=duration)
        con.execute("DELETE FROM travel_state WHERE character_id = ?", (character["id"],))
        con.execute("DELETE FROM job_state WHERE character_id = ?", (character["id"],))
        con.execute("DELETE FROM career_shift_state WHERE character_id = ?", (character["id"],))
        con.execute("DELETE FROM combat_state WHERE character_id = ?", (character["id"],))
        con.execute(
            "UPDATE character SET cash = cash - ?, current_location = 'county_jail', updated_at = ? WHERE id = ?",
            (fine, now.isoformat(timespec="seconds"), character["id"]),
        )
        con.execute(
            "INSERT OR REPLACE INTO jail_state (character_id, reason, started_at, release_at, duration_seconds, fine) VALUES (?, ?, ?, ?, ?, ?)",
            (character["id"], reason, now.isoformat(timespec="seconds"), release.isoformat(timespec="seconds"), duration, fine),
        )
        con.execute(
            "UPDATE crime_profile SET arrests = arrests + 1, heat = MIN(100, heat + 8), mask_worn = 0 WHERE character_id = ?",
            (character["id"],),
        )
        con.execute(
            "INSERT INTO court_cases (character_id, charge, filed_day, severity, status) VALUES (?, ?, ?, ?, 'Pending')",
            (character["id"], reason, int(character["day"]), max(1, int(severity))),
        )
        return fine, duration

    def available_crimes(self) -> list[dict]:
        character = self.load_character()
        profile = self.get_crime_profile()
        rows = []
        for crime in CRIMES.values():
            available = normalize_location_key(character.current_location) == "millhaven" and not self.is_busy()
            reason = ""
            if crime.night_only and not (character.time_minutes >= 1200 or character.time_minutes < 300):
                available = False
                reason = "Available from 8:00 PM to 5:00 AM."
            rows.append({
                "key": crime.key,
                "name": crime.name,
                "description": crime.description,
                "stamina_cost": crime.stamina_cost,
                "heat_gain": crime.heat_gain,
                "available": available and character.stamina >= crime.stamina_cost,
                "reason": reason,
                "masked": bool(profile["mask_worn"]),
            })
        return rows

    def commit_crime(self, crime_key: str) -> dict:
        crime = CRIMES.get(crime_key)
        if crime is None:
            raise ValueError("Unknown crime.")
        character = self.load_character()
        if normalize_location_key(character.current_location) != "millhaven":
            raise RuntimeError("You need to be in Millhaven.")
        if self.is_busy():
            raise RuntimeError("You cannot do that while occupied with another activity.")
        if character.stamina < crime.stamina_cost:
            raise RuntimeError("You do not have enough stamina.")
        if crime.night_only and not (character.time_minutes >= 1200 or character.time_minutes < 300):
            raise RuntimeError("That crime is only available at night.")
        return self._resolve_crime(crime.name, crime.base_success, crime.base_arrest, crime.min_cash, crime.max_cash,
                                   crime.stamina_cost, crime.heat_gain, crime.crime_xp, crime.game_minutes,
                                   crime.murder, payout_fixed=None)

    def crime_jobs(self) -> list[dict]:
        character = self.load_character()
        return [{
            "key": job.key,
            "name": job.name,
            "description": job.description,
            "payout": job.payout,
            "stamina_cost": job.stamina_cost,
            "heat_gain": job.heat_gain,
            "available": normalize_location_key(character.current_location) == "millhaven" and not self.is_busy() and character.stamina >= job.stamina_cost,
        } for job in CRIME_JOBS.values()]

    def take_crime_job(self, job_key: str) -> dict:
        job = CRIME_JOBS.get(job_key)
        if job is None:
            raise ValueError("Unknown crime job.")
        character = self.load_character()
        if normalize_location_key(character.current_location) != "millhaven":
            raise RuntimeError("You need to be in Millhaven.")
        if self.is_busy():
            raise RuntimeError("You cannot take the job while occupied with another activity.")
        if character.stamina < job.stamina_cost:
            raise RuntimeError("You do not have enough stamina.")
        return self._resolve_crime(job.name, job.base_success, job.base_arrest, 0, 0,
                                   job.stamina_cost, job.heat_gain, job.crime_xp, job.game_minutes,
                                   job.murder, payout_fixed=job.payout)

    def _resolve_crime(self, name: str, base_success: int, base_arrest: int, min_cash: int, max_cash: int,
                       stamina_cost: int, heat_gain: int, crime_xp: int, game_minutes: int,
                       murder: bool, payout_fixed: int | None) -> dict:
        character = self.load_character()
        profile = self.get_crime_profile()
        skill = self.skill_level("Crime")
        masked = bool(profile["mask_worn"]) and profile["has_mask"]
        success_chance = max(8, min(92, base_success + skill * 3))
        roll = random.randint(1, 100)
        success = roll <= success_chance
        cash_gain = payout_fixed if (success and payout_fixed is not None) else (random.randint(min_cash, max_cash) if success and max_cash > 0 else 0)
        effective_heat = heat_gain
        if masked:
            effective_heat = max(1, round(effective_heat * 0.65))
        current_heat = int(profile["heat"])
        arrest_chance = base_arrest + current_heat // 3
        if success:
            arrest_chance = max(3, arrest_chance // 3)
        if masked:
            arrest_chance = max(2, arrest_chance - 14)
        arrest_chance = max(2, min(95, arrest_chance))
        arrested = random.randint(1, 100) <= arrest_chance
        outcome = "Completed" if success else "Failed"
        day, minutes = self._time_after(character.day, character.time_minutes, game_minutes)
        now = datetime.now().isoformat(timespec="seconds")
        fine = 0
        sentence = 0
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET stamina = stamina - ?, cash = cash + ?, day = ?, time_minutes = ?, stamina_updated_at = ?, updated_at = ? WHERE id = ?",
                (stamina_cost, cash_gain, day, minutes, now, now, character.id),
            )
            con.execute(
                "UPDATE skills SET xp = xp + ? WHERE character_id = ? AND skill_name = 'Crime'",
                (crime_xp if success else max(1, crime_xp // 2), character.id),
            )
            con.execute(
                "UPDATE crime_profile SET heat = MIN(100, heat + ?), crimes_committed = crimes_committed + 1, murders = murders + ?, last_heat_day = ? WHERE character_id = ?",
                (effective_heat, 1 if murder and success else 0, day, character.id),
            )
            if arrested:
                current = con.execute("SELECT * FROM character WHERE id = ?", (character.id,)).fetchone()
                fine, sentence = self._arrest(con, current, name, max(5, effective_heat))
                outcome += " — Arrested"
            con.execute(
                "INSERT INTO crime_record (character_id, day, crime_name, outcome, cash_change, heat_change, arrested) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (character.id, day, name, outcome, cash_gain - fine, effective_heat, 1 if arrested else 0),
            )
        return {
            "name": name,
            "success": success,
            "arrested": arrested,
            "cash_gain": cash_gain,
            "fine": fine,
            "sentence_seconds": sentence,
            "heat_gain": effective_heat,
            "masked": masked,
            "murder": murder and success,
        }

    # ---------- Gathering / Crafting ----------
    def inventory_quantity(self, item_name: str) -> int:
        character = self.load_character()
        row = self.db.fetchone(
            "SELECT quantity FROM inventory WHERE character_id = ? AND item_name = ?",
            (character.id, item_name),
        )
        return int(row["quantity"]) if row else 0

    def property_storage_quantity(self, item_name: str) -> int:
        character = self.load_character()
        row = self.db.fetchone(
            "SELECT quantity FROM property_storage WHERE plot_id = ? AND item_name = ?",
            (character.home_plot_id, item_name),
        )
        return int(row["quantity"]) if row else 0

    def available_material_quantity(self, item_name: str) -> int:
        return self.inventory_quantity(item_name) + self.property_storage_quantity(item_name)

    def _consume_material_from_inventory_and_storage(self, con, character_id: int, plot_id: int, item_name: str, quantity: int) -> None:
        remaining = quantity
        inv = con.execute(
            "SELECT id, quantity FROM inventory WHERE character_id = ? AND item_name = ?",
            (character_id, item_name),
        ).fetchone()
        if inv and remaining:
            take = min(remaining, int(inv["quantity"]))
            if take == int(inv["quantity"]):
                con.execute("DELETE FROM inventory WHERE id = ?", (inv["id"],))
            else:
                con.execute("UPDATE inventory SET quantity = quantity - ? WHERE id = ?", (take, inv["id"]))
            remaining -= take
        store = con.execute(
            "SELECT id, quantity FROM property_storage WHERE plot_id = ? AND item_name = ?",
            (plot_id, item_name),
        ).fetchone()
        if store and remaining:
            take = min(remaining, int(store["quantity"]))
            if take == int(store["quantity"]):
                con.execute("DELETE FROM property_storage WHERE id = ?", (store["id"],))
            else:
                con.execute("UPDATE property_storage SET quantity = quantity - ? WHERE id = ?", (take, store["id"]))
            remaining -= take
        if remaining:
            raise RuntimeError(f"Not enough {item_name}.")

    def missing_construction_materials(self, structure_key: str) -> dict[str, int]:
        definition = STRUCTURES[structure_key]
        missing: dict[str, int] = {}
        for item_name, quantity in definition.materials:
            available = self.available_material_quantity(item_name)
            if available < quantity:
                missing[item_name] = quantity - available
        return missing

    def has_structure(self, structure_key: str) -> bool:
        character = self.load_character()
        return self.db.fetchone(
            "SELECT id FROM structures WHERE plot_id = ? AND definition_key = ?",
            (character.home_plot_id, structure_key),
        ) is not None

    def _best_gathering_tool(self, activity: str) -> str | None:
        character = self.load_character()
        owned = {
            row["item_name"]
            for row in self.db.fetchall("SELECT item_name FROM inventory WHERE character_id = ? AND quantity > 0", (character.id,))
        }
        candidates = [tool for tool in GATHERING_TOOLS.values() if tool.activity == activity and tool.name in owned]
        if not candidates:
            return None
        return max(candidates, key=lambda tool: (tool.yield_bonus, tool.stamina_reduction)).name

    def gather_wood(self) -> dict:
        character = self.load_character()
        current = normalize_location_key(character.current_location)
        if current not in {"blackwood_trail", "hollow_creek_sawmill"}:
            raise RuntimeError("You need to be at a managed timber area to cut timber.")
        if self.is_busy():
            raise RuntimeError("You cannot gather materials while occupied with another activity.")
        tool_name = self._best_gathering_tool("woodcutting")
        if not tool_name:
            raise RuntimeError("You need a Wood Axe or Forged Axe.")
        tool = GATHERING_TOOLS[tool_name]
        stamina_cost = max(1, 3 - tool.stamina_reduction)
        if character.stamina < stamina_cost:
            raise RuntimeError("You do not have enough stamina.")
        level = self.skill_level("Woodcutting")
        site_bonus = 1 if current == "hollow_creek_sawmill" else 0
        quantity = random.randint(2, 4) + tool.yield_bonus + level // 5 + site_bonus
        day, minutes = self._time_after(character.day, character.time_minutes, 35)
        now = datetime.now().isoformat(timespec="seconds")
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET stamina = stamina - ?, day = ?, time_minutes = ?, stamina_updated_at = ?, updated_at = ? WHERE id = ?",
                (stamina_cost, day, minutes, now, now, character.id),
            )
            con.execute("UPDATE skills SET xp = xp + 2 WHERE character_id = ? AND skill_name = 'Woodcutting'", (character.id,))
            self._add_inventory_item(con, character.id, "Log", GATHERING_ITEM_DESCRIPTIONS["Log"], quantity)
        return {"item": "Log", "quantity": quantity, "tool": tool_name, "stamina": stamina_cost}

    def mine_quarry(self) -> dict:
        character = self.load_character()
        current = normalize_location_key(character.current_location)
        if current not in {"millhaven_quarry", "pine_ridge_mine"}:
            raise RuntimeError("You need to be at a mining site to extract stone and ore.")
        if self.is_busy():
            raise RuntimeError("You cannot gather materials while occupied with another activity.")
        tool_name = self._best_gathering_tool("mining")
        if not tool_name:
            raise RuntimeError("You need a Mining Pick or Forged Mining Pick.")
        tool = GATHERING_TOOLS[tool_name]
        stamina_cost = max(1, 4 - tool.stamina_reduction)
        if character.stamina < stamina_cost:
            raise RuntimeError("You do not have enough stamina.")
        level = self.skill_level("Mining")
        site_bonus = 1 if current == "pine_ridge_mine" else 0
        stone = random.randint(2, 4) + tool.yield_bonus + level // 5 + site_bonus
        ore_chance = min(85, 30 + level * 3 + tool.yield_bonus * 8 + (15 if current == "pine_ridge_mine" else 0))
        ore = 1 if random.randint(1, 100) <= ore_chance else 0
        if tool.yield_bonus >= 2 and ore and random.randint(1, 100) <= 30:
            ore += 1
        day, minutes = self._time_after(character.day, character.time_minutes, 40)
        now = datetime.now().isoformat(timespec="seconds")
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET stamina = stamina - ?, day = ?, time_minutes = ?, stamina_updated_at = ?, updated_at = ? WHERE id = ?",
                (stamina_cost, day, minutes, now, now, character.id),
            )
            con.execute("UPDATE skills SET xp = xp + 2 WHERE character_id = ? AND skill_name = 'Mining'", (character.id,))
            self._add_inventory_item(con, character.id, "Stone", GATHERING_ITEM_DESCRIPTIONS["Stone"], stone)
            if ore:
                self._add_inventory_item(con, character.id, "Iron Ore", GATHERING_ITEM_DESCRIPTIONS["Iron Ore"], ore)
        return {"stone": stone, "ore": ore, "tool": tool_name, "stamina": stamina_cost}

    def fish_lake_mercy(self) -> dict:
        character = self.load_character()
        current = normalize_location_key(character.current_location)
        if current not in {"lake_mercy", "lake_mercy_north_shore"}:
            raise RuntimeError("You need to be at Lake Mercy to fish.")
        if self.is_busy():
            raise RuntimeError("You cannot fish while occupied with another activity.")
        rod = self.db.fetchone(
            "SELECT id FROM inventory WHERE character_id = ? AND item_name = 'Fishing Rod' AND quantity > 0",
            (character.id,),
        )
        if not rod:
            raise RuntimeError("You need a Fishing Rod.")
        if character.stamina < 2:
            raise RuntimeError("You do not have enough stamina.")
        level = self.skill_level("Fishing")
        catches = [
            ("Lake Perch", "A small freshwater perch caught in Lake Mercy."),
            ("Rainbow Trout", "A freshwater trout caught in the cold water of Lake Mercy."),
            ("Lake Whitefish", "A pale freshwater fish taken from deeper water."),
        ]
        weights = [55, 35, 10 + min(30, level * 2)]
        catch_name, description = random.choices(catches, weights=weights, k=1)[0]
        quantity = 1 + (1 if level >= 8 and random.randint(1, 100) <= 25 else 0)
        day, minutes = self._time_after(character.day, character.time_minutes, 45)
        now = datetime.now().isoformat(timespec="seconds")
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET stamina = stamina - 2, day = ?, time_minutes = ?, stamina_updated_at = ?, updated_at = ? WHERE id = ?",
                (day, minutes, now, now, character.id),
            )
            con.execute("UPDATE skills SET xp = xp + 2 WHERE character_id = ? AND skill_name = 'Fishing'", (character.id,))
            self._add_inventory_item(con, character.id, catch_name, description, quantity)
            region = region_key_for_location(current)
            con.execute(
                "INSERT OR IGNORE INTO regional_reputation (character_id, region_key, reputation) VALUES (?, ?, 0)",
                (character.id, region),
            )
        return {"item": catch_name, "quantity": quantity}

    def salvage_redwater(self) -> dict:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "redwater_industrial":
            raise RuntimeError("You need to be at the Redwater Industrial Yard to salvage material.")
        if self.is_busy():
            raise RuntimeError("You cannot search the yard while occupied with another activity.")
        if character.stamina < 3:
            raise RuntimeError("You do not have enough stamina.")
        finds = [
            ("Scrap Metal", "Sorted scrap metal recovered from discarded industrial material.", 2, 5),
            ("Machine Parts", "A collection of used mechanical parts that remain serviceable.", 1, 3),
            ("Wire Bundle", "A bundled length of insulated electrical wire recovered from industrial scrap.", 1, 2),
            ("Iron Ore", GATHERING_ITEM_DESCRIPTIONS["Iron Ore"], 1, 1),
        ]
        item_name, description, low, high = random.choice(finds)
        quantity = random.randint(low, high)
        day, minutes = self._time_after(character.day, character.time_minutes, 50)
        now = datetime.now().isoformat(timespec="seconds")
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET stamina = stamina - 3, day = ?, time_minutes = ?, stamina_updated_at = ?, updated_at = ? WHERE id = ?",
                (day, minutes, now, now, character.id),
            )
            con.execute("UPDATE skills SET xp = xp + 1 WHERE character_id = ? AND skill_name = 'Exploration'", (character.id,))
            con.execute("UPDATE skills SET xp = xp + 1 WHERE character_id = ? AND skill_name = 'Crafting'", (character.id,))
            self._add_inventory_item(con, character.id, item_name, description, quantity)
        return {"item": item_name, "quantity": quantity}

    def rent_regional_room(self) -> dict:
        character = self.load_character()
        current = normalize_location_key(character.current_location)
        prices = {"redwater": 28, "lake_mercy": 42, "greybridge_city": 65, "hollow_creek": 24, "pine_ridge": 30, "westhaven": 58}
        if current not in prices:
            raise RuntimeError("There is no overnight lodging available here.")
        if self.is_busy():
            raise RuntimeError("You cannot rent a room while occupied with another activity.")
        price = prices[current]
        if character.cash < price:
            raise RuntimeError("You do not have enough cash for a room.")
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET cash = cash - ?, hp = max_hp, stamina = max_stamina, stamina_updated_at = ? WHERE id = ?",
                (price, datetime.now().isoformat(timespec="seconds"), character.id),
            )
        self._advance_time(character.id, 480)
        return {"price": price, "location": LOCATIONS[current].name}

    def craft_recipe(self, recipe_key: str) -> dict:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "home":
            raise RuntimeError("You need to be at your property to craft materials.")
        if self.is_busy():
            raise RuntimeError("You cannot craft while occupied with another activity.")
        recipe = CRAFT_RECIPES.get(recipe_key)
        if recipe is None:
            raise ValueError("Unknown crafting recipe.")
        if not self.has_structure(recipe.station):
            station_name = "Workbench" if recipe.station == "workbench" else "Stone Forge"
            raise RuntimeError(f"You need a {station_name} on your property.")
        missing = [(name, qty - self.available_material_quantity(name)) for name, qty in recipe.inputs if self.available_material_quantity(name) < qty]
        if missing:
            text = ", ".join(f"{name} x{qty}" for name, qty in missing)
            raise RuntimeError(f"Required materials are missing: {text}.")
        day, minutes = self._time_after(character.day, character.time_minutes, recipe.game_minutes)
        now = datetime.now().isoformat(timespec="seconds")
        with self.db.transaction() as con:
            for item_name, quantity in recipe.inputs:
                self._consume_material_from_inventory_and_storage(con, character.id, character.home_plot_id, item_name, quantity)
            self._add_inventory_item(con, character.id, recipe.output_name, recipe.output_description, recipe.output_quantity)
            con.execute("UPDATE skills SET xp = xp + ? WHERE character_id = ? AND skill_name = 'Crafting'", (recipe.crafting_xp, character.id))
            con.execute("UPDATE character SET day = ?, time_minutes = ?, updated_at = ? WHERE id = ?", (day, minutes, now, character.id))
        return {"name": recipe.name, "output": recipe.output_name, "quantity": recipe.output_quantity, "xp": recipe.crafting_xp}

    # ---------- Vice / Addiction / Casino ----------
    @staticmethod
    def _game_total_minutes(day: int, time_minutes: int) -> int:
        return max(0, (int(day) - 1) * 1440 + int(time_minutes))

    def _process_vice_state(self, character_row) -> None:
        if character_row is None:
            return
        character_id = int(character_row["id"])
        profile = self.db.fetchone("SELECT * FROM vice_profile WHERE character_id = ?", (character_id,))
        if profile is None:
            self.db.execute(
                "INSERT INTO vice_profile (character_id, last_processed_day, last_processed_minute) VALUES (?, ?, ?)",
                (character_id, int(character_row["day"]), int(character_row["time_minutes"])),
            )
            return

        current_total = self._game_total_minutes(character_row["day"], character_row["time_minutes"])
        previous_total = self._game_total_minutes(profile["last_processed_day"], profile["last_processed_minute"])
        elapsed = max(0, current_total - previous_total)
        intoxication = int(profile["intoxication"])
        drug_effect = int(profile["drug_effect"])
        if elapsed:
            intoxication = max(0, intoxication - (elapsed // 30) * 5)
            drug_effect = max(0, drug_effect - (elapsed // 30) * 6)

        day = int(character_row["day"])
        alcohol_dep = int(profile["alcohol_dependence"])
        drug_dep = int(profile["drug_dependence"])
        gambling_dep = int(profile["gambling_dependence"])
        alcohol_withdrawal = (
            alcohol_dep >= 25 and profile["last_alcohol_day"] is not None
            and day - int(profile["last_alcohol_day"]) >= 1
        )
        drug_withdrawal = (
            drug_dep >= 25 and profile["last_drug_day"] is not None
            and day - int(profile["last_drug_day"]) >= 1
        )
        gambling_urge = (
            gambling_dep >= 25 and profile["last_gamble_day"] is not None
            and day - int(profile["last_gamble_day"]) >= 1
        )
        last_withdrawal_day = int(profile["last_withdrawal_day"] or 0)
        withdrawal_today = (alcohol_withdrawal or drug_withdrawal) and last_withdrawal_day < day
        last_gambling_urge_day = int(profile["last_gambling_urge_day"] or 0)
        gambling_urge_today = gambling_urge and last_gambling_urge_day < day

        with self.db.transaction() as con:
            con.execute(
                """
                UPDATE vice_profile
                SET intoxication = ?, drug_effect = ?, last_processed_day = ?, last_processed_minute = ?
                WHERE character_id = ?
                """,
                (intoxication, drug_effect, day, int(character_row["time_minutes"]), character_id),
            )
            if withdrawal_today:
                severity = max(alcohol_dep if alcohol_withdrawal else 0, drug_dep if drug_withdrawal else 0)
                stamina_loss = min(6, 2 + severity // 25)
                hp_loss = 1 if severity < 75 else 2
                con.execute(
                    "UPDATE character SET stamina = MAX(0, stamina - ?), hp = MAX(1, hp - ?) WHERE id = ?",
                    (stamina_loss, hp_loss, character_id),
                )
                con.execute(
                    "UPDATE vice_profile SET last_withdrawal_day = ? WHERE character_id = ?",
                    (day, character_id),
                )
            if gambling_urge_today:
                stamina_loss = min(5, 1 + gambling_dep // 25)
                con.execute(
                    "UPDATE character SET stamina = MAX(0, stamina - ?) WHERE id = ?",
                    (stamina_loss, character_id),
                )
                con.execute(
                    "UPDATE vice_profile SET last_gambling_urge_day = ? WHERE character_id = ?",
                    (day, character_id),
                )

    def get_vice_profile(self) -> dict:
        row = self.db.fetchone("SELECT * FROM character LIMIT 1")
        if row is None:
            raise RuntimeError("No saved character exists.")
        self._process_vice_state(row)
        profile = self.db.fetchone("SELECT * FROM vice_profile WHERE character_id = ?", (row["id"],))
        if profile is None:
            raise RuntimeError("Vice profile is unavailable.")
        result = dict(profile)
        current_day = int(row["day"])
        alcohol_withdrawal = (
            int(result["alcohol_dependence"]) >= 25 and result["last_alcohol_day"] is not None
            and current_day - int(result["last_alcohol_day"]) >= 1
        )
        drug_withdrawal = (
            int(result["drug_dependence"]) >= 25 and result["last_drug_day"] is not None
            and current_day - int(result["last_drug_day"]) >= 1
        )
        gambling_urge = (
            int(result["gambling_dependence"]) >= 25 and result["last_gamble_day"] is not None
            and current_day - int(result["last_gamble_day"]) >= 1
        )
        result.update({
            "intoxication_label": intoxication_label(int(result["intoxication"])),
            "drug_effect_label": drug_effect_label(int(result["drug_effect"])),
            "alcohol_dependence_label": dependence_label(int(result["alcohol_dependence"])),
            "drug_dependence_label": dependence_label(int(result["drug_dependence"])),
            "gambling_dependence_label": dependence_label(int(result["gambling_dependence"])),
            "alcohol_withdrawal": alcohol_withdrawal,
            "drug_withdrawal": drug_withdrawal,
            "gambling_urge": gambling_urge,
            "dealer_tier": dealer_tier(int(result["dealer_reputation"])),
            "record": [dict(x) for x in self.db.fetchall(
                "SELECT * FROM vice_record WHERE character_id = ? ORDER BY id DESC LIMIT 12", (row["id"],)
            )],
        })
        return result

    def _record_vice(self, con, character_id: int, day: int, event_type: str, description: str, cash_change: int = 0) -> None:
        con.execute(
            "INSERT INTO vice_record (character_id, day, event_type, description, cash_change) VALUES (?, ?, ?, ?, ?)",
            (character_id, day, event_type, description, cash_change),
        )

    def buy_vice_item(self, item_key: str) -> None:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "millhaven":
            raise RuntimeError("You need to be in Millhaven.")
        item = ALCOHOL_ITEMS.get(item_key) or DRUG_ITEMS.get(item_key)
        if item is None:
            raise ValueError("Unknown item.")
        if character.cash < item.price:
            raise RuntimeError("You do not have enough cash.")
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? WHERE id = ?", (item.price, character.id))
            self._add_inventory_item(con, character.id, item.name, item.description)
            self._record_vice(con, character.id, character.day, "Purchase", f"Purchased {item.name}.", -item.price)

    def use_vice_item(self, item_name: str) -> dict:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You cannot use that while occupied with another activity.")
        item = ITEM_BY_NAME.get(item_name)
        if item is None:
            raise ValueError("That item is not a vice item.")
        day, minutes = self._time_after(character.day, character.time_minutes, 20)
        hp = max(1, min(character.max_hp, character.hp + item.hp_change))
        stamina = max(0, min(character.max_stamina, character.stamina + item.stamina_change))
        now = datetime.now().isoformat(timespec="seconds")
        with self.db.transaction() as con:
            if not self._remove_inventory_item(con, character.id, item.name):
                raise RuntimeError("You do not have that item.")
            if item.kind == "alcohol":
                con.execute(
                    """
                    UPDATE vice_profile
                    SET alcohol_dependence = MIN(100, alcohol_dependence + ?),
                        intoxication = MIN(100, intoxication + ?), last_alcohol_day = ?,
                        last_processed_day = ?, last_processed_minute = ?
                    WHERE character_id = ?
                    """,
                    (item.dependence_gain, item.intoxication, day, day, minutes, character.id),
                )
            else:
                con.execute(
                    """
                    UPDATE vice_profile
                    SET drug_dependence = MIN(100, drug_dependence + ?),
                        drug_effect = MIN(100, drug_effect + ?), last_drug_day = ?,
                        last_processed_day = ?, last_processed_minute = ?
                    WHERE character_id = ?
                    """,
                    (item.dependence_gain, item.drug_effect, day, day, minutes, character.id),
                )
            con.execute(
                "UPDATE character SET hp = ?, stamina = ?, day = ?, time_minutes = ?, stamina_updated_at = ?, updated_at = ? WHERE id = ?",
                (hp, stamina, day, minutes, now, now, character.id),
            )
            con.execute("UPDATE skills SET xp = xp + 1 WHERE character_id = ? AND skill_name = 'Vice'", (character.id,))
            self._record_vice(con, character.id, day, "Use", f"Used {item.name}.")
        return {"name": item.name, "hp": hp, "stamina": stamina}

    def detox_treatment(self) -> dict:
        character = self.load_character()
        if normalize_location_key(character.current_location) not in {"millhaven", "redwater", "lake_mercy", "greybridge_city", "hollow_creek", "pine_ridge", "westhaven"}:
            raise RuntimeError("You need to be at a medical facility.")
        if self.is_busy():
            raise RuntimeError("You are already busy.")
        profile = self.get_vice_profile()
        if (int(profile["alcohol_dependence"]) <= 0 and int(profile["drug_dependence"]) <= 0
                and int(profile["gambling_dependence"]) <= 0):
            raise RuntimeError("There is no dependence to treat.")
        cost = 75
        if character.cash < cost:
            raise RuntimeError("You do not have enough cash.")
        day, minutes = self._time_after(character.day, character.time_minutes, 180)
        now = datetime.now().isoformat(timespec="seconds")
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ?, day = ?, time_minutes = ?, updated_at = ? WHERE id = ?", (cost, day, minutes, now, character.id))
            con.execute(
                """
                UPDATE vice_profile
                SET alcohol_dependence = MAX(0, alcohol_dependence - 25),
                    drug_dependence = MAX(0, drug_dependence - 25),
                    gambling_dependence = MAX(0, gambling_dependence - 25),
                    intoxication = 0, drug_effect = 0,
                    last_processed_day = ?, last_processed_minute = ?
                WHERE character_id = ?
                """,
                (day, minutes, character.id),
            )
            self._record_vice(con, character.id, day, "Treatment", "Completed a clinic dependence treatment session.", -cost)
        return {"cost": cost}

    def start_dealer_operation(self) -> None:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "millhaven":
            raise RuntimeError("You need to be in Millhaven.")
        if self.skill_level("Crime") < 1:
            raise RuntimeError("You need Crime level 1 before Darius will bring you into the trade.")
        profile = self.get_vice_profile()
        if profile["dealer_started"]:
            raise RuntimeError("You already have an active dealing operation.")
        startup = 100
        if character.cash < startup:
            raise RuntimeError("You need $100 to establish the operation.")
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? WHERE id = ?", (startup, character.id))
            con.execute("UPDATE vice_profile SET dealer_started = 1, dealer_reputation = 1 WHERE character_id = ?", (character.id,))
            self._record_vice(con, character.id, character.day, "Dealing", "Established a small street dealing operation.", -startup)

    def buy_dealer_stock(self, item_key: str, quantity: int = 5) -> dict:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "millhaven":
            raise RuntimeError("You need to be in Millhaven.")
        profile = self.get_vice_profile()
        if not profile["dealer_started"]:
            raise RuntimeError("You have not established a dealing operation.")
        item = DRUG_ITEMS.get(item_key)
        if item is None:
            raise ValueError("Unknown stock item.")
        quantity = max(1, min(20, int(quantity)))
        unit_cost = max(1, int(round(item.price * 0.62)))
        total = unit_cost * quantity
        if character.cash < total:
            raise RuntimeError("You do not have enough cash for that stock.")
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? WHERE id = ?", (total, character.id))
            self._add_inventory_item(con, character.id, item.name, item.description, quantity)
            self._record_vice(con, character.id, character.day, "Dealing", f"Purchased {quantity} units of {item.name} as dealer stock.", -total)
        return {"quantity": quantity, "cost": total, "item": item.name}

    def make_drugs(self) -> dict:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "home":
            raise RuntimeError("Drug production can only be managed from your property.")
        if self.is_busy():
            raise RuntimeError("You are already occupied with another activity.")
        profile = self.get_vice_profile()
        if not profile["dealer_started"]:
            raise RuntimeError("You need an established dealing operation before you can produce drugs.")
        if character.stamina < 3:
            raise RuntimeError("You do not have enough stamina.")

        reputation = int(profile["dealer_reputation"])
        batch = 3 if reputation < 55 else 5 if reputation < 110 else 8
        cost = 25 if batch == 3 else 40 if batch == 5 else 60
        if character.cash < cost:
            raise RuntimeError(f"You need ${cost} for generic operating supplies.")

        item = DRUG_ITEMS["drugs"]
        heat_gain = 4 + max(0, batch - 3)
        day, minutes = self._time_after(character.day, character.time_minutes, 90)
        now = datetime.now().isoformat(timespec="seconds")
        with self.db.transaction() as con:
            con.execute(
                "UPDATE character SET cash = cash - ?, stamina = MAX(0, stamina - 3), day = ?, time_minutes = ?, stamina_updated_at = ?, updated_at = ? WHERE id = ?",
                (cost, day, minutes, now, now, character.id),
            )
            self._add_inventory_item(con, character.id, item.name, item.description, batch)
            con.execute("UPDATE skills SET xp = xp + 3 WHERE character_id = ? AND skill_name = 'Vice'", (character.id,))
            con.execute("UPDATE skills SET xp = xp + 2 WHERE character_id = ? AND skill_name = 'Crime'", (character.id,))
            con.execute(
                "UPDATE vice_profile SET dealer_reputation = dealer_reputation + 2 WHERE character_id = ?",
                (character.id,),
            )
            con.execute(
                "UPDATE crime_profile SET heat = MIN(100, heat + ?), crimes_committed = crimes_committed + 1 WHERE character_id = ?",
                (heat_gain, character.id),
            )
            con.execute(
                "INSERT INTO crime_record (character_id, day, crime_name, outcome, cash_change, heat_change, arrested) VALUES (?, ?, 'Drug Production', 'Completed', ?, ?, 0)",
                (character.id, day, -cost, heat_gain),
            )
            self._record_vice(
                con, character.id, day, "Production",
                f"Produced {batch} unit(s) of Drugs through the dealing operation.", -cost,
            )
        return {"quantity": batch, "cost": cost, "heat_gain": heat_gain}

    def dealer_stock(self) -> dict[str, int]:
        row = self.db.fetchone("SELECT id FROM character LIMIT 1")
        if row is None:
            return {}
        stock = {}
        for item in DRUG_ITEMS.values():
            inv = self.db.fetchone(
                "SELECT quantity FROM inventory WHERE character_id = ? AND item_name = ?", (row["id"], item.name)
            )
            stock[item.name] = int(inv["quantity"]) if inv else 0
        return stock

    def dealer_sale(self, item_key: str, quantity: int = 1) -> dict:
        character = self.load_character()
        if normalize_location_key(character.current_location) != "millhaven":
            raise RuntimeError("You need to be in Millhaven.")
        if self.is_busy():
            raise RuntimeError("You are already busy.")
        profile = self.get_vice_profile()
        if not profile["dealer_started"]:
            raise RuntimeError("You have not established a dealing operation.")
        item = DRUG_ITEMS.get(item_key)
        if item is None:
            raise ValueError("Unknown stock item.")
        quantity = 5 if int(quantity) >= 5 else 1
        if quantity == 5 and int(profile["dealer_reputation"]) < 20:
            raise RuntimeError("Your operation is not established enough to move larger batches.")
        owned = self.db.fetchone("SELECT quantity FROM inventory WHERE character_id = ? AND item_name = ?", (character.id, item.name))
        if owned is None or int(owned["quantity"]) < quantity:
            raise RuntimeError("You do not have enough stock.")

        crime_level = self.skill_level("Crime")
        heat = int(self.get_crime_profile()["heat"])
        chance = max(35, min(94, 82 + crime_level * 2 - (10 if quantity == 5 else 0) - heat * 0.22))
        roll = random.SystemRandom().uniform(0, 100)
        success = roll <= chance
        heat_gain = 4 + quantity * 2
        cash_gain = int(round(item.price * 1.35)) * quantity if success else 0
        rep_gain = (3 if quantity == 1 else 10) if success else 1
        arrest_chance = max(4, min(70, 8 + heat * 0.35 + (12 if quantity == 5 else 0) + (18 if not success else 0)))
        arrested = random.SystemRandom().uniform(0, 100) < arrest_chance
        game_minutes = 35 if quantity == 1 else 90
        day, minutes = self._time_after(character.day, character.time_minutes, game_minutes)
        now = datetime.now().isoformat(timespec="seconds")
        fine = 0

        with self.db.transaction() as con:
            if not self._remove_inventory_item(con, character.id, item.name, quantity):
                raise RuntimeError("Dealer stock changed before the sale could be completed.")
            con.execute(
                "UPDATE character SET cash = cash + ?, stamina = MAX(0, stamina - 1), day = ?, time_minutes = ?, stamina_updated_at = ?, updated_at = ? WHERE id = ?",
                (cash_gain, day, minutes, now, now, character.id),
            )
            con.execute("UPDATE skills SET xp = xp + ? WHERE character_id = ? AND skill_name = 'Crime'", (2 + quantity, character.id))
            con.execute("UPDATE skills SET xp = xp + ? WHERE character_id = ? AND skill_name = 'Vice'", (1 + quantity, character.id))
            con.execute(
                "UPDATE vice_profile SET dealer_reputation = dealer_reputation + ? WHERE character_id = ?",
                (rep_gain, character.id),
            )
            con.execute(
                "UPDATE crime_profile SET heat = MIN(100, heat + ?), crimes_committed = crimes_committed + ? WHERE character_id = ?",
                (heat_gain, 1 if success else 0, character.id),
            )
            outcome = "Completed" if success else "Failed"
            con.execute(
                "INSERT INTO crime_record (character_id, day, crime_name, outcome, cash_change, heat_change, arrested) VALUES (?, ?, 'Drug Distribution', ?, ?, ?, ?)",
                (character.id, day, outcome, cash_gain, heat_gain, 1 if arrested else 0),
            )
            self._record_vice(con, character.id, day, "Dealing", f"{outcome} sale of {quantity} unit(s) of {item.name}.", cash_gain)
            if arrested:
                row = con.execute("SELECT * FROM character WHERE id = ?", (character.id,)).fetchone()
                fine, _duration = self._arrest(con, row, "Drug Distribution", 10 + quantity * 3)
        return {"success": success, "arrested": arrested, "cash_gain": cash_gain, "fine": fine, "heat_gain": heat_gain, "reputation_gain": rep_gain}

    def casino_profile(self) -> dict:
        profile = self.get_vice_profile()
        return {
            "wins": int(profile["casino_wins"]),
            "losses": int(profile["casino_losses"]),
            "net": int(profile["casino_net"]),
        }

    def _casino_record(self, con, character_id: int, day: int, description: str, wager: int, payout: int) -> None:
        net = payout - wager
        dependence_gain = 1 if wager <= 10 else 2 if wager <= 25 else 3
        con.execute(
            """
            UPDATE vice_profile
            SET casino_wins = casino_wins + ?, casino_losses = casino_losses + ?, casino_net = casino_net + ?,
                gambling_dependence = MIN(100, gambling_dependence + ?), last_gamble_day = ?
            WHERE character_id = ?
            """,
            (1 if net > 0 else 0, 1 if net < 0 else 0, net, dependence_gain, day, character_id),
        )
        self._record_vice(con, character_id, day, "Casino", description, net)
        con.execute("UPDATE skills SET xp = xp + 1 WHERE character_id = ? AND skill_name = 'Vice'", (character_id,))

    @staticmethod
    def _validate_wager(wager: int) -> int:
        wager = int(wager)
        if wager not in (5, 10, 25, 50):
            raise ValueError("Casino wagers must be $5, $10, $25, or $50.")
        return wager

    def _casino_ready(self, wager: int, allow_blackjack: bool = False) -> Character:
        character = self.load_character()
        if normalize_location_key(character.current_location) not in {"millhaven", "greybridge_city", "westhaven"}:
            raise RuntimeError("You need to be at a casino to gamble.")
        if self.is_busy():
            raise RuntimeError("You are already busy.")
        wager = self._validate_wager(wager)
        if character.cash < wager:
            raise RuntimeError("You do not have enough cash for that wager.")
        if not allow_blackjack and self.get_blackjack_state() is not None:
            raise RuntimeError("Finish the current blackjack hand first.")
        return character

    def play_slots(self, wager: int) -> dict:
        wager = self._validate_wager(wager)
        character = self._casino_ready(wager)
        rng = random.SystemRandom()
        reels = [rng.choice(CASINO_SYMBOLS) for _ in range(3)]
        if reels[0] == reels[1] == reels[2]:
            payout = wager * 8
            result = "Three matching symbols"
        elif len(set(reels)) == 2:
            payout = int(round(wager * 1.25))
            result = "Two matching symbols"
        else:
            payout = 0
            result = "No matching line"
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? + ? WHERE id = ?", (wager, payout, character.id))
            self._casino_record(con, character.id, character.day, f"Slots: {' | '.join(reels)} — {result}.", wager, payout)
        return {"reels": reels, "wager": wager, "payout": payout, "net": payout - wager, "result": result}

    @staticmethod
    def _card_score(cards: list[str]) -> int:
        score = 0
        aces = 0
        for card in cards:
            rank = card[:-1]
            if rank in ("J", "Q", "K"):
                score += 10
            elif rank == "A":
                score += 11
                aces += 1
            else:
                score += int(rank)
        while score > 21 and aces:
            score -= 10
            aces -= 1
        return score

    @staticmethod
    def _new_blackjack_deck() -> list[str]:
        return [f"{rank}{suit}" for suit in "SHDC" for rank in ("A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K")]

    def get_blackjack_state(self) -> dict | None:
        row = self.db.fetchone("SELECT id FROM character LIMIT 1")
        if row is None:
            return None
        state = self.db.fetchone("SELECT * FROM blackjack_state WHERE character_id = ?", (row["id"],))
        if state is None:
            return None
        player = json.loads(state["player_cards"])
        dealer = json.loads(state["dealer_cards"])
        return {
            "wager": int(state["wager"]),
            "player_cards": player,
            "dealer_cards": dealer,
            "player_score": self._card_score(player),
            "dealer_score": self._card_score(dealer),
        }

    def _resolve_blackjack(self, character_id: int, wager: int, player: list[str], dealer: list[str], result: str, payout: int) -> dict:
        character = self.db.fetchone("SELECT * FROM character WHERE id = ?", (character_id,))
        if character is None:
            raise RuntimeError("Character is unavailable.")
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash + ? WHERE id = ?", (payout, character_id))
            con.execute("DELETE FROM blackjack_state WHERE character_id = ?", (character_id,))
            self._casino_record(con, character_id, int(character["day"]), f"Blackjack: {result}.", wager, payout)
        return {
            "ended": True, "result": result, "payout": payout, "net": payout - wager,
            "player_cards": player, "dealer_cards": dealer,
            "player_score": self._card_score(player), "dealer_score": self._card_score(dealer),
        }

    def blackjack_start(self, wager: int) -> dict:
        wager = self._validate_wager(wager)
        character = self._casino_ready(wager, allow_blackjack=True)
        if self.get_blackjack_state() is not None:
            raise RuntimeError("A blackjack hand is already in progress.")
        deck = self._new_blackjack_deck()
        random.SystemRandom().shuffle(deck)
        player = [deck.pop(), deck.pop()]
        dealer = [deck.pop(), deck.pop()]
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? WHERE id = ?", (wager, character.id))
            con.execute(
                "INSERT INTO blackjack_state (character_id, wager, player_cards, dealer_cards, deck_cards) VALUES (?, ?, ?, ?, ?)",
                (character.id, wager, json.dumps(player), json.dumps(dealer), json.dumps(deck)),
            )
        player_score = self._card_score(player)
        dealer_score = self._card_score(dealer)
        if player_score == 21 or dealer_score == 21:
            if player_score == 21 and dealer_score == 21:
                return self._resolve_blackjack(character.id, wager, player, dealer, "Push — both hands have blackjack", wager)
            if player_score == 21:
                return self._resolve_blackjack(character.id, wager, player, dealer, "Blackjack", wager + int(wager * 1.5))
            return self._resolve_blackjack(character.id, wager, player, dealer, "Dealer blackjack", 0)
        return {"ended": False, **(self.get_blackjack_state() or {})}

    def blackjack_hit(self) -> dict:
        character = self.load_character()
        state = self.db.fetchone("SELECT * FROM blackjack_state WHERE character_id = ?", (character.id,))
        if state is None:
            raise RuntimeError("No blackjack hand is in progress.")
        player = json.loads(state["player_cards"])
        dealer = json.loads(state["dealer_cards"])
        deck = json.loads(state["deck_cards"])
        player.append(deck.pop())
        score = self._card_score(player)
        if score > 21:
            return self._resolve_blackjack(character.id, int(state["wager"]), player, dealer, "Player bust", 0)
        self.db.execute(
            "UPDATE blackjack_state SET player_cards = ?, deck_cards = ? WHERE character_id = ?",
            (json.dumps(player), json.dumps(deck), character.id),
        )
        return {"ended": False, **(self.get_blackjack_state() or {})}

    def blackjack_stand(self) -> dict:
        character = self.load_character()
        state = self.db.fetchone("SELECT * FROM blackjack_state WHERE character_id = ?", (character.id,))
        if state is None:
            raise RuntimeError("No blackjack hand is in progress.")
        wager = int(state["wager"])
        player = json.loads(state["player_cards"])
        dealer = json.loads(state["dealer_cards"])
        deck = json.loads(state["deck_cards"])
        while self._card_score(dealer) < 17:
            dealer.append(deck.pop())
        pscore = self._card_score(player)
        dscore = self._card_score(dealer)
        if dscore > 21 or pscore > dscore:
            return self._resolve_blackjack(character.id, wager, player, dealer, "Player wins", wager * 2)
        if pscore == dscore:
            return self._resolve_blackjack(character.id, wager, player, dealer, "Push", wager)
        return self._resolve_blackjack(character.id, wager, player, dealer, "Dealer wins", 0)

    def play_roulette(self, wager: int, bet_type: str, number: int | None = None) -> dict:
        wager = self._validate_wager(wager)
        character = self._casino_ready(wager)
        bet_type = bet_type.lower()
        if bet_type not in {"red", "black", "odd", "even", "number"}:
            raise ValueError("Unknown roulette bet.")
        if bet_type == "number":
            if number is None or not 0 <= int(number) <= 36:
                raise ValueError("Single-number bets must be from 0 to 36.")
            number = int(number)
        spin = random.SystemRandom().randint(0, 36)
        if spin == 0:
            color = "green"
        else:
            color = "red" if spin in ROULETTE_RED else "black"
        won = False
        if bet_type == "red": won = color == "red"
        elif bet_type == "black": won = color == "black"
        elif bet_type == "odd": won = spin != 0 and spin % 2 == 1
        elif bet_type == "even": won = spin != 0 and spin % 2 == 0
        elif bet_type == "number": won = spin == number
        payout = wager * (36 if bet_type == "number" and won else 2 if won else 0)
        bet_text = f"number {number}" if bet_type == "number" else bet_type
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? + ? WHERE id = ?", (wager, payout, character.id))
            self._casino_record(con, character.id, character.day, f"Roulette: bet {bet_text}; wheel landed on {spin} {color}.", wager, payout)
        return {"spin": spin, "color": color, "won": won, "wager": wager, "payout": payout, "net": payout - wager, "bet": bet_text}

    # ---------- Seasons / Weather / Outdoors ----------
    def season_weather_profile(self) -> dict:
        character = self.load_character()
        current = normalize_location_key(character.current_location)
        if current == "home":
            region_key = self.load_home_plot().get("region_key", "millhaven_county")
        else:
            region_key = region_key_for_location(current)
        return {
            "season": season_for_day(character.day),
            "weather": weather_for_day(character.day, region_key),
            "day_in_season": ((character.day - 1) % 30) + 1,
        }

    def hunt(self) -> dict:
        character = self.load_character()
        current = normalize_location_key(character.current_location)
        if self.is_busy():
            raise RuntimeError("You cannot hunt while occupied with another activity.")
        if current not in HUNTING_LOCATIONS:
            raise RuntimeError("Hunting is not available at this location.")
        if self.inventory_quantity("Hunting Rifle") <= 0:
            raise RuntimeError("You need a Hunting Rifle in your inventory.")
        if character.stamina < 3:
            raise RuntimeError("You need at least 3 stamina to hunt.")
        season = season_for_day(character.day)
        weather = weather_for_day(character.day, region_key_for_location(current))
        level = self.skill_level("Hunting")
        entries = HUNTING_LOCATIONS[current]
        animal = random.choice(entries)
        animal_name, meat_name, meat_qty, hide_name, hide_qty, base_chance = animal
        weather_mod = -12 if weather in {"Heavy Rain", "Thunderstorms", "Heavy Snow"} else -5 if weather in {"Light Rain", "Snow", "Fog"} else 0
        season_mod = 5 if season == "Autumn" else -5 if season == "Winter" else 0
        success = random.randint(1, 100) <= min(90, base_chance + level * 3 + weather_mod + season_mod)
        with self.db.transaction() as con:
            con.execute("UPDATE character SET stamina = MAX(0, stamina - 3) WHERE id = ?", (character.id,))
            con.execute("UPDATE skills SET xp = xp + ? WHERE character_id = ? AND skill_name = 'Hunting'", (4 if success else 2, character.id))
            if success:
                self._add_inventory_item(con, character.id, meat_name, HUNTING_ITEM_DESCRIPTIONS[meat_name], meat_qty)
                self._add_inventory_item(con, character.id, hide_name, HUNTING_ITEM_DESCRIPTIONS[hide_name], hide_qty)
        self._advance_time(character.id, 90)
        if success:
            return {"success": True, "text": f"You complete a successful hunt and recover {meat_qty} {meat_name} and {hide_qty} {hide_name}.", "animal": animal_name}
        return {"success": False, "text": "You spend time tracking game but return without a usable harvest.", "animal": animal_name}

    def camp_wilderness(self) -> dict:
        character = self.load_character()
        current = normalize_location_key(character.current_location)
        if self.is_busy():
            raise RuntimeError("You cannot make camp while occupied with another activity.")
        if current not in {"blackwood_trail", "lake_mercy_north_shore", "pine_ridge", "hollow_creek_sawmill"}:
            raise RuntimeError("You need to be in a wilderness or backcountry location to camp.")
        if self.inventory_quantity("Camping Kit") <= 0:
            raise RuntimeError("You need a Camping Kit.")
        profile = self.season_weather_profile()
        harsh = profile["weather"] in {"Heavy Rain", "Thunderstorms", "Heavy Snow", "Snow", "Cold"}
        hp = 4 if harsh else 8
        stamina = 6 if harsh else 10
        with self.db.transaction() as con:
            con.execute("UPDATE character SET hp = MIN(max_hp, hp + ?), stamina = MIN(max_stamina, stamina + ?) WHERE id = ?", (hp, stamina, character.id))
            con.execute("UPDATE skills SET xp = xp + 4 WHERE character_id = ? AND skill_name = 'Survival'", (character.id,))
        self._advance_time(character.id, 360)
        return {"hp": hp, "stamina": stamina, "text": f"You establish a temporary camp and rest for six hours. The {profile['weather'].lower()} conditions affect the quality of the rest."}

    # ---------- Education ----------
    def has_certificate(self, certificate: str) -> bool:
        character = self.load_character()
        return self.db.fetchone("SELECT 1 FROM education_certificates WHERE character_id = ? AND certificate = ?", (character.id, certificate)) is not None

    def education_profile(self) -> dict:
        character = self.load_character()
        enrollment = self.db.fetchone("SELECT * FROM education_enrollment WHERE character_id = ?", (character.id,))
        certificates = [dict(r) for r in self.db.fetchall("SELECT * FROM education_certificates WHERE character_id = ? ORDER BY earned_day, certificate", (character.id,))]
        current = None
        if enrollment:
            program = EDUCATION_PROGRAMS.get(enrollment["program_key"])
            if program:
                current = {"key": program.key, "name": program.name, "sessions_completed": int(enrollment["sessions_completed"]), "sessions": program.sessions, "certificate": program.certificate}
        return {"current": current, "certificates": certificates}

    def enroll_education(self, program_key: str) -> None:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You cannot enroll while occupied with another activity.")
        if normalize_location_key(character.current_location) != "greybridge_city":
            raise RuntimeError("Enrollment is handled at Greybridge Community College.")
        if self.db.fetchone("SELECT 1 FROM education_enrollment WHERE character_id = ?", (character.id,)):
            raise RuntimeError("You are already enrolled in a program.")
        program = EDUCATION_PROGRAMS.get(program_key)
        if not program:
            raise ValueError("Unknown education program.")
        if character.cash < program.tuition:
            raise RuntimeError("You do not have enough cash for tuition.")
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? WHERE id = ?", (program.tuition, character.id))
            con.execute("INSERT INTO education_enrollment (character_id, program_key, sessions_completed, enrolled_day) VALUES (?, ?, 0, ?)", (character.id, program.key, character.day))

    def study_education(self) -> dict:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You cannot study while occupied with another activity.")
        if normalize_location_key(character.current_location) != "greybridge_city":
            raise RuntimeError("You need to be in Greybridge City to attend class.")
        row = self.db.fetchone("SELECT * FROM education_enrollment WHERE character_id = ?", (character.id,))
        if not row:
            raise RuntimeError("You are not enrolled in a program.")
        if character.stamina < 3:
            raise RuntimeError("You need at least 3 stamina to attend class.")
        program = EDUCATION_PROGRAMS[row["program_key"]]
        completed = int(row["sessions_completed"]) + 1
        finished = completed >= program.sessions
        with self.db.transaction() as con:
            con.execute("UPDATE character SET stamina = stamina - 3 WHERE id = ?", (character.id,))
            con.execute("UPDATE skills SET xp = xp + 4 WHERE character_id = ? AND skill_name = 'Education'", (character.id,))
            if finished:
                con.execute("INSERT OR IGNORE INTO education_certificates (character_id, certificate, earned_day) VALUES (?, ?, ?)", (character.id, program.certificate, character.day))
                con.execute("DELETE FROM education_enrollment WHERE character_id = ?", (character.id,))
            else:
                con.execute("UPDATE education_enrollment SET sessions_completed = ? WHERE character_id = ?", (completed, character.id))
        self._advance_time(character.id, 240)
        return {"finished": finished, "name": program.name, "completed": completed, "sessions": program.sessions, "certificate": program.certificate}

    # ---------- Pets / Children ----------
    def load_pets(self) -> list[dict]:
        character = self.load_character()
        rows = self.db.fetchall("SELECT * FROM pets WHERE character_id = ? ORDER BY id", (character.id,))
        result = []
        for row in rows:
            data = dict(row)
            definition = PETS.get(row["pet_key"])
            if definition:
                data["species"] = definition.name
                data["description"] = definition.description
            result.append(data)
        return result

    def adopt_pet(self, pet_key: str, name: str) -> None:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You cannot adopt a pet while occupied with another activity.")
        if normalize_location_key(character.current_location) != "millhaven":
            raise RuntimeError("Pet adoption is handled through the Millhaven Animal Shelter.")
        definition = PETS.get(pet_key)
        if not definition:
            raise ValueError("Unknown pet.")
        if character.cash < definition.adoption_fee:
            raise RuntimeError("You do not have enough cash for the adoption fee.")
        clean = " ".join(name.strip().split())[:24] or definition.name
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? WHERE id = ?", (definition.adoption_fee, character.id))
            con.execute("INSERT INTO pets (character_id, pet_key, name, adopted_day, bond, last_interaction_day) VALUES (?, ?, ?, ?, 0, 0)", (character.id, pet_key, clean, character.day))

    def interact_pet(self, pet_id: int) -> dict:
        character = self.load_character()
        pet = self.db.fetchone("SELECT * FROM pets WHERE id = ? AND character_id = ?", (pet_id, character.id))
        if not pet:
            raise RuntimeError("Pet not found.")
        if int(pet["last_interaction_day"]) == character.day:
            raise RuntimeError("You have already spent focused time with this pet today.")
        with self.db.transaction() as con:
            con.execute("UPDATE pets SET bond = MIN(100, bond + 3), last_interaction_day = ? WHERE id = ?", (character.day, pet_id))
            con.execute("UPDATE character SET stamina = MIN(max_stamina, stamina + 2) WHERE id = ?", (character.id,))
        self._advance_time(character.id, 30)
        return {"name": pet["name"], "bond": min(100, int(pet["bond"]) + 3)}

    def schooling_profile(self) -> list[dict]:
        household = self.get_household()
        results = []
        for child in household["children"]:
            row = self.db.fetchone("SELECT * FROM child_schooling WHERE child_id = ?", (child["id"],))
            item = dict(child)
            item["school"] = dict(row) if row else None
            results.append(item)
        return results

    def enroll_child_school(self, child_id: int) -> None:
        character = self.load_character()
        child = next((c for c in self.get_household()["children"] if int(c["id"]) == int(child_id)), None)
        if not child:
            raise RuntimeError("Child not found.")
        if child["stage"] not in {"Young Child", "Older Child"}:
            raise RuntimeError("This child is not yet school age.")
        self.db.execute("INSERT OR IGNORE INTO child_schooling (child_id, school_name, enrolled_day, attendance_days, last_processed_day) VALUES (?, ?, ?, 0, ?)", (child_id, SCHOOL_NAME, character.day, character.day))

    def _process_child_schooling(self, character_id: int, current_day: int) -> None:
        rows = self.db.fetchall("SELECT cs.* FROM child_schooling cs JOIN household_children hc ON hc.id = cs.child_id WHERE hc.character_id = ?", (character_id,))
        for row in rows:
            last = int(row["last_processed_day"])
            if current_day <= last:
                continue
            attendance = 0
            for day in range(last + 1, current_day + 1):
                if ((day - 1) % 7) < 5:
                    attendance += 1
            self.db.execute("UPDATE child_schooling SET attendance_days = attendance_days + ?, last_processed_day = ? WHERE child_id = ?", (attendance, current_day, row["child_id"]))

    # ---------- Court ----------
    def court_cases(self) -> list[dict]:
        character = self.load_character()
        return [dict(r) for r in self.db.fetchall("SELECT * FROM court_cases WHERE character_id = ? ORDER BY id DESC", (character.id,))]

    def attend_court(self, case_id: int) -> dict:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You cannot attend court while occupied with another activity.")
        if normalize_location_key(character.current_location) not in {"millhaven", "greybridge_city"}:
            raise RuntimeError("Court hearings are available in Millhaven or Greybridge City.")
        case = self.db.fetchone("SELECT * FROM court_cases WHERE id = ? AND character_id = ? AND status = 'Pending'", (case_id, character.id))
        if not case:
            raise RuntimeError("That case is not pending.")
        severity = int(case["severity"])
        speech = self.skill_level("Speech")
        roll = random.randint(1, 100) + speech * 3
        if roll >= 90 + severity:
            outcome = "Case dismissed after review."
            fine = 0
        elif roll >= 55:
            fine = min(character.cash, max(10, severity * 2))
            outcome = f"The court imposes an additional ${fine} fine and closes the case."
        else:
            fine = min(character.cash, max(20, severity * 4))
            outcome = f"The court imposes an additional ${fine} fine and records a conviction."
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? WHERE id = ?", (fine, character.id))
            con.execute("UPDATE court_cases SET status = 'Resolved', outcome = ?, additional_fine = ? WHERE id = ?", (outcome, fine, case_id))
        self._advance_time(character.id, 180)
        return {"outcome": outcome, "fine": fine}

    # ---------- Property portfolio / rentals ----------
    def owned_plots(self) -> list[dict]:
        character = self.load_character()
        self._process_rent_income(character.id, character.day)
        rows = self.db.fetchall("SELECT * FROM plots WHERE owner_character_id = ? ORDER BY id", (character.id,))
        result = []
        for row in rows:
            data = dict(row)
            data["is_home"] = int(row["id"]) == character.home_plot_id
            rental = self.db.fetchone("SELECT * FROM property_rentals WHERE plot_id = ?", (row["id"],))
            data["rental"] = dict(rental) if rental else None
            structures = self.db.fetchall("SELECT name FROM structures WHERE plot_id = ? ORDER BY id", (row["id"],))
            data["structures"] = [r["name"] for r in structures]
            result.append(data)
        return result

    def plots_for_sale(self) -> list[dict]:
        return [dict(r) for r in self.db.fetchall("SELECT * FROM plots WHERE owner_character_id IS NULL ORDER BY base_value, id LIMIT 30")]

    def buy_plot(self, plot_id: int) -> None:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You cannot purchase land while occupied with another activity.")
        plot = self.db.fetchone("SELECT * FROM plots WHERE id = ? AND owner_character_id IS NULL", (plot_id,))
        if not plot:
            raise RuntimeError("That plot is not available.")
        price = int(plot["base_value"])
        if character.cash < price:
            raise RuntimeError("You do not have enough cash to purchase this plot.")
        with self.db.transaction() as con:
            con.execute("UPDATE character SET cash = cash - ? WHERE id = ?", (price, character.id))
            con.execute("UPDATE plots SET owner_character_id = ? WHERE id = ?", (character.id, plot_id))

    def set_home_plot(self, plot_id: int) -> None:
        character = self.load_character()
        if self.is_busy():
            raise RuntimeError("You cannot move your primary residence while occupied with another activity.")
        plot = self.db.fetchone("SELECT * FROM plots WHERE id = ? AND owner_character_id = ?", (plot_id, character.id))
        if not plot:
            raise RuntimeError("You do not own that plot.")
        shelter = self.db.fetchone("SELECT 1 FROM structures WHERE plot_id = ? AND definition_key IN ('basic_tent','wooden_shack','small_cabin')", (plot_id,))
        if not shelter:
            now = datetime.now().isoformat(timespec="seconds")
            self.db.execute("INSERT INTO structures (plot_id, structure_type, name, condition_percent, definition_key, built_at) VALUES (?, 'shelter', 'Basic Tent', 100, 'basic_tent', ?)", (plot_id, now))
        self.db.execute("UPDATE character SET home_plot_id = ?, current_location = ? WHERE id = ?", (plot_id, f"plot:{plot_id}", character.id))

    def start_rental(self, plot_id: int) -> dict:
        character = self.load_character()
        if plot_id == character.home_plot_id:
            raise RuntimeError("You cannot rent out your primary residence.")
        plot = self.db.fetchone("SELECT * FROM plots WHERE id = ? AND owner_character_id = ?", (plot_id, character.id))
        if not plot:
            raise RuntimeError("You do not own that property.")
        permanent = self.db.fetchone("SELECT 1 FROM structures WHERE plot_id = ? AND definition_key IN ('wooden_shack','small_cabin')", (plot_id,))
        if not permanent:
            raise RuntimeError("The property needs a permanent dwelling before it can be rented.")
        existing = self.db.fetchone("SELECT 1 FROM property_rentals WHERE plot_id = ?", (plot_id,))
        if existing:
            raise RuntimeError("That property is already rented.")
        weekly = max(60, int(plot["base_value"] * 0.035))
        tenant = random.choice(("Avery Cole", "Morgan Reed", "Jordan Price", "Casey Ward", "Taylor Finch", "Riley Hart"))
        self.db.execute("INSERT INTO property_rentals (plot_id, character_id, tenant_name, weekly_rent, started_day, last_paid_day, lifetime_rent) VALUES (?, ?, ?, ?, ?, ?, 0)", (plot_id, character.id, tenant, weekly, character.day, character.day))
        return {"tenant": tenant, "weekly_rent": weekly}

    def end_rental(self, plot_id: int) -> None:
        character = self.load_character()
        self.db.execute("DELETE FROM property_rentals WHERE plot_id = ? AND character_id = ?", (plot_id, character.id))

    def _process_rent_income(self, character_id: int, current_day: int) -> None:
        rows = self.db.fetchall("SELECT * FROM property_rentals WHERE character_id = ?", (character_id,))
        total = 0
        for row in rows:
            weeks = max(0, (current_day - int(row["last_paid_day"])) // 7)
            if weeks:
                amount = weeks * int(row["weekly_rent"])
                total += amount
                self.db.execute("UPDATE property_rentals SET last_paid_day = last_paid_day + ?, lifetime_rent = lifetime_rent + ? WHERE plot_id = ?", (weeks * 7, amount, row["plot_id"]))
        if total:
            self.db.execute("UPDATE character SET cash = cash + ? WHERE id = ?", (total, character_id))

    # ---------- Time / Save ----------
    def _advance_time(self, character_id: int, game_minutes: int, current_location: str | None = None) -> None:
        row = self.db.fetchone("SELECT day, time_minutes FROM character WHERE id = ?", (character_id,))
        if row is None:
            return
        day, minutes = self._time_after(row["day"], row["time_minutes"], game_minutes)
        now = datetime.now().isoformat(timespec="seconds")
        loc = current_location
        if loc is None:
            current_row = self.db.fetchone("SELECT current_location FROM character WHERE id = ?", (character_id,))
            loc = current_row["current_location"] if current_row else "millhaven"
        normalized = normalize_location_key(loc)
        if normalized == "home":
            plot_row = self.db.fetchone("SELECT region_key FROM plots WHERE id = (SELECT home_plot_id FROM character WHERE id = ?)", (character_id,))
            region_key = plot_row["region_key"] if plot_row else "millhaven_county"
        else:
            region_key = region_key_for_location(normalized)
        weather = weather_for_day(day, region_key)
        if current_location is None:
            self.db.execute(
                "UPDATE character SET day = ?, time_minutes = ?, weather = ?, updated_at = ? WHERE id = ?",
                (day, minutes, weather, now, character_id),
            )
        else:
            self.db.execute(
                "UPDATE character SET day = ?, time_minutes = ?, current_location = ?, weather = ?, updated_at = ? WHERE id = ?",
                (day, minutes, current_location, weather, now, character_id),
            )
        self._process_rent_income(character_id, day)
        self._process_child_schooling(character_id, day)

    @staticmethod
    def _time_after(day: int, minutes: int, amount: int) -> tuple[int, int]:
        total = minutes + amount
        return day + total // (24 * 60), total % (24 * 60)

    def save_now(self) -> None:
        character = self.load_character()
        self.db.execute(
            "UPDATE character SET updated_at = ? WHERE id = ?",
            (datetime.now().isoformat(timespec="seconds"), character.id),
        )

    @staticmethod
    def format_time(minutes: int) -> str:
        minutes %= 24 * 60
        hour_24, minute = divmod(minutes, 60)
        suffix = "AM" if hour_24 < 12 else "PM"
        hour_12 = hour_24 % 12 or 12
        return f"{hour_12}:{minute:02d} {suffix}"
