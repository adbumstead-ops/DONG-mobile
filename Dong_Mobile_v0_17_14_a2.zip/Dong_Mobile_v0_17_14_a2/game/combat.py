from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Move:
    key: str
    name: str
    min_damage: int
    max_damage: int
    accuracy: int
    description: str


@dataclass(frozen=True)
class Weapon:
    key: str
    name: str
    description: str
    moves: tuple[Move, ...]


@dataclass(frozen=True)
class HealingItem:
    name: str
    heal: int
    description: str


@dataclass(frozen=True)
class Enemy:
    key: str
    name: str
    max_hp: int
    min_damage: int
    max_damage: int
    accuracy: int
    combat_xp: int
    cash_min: int
    cash_max: int
    loot: tuple[tuple[str, int, str], ...]
    description: str


WEAPONS = {
    "Old Shovel": Weapon(
        "old_shovel",
        "Old Shovel",
        "A heavy steel shovel with a worn wooden handle and a scratched blade.",
        (
            Move("shovel_smack", "Shovel Strike", 3, 6, 90, "A direct strike with the flat or edge of the shovel."),
            Move("heavy_swing", "Heavy Swing", 5, 9, 72, "A slower two-handed swing with greater force."),
        ),
    ),
    "Pocket Knife": Weapon(
        "pocket_knife",
        "Pocket Knife",
        "A small folding knife with a short steel blade.",
        (
            Move("quick_stab", "Quick Stab", 3, 5, 96, "A fast thrust at close range."),
            Move("deep_cut", "Deep Cut", 5, 8, 78, "A committed cutting strike."),
        ),
    ),
    "Rusty Hatchet": Weapon(
        "rusty_hatchet",
        "Rusty Hatchet",
        "An old woodcutting hatchet with a rusted steel head and worn handle.",
        (
            Move("chop", "Chop", 4, 7, 90, "A short chopping strike."),
            Move("overhead_chop", "Overhead Chop", 7, 11, 68, "A powerful overhead swing that is harder to land."),
        ),
    ),
}

HEALING_ITEMS = {
    "Granola Bar": HealingItem("Granola Bar", 4, "Restores 4 HP."),
    "Bandage": HealingItem("Bandage", 7, "Restores 7 HP."),
}

ENEMIES = {
    "wild_dog": Enemy(
        "wild_dog",
        "Wild Dog",
        12,
        2,
        4,
        86,
        3,
        0,
        0,
        (
            ("Dog Collar", 55, "A worn collar with no readable tag."),
            ("Scrap Leather", 45, "A rough piece of usable leather."),
        ),
        "A lean dog steps onto the trail, lowers its head, and begins to growl.",
    ),
    "feral_raccoon": Enemy(
        "feral_raccoon",
        "Feral Raccoon",
        9,
        1,
        3,
        88,
        2,
        0,
        0,
        (
            ("Shiny Bottle Cap", 60, "A clean metal bottle cap caught in the animal's fur."),
            ("Torn Cloth", 35, "A dirty strip of cloth snagged in its claws."),
        ),
        "A large raccoon bursts from the brush and turns toward you with its teeth exposed.",
    ),
    "knoblin_runt": Enemy(
        "knoblin_runt",
        "Knoblin Runt",
        15,
        2,
        5,
        82,
        4,
        1,
        4,
        (
            ("Bent Coin", 65, "A badly stamped coin of unclear origin."),
            ("Rusty Hatchet", 12, WEAPONS["Rusty Hatchet"].description),
        ),
        "A small green humanoid in a stained vest steps from behind a tree and raises a crude weapon.",
    ),
    "redwater_brawler": Enemy(
        "redwater_brawler",
        "Fight Club Brawler",
        18,
        3,
        6,
        84,
        6,
        8,
        14,
        (
            ("Hand Wraps", 35, "A used pair of cloth hand wraps from the Fight Club ring."),
        ),
        "A local fighter steps into the ring, raises both hands, and waits for the opening bell.",
    ),
    "club_veteran": Enemy(
        "club_veteran",
        "Fight Club Veteran",
        26,
        4,
        7,
        86,
        9,
        14,
        24,
        (
            ("Fight Purse Token", 30, "A stamped brass token issued by the Fight Club."),
        ),
        "An experienced fighter enters the ring and takes position beneath the overhead lights.",
    ),
    "cave_crawler": Enemy(
        "cave_crawler",
        "Cave Crawler",
        17,
        2,
        5,
        86,
        6,
        2,
        6,
        (
            ("Crawler Carapace", 45, "A hard section of dark shell taken from a cave creature."),
        ),
        "A low, many-legged creature moves out from between the stones and closes across the chamber floor.",
    ),
    "dungeon_knoblin": Enemy(
        "dungeon_knoblin",
        "Dungeon Knoblin",
        23,
        3,
        7,
        84,
        8,
        4,
        10,
        (
            ("Dungeon Scrap", 55, "A corroded piece of metal carried by a creature in the lower tunnels."),
        ),
        "A stocky knoblin emerges from the passage with a crude weapon and blocks the way forward.",
    ),
    "tunnel_horror": Enemy(
        "tunnel_horror",
        "Tunnel Horror",
        34,
        5,
        9,
        80,
        13,
        8,
        18,
        (
            ("Horror Tooth", 50, "A heavy curved tooth recovered from a large underground creature."),
        ),
        "A large pale creature unfolds from the darkness at the far end of the chamber and advances through the tunnel.",
    ),
}


def weapon_moves(weapon_name: str) -> tuple[Move, ...]:
    weapon = WEAPONS.get(weapon_name) or WEAPONS["Old Shovel"]
    return weapon.moves
