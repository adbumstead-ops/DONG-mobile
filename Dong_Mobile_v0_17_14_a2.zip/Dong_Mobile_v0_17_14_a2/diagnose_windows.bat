@echo off
setlocal
cd /d "%~dp0"
set "OUT=%~dp0dong_windows_diagnostics.txt"
>"%OUT%" echo Dong Windows diagnostics
>>"%OUT%" echo Date: %DATE% %TIME%
>>"%OUT%" echo Folder: %CD%
>>"%OUT%" echo.
>>"%OUT%" echo === Windows ===
ver >>"%OUT%" 2>&1
>>"%OUT%" echo.
>>"%OUT%" echo === py ===
where py >>"%OUT%" 2>&1
py --version >>"%OUT%" 2>&1
py --list >>"%OUT%" 2>&1
>>"%OUT%" echo.
>>"%OUT%" echo === python ===
where python >>"%OUT%" 2>&1
python --version >>"%OUT%" 2>&1
>>"%OUT%" echo.
>>"%OUT%" echo === pymanager ===
where pymanager >>"%OUT%" 2>&1
pymanager --version >>"%OUT%" 2>&1
>>"%OUT%" echo.
>>"%OUT%" echo === winget ===
where winget >>"%OUT%" 2>&1
winget --version >>"%OUT%" 2>&1
>>"%OUT%" echo.
>>"%OUT%" echo === Local Dong environment ===
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" --version >>"%OUT%" 2>&1
    ".venv\Scripts\python.exe" -c "import PySide6; print('PySide6', PySide6.__version__)" >>"%OUT%" 2>&1
) else (
    >>"%OUT%" echo No .venv found.
)
echo Diagnostics saved to:
echo %OUT%
pause
