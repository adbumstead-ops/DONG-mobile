# DONG Android test fork

This fork is a standalone single-player Android target. It does **not** use a browser, PWA, WebView, HTML, or JavaScript wrapper.

## What changed in mobile alpha 2

- Keeps the existing Python/PySide6 game engine and SQLite save format.
- Uses Qt for Python's native Android deployment path.
- Stores `game.db` in Android app-private writable storage.
- Removes desktop-only minimum window sizes on Android.
- Replaces the bottom touch navigation with a collapsible left-side menu so the game content can use the full phone height.
- Adds a MENU/CLOSE button in the top location header.
- Closes the drawer after navigation or saving, and lets Android Back close it first.
- Makes main actions and navigation easier to tap.
- Converts hub, skill, and activity grids to one column on phones.
- Makes hover-description controls respond to touch presses.
- Keeps the desktop layout unchanged when run on Windows/Linux.

## Packaging target

Use Qt for Python's `pyside6-android-deploy` from Linux or macOS to create an APK. The build host needs the Android SDK/NDK and the matching PySide6/Shiboken6 Android wheels.
