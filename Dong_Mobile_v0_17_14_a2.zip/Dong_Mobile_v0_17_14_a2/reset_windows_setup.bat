@echo off
setlocal
cd /d "%~dp0"
echo This removes only Dong's local .venv setup.
echo It does NOT delete your save in data\game.db.
echo.
if exist ".venv" (
    rmdir /s /q ".venv"
    echo Dong's Windows environment was reset.
) else (
    echo No local environment was found.
)
echo Run run_windows.bat again to rebuild it.
pause
