from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import QStandardPaths


IS_ANDROID = sys.platform == "android" or hasattr(sys, "getandroidapilevel")


def database_path(app_dir: Path) -> Path:
    """Return a writable SQLite path. Android APK contents are read-only."""
    if IS_ANDROID:
        base = QStandardPaths.writableLocation(QStandardPaths.AppDataLocation)
        data_dir = Path(base) if base else app_dir / "data"
    else:
        data_dir = app_dir / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir / "game.db"


def show_app_window(window) -> None:
    """Use the phone screen without requiring desktop-sized geometry."""
    if IS_ANDROID:
        window.showMaximized()
    else:
        window.show()
