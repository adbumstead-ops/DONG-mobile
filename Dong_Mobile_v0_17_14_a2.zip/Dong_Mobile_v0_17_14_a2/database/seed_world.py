from __future__ import annotations

import random

from database.database import Database


# Starter plots remain broadly rural and comparable. The remaining forty plots are spread across
# the larger v0.15 world so the permanent 100-plot system already has regional geography.
STARTER_AREAS = [
    ("Dong", "millhaven_county"),
    ("Dong", "millhaven_county"),
    ("Dong", "lake_mercy_district"),
    ("Dong", "hollow_creek_valley"),
]

EXPANSION_AREAS = [
    ("Dong", "lake_mercy_district"),
    ("Dong", "redwater_district"),
    ("Dong", "greybridge_metro"),
    ("Dong", "hollow_creek_valley"),
    ("Dong", "pine_ridge_highlands"),
    ("Dong", "westhaven_coast"),
]

TERRAINS = [
    "Open Field",
    "Pine Forest",
    "Mixed Woodland",
    "Grassy Clearing",
    "Lakeside Woodland",
    "Rolling Field",
    "Creekside Forest",
    "Rocky Meadow",
]

FEATURES = [
    "Old oak tree",
    "Wild berry patch",
    "Large flat clearing",
    "Small rocky rise",
    "Old fence line",
    "Dense tree line",
    "Patch of wildflowers",
    "Weathered stone wall",
    "Fallen cedar",
    "Open southern exposure",
]

ROAD_ACCESS = [
    "Paved-road access",
    "Dirt-road access",
    "Gravel-road access",
    "Narrow lane access",
]

WATER_ACCESS = [None, None, None, "Shallow creek", "Small pond", "Lake access"]
SIZES = ["Small", "Small", "Medium", "Medium", "Large"]


def seed_world(db: Database) -> None:
    existing = db.fetchone("SELECT COUNT(*) AS count FROM plots")
    if existing and existing["count"] >= 100:
        return

    rng = random.Random(10292026)
    rows = []
    for plot_id in range(1, 101):
        starter = 1 if plot_id <= 60 else 0
        area, region_key = rng.choice(STARTER_AREAS if starter else EXPANSION_AREAS)
        terrain = rng.choice(TERRAINS)
        size = rng.choice(SIZES if not starter else ["Small", "Small", "Medium"])
        feature = rng.choice(FEATURES)
        road = rng.choice(ROAD_ACCESS)
        water = rng.choice(WATER_ACCESS)
        base_value = rng.randint(1100, 1800) if starter else rng.randint(1800, 16000)
        rows.append((
            plot_id, f"PLOT-{plot_id:03d}", area, region_key, terrain, size, feature,
            road, water, starter, base_value,
        ))

    with db.transaction() as con:
        con.execute("DELETE FROM plots WHERE id BETWEEN 1 AND 100")
        con.executemany(
            """
            INSERT INTO plots (
                id, code, area, region_key, terrain, size, natural_feature,
                road_access, water_access, starter_eligible, base_value
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            rows,
        )
