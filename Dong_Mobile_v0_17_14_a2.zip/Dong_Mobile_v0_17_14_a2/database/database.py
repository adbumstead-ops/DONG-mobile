from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
import sqlite3
from typing import Iterable, Iterator


class Database:
    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.path)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys = ON")
        return con

    def _column_names(self, con: sqlite3.Connection, table: str) -> set[str]:
        return {row[1] for row in con.execute(f"PRAGMA table_info({table})")}

    def initialize(self) -> None:
        with self.connect() as con:
            con.executescript(
                """
                CREATE TABLE IF NOT EXISTS plots (
                    id INTEGER PRIMARY KEY,
                    code TEXT NOT NULL UNIQUE,
                    area TEXT NOT NULL,
                    region_key TEXT NOT NULL DEFAULT 'millhaven_county',
                    terrain TEXT NOT NULL,
                    size TEXT NOT NULL,
                    natural_feature TEXT,
                    road_access TEXT,
                    water_access TEXT,
                    starter_eligible INTEGER NOT NULL DEFAULT 0,
                    base_value INTEGER NOT NULL,
                    owner_character_id INTEGER
                );

                CREATE TABLE IF NOT EXISTS character (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    hp INTEGER NOT NULL,
                    max_hp INTEGER NOT NULL,
                    stamina INTEGER NOT NULL,
                    max_stamina INTEGER NOT NULL,
                    cash INTEGER NOT NULL,
                    home_plot_id INTEGER NOT NULL,
                    current_location TEXT NOT NULL,
                    day INTEGER NOT NULL,
                    time_minutes INTEGER NOT NULL,
                    weather TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY(home_plot_id) REFERENCES plots(id)
                );

                CREATE TABLE IF NOT EXISTS structures (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    plot_id INTEGER NOT NULL,
                    structure_type TEXT NOT NULL,
                    name TEXT NOT NULL,
                    condition_percent INTEGER NOT NULL DEFAULT 100,
                    FOREIGN KEY(plot_id) REFERENCES plots(id)
                );

                CREATE TABLE IF NOT EXISTS inventory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    character_id INTEGER NOT NULL,
                    item_name TEXT NOT NULL,
                    quantity INTEGER NOT NULL DEFAULT 1,
                    description TEXT NOT NULL DEFAULT '',
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS skills (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    character_id INTEGER NOT NULL,
                    skill_name TEXT NOT NULL,
                    xp INTEGER NOT NULL DEFAULT 0,
                    UNIQUE(character_id, skill_name),
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS known_locations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    character_id INTEGER NOT NULL,
                    location_key TEXT NOT NULL,
                    UNIQUE(character_id, location_key),
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS regional_reputation (
                    character_id INTEGER NOT NULL,
                    region_key TEXT NOT NULL,
                    reputation INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY(character_id, region_key),
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS travel_state (
                    character_id INTEGER PRIMARY KEY,
                    origin_key TEXT NOT NULL,
                    destination_key TEXT NOT NULL,
                    method TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    arrives_at TEXT NOT NULL,
                    duration_seconds INTEGER NOT NULL,
                    game_minutes INTEGER NOT NULL,
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS vehicles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    character_id INTEGER NOT NULL,
                    vehicle_key TEXT NOT NULL,
                    current_location TEXT NOT NULL DEFAULT 'millhaven',
                    fuel INTEGER NOT NULL DEFAULT 0,
                    condition_percent INTEGER NOT NULL DEFAULT 100,
                    purchased_at TEXT NOT NULL,
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS vehicle_storage (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    vehicle_id INTEGER NOT NULL,
                    item_name TEXT NOT NULL,
                    quantity INTEGER NOT NULL DEFAULT 1,
                    description TEXT NOT NULL DEFAULT '',
                    UNIQUE(vehicle_id, item_name),
                    FOREIGN KEY(vehicle_id) REFERENCES vehicles(id)
                );

                CREATE TABLE IF NOT EXISTS job_state (
                    character_id INTEGER PRIMARY KEY,
                    job_key TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    completes_at TEXT NOT NULL,
                    duration_seconds INTEGER NOT NULL,
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS combat_state (
                    character_id INTEGER PRIMARY KEY,
                    enemy_key TEXT NOT NULL,
                    enemy_hp INTEGER NOT NULL,
                    enemy_max_hp INTEGER NOT NULL,
                    guard_amount INTEGER NOT NULL DEFAULT 0,
                    log_text TEXT NOT NULL DEFAULT '',
                    started_at TEXT NOT NULL,
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS construction_state (
                    character_id INTEGER PRIMARY KEY,
                    plot_id INTEGER NOT NULL,
                    structure_key TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    completes_at TEXT NOT NULL,
                    duration_seconds INTEGER NOT NULL,
                    game_minutes INTEGER NOT NULL,
                    FOREIGN KEY(character_id) REFERENCES character(id),
                    FOREIGN KEY(plot_id) REFERENCES plots(id)
                );

                CREATE TABLE IF NOT EXISTS furniture (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    structure_id INTEGER NOT NULL,
                    room_name TEXT NOT NULL,
                    item_name TEXT NOT NULL,
                    FOREIGN KEY(structure_id) REFERENCES structures(id)
                );

                CREATE TABLE IF NOT EXISTS property_storage (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    plot_id INTEGER NOT NULL,
                    item_name TEXT NOT NULL,
                    quantity INTEGER NOT NULL DEFAULT 1,
                    description TEXT NOT NULL DEFAULT '',
                    UNIQUE(plot_id, item_name),
                    FOREIGN KEY(plot_id) REFERENCES plots(id)
                );

                CREATE TABLE IF NOT EXISTS farm_crops (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    plot_id INTEGER NOT NULL,
                    crop_key TEXT NOT NULL,
                    planted_at TEXT NOT NULL,
                    ready_at TEXT NOT NULL,
                    watered INTEGER NOT NULL DEFAULT 0,
                    FOREIGN KEY(plot_id) REFERENCES plots(id)
                );

                CREATE TABLE IF NOT EXISTS farm_feed (
                    plot_id INTEGER PRIMARY KEY,
                    quantity INTEGER NOT NULL DEFAULT 0,
                    FOREIGN KEY(plot_id) REFERENCES plots(id)
                );

                CREATE TABLE IF NOT EXISTS farm_animals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    plot_id INTEGER NOT NULL,
                    animal_key TEXT NOT NULL,
                    purchased_at TEXT NOT NULL,
                    next_output_at TEXT NOT NULL,
                    stored_output INTEGER NOT NULL DEFAULT 0,
                    FOREIGN KEY(plot_id) REFERENCES plots(id)
                );

                CREATE TABLE IF NOT EXISTS businesses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    plot_id INTEGER NOT NULL,
                    structure_id INTEGER NOT NULL UNIQUE,
                    business_key TEXT NOT NULL,
                    is_open INTEGER NOT NULL DEFAULT 0,
                    price_tier TEXT NOT NULL DEFAULT 'standard',
                    till INTEGER NOT NULL DEFAULT 0,
                    lifetime_revenue INTEGER NOT NULL DEFAULT 0,
                    customers_served INTEGER NOT NULL DEFAULT 0,
                    last_processed_at TEXT NOT NULL,
                    FOREIGN KEY(plot_id) REFERENCES plots(id),
                    FOREIGN KEY(structure_id) REFERENCES structures(id)
                );

                CREATE TABLE IF NOT EXISTS business_stock (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    business_id INTEGER NOT NULL,
                    item_name TEXT NOT NULL,
                    quantity INTEGER NOT NULL DEFAULT 0,
                    base_price INTEGER NOT NULL,
                    description TEXT NOT NULL DEFAULT '',
                    UNIQUE(business_id, item_name),
                    FOREIGN KEY(business_id) REFERENCES businesses(id)
                );

                CREATE TABLE IF NOT EXISTS npc_relationships (
                    character_id INTEGER NOT NULL,
                    npc_key TEXT NOT NULL,
                    friendship INTEGER NOT NULL DEFAULT 0,
                    talk_count INTEGER NOT NULL DEFAULT 0,
                    last_talk_day INTEGER,
                    romance INTEGER NOT NULL DEFAULT 0,
                    romantic_status TEXT NOT NULL DEFAULT 'none',
                    last_date_day INTEGER,
                    last_intimacy_day INTEGER,
                    PRIMARY KEY(character_id, npc_key),
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS npc_favors (
                    character_id INTEGER NOT NULL,
                    favor_key TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'accepted',
                    accepted_day INTEGER NOT NULL,
                    completed_day INTEGER,
                    PRIMARY KEY(character_id, favor_key),
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS mail (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    character_id INTEGER NOT NULL,
                    mail_key TEXT NOT NULL,
                    sender TEXT NOT NULL,
                    subject TEXT NOT NULL,
                    body TEXT NOT NULL,
                    sent_day INTEGER NOT NULL,
                    is_read INTEGER NOT NULL DEFAULT 0,
                    UNIQUE(character_id, mail_key),
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS daily_actions (
                    character_id INTEGER NOT NULL,
                    action_key TEXT NOT NULL,
                    day INTEGER NOT NULL,
                    PRIMARY KEY(character_id, action_key),
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS business_visits (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    business_id INTEGER NOT NULL,
                    npc_key TEXT NOT NULL,
                    item_name TEXT NOT NULL,
                    sale_price INTEGER NOT NULL,
                    visited_at TEXT NOT NULL,
                    FOREIGN KEY(business_id) REFERENCES businesses(id)
                );

                CREATE TABLE IF NOT EXISTS crime_profile (
                    character_id INTEGER PRIMARY KEY,
                    heat INTEGER NOT NULL DEFAULT 0,
                    crimes_committed INTEGER NOT NULL DEFAULT 0,
                    arrests INTEGER NOT NULL DEFAULT 0,
                    murders INTEGER NOT NULL DEFAULT 0,
                    mask_worn INTEGER NOT NULL DEFAULT 0,
                    last_heat_day INTEGER NOT NULL DEFAULT 1,
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS crime_record (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    character_id INTEGER NOT NULL,
                    day INTEGER NOT NULL,
                    crime_name TEXT NOT NULL,
                    outcome TEXT NOT NULL,
                    cash_change INTEGER NOT NULL DEFAULT 0,
                    heat_change INTEGER NOT NULL DEFAULT 0,
                    arrested INTEGER NOT NULL DEFAULT 0,
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS jail_state (
                    character_id INTEGER PRIMARY KEY,
                    reason TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    release_at TEXT NOT NULL,
                    duration_seconds INTEGER NOT NULL,
                    fine INTEGER NOT NULL DEFAULT 0,
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS household (
                    character_id INTEGER PRIMARY KEY,
                    spouse_npc_key TEXT,
                    married_day INTEGER,
                    expecting_child INTEGER NOT NULL DEFAULT 0,
                    child_due_day INTEGER,
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS household_children (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    character_id INTEGER NOT NULL,
                    name TEXT NOT NULL,
                    birth_day INTEGER NOT NULL,
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS vice_profile (
                    character_id INTEGER PRIMARY KEY,
                    alcohol_dependence INTEGER NOT NULL DEFAULT 0,
                    drug_dependence INTEGER NOT NULL DEFAULT 0,
                    gambling_dependence INTEGER NOT NULL DEFAULT 0,
                    intoxication INTEGER NOT NULL DEFAULT 0,
                    drug_effect INTEGER NOT NULL DEFAULT 0,
                    last_alcohol_day INTEGER,
                    last_drug_day INTEGER,
                    last_gamble_day INTEGER,
                    last_processed_day INTEGER NOT NULL DEFAULT 1,
                    last_processed_minute INTEGER NOT NULL DEFAULT 480,
                    last_withdrawal_day INTEGER NOT NULL DEFAULT 0,
                    last_gambling_urge_day INTEGER NOT NULL DEFAULT 0,
                    dealer_reputation INTEGER NOT NULL DEFAULT 0,
                    dealer_started INTEGER NOT NULL DEFAULT 0,
                    casino_wins INTEGER NOT NULL DEFAULT 0,
                    casino_losses INTEGER NOT NULL DEFAULT 0,
                    casino_net INTEGER NOT NULL DEFAULT 0,
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS vice_record (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    character_id INTEGER NOT NULL,
                    day INTEGER NOT NULL,
                    event_type TEXT NOT NULL,
                    description TEXT NOT NULL,
                    cash_change INTEGER NOT NULL DEFAULT 0,
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS blackjack_state (
                    character_id INTEGER PRIMARY KEY,
                    wager INTEGER NOT NULL,
                    player_cards TEXT NOT NULL,
                    dealer_cards TEXT NOT NULL,
                    deck_cards TEXT NOT NULL,
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );
                """
            )

            con.executescript(
                """
                CREATE TABLE IF NOT EXISTS career_employment (
                    character_id INTEGER PRIMARY KEY,
                    career_key TEXT NOT NULL,
                    hired_day INTEGER NOT NULL,
                    last_checked_day INTEGER NOT NULL,
                    reliability INTEGER NOT NULL DEFAULT 100,
                    missed_shifts INTEGER NOT NULL DEFAULT 0,
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS career_progress (
                    character_id INTEGER NOT NULL,
                    career_key TEXT NOT NULL,
                    shifts_worked INTEGER NOT NULL DEFAULT 0,
                    career_xp INTEGER NOT NULL DEFAULT 0,
                    best_rank TEXT NOT NULL DEFAULT 'Probationary',
                    PRIMARY KEY(character_id, career_key),
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS career_shift_state (
                    character_id INTEGER PRIMARY KEY,
                    career_key TEXT NOT NULL,
                    shift_day INTEGER NOT NULL,
                    started_at TEXT NOT NULL,
                    completes_at TEXT NOT NULL,
                    duration_seconds INTEGER NOT NULL,
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS career_shift_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    character_id INTEGER NOT NULL,
                    career_key TEXT NOT NULL,
                    shift_day INTEGER NOT NULL,
                    pay INTEGER NOT NULL,
                    rank_name TEXT NOT NULL,
                    UNIQUE(character_id, career_key, shift_day),
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS career_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    character_id INTEGER NOT NULL,
                    career_key TEXT NOT NULL,
                    day INTEGER NOT NULL,
                    event_type TEXT NOT NULL,
                    description TEXT NOT NULL,
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );
                """
            )

            con.executescript(
                """
                CREATE TABLE IF NOT EXISTS education_enrollment (
                    character_id INTEGER PRIMARY KEY,
                    program_key TEXT NOT NULL,
                    sessions_completed INTEGER NOT NULL DEFAULT 0,
                    enrolled_day INTEGER NOT NULL,
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS education_certificates (
                    character_id INTEGER NOT NULL,
                    certificate TEXT NOT NULL,
                    earned_day INTEGER NOT NULL,
                    PRIMARY KEY(character_id, certificate),
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS pets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    character_id INTEGER NOT NULL,
                    pet_key TEXT NOT NULL,
                    name TEXT NOT NULL,
                    adopted_day INTEGER NOT NULL,
                    bond INTEGER NOT NULL DEFAULT 0,
                    last_interaction_day INTEGER NOT NULL DEFAULT 0,
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS child_schooling (
                    child_id INTEGER PRIMARY KEY,
                    school_name TEXT NOT NULL,
                    enrolled_day INTEGER NOT NULL,
                    attendance_days INTEGER NOT NULL DEFAULT 0,
                    last_processed_day INTEGER NOT NULL DEFAULT 0,
                    FOREIGN KEY(child_id) REFERENCES household_children(id)
                );

                CREATE TABLE IF NOT EXISTS court_cases (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    character_id INTEGER NOT NULL,
                    charge TEXT NOT NULL,
                    filed_day INTEGER NOT NULL,
                    severity INTEGER NOT NULL,
                    status TEXT NOT NULL DEFAULT 'Pending',
                    outcome TEXT NOT NULL DEFAULT '',
                    additional_fine INTEGER NOT NULL DEFAULT 0,
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );

                CREATE TABLE IF NOT EXISTS property_rentals (
                    plot_id INTEGER PRIMARY KEY,
                    character_id INTEGER NOT NULL,
                    tenant_name TEXT NOT NULL,
                    weekly_rent INTEGER NOT NULL,
                    started_day INTEGER NOT NULL,
                    last_paid_day INTEGER NOT NULL,
                    lifetime_rent INTEGER NOT NULL DEFAULT 0,
                    FOREIGN KEY(plot_id) REFERENCES plots(id),
                    FOREIGN KEY(character_id) REFERENCES character(id)
                );
                """
            )

            # Lightweight migrations for saves from earlier prototypes.
            character_columns = self._column_names(con, "character")
            if "stamina_updated_at" not in character_columns:
                con.execute("ALTER TABLE character ADD COLUMN stamina_updated_at TEXT")
                con.execute(
                    "UPDATE character SET stamina_updated_at = COALESCE(updated_at, created_at) "
                    "WHERE stamina_updated_at IS NULL"
                )
            if "equipped_weapon" not in character_columns:
                con.execute("ALTER TABLE character ADD COLUMN equipped_weapon TEXT")
                con.execute(
                    "UPDATE character SET equipped_weapon = 'Old Shovel' "
                    "WHERE equipped_weapon IS NULL OR equipped_weapon = ''"
                )

            plot_columns = self._column_names(con, "plots")
            if "region_key" not in plot_columns:
                con.execute("ALTER TABLE plots ADD COLUMN region_key TEXT NOT NULL DEFAULT 'millhaven_county'")
                con.execute("UPDATE plots SET region_key = CASE WHEN area LIKE 'Lake Mercy%' THEN 'lake_mercy_district' WHEN area LIKE 'Hollow Creek%' THEN 'hollow_creek_valley' WHEN area LIKE 'Pine Ridge%' THEN 'pine_ridge_highlands' ELSE 'millhaven_county' END")

            relationship_columns = self._column_names(con, "npc_relationships")
            if "romance" not in relationship_columns:
                con.execute("ALTER TABLE npc_relationships ADD COLUMN romance INTEGER NOT NULL DEFAULT 0")
            if "romantic_status" not in relationship_columns:
                con.execute("ALTER TABLE npc_relationships ADD COLUMN romantic_status TEXT NOT NULL DEFAULT 'none'")
            if "last_date_day" not in relationship_columns:
                con.execute("ALTER TABLE npc_relationships ADD COLUMN last_date_day INTEGER")
            if "last_intimacy_day" not in relationship_columns:
                con.execute("ALTER TABLE npc_relationships ADD COLUMN last_intimacy_day INTEGER")

            # v0.17.13: Dong is one massive city. Old area labels are retained only
            # through hidden region keys; player-facing plot area names collapse to Dong.
            con.execute("UPDATE plots SET area = 'Dong' WHERE area <> 'Dong'")

            farm_animal_columns = self._column_names(con, "farm_animals")
            if "current_location" not in farm_animal_columns:
                con.execute("ALTER TABLE farm_animals ADD COLUMN current_location TEXT")
                con.execute("UPDATE farm_animals SET current_location = 'home' WHERE current_location IS NULL")

            travel_columns = self._column_names(con, "travel_state")
            if "mount_animal_id" not in travel_columns:
                con.execute("ALTER TABLE travel_state ADD COLUMN mount_animal_id INTEGER")
            if "vehicle_id" not in travel_columns:
                con.execute("ALTER TABLE travel_state ADD COLUMN vehicle_id INTEGER")
            if "fuel_used" not in travel_columns:
                con.execute("ALTER TABLE travel_state ADD COLUMN fuel_used INTEGER NOT NULL DEFAULT 0")
            if "condition_used" not in travel_columns:
                con.execute("ALTER TABLE travel_state ADD COLUMN condition_used INTEGER NOT NULL DEFAULT 0")


            vice_columns = self._column_names(con, "vice_profile")
            if "gambling_dependence" not in vice_columns:
                con.execute("ALTER TABLE vice_profile ADD COLUMN gambling_dependence INTEGER NOT NULL DEFAULT 0")
            if "last_gamble_day" not in vice_columns:
                con.execute("ALTER TABLE vice_profile ADD COLUMN last_gamble_day INTEGER")
            if "last_gambling_urge_day" not in vice_columns:
                con.execute("ALTER TABLE vice_profile ADD COLUMN last_gambling_urge_day INTEGER NOT NULL DEFAULT 0")

            structure_columns = self._column_names(con, "structures")
            if "definition_key" not in structure_columns:
                con.execute("ALTER TABLE structures ADD COLUMN definition_key TEXT")
                con.execute(
                    "UPDATE structures SET definition_key = 'basic_tent' "
                    "WHERE name = 'Basic Tent' AND (definition_key IS NULL OR definition_key = '')"
                )
            if "built_at" not in structure_columns:
                con.execute("ALTER TABLE structures ADD COLUMN built_at TEXT")
                con.execute(
                    "UPDATE structures SET built_at = datetime('now') WHERE built_at IS NULL"
                )

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        con = self.connect()
        try:
            yield con
            con.commit()
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()

    def execute(self, sql: str, params: Iterable = ()) -> None:
        with self.connect() as con:
            con.execute(sql, tuple(params))
            con.commit()

    def fetchone(self, sql: str, params: Iterable = ()) -> sqlite3.Row | None:
        with self.connect() as con:
            return con.execute(sql, tuple(params)).fetchone()

    def fetchall(self, sql: str, params: Iterable = ()) -> list[sqlite3.Row]:
        with self.connect() as con:
            return con.execute(sql, tuple(params)).fetchall()
