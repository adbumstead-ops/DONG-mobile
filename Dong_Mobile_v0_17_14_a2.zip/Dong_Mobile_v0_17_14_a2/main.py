from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtWidgets import QApplication

from database.database import Database
from database.seed_world import seed_world
from game.game_state import GameState
from ui.main_menu import MainMenu
from platform_support import database_path, show_app_window


APP_DIR = Path(__file__).resolve().parent


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("Dong")
    app.setApplicationDisplayName("Dong")
    app.setOrganizationName("Dong")

    database = Database(database_path(APP_DIR))
    database.initialize()
    seed_world(database)

    game_state = GameState(database)
    window = MainMenu(game_state)
    show_app_window(window)

    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
