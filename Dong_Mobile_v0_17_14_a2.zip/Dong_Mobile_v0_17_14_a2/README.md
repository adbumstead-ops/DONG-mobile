# Dong v0.17.14 — Character Life Sheet

Dong v0.17.7 keeps every gameplay system from v0.17.5 and combines the old Character, Inventory, and Skills pages into one unified character sheet. The interface remains deliberately simple and text-driven, but the hierarchy, spacing, status information, typography, and hub navigation are now cleaner and easier to scan. All in-game descriptive prose remains straight-faced and serious.

## Windows compatibility fix

- Rebuilt `run_windows.bat` so a second Windows PC no longer needs to already have a working `py` command.
- The launcher now reuses an existing working `.venv`, looks for Python 3.13, and can use the official Python Install Manager when Python is missing.
- On supported Windows systems with WinGet, it can install the official Python manager automatically.
- Dependency installation is logged to `dong_windows_log.txt` instead of the launcher simply closing on an error.
- Added `diagnose_windows.bat` to generate `dong_windows_diagnostics.txt`.
- Added `reset_windows_setup.bat` to safely rebuild Dong's local Python environment without deleting the save.
- Added `WINDOWS_TROUBLESHOOTING.txt`.
- Gameplay and save format are unchanged from v0.17.6.


## New in v0.17.8

### Full visual overhaul

- Reworked the overall game frame into a cleaner dark charcoal/slate interface with warm brass accents.
- Added a proper current-location header instead of treating the location name like another generic label.
- Gave Day/Time, Season/Weather, HP, Stamina, and Cash distinct status treatments so they are easier to read at a glance.
- Reworked page headings into framed title banners with stronger hierarchy.
- Updated content cards with richer surfaces, softer contrast, and clearer separation between information and actions.
- Moved card action buttons to the lower-right so descriptions and actions no longer compete visually.
- Refined sidebar spacing, active states, utility links, and overall width.
- Improved progress bars, notices, scrollbars, and secondary headings.
- Redesigned the title screen to match the in-game visual language.
- Refreshed the New Game dialog to match the new interface.
- Preserved the v0.17.7 Windows compatibility launcher unchanged.
- No gameplay systems, balance, save schema, or world content were changed.


### Unified character sheet

- The Character sidebar link now opens the complete character sheet directly.
- Core status, home, current location, and equipped weapon appear at the top.
- Inventory and equipment now live on the same page, including Equip and Eat actions.
- Skills appear beneath inventory in a compact two-column grid.
- The separate Character hub, Inventory page, and Skills page have been removed from normal navigation.
- Inventory actions return to the same character sheet after use.
- No gameplay mechanics, save data, or progression values were changed.

### Visual refresh

- Refreshed the main in-game palette with a richer dark theme and subtle green accents.
- Improved card, panel, and sidebar contrast so the interface feels more alive while staying readable.
- Updated hover and active states for navigation and buttons.
- Refined status blocks, progress bars, and scrollbars to better match the new look.
- Updated the main menu to match the in-game presentation.
- No gameplay mechanics, saves, or world content were changed.

### Polished main interface

### Hover grid hub navigation

- Clicking Character, Life, Property, World, and Crime & Vice now opens a compact grid of text-only links instead of long full-width menu rows.
- Each hub item shows only its title by default.
- Hovering a hub item updates the helper text below the grid with that page's description.
- The same descriptions also appear as tooltips on hover.
- This keeps the hub pages much cleaner while still explaining what each destination does.

- Reworked the top bar into compact status blocks for Day/Time, Season/Weather, HP, Stamina, and Cash.
- Reduced the visual weight of the status bar while keeping all important information permanently visible.
- Switched the general interface to a cleaner sans-serif UI font, while status readouts retain a compact monospace treatment.
- Tightened sidebar width and navigation spacing.
- Improved content margins and vertical rhythm throughout the game.
- Simplified hub pages: Character, Life, Property, World, and Crime & Vice now use clean clickable text rows instead of a stack of boxed cards with OPEN buttons.
- Softened borders and card backgrounds across the main content area.
- Reduced button padding and visual weight while keeping gameplay actions clearly clickable.
- Added cleaner scrollbars to long pages.
- Updated the title screen to match the refined in-game interface.
- No gameplay mechanics, balancing, save data, or world content were changed.

### Compact navigation retained

- Permanent sidebar remains Location, Character, Life, Property, World, Crime & Vice, and Map.
- Subpages remain grouped under their parent hubs.
- Parent sidebar sections remain highlighted while viewing their subpages.
- Location-specific actions continue to open stores, jobs, clinics, casinos, residents, and other contextual pages directly.

### Seasons and weather
- Four 30-day seasons: Spring, Summer, Autumn, Winter.
- Weather changes by in-game day and region.
- The top status bar now shows the current season and weather.
- Harsh weather lowers hunting success and reduces wilderness-camp recovery.

### Hunting
- New Hunting skill.
- Buy a Hunting Rifle from general markets.
- Hunt at Blackwood Trail, Lake Mercy North Shore, and Pine Ridge.
- Hunting is resolved abstractly.
- Successful hunts can produce Game Meat, Small Hide, Hide, or Large Hide.
- Season, weather, and Hunting skill affect success.

### Wilderness survival
- New Survival skill.
- Buy a Camping Kit.
- Make camp in supported wilderness/backcountry locations.
- Camping advances six in-game hours and restores HP/stamina.
- Harsh weather reduces recovery.

### Boats
- Rowboat and Small Motorboat added as persistent owned vehicles.
- Boats have location, condition, cargo capacity, and in the motorboat's case, fuel.
- Boat travel works on Lake Mercy and Westhaven water routes.
- Lake Mercy Marina and Westhaven sell/service boats.

### Education
- New Education skill.
- Greybridge Community College offers certificate programs.
- Programs require tuition and multiple four-hour class sessions.
- Certificates: General Studies, Criminal Justice, Emergency Care, Automotive Mechanics, Small Business, Forestry, Mining Operations.
- Certificates persist permanently.

### Police/public-safety careers
- Police Constable — Millhaven County Police.
- Police Officer — Greybridge Police Department.
- Port Police Officer — Westhaven Port Police.
- These careers require the Criminal Justice certificate plus skill/reputation requirements.
- They use the same full-time 8-hour shift, promotion, reliability, and career-history systems as other careers.

### Courts
- Arrests now create persistent pending court cases.
- Court hearings can be attended in Millhaven or Greybridge City after release.
- Outcomes can include dismissal, additional fines, or recorded conviction.
- Speech skill can improve hearing outcomes.

### Children and school
- Young Child and Older Child household members can be enrolled in Millhaven Regional School.
- School enrollment and attendance persist.
- Attendance automatically advances across weekday in-game days.

### Pets
- Millhaven Animal Shelter added through the Outdoors screen.
- Adopt Dogs, Cats, or Rabbits.
- Name adopted pets.
- Pets have a persistent bond score.
- Spend focused time with a pet once per in-game day to improve bond and restore a small amount of stamina.

### Multiple properties
- The existing 100 real persistent plots are now directly purchasable.
- Own multiple plots at once.
- The Properties screen shows your portfolio and land currently for sale.
- Any owned plot can become your primary residence. If it has no shelter, a Basic Tent is established when you move there.
- This lets you move between owned plots, build on them using the existing property system, then move elsewhere without losing the first property.

### Rentals
- Developed secondary properties with a Wooden Shack or Small Cabin can be rented to NPC tenants.
- Rental properties generate weekly income automatically as in-game days pass.
- Track tenant, weekly rent, and lifetime rent from the Properties screen.
- End a tenancy at any time.

## Existing systems retained

v0.17 keeps all previous Dong systems: 100 persistent plots, homes, rooms, furniture, farming, livestock, horses, businesses, cooking, gathering, crafting, forging, fishing, exploration, Pokemon-style combat, NPC schedules, friendships, romance, marriage, intimacy, children, mail, crime, murder, jail, generic Drugs, alcohol, addiction, dealing operations, casinos, slot machine, blackjack, roulette, vehicles, fuel, repairs, cargo, regional travel, public transit, seven world regions, regional reputation, casual jobs, full-time careers, and save persistence.

## Save migration from v0.17.2

To keep your current character, copy:

`Dong_v0_17_2/data/game.db`

into:

`Dong_v0_17_3/data/game.db`

before launching v0.17.3. The save schema is unchanged from v0.17.2, so all character, property, buildings, family, relationships, crime, vice, career, vehicles, businesses, inventory, money, skills, education, courts, pets, rentals, and world state are preserved. Earlier v0.17 saves are also compatible.

## Running on Windows

Double-click `run_windows.bat`. The launcher creates the local Python environment and installs PySide6 if needed.

## Running on Linux

Run `./run_linux.sh` or create a Python environment manually, install `requirements.txt`, and run `python main.py`.


### New in v0.17.9

- Removed some of the darker boxed text styling for a cleaner look.
- Map now uses hoverable text titles in a grid, with travel actions shown for the selected destination.
- Vice information is now folded into the Character sheet.
- Crime opens directly from the sidebar.
- Vehicles and pets now live under the Home grouping.
- Removed the need for World and Outdoors as top-level navigation concepts.
- Renamed Your Property to Home in the interface.


### New in v0.17.10

- Reworked the interface from a desktop-dashboard look into a flatter RPG dossier style.
- Removed panel boxes around the top HUD, sidebar, and main content frame.
- Converted information cards into compact dossier rows with subtle dividers.
- Actionable rows use a restrained brass accent instead of large dark rectangles.
- Rebuilt the Character overview as a clean stat grid.
- Simplified the skill grid styling.
- Made the HUD read as one continuous status strip rather than individual boxes.
- Refined typography, spacing, sidebar branding, headings, progress bars, and notices.
- Preserved all v0.17.9 gameplay and Windows launcher compatibility.


### New in v0.17.11

- Removed borders and dark fills from informational text sections.
- Removed boxes from HUD status text.
- Removed box framing from the main content panel and sidebar.
- Informational entries are now plain text separated by subtle divider lines.
- Actual actions remain visibly boxed buttons so clickable controls still stand out.
- Flattened skill entries to match the rest of the character sheet.


## New in v0.17.12 — Torn-style Activity Directory

- Replaced the large destination map with a compact activity directory.
- Map now groups activities into Shops & Services, Work, Gathering & Outdoors, Crime & Vice, Combat, and Home & Property.
- Clicking an activity either opens it immediately or shows travel options for its physical location.
- Added Redwater Fight Club with repeatable supervised combat bouts.
- Added Blackstone Dungeon in Pine Ridge with repeatable creature encounters.
- Added new combat opponents for the Fight Club and Dungeon.
- Existing physical travel, vehicles, public transport, and location persistence are preserved.


## v0.17.13 — One City

- Dong is now presented as one massive city rather than a collection of separate towns.
- Existing internal location keys remain for save compatibility, but player-facing locations use standalone place names only.
- The activity directory no longer appends area names to entries.
- Clicking a destination immediately opens a travel popup.
- The popup shows walking time and offers any usable horse, bicycle, car, motorcycle, pickup truck, or other owned travel method currently with the player.
- Travel begins directly from the popup; no scrolling to the bottom of the Map page is required.
- Home/plot displays no longer show old regional area names.
- Existing saves are migrated so plot areas display simply as Dong.


## v0.17.14 — Character Life Sheet

- Career is now a full section of the Character sheet.
- Education is now a full section of the Character sheet.
- Family is now a full section of the Character sheet.
- Life now contains only People and Mail.
- Links elsewhere in the game that previously opened Career, Education, or Family now open Character and jump directly to the matching section.
- Career shifts, applications, resigning, promotions, employment history, college enrollment/classes, certificates, spouse information, children, and school enrollment remain usable from the Character sheet.
- Save format and gameplay data are unchanged.
